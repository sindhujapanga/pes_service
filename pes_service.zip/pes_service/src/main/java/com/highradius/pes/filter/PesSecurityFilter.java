package com.highradius.pes.filter;

import java.io.IOException;
import java.util.Base64;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.highradius.pes.model.Employee;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.util.JwtUtil;
import com.highradius.pes.util.PesPropertiesUtil;

@Component
public class PesSecurityFilter implements Filter {

	private static final Logger LOGGER = LogManager.getLogger(PesSecurityFilter.class);

	@Autowired
	JwtUtil jwtUtil;
	
	@Autowired
	PesPropertiesUtil propertiesUtil;
	
	@Autowired
	EmployeeRepository empRepo;

	private String enableApiRoleAccess = null;
	
	@Override
	public void init(FilterConfig filterconfig) throws ServletException {
	}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterchain)
			throws IOException, ServletException {

		HttpServletRequest httpRequest = (HttpServletRequest) request;

		if ("OPTIONS".equalsIgnoreCase(httpRequest.getMethod())) {
			String authHeader = httpRequest.getHeader("access-control-request-headers");
			if (authHeader.contains("authorization")) {
				filterchain.doFilter(request, response);
				return;
			}
		}

		String requestedUrl = httpRequest.getRequestURI();
		if ("/admin/refreshADAuthToken".equals(requestedUrl) || "/common/login".equals(requestedUrl) || "/common/adLogin".equals(requestedUrl)
				|| "/common/authValidate".equals(requestedUrl) || "/common/refreshAuth".equals(requestedUrl)) {
			filterchain.doFilter(request, response);
			return;
		}

		String authHeader = httpRequest.getHeader("authorization");
		String credentials = "";
		try {
			if (authHeader != null && authHeader.startsWith("Bearer ")) {
				
				if(enableApiRoleAccess == null) {
					enableApiRoleAccess = propertiesUtil.getPropertyByName("ENABLE_API_ROLE_ACCESS").getPropertyValue();
				}

				String encodedToken = authHeader.substring(7);
				byte[] decodedTokenArr = Base64.getDecoder().decode(encodedToken);
				credentials = new String(decodedTokenArr, "UTF-8");
				String credsArr[] = credentials.split("::emailTokenDelimiter::");
				String email = credsArr[0];
				String token = credsArr[1];

				Map<String, Object> empMap = jwtUtil.validateJwtToken(token, email, requestedUrl, enableApiRoleAccess);

				if ("/common/logout".equals(requestedUrl)) {
					request.setAttribute("token", token);
				}
				
				//Verify and filter user authorized API calls
				if (!ObjectUtils.isEmpty(empMap) && (Boolean) empMap.get("isAuthorized") == true) {
					LOGGER.info("SecurityFilter :: Logged in user is " + email);
					request.setAttribute("email", email);
					request.setAttribute("roleId", empMap.get("empRoleId"));
					request.setAttribute("pkId", empMap.get("empPkId"));
					filterchain.doFilter(request, response);
				} else {
					LOGGER.info("SecurityFilter :: Token validation failed");
				}
			} else {
				LOGGER.info("SecurityFilter Token validation failed - Header/Bearer not found");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void destroy() {
	}

}
