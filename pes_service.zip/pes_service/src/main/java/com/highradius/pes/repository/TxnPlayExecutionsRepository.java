package com.highradius.pes.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.TxnPlayExecutions;

/**
 * Repository class for TxnPlayExecutions pojo. Used for queries and crud
 * operations.
 * 
 *
 */
@Repository
public interface TxnPlayExecutionsRepository
		extends JpaRepository<TxnPlayExecutions, Long>, JpaSpecificationExecutor<TxnPlayExecutions> {

	// Query to get txnPlayExecutions by id
	@Query("Select t from TxnPlayExecutions t where t.id=?1")
	public TxnPlayExecutions getById(Long id);

	// Query to get txnPlayExecutions by name of prospect
	@Query("Select t from TxnPlayExecutions t where t.nameOfProspect=?1")
	public TxnPlayExecutions getByNameOfProspect(String name);

	// Query to get txnPlayExecutions by opportunity name
	@Query("Select t from TxnPlayExecutions t where t.opportunityName=?1")
	public TxnPlayExecutions getByOpportunityName(String name);

	// Query to get txnPlayExecutions by pesStatus
	@Query(value = "SELECT * FROM txn_play_executions where pes_status = :pesStatus and YEAR(created_date) = :year", nativeQuery = true)
	public List<TxnPlayExecutions> getByPesStatus(@Param("pesStatus") String pesStatus, @Param("year") String year);

	// Query to get txnPlayExecutions by sfdcStatus
	@Query("Select t from TxnPlayExecutions t where t.sfdcStatus=?1")
	public List<TxnPlayExecutions> getBysfdcStatus(String sfdcStatus);

	// Query to get txnPlayExecutions by assigned to pes agent
	@Query("Select t from TxnPlayExecutions t where t.assignedToPesAgent.id=?1")
	public TxnPlayExecutions getByAssignedAgentId(Long assignedToPesAgentId);

	// Query to get txnPlayExecutions by assigned to pes lead
	@Query("Select t from TxnPlayExecutions t where t.assignedByPesLead.id=?1")
	public TxnPlayExecutions getByAssigningPesLead(Long assignedByPesLeadId);

	// Query to get plays with distinct name of prospects
	// @Query("Select distinct t.nameOfProspect from TxnPlayExecutions t")
	@Query(value = "SELECT DISTINCT name_of_prospect FROM txn_play_executions", nativeQuery = true)
	public List<String> getDistinctNameOfProspects();

	// Query to get txns with activity Id
	@Query("Select t from TxnPlayExecutions t where t.activityId=?1")
	public List<TxnPlayExecutions> getByActivityId(String activityId);

	// Query to get txns with activity Id
	@Query("Select t from TxnPlayExecutions t where t.activityId=?1 and t.play.name=?2")
	public List<TxnPlayExecutions> getByActivityIdNPlayName(String activityId, String playName);

	// Query to get txnPlayExecutions scored in given dates
	@Query(value = "SELECT * FROM txn_play_executions WHERE pes_status = 'Completed' and created_date >= :startDate AND created_date <= :endDate", nativeQuery = true)
	public List<TxnPlayExecutions> getScoresBetweenDates(@Param("startDate") LocalDateTime startDate,
			@Param("endDate") LocalDateTime endDate);
	
	// Query to get txnPlayExecutions scored in given dates with status,playId and Start/end Date (Added for ExportPlaysData)
		@Query(value = "SELECT * FROM txn_play_executions WHERE pes_status in (:pesStatus) and play_id in (:playIds) and created_date >= :startDate AND created_date <= :endDate", nativeQuery = true)
		public List<TxnPlayExecutions> getAllScoresBetweenDates(@Param("startDate") LocalDate startDate,
				@Param("endDate") LocalDate endDate, @Param("pesStatus") List<String> pesStatus, List<String> playIds);

	
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE txn_play_executions SET pes_status = 'Completed', completed_on = NOW() WHERE pes_status = 'PUSH_TO_POD_LEAD' or pes_status = 'Push To POD Lead'", nativeQuery = true)
	public void updateStatusToCompleted();
	
	//Change status to completed for all plays except the plays in arguments
	@Transactional
	@Modifying
	@Query(value = "UPDATE txn_play_executions SET pes_status = 'Completed', completed_on = NOW() WHERE pes_status = 'Push To POD Lead' AND play_id NOT IN :monthlyPlays", nativeQuery = true)
	public void updateStatusToCompletedForWeeklyPlays(@Param("monthlyPlays") List<Long> monthylPlays);
	
	@Query("SELECT t FROM TxnPlayExecutions t WHERE t.id IN (:ids)")
	public List<TxnPlayExecutions> getByIds(@Param("ids")List<Long> ids);
	
	// Query to get txnPlayExecutions scored in given dates non completion
		@Query(value = "SELECT * FROM txn_play_executions WHERE created_date >= :startDate AND created_date <= :endDate "
				+ "AND pes_status IN ('Reviewed by PES','Push To POD Lead')", nativeQuery = true)
		public List<TxnPlayExecutions> getScoresBetweenDatesNonCompletedRecs(@Param("startDate") LocalDateTime startDate,
				@Param("endDate") LocalDateTime endDate);
		
	// Query to get txnPlayExecutions scored in given dates non completion
		@Query(value = "SELECT * FROM txn_play_executions WHERE created_date >= :startDate AND created_date <= :endDate "
				+ "AND pes_status ='Completed' AND play_id IN (:champion,:zztop)", nativeQuery = true)
		public List<TxnPlayExecutions> getScoresBetweenDatesChampionsAndZZTop(@Param("startDate") LocalDateTime startDate,
				@Param("endDate") LocalDateTime endDate, @Param("champion") Long championId, @Param("zztop") Long zztop);
		
		@Query("SELECT count(t) FROM TxnPlayExecutions t")
		public Integer getTotalRows();
		
		@Transactional
		@Modifying
		@Query("UPDATE TxnPlayExecutions t  SET t.isStarred = ?1 WHERE id =?2 ")
		public void toggleFavouriteForPlay(Boolean isStarred, Long rowId);
		
		@Query("SELECT DISTINCT t.activityId FROM TxnPlayExecutions t WHERE t.activityId IN (:ids) AND pesStatus != 'Completed' AND pesStatus !='Descoped'")
		public List<String> getByActivityIdsAndNotCompleted(@Param("ids")List<String> activityIds);
		
		@Query("SELECT t FROM TxnPlayExecutions t WHERE t.activityId IN (:ids) AND t.play.name = 'Discovery STRAP' AND pesStatus !='Descoped'")
		public List<TxnPlayExecutions> getDiscoveryPlaysByActivityIds(@Param("ids") List<String> activityIds);
		
		@Query("SELECT DISTINCT t FROM TxnPlayExecutions t WHERE t.activityId IN (:ids) AND t.play.name = 'OTC Whitespace Analysis - FA Stage' OR t.play.name = 'OTC Whitespace Analysis - GI Stage' OR t.play.name = 'OTC Whitespace Web Research' AND pesStatus !='Descoped'")
		public List<TxnPlayExecutions> getByActivityIdsPlays(@Param("ids") List<String> activityIds);

		@Query("SELECT DISTINCT t.activityId FROM TxnPlayExecutions t WHERE t.activityId IN (:ids) AND t.play.name = 'Demo' AND pesStatus != 'Completed' AND pesStatus !='Descoped'")
		public List<String> getNotCompletedByDemoPlay(@Param("ids") List<String> activityIds);

}
