package com.highradius.pes.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "lu_play")
/**
 * Model class for play pojo.Handles transactions for plays table.
 * Contains details for plays. Plays can be added and deleted.
 *
 */
public class Play implements Serializable{
	
	private static final long serialVersionUID = 101L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String description;
	
	@Column(name = "play_opera_link")
	private String playOperaLink;
	
	@Column(name = "doc_url_2")
	private String docUrl2;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_date")
	private Date updateDate;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Playbook.class)
    private Playbook playbook;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Department.class)
	private Department department;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = MapPlayRoles.class)
	@JoinColumn(name = "fk_play_id", referencedColumnName = "id")
    private List<MapPlayRoles> mapPlayRolesList;

	public Playbook getPlaybook() {
		return playbook;
	}

	public void setPlaybook(Playbook playbook) {
		this.playbook = playbook;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPlayOperaLink() {
		return playOperaLink;
	}

	public void setPlayOperaLink(String playOperaLink) {
		this.playOperaLink = playOperaLink;
	}

	public String getDocUrl2() {
		return docUrl2;
	}

	public void setDocUrl2(String docUrl2) {
		this.docUrl2 = docUrl2;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
    public List<MapPlayRoles> getMapPlayRolesList() {
		return mapPlayRolesList;
	}

	public void setMapPlayRolesList(List<MapPlayRoles> mapPlayRolesList) {
		this.mapPlayRolesList = mapPlayRolesList;
	}

	public Play() {
    	super();
    }

	@Override
	public String toString() {
		return "Play [id=" + id + ", name=" + name + ", description=" + description + ", playOperaLink=" + playOperaLink
				+ ", departmentId=" + department + ", docUrl2=" + docUrl2 + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updateDate=" + updateDate
				+ ", playbook=" + playbook + "]";
	}

	
    
}
