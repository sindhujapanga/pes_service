package com.highradius.pes.dto;

public class EmployeeSFDTO {
	
	private String sf18CharacterID;
	private String userId;
    private String firstName;
    private String lastName;
    private String fullName;
    private String podLeadName;
    private String podLead18CharId;
    private String profile;
    private String role;
    private String team;
    private String market;
    private String department;
    private String aeLead;
    private String spLead;
    private String email;
    private String alias;
    private String active;
    private String lastLogin;
	public String getSf18CharacterID() {
		return sf18CharacterID;
	}
	public void setSf18CharacterID(String sf18CharacterID) {
		this.sf18CharacterID = sf18CharacterID;
	}
	public String getUserId() {
		return userId;
	}
	
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getProfile() {
		return profile;
	}
	public String getPodLeadName() {
		return podLeadName;
	}
	public void setPodLeadName(String podLeadName) {
		this.podLeadName = podLeadName;
	}
	public String getPodLead18CharId() {
		return podLead18CharId;
	}
	public void setPodLead18CharId(String podLead18CharId) {
		this.podLead18CharId = podLead18CharId;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getAeLead() {
		return aeLead;
	}
	public void setAeLead(String aeLead) {
		this.aeLead = aeLead;
	}
	public String getSpLead() {
		return spLead;
	}
	public void setSpLead(String spLead) {
		this.spLead = spLead;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}
	@Override
	public String toString() {
		return "EmployeeSFDTO [sf18CharacterID=" + sf18CharacterID + ", userId=" + userId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", fullName=" + fullName + ", podLeadName=" + podLeadName
				+ ", podLead18CharId=" + podLead18CharId + ", profile=" + profile + ", role=" + role + ", team=" + team
				+ ", market=" + market + ", department=" + department + ", aeLead=" + aeLead + ", spLead=" + spLead
				+ ", email=" + email + ", alias=" + alias + ", active=" + active + ", lastLogin=" + lastLogin + "]";
	}
	
}
