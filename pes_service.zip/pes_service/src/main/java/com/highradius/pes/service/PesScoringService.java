package com.highradius.pes.service;


import org.json.simple.JSONObject;

import com.highradius.pes.dto.MovePlayDTO;
import com.highradius.pes.dto.PesStatusDTO;
import com.highradius.pes.dto.ScoringDTO;
import com.highradius.pes.dto.ScoringGridSearchDTO;
import com.highradius.pes.dto.ScoringSearchDTO;
import com.highradius.pes.dto.ScoringSearchResultsDTO;
import com.highradius.pes.dto.PlayStatusDTO;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.util.GenericResult;

public interface PesScoringService {
	
	public GenericResult assignPlayExecForScoring(ScoringDTO scoringDto);
	
	public GenericResult searchPlayExecutions(ScoringSearchDTO scoringSearchDto, JSONObject pageOptions, ScoringGridSearchDTO scoringGridSearchDTO);
	
	public GenericResult addDummyEntries(ScoringDTO scoringDto);
	
	public GenericResult getPlayExecutions(Long id);
	
    public GenericResult updatePlayExecutions(ScoringDTO scoringDto);
    
    public boolean assignForScoring(PesStatusDTO statusDto);
    
    public boolean assignForReview(PesStatusDTO statusDto);
    
    public String pushToPodLead(PesStatusDTO statusDto);
    
    public void processDiscoveryCallRecords(String reportName, String usermail, String startDate, String endDate);
    
    public void processSalesPipelineOTCWhiteSpaceRecords(String usermail,String startDate, String endDate);
    
    public void processWebResearchOTCRecords(String usermail, String startDate, String endDate);

    public void processCPRSIHRecords(String usermail, String startDate, String endDate);

	public void updateStatusToCompleted();
	
	public boolean movePlays(MovePlayDTO movePlayDto);
	
	public void processChampionsnZZTop(String usermail);
	
	public void processSTRAPRecords(String usermail, String startDate, String endDate);
	
	public void processDemoPlay(String usermail, String startDate, String endDate);

	public GenericResult toggleFavouriteForPlay(Boolean isStarred, Long rowId);

	public void saveReportData(String reportName, String userMail, String startDate, String endDate);
}
