package com.highradius.pes.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.highradius.pes.dto.ChampionsnZZTopDTO;
import com.highradius.pes.dto.MovePlayDTO;
import com.highradius.pes.dto.PesStatusDTO;
import com.highradius.pes.dto.STRAP_DTO;
import com.highradius.pes.dto.ScoringDTO;
import com.highradius.pes.dto.ScoringGridSearchDTO;
import com.highradius.pes.dto.ScoringSearchDTO;
import com.highradius.pes.dto.PlayStatusDTO;
import com.highradius.pes.model.PesSchedulerExecHistory;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;
import com.highradius.pes.scheduler.PesSalesForceScheduler;
import com.highradius.pes.service.PesReportService;
import com.highradius.pes.service.PesSalesForceService;
import com.highradius.pes.service.PesScoringService;
import com.highradius.pes.util.DataMigrationUtil;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.PesGsheetUtil;
import com.highradius.pes.util.PesConstants;

@RestController
@CrossOrigin(origins = { "http://localhost:3000", "https://pestest.highradius.com",
		"https://pestest-sb.highradius.com", "https://pes.highradius.com","https://pes-sb.highradius.com" })
@RequestMapping(value = "/pesScoring")
public class PesScoringController {

	@Autowired
	TxnPlayExecutionsRepository txnRepo;

	@Autowired
	PesScoringService pesScoringService;

	@Autowired
	PesSalesForceService pesSalesForceService;

	@Autowired
	PesSalesForceScheduler pesSalesForceScheduler;
	
	@Autowired
	PesReportService reportService;
	
	@Autowired
	DataMigrationUtil migrationUtil;

	private static final Logger LOGGER = LogManager.getLogger(PesScoringController.class);

	/**
	 * Initial function to add plays manually in the system
	 * @param scoringDto
	 * @return
	 */
	@PostMapping(value = "/assign")
	public GenericResult assignPlayExecForScoring(@RequestBody ScoringDTO scoringDto) {
		LOGGER.info("PesScoringController.assignPlayExecForScoring() : ScoringDTO = " + scoringDto.toString());
		GenericResult result = pesScoringService.assignPlayExecForScoring(scoringDto);
		LOGGER.info("PesScoringController.assignPlayExecForScoring() : END");
		return result;
	}

	/**
	 * Sends back filtered records depending upon a set of fields in the scoringSearchDto
	 * @param scoringSearchDto
	 * @return
	 */
	@PostMapping(value = "/search")
	public GenericResult searchPlayExecutions(@RequestBody HashMap<String, JSONObject> searchConfig) throws JsonMappingException, JsonProcessingException {
		JSONObject pageOptions =  searchConfig.get("options");
		ObjectMapper objectMapper = new ObjectMapper();
		ScoringSearchDTO scoringSearchDto = objectMapper.readValue(searchConfig.get("parameters").toString(), ScoringSearchDTO.class);
		ScoringGridSearchDTO scoringGridSearchDTO = objectMapper.readValue(searchConfig.get("filterParameters").toString(), ScoringGridSearchDTO.class);
		try {
			LOGGER.info("PesScoringController.searchPlayExecutions() : ScoringSearchDTO = " + scoringSearchDto.toString());
			GenericResult searchResult = pesScoringService.searchPlayExecutions(scoringSearchDto, pageOptions, scoringGridSearchDTO);
			return searchResult;
		}
		catch(Exception e) {
			LOGGER.error("PesScoringController.searchPlayExecutions() : ScoringSearchDTO : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets the particular record from the id
	 * @param id
	 * @return
	 */
	@PostMapping(value = "/getPlayExc")
	public GenericResult getPlayExecForScoringById(@RequestBody Long id) {
		LOGGER.info("PesScoringController.getPlayExecForScoringById : Play Id = " + id);
		GenericResult result = pesScoringService.getPlayExecutions(id);
		LOGGER.info("PesScoringController.updatePlayExecForScoring : END");
		return result;
	}

	/**
	 * Updates a record present in the system
	 * @param scoringDto
	 * @return
	 */
	@PostMapping(value = "/update")
	public GenericResult updatePlayExecForScoring(@RequestBody ScoringDTO scoringDto) {
		LOGGER.info("PesScoringController.updatePlayExecForScoring : ScoringDTO = " + scoringDto);
		GenericResult result = pesScoringService.updatePlayExecutions(scoringDto);
		LOGGER.info("PesScoringController.updatePlayExecForScoring : END");
		return result;
	}
	
	// Favourite/ UnFavourite a Play
	@PostMapping(value ="/toggleFavouriteForPlay")
	public GenericResult toggleFavouriteForPlay(@RequestBody JSONObject favouriteConfig) throws JsonMappingException, JsonProcessingException {
		boolean isStarred =  (boolean) favouriteConfig.get("isStarred");
		Long rowId =   Long.parseLong(favouriteConfig.get("rowId").toString());
		GenericResult result = pesScoringService.toggleFavouriteForPlay(isStarred, rowId);
		return result;
	}

	/**
	 * assigns records for scoring to pes scores in bulk
	 * @param statusDto
	 * @return
	 */
	@PostMapping(value = "/assignForScoring")
	public GenericResult assignForScoring(@RequestBody PesStatusDTO statusDto) {
		LOGGER.info("PesScoringController.assignForScoring() : START");
		GenericResult result = new GenericResult();
		boolean changeResult = pesScoringService.assignForScoring(statusDto);
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for scoring");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.assignForScoring() : END");
		return result;
	}

	/**
	 * assigns records for review to supervisors in bulk
	 * @param statusDto
	 * @return
	 */
	@PostMapping(value = "/assignForReview")
	public GenericResult assignForReview(@RequestBody PesStatusDTO statusDto) {
		LOGGER.info("PesScoringController.assignForReview() : START");
		GenericResult result = new GenericResult();
		boolean changeResult = pesScoringService.assignForReview(statusDto);
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for review");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.assignForReview() : END");
		return result;
	}

	/**
	 * pushes records in bulk to pod leads. Splits records with multiple sellers. 
	 * @param statusDto
	 * @return
	 */
	@PostMapping(value = "/pushToPodLead")
    public GenericResult pushToPodLead(@RequestBody PesStatusDTO statusDto) {
        LOGGER.info("PesScoringController.pushToPodLead() : START");
        GenericResult result = new GenericResult();
        //Validate Push to Pod Lead based on the result
        String changeResult = pesScoringService.pushToPodLead(statusDto);
        if (changeResult.equalsIgnoreCase("false")) {
            result.setSuccess(PesConstants.FALSE);
            result.setStatus(PesConstants.FAIL);
            result.setMessage("Unable to assign to pod lead");
        } else if(changeResult.equalsIgnoreCase("true")){
            result.setSuccess(PesConstants.TRUE);
            result.setData(true);
            result.setMessage("Operation Successful");
        }
        else if(changeResult.equalsIgnoreCase("insufficient data")){
            result.setSuccess(PesConstants.TRUE);
            result.setData("PARTIAL");
            result.setMessage("Operation Partially Successful");
        }
        else if(changeResult.equalsIgnoreCase("all Invalid")){
            result.setSuccess(PesConstants.TRUE);
            result.setData("ALLINVALID");
            result.setMessage("Operation Failed Because of All Invalid records");
        }
            
        LOGGER.info("PesScoringController.pushToPodLead() : END");
        return result;
    }

	/* Call for report fetch for Discovery Call
	 * JSONObject = {
	 *                name : Report Name( Enterprise EMEA, Enterprise NA, etc),
	 *                startDate : startDate to fetch from,
	 *                endDate : endDate to fetch to,
	 *                user: current user mail id
	 *              }
	 */
	@PostMapping(value = "/dcSfReport")
	public GenericResult checkDCSFIntegration(@RequestBody JSONObject Report) {
		String reportName = (String) Report.get("name");
		String startDate = (String) Report.get("startDate");
		String endDate = (String) Report.get("endDate");
		GenericResult result = new GenericResult();
		LOGGER.info("PesScoringController.checkSFIntegration() : START : Report Name : " + reportName);
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual:processDCSF Report : " + reportName, "Initiated");
			pesScoringService.processDiscoveryCallRecords(reportName, (String) Report.get("user"),startDate,endDate);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual:processDCSF Report: " + reportName + ": Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started");
		LOGGER.info("PesScoringController.checkSFIntegration() : END");
		return result;
	}

    /*
     * Call for report fetch for OTC
     * JSON Object = {
     *                 user : current user mail id,
     *                 startDate : startDate of fetch,
     *                 endDate : endDate of report fetch
     *               }
     */
	@PostMapping(value = "/otcSPReport")
	public GenericResult checkOTCSFIntegration(@RequestBody JSONObject Report) {
		LOGGER.info("PesScoringController.checkSFIntegration() : START");
		GenericResult result = new GenericResult();
		String user = (String) Report.get("user");
		String startDate = (String) Report.get("startDate");
		String endDate = (String) Report.get("endDate");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual: processSalesPipelineOTCWhiteSpaceRecords", "Initiated");
			pesScoringService.processSalesPipelineOTCWhiteSpaceRecords(user,startDate,endDate);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual: processSalesPipelineOTCWhiteSpaceRecords: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started");
		LOGGER.info("PesScoringController.checkSFIntegration() : END");
		return result;
	}

	 /*
     * Call for report fetch for OTC Web Research
     * JSON Object = {
     *                 user : current user mail id,
     *                 startDate : startDate of fetch,
     *                 endDate : endDate of report fetch
     *               }
     */
	@PostMapping(value = "/otcDCReport")
	public GenericResult checkOTCWebResearchIntegration(@RequestBody JSONObject Report) {
		LOGGER.info("PesScoringController.checkOTCWebResearchIntegration() : START");
		String user = (String) Report.get("user");
		String startDate = (String) Report.get("startDate");
		String endDate = (String) Report.get("endDate");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual: checkOTCWebResearchIntegration", "Initiated");
			pesScoringService.processWebResearchOTCRecords(user, startDate, endDate);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual: checkOTCWebResearchIntegration: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		GenericResult result = new GenericResult();
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started.");
		LOGGER.info("PesScoringController.checkSFIntegration() : END");
		return result;

	}
	
	 /*
     * Call for report fetch for CPR SIH plays gsheet data
     * JSON Object = {
     *                 user : current user mail id,
     *                 startDate : startDate of fetch,
     *                 endDate : endDate of report fetch
     *               }
     */
	@PostMapping(value = "/cprSihReport")
	public GenericResult checkCPRSIHIntegration(@RequestBody JSONObject Report) {
		LOGGER.info("PesScoringController.checkCPRSIHIntegration() : START");
		String user = (String) Report.get("user");
		String startDate = (String) Report.get("startDate");
		String endDate = (String) Report.get("endDate");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual: checkCPRSIHIntegration", "Initiated");
			pesScoringService.processCPRSIHRecords(user, startDate, endDate);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual: checkCPRSIHIntegration: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		GenericResult result = new GenericResult();
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started.");
		LOGGER.info("PesScoringController.checkCPRSIHIntegration() : END");
		return result;

	}
	
	 /*
     * Call for report fetch for Champions n ZZTop
     * JSON Object = {
     *                 user : current user mail id,
     *                 startDate : startDate of fetch,
     *                 endDate : endDate of report fetch
     *               }
     */
	@PostMapping(value = "/championsnZZTop")
	public GenericResult checkChampionsnZZTopIntegration(@RequestBody JSONObject Report) {
		LOGGER.info("PesScoringController.checkchampionsnZZTopIntegration() : START");
		String user = (String) Report.get("user");
		List<ChampionsnZZTopDTO> data = null;
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual: checkhampionsnZZTopIntegration", "Initiated");
			pesScoringService.processChampionsnZZTop(user);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual: checkChampionsnZZTopIntegration: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		GenericResult result = new GenericResult();
		result.setSuccess(PesConstants.TRUE);
		result.setData("true");
		result.setMessage("Operation Started.");
		LOGGER.info("PesScoringController.checkChampionnZZTopIntegration() : END");
		return result;
	}
	
	/*
     * Call for report fetch for STRAP
     * JSON Object = {
     *                 user : current user mail id,
     *                 startDate : startDate of fetch,
     *                 endDate : endDate of report fetch
     *               }
     */
	@PostMapping(value = "/strap")
	public GenericResult checkSTRAP(@RequestBody JSONObject Report) {
		LOGGER.info("PesScoringController.checkSTRAPIntegration() : START");
		String user = (String) Report.get("user");
		String startDate = (String) Report.get("startDate");
		String endDate = (String) Report.get("endDate");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual: checkSTRAPIntegration", "Initiated");
			pesScoringService.processSTRAPRecords(user,startDate,endDate);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual: checkSTRAPIntegration: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		GenericResult result = new GenericResult();
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started.");
		LOGGER.info("PesScoringController.checkSTRAPIntegration() : END");
		return result;
	}
	
	/*
     * Call for report fetch for Demo
     * JSON Object = {
     *                 user : current user mail id,
     *                 startDate : startDate of fetch,
     *                 endDate : endDate of report fetch
     *               }
     */
	@PostMapping(value = "/demo")
	public GenericResult checkDEMO(@RequestBody JSONObject Report) {
		LOGGER.info("PesScoringController.checkDEMO() : START");
		String user = (String) Report.get("user");
		String startDate = (String) Report.get("startDate");
		String endDate = (String) Report.get("endDate");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual: checkDEMOIntegration", "Initiated");
			pesScoringService.processDemoPlay(user,startDate,endDate);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual: checkDEMOIntegration: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		GenericResult result = new GenericResult();
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started.");
		LOGGER.info("PesScoringController.checkDEMOIntegration() : END");
		return result;
	}
	
	/**
	 * updates all Push To PodLead records to Completed on Friday
	 * @throws Exception
	 */
	@PostMapping(value = "/status/completed")
	public void updateStatusToCompleted() throws Exception{
		LOGGER.info("PesComonController.updateStatusToCompleted() : Updating completed records status to Complete");
		pesScoringService.updateStatusToCompleted();
	}
	
	//moves created date for play, obj = {[idList],movedate,user}
	@PostMapping(value = "/movePlays")
	public GenericResult movePlays(@RequestBody MovePlayDTO moveObj) {
		LOGGER.info("PesScoringController.moveCreatedDate() : START : ");
		GenericResult result = new GenericResult();
		boolean changeResult = pesScoringService.movePlays(moveObj);
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for review");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.moveCreatedDate() : END");
		return result;
	}
	
	//Not important, migration related code
	@GetMapping(value = "/migrationDCSTRAP")
	public GenericResult migrationDCSTRAP() {
		LOGGER.info("PesScoringController.migrationDCSTRAP() : START : ");
		GenericResult result = new GenericResult();
		boolean changeResult = migrationUtil.processDCSTRAPRecords();
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for review");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.migrationDCSTRAP() : END");
		return result;
	} 
	
	//Not important, migration related code
	@GetMapping(value = "/migrationDCExecCall")
	public GenericResult migrationDCExecCall() {
		LOGGER.info("PesScoringController.migrationDCExecCall() : START : ");
		GenericResult result = new GenericResult();
		boolean changeResult = migrationUtil.processDCExecCallRecords();
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for review");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.migrationDCExecCall() : END");
		return result;
	} 
	
	//Not important, migration related code
	@GetMapping(value = "/migrationOTC")
	public GenericResult migrationOTC() {
		LOGGER.info("PesScoringController.migrationOTC() : START : ");
		GenericResult result = new GenericResult();
		boolean changeResult = migrationUtil.processOTCRecords();
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for review");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.migrationOTC() : END");
		return result;
	} 
	
	//Not important, migration related code
	@GetMapping(value = "/migrationCPR")
	public GenericResult migrationCPR() {
		LOGGER.info("PesScoringController.migrationCPR() : START : ");
		GenericResult result = new GenericResult();
		boolean changeResult = migrationUtil.processCPRRecords();
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for review");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.migrationCPR() : END");
		return result;
	} 
	
	//Not important, migration related code
	@GetMapping(value = "/migrationSIH")
	public GenericResult migrationSIH() {
		LOGGER.info("PesScoringController.migrationSIH() : START : ");
		GenericResult result = new GenericResult();
		boolean changeResult = migrationUtil.processSIHRecords();
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to assign for review");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesScoringController.migrationSIH() : END");
		return result;
	} 


	//To Create Dummy entries from user input data
	@PostMapping(value = "/addDumyEntries")
	public GenericResult addDummyEntries(@RequestBody ScoringDTO scoringDto) {
		LOGGER.info("PesScoringController.addDummyEntries() : ScoringDTO = " + scoringDto.toString());
		GenericResult result = pesScoringService.addDummyEntries(scoringDto);
		LOGGER.info("PesScoringController.addDummyEntries() : END");
		return result;
	}
	
	@PostMapping(value = "/dcMidMarketReport")
	public GenericResult checkSFDCIntegration(@RequestBody JSONObject Report) {
		String reportName = (String) Report.get("name");
		String startDate = (String) Report.get("startDate");
		String endDate = (String) Report.get("endDate");
		GenericResult result = new GenericResult();
		LOGGER.info("PesScoringController.checkSFIntegration() : START : Report Name : " + reportName);
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual:processDCSF Report : " + reportName, "Initiated");
			pesScoringService.saveReportData(reportName, (String) Report.get("user"),startDate,endDate);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual:processDCSF Report: " + reportName + ": Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started");
		LOGGER.info("PesScoringController.checkSFIntegration() : END");
		return result;
	}
}
