package com.highradius.pes.dto;

public class MarketPlayWeightageDTO {
	private String id;
	
	private String marketId;
	
	private String teamId;
	
	private String playId;
	
	private String roleId;
	
	private String weightage;
	
	private String createdBy;
	
	private String updatedBy;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMarketId() {
		return marketId;
	}

	public void setMarketId(String marketId) {
		this.marketId = marketId;
	}

	public String getTeamId() {
		return teamId;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}

	public String getPlayId() {
		return playId;
	}

	public void setPlayId(String playId) {
		this.playId = playId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getWeightage() {
		return weightage;
	}

	public void setWeightage(String weightage) {
		this.weightage = weightage;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "MarketPlayWeightageDTO [id=" + id + ", marketId=" + marketId + ", teamId=" + teamId + ", playId="
				+ playId + ", roleId=" + roleId + ", weightage=" + weightage + ", createdBy=" + createdBy
				+ ", updatedBy=" + updatedBy + "]";
	}

	
}
