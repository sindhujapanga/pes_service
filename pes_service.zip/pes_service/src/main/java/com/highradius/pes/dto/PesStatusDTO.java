package com.highradius.pes.dto;

import java.util.Arrays;

public class PesStatusDTO {
	
	private String[] ids;
	
	private String employeeId;
	
	private String loginUserId;

	public String[] getIds() {
		return ids;
	}

	public void setIds(String[] ids) {
		this.ids = ids;
	}
	
	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	public String getLoginUserId() {
		return loginUserId;
	}

	public void setLoginUserId(String loginUserId) {
		this.loginUserId = loginUserId;
	}

	@Override
	public String toString() {
		return "PesStatusDTO [ids=" + Arrays.toString(ids) + ", employeeId=" + employeeId + ", loginUserId="
				+ loginUserId + "]";
	}
}
