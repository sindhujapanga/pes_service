package com.highradius.pes.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="txn_play_execution_data")
/**
 * Model class for transactionPlayExecutionData pojo.Handles transactions for transactionPlayExecutionData table.
 * Stores data for each playExecution transaction data.
 *
 */
public class TxnPlayExecutionData implements Serializable {
	
	public static final long serialVersionUID = 18L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "txn_play_execution_id")
	private Long txnPlayExecutionId;
	
	@Column(name = "field_id")
	private Long fieldId;
	
	@Column(name = "value")
	private String value;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_date")
	private Date updatedDate;
	
//	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Field.class)
//	private Field field;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTxnPlayExecutionId() {
		return txnPlayExecutionId;
	}

	public void setTxnPlayExecutionId(Long txnPlayExecutionId) {
		this.txnPlayExecutionId = txnPlayExecutionId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

//	public Field getField() {
//		return field;
//	}
//
//	public void setField(Field field) {
//		this.field = field;
//	}
	
	public Long getFieldId() {
		return fieldId;
	}

	public void setFieldId(Long fieldId) {
		this.fieldId = fieldId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	public void copy(TxnPlayExecutionData txnData){
		    this.setFieldId(txnData.getFieldId());
			this.setValue(txnData.getValue());
			}

	@Override
	public String toString() {
		return "TxnPlayExecutionData [id=" + id + ", txnPlayExecutionId=" + txnPlayExecutionId + ", fieldId=" + fieldId
				+ ", value=" + value + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy="
				+ updatedBy + ", updatedDate=" + updatedDate + "]";
	}
	
	
}
