package com.highradius.pes.util;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.highradius.pes.model.PesProperties;
import com.highradius.pes.repository.PesPropertiesRepository;

@Component
@Transactional
/**
 * Util class for setting and getting properties values.
 * 
 *
 */
public class PesPropertiesUtil {
	
	@Autowired
	PesPropertiesRepository propertiesRepo;
	
	public PesProperties getPropertyByName(String name) {
		PesProperties prop = propertiesRepo.getPropertyByName(name);
		return prop;
	}
	
	public void clearPropertyByName(String name) {
		
	}
	
	public PesProperties setProperty(String propertyName, String description, String propertyValue) {
		PesProperties newProperty = new PesProperties();
		newProperty.setPropertyName(propertyName);
		newProperty.setDescription(description);
		newProperty.setPropertyValue(propertyValue);
		return propertiesRepo.save(newProperty);
	}

}
