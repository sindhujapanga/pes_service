package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Department;

@Repository
/**
 * Repository class for Department pojo. Used for queries and crud operations.
 * @author subhayan.mukherjee
 *
 */
public interface DepartmentRepository extends JpaRepository<Department, Long>{
    
	
	//Query to get by id
	@Query("Select d from Department d where d.id=?1")
	public Department getById(Long id);
	
	//Query to get by department name
	@Query("Select d from Department d where d.name=?1")
	public Department findByName(String name);
	
	//Query to delete department by Id
    @Query("Delete from Department d where d.id=?1")
	public void deleteById(Long Id);
}
