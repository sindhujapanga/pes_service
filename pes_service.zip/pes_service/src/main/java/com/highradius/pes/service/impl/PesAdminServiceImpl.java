package com.highradius.pes.service.impl;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.highradius.pes.dto.EmployeeDTO;
import com.highradius.pes.dto.EmployeeSearchDTO;
import com.highradius.pes.dto.EmployeeSearchResultDTO;
import com.highradius.pes.dto.HistoryDTO;
import com.highradius.pes.dto.HistorySearchDTO;
import com.highradius.pes.dto.HistorySearchResultDTO;
import com.highradius.pes.dto.MapPlayMarketWeightageSearchResultDTO;
import com.highradius.pes.dto.MarketPlayWeightageDTO;
import com.highradius.pes.dto.MarketPlayWeightageSearchDTO;
import com.highradius.pes.dto.PlaysSearchDTO;
import com.highradius.pes.model.Department;
import com.highradius.pes.model.Designation;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.FieldType;
import com.highradius.pes.model.FunctionalRole;
import com.highradius.pes.model.MapFieldOptions;
import com.highradius.pes.model.MapPlayFields;
import com.highradius.pes.model.MapPlayMarketWeightage;
import com.highradius.pes.model.MapPlayRoles;
import com.highradius.pes.model.Market;
import com.highradius.pes.model.PesAuditHistory;
import com.highradius.pes.model.Play;
import com.highradius.pes.model.Playbook;
import com.highradius.pes.model.Reports;
import com.highradius.pes.model.SecurityRole;
import com.highradius.pes.model.Team;
import com.highradius.pes.repository.DepartmentRepository;
import com.highradius.pes.repository.DesignationRepository;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FieldRepository;
import com.highradius.pes.repository.FieldTypeRepository;
import com.highradius.pes.repository.FunctionalRoleRepository;
import com.highradius.pes.repository.MapFieldOptionsRepository;
import com.highradius.pes.repository.MapPlayFieldsRepository;
import com.highradius.pes.repository.MapPlayMarketWeightageRepository;
import com.highradius.pes.repository.MapPlayRolesRepository;
import com.highradius.pes.repository.MarketRepository;
import com.highradius.pes.repository.PesAuditHistoryRepository;
import com.highradius.pes.repository.PlayRepository;
import com.highradius.pes.repository.PlaybookRepository;
import com.highradius.pes.repository.ReportRepository;
import com.highradius.pes.repository.SecurityRoleRepository;
import com.highradius.pes.repository.TeamRepository;
import com.highradius.pes.service.PesAdminService;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.PesConstants;

@Service
@Transactional
public class PesAdminServiceImpl implements PesAdminService {
	private static final Logger LOGGER = LogManager.getLogger(PesAdminServiceImpl.class);

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	FunctionalRoleRepository functionalRoleRepository;

	@Autowired
	SecurityRoleRepository securityRoleRepository;

	@Autowired
	MarketRepository marketRepository;

	@Autowired
	TeamRepository teamRepository;

	@Autowired
	MapPlayMarketWeightageRepository mapPlayMarketWeightageRepository;

	@Autowired
	DesignationRepository designationRepository;

	@Autowired
	DepartmentRepository departmentRepository;

	@Autowired
	PesAuditHistoryRepository pesAuditHistoryRepository;

	@Autowired
	PlayRepository playRepository;

	@Autowired
	FieldRepository fieldRepository;

	@Autowired
	MapFieldOptionsRepository mapFieldOptionsRepository;

	@Autowired
	FieldTypeRepository fieldTypeRepository;

	@Autowired
	PlaybookRepository playbookRepository;

	@Autowired
	MapPlayFieldsRepository mapPlayFieldsRepository;
	
	@Autowired
	MapPlayRolesRepository playRoleRepo;
	
	@Autowired
	ReportRepository reportsRepo;

	/**
	 * Function to add employees
	 */
	@Override
	public GenericResult addEmployee(EmployeeDTO empDto) {
		LOGGER.info("PesAdminServiceImpl.addEmployee(): START:");
		try {
			GenericResult result = new GenericResult();
			Employee employee = employeeRepository.findByEmailId(empDto.getEmail());
			if(employee != null) {
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.SUCCESS);
				result.setMessage("Operation Successfull");
				return result;
			}
			else {
				employee = new Employee();
			}
			String firstName = empDto.getFirstName().trim();
			String lastName = empDto.getLastName().trim();
			employee.setSf18CharId(empDto.getSf18CharId());
			employee.setSfUserId(empDto.getSfUserId());
			employee.setEmpId(Long.parseLong(empDto.getEmpId()));
			employee.setAlias(empDto.getAlias());
			employee.setFirstName(firstName);
			employee.setLastName(lastName);
			employee.setFullName(firstName + " " + lastName);
			FunctionalRole fnRole = functionalRoleRepository.getById(Long.parseLong(empDto.getFnRoleId()));
			employee.setFnRole(fnRole);
			if (!StringUtils.isEmpty(empDto.getSecurityRoleId())) {
				employee.setSecurityRoleId(Long.parseLong(empDto.getSecurityRoleId()));
			}
			if (!StringUtils.isEmpty(empDto.getPodLeadId())) {
				employee.setPodLeadId(Long.parseLong(empDto.getPodLeadId()));
			}
			employee.setTeamId(Long.parseLong(empDto.getTeamId()));
			employee.setMarketId(Long.parseLong(empDto.getMarketId()));
			employee.setProfileName(empDto.getProfileName());
			employee.setEmail(empDto.getEmail());
			employee.setStatus("Active");
			employee.setCreatedBy(empDto.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();
			employee.setCreatedDate(currDate);
			
			employeeRepository.save(employee);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.addEmployee(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.addEmployee: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add employee");
			return result;
		}
	}

	/*
	 * Function to save History
	 */
	@Override
	public GenericResult saveHistory(HistoryDTO historyDto) {
		LOGGER.info("PesAdminServiceImpl.saveHistory(): START:");
		try {
			PesAuditHistory audit = new PesAuditHistory();
			audit.setInputData(historyDto.getInputData().toJSONString());
			audit.setAction(historyDto.getAction());
			audit.setFnRole(historyDto.getFnRole());
			audit.setEmail(historyDto.getEmail());
			audit.setUserName(historyDto.getUserName());
			audit.setPlayName(historyDto.getPlayName());
			audit.setNameOfProspect(historyDto.getNameOfProspect());
			Calendar cal = Calendar.getInstance();
			cal.setTimeZone(TimeZone.getTimeZone("IST"));
			java.util.Date currDate = cal.getTime();
			Timestamp currDateTime = new java.sql.Timestamp(currDate.getTime());
			audit.setCreatedDate(currDate);
			audit.setDate(currDateTime);
			audit.setCreatedBy(historyDto.getUserName());
			GenericResult result = new GenericResult();
			pesAuditHistoryRepository.save(audit);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.saveHistory(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.saveHistory: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to save history");
			return result;
		}
	}

	/*
	 * Function to update the employees
	 */
	@Override
	public GenericResult updateEmployee(EmployeeDTO empDto) {
		LOGGER.info("PesAdminServiceImpl.updateEmployee(): START:");
		try {
			Employee employee = employeeRepository.getById(Long.parseLong(empDto.getId()));
			FunctionalRole fnRole = functionalRoleRepository.getById(Long.parseLong(empDto.getFnRoleId()));
			employee.setFnRole(fnRole);
			if (!StringUtils.isEmpty(empDto.getSecurityRoleId())) {
				employee.setSecurityRoleId(Long.parseLong(empDto.getSecurityRoleId()));
			}
			if (!StringUtils.isEmpty(empDto.getPodLeadId())) {
				employee.setPodLeadId(Long.parseLong(empDto.getPodLeadId()));
			}
			employee.setTeamId(Long.parseLong(empDto.getTeamId()));
			employee.setMarketId(Long.parseLong(empDto.getMarketId()));
			employee.setProfileName(empDto.getProfileName());
			employee.setUpdatedBy(empDto.getUpdatedBy());
			if(!StringUtils.isEmpty(empDto.getEmpId()))
					employee.setEmpId(Long.parseLong(empDto.getEmpId()));
			Calendar cal = Calendar.getInstance();
			java.util.Date updateDate = cal.getTime();
			employee.setUpdatedDate(updateDate);
			GenericResult result = new GenericResult();
			employeeRepository.save(employee);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.updateEmployee(): Employee with empId: " + empDto.getEmpId() + " saved ");
			LOGGER.info("PesAdminServiceImpl.updateEmployee(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.updateEmployee() : " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to update employee with emp id :" + empDto.getEmpId());
			return result;
		}
	}

	// Fetching employee names lookup
	@Override
	public List<Map<String, String>> getEmployeeNames() {
		LOGGER.info("PesAdminServiceImpl.getEmployeeNames(): START");
		List<Employee> namesEmpList = employeeRepository.getAllDistinctEmployeeNames();
		List<Map<String, String>> list = new ArrayList<>();
		for (Employee nameEmp : namesEmpList) {
			Map<String, String> map = new HashMap<>();
			map.put("id", nameEmp.getId() + "");
			String Alias = "";
			if (!StringUtils.isEmpty(nameEmp.getAlias()))
				Alias = Alias + "(" + nameEmp.getAlias() + ")";
			map.put("displayName", nameEmp.getFullName() + " - " + Alias);
			list.add(map);
		}
		Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
			public int compare(Map<String, String> m1, Map<String, String> m2) {
				return m1.get("displayName").compareTo(m2.get("displayName"));
			}
		};
		Collections.sort(list, mapComparator);
		LOGGER.info("PesAdminServiceImpl.getEmployeeNames(): END");
		return list;
	}

	// Fetching functional roles lookup
	@Override
	public List<Map<String, String>> getFunctionalRoles() {
		LOGGER.info("PesAdminServiceImpl.getFunctionalRoles(): START");
		List<FunctionalRole> roles = functionalRoleRepository.findAll();
		List<Map<String, String>> list = new ArrayList<>();
		for (FunctionalRole role : roles) {
			Map<String, String> map = new HashMap<>();
			map.put("id", role.getId() + "");
			map.put("displayName", role.getName());
			list.add(map);
		}
		Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
			public int compare(Map<String, String> m1, Map<String, String> m2) {
				return m1.get("displayName").compareTo(m2.get("displayName"));
			}
		};
		Collections.sort(list, mapComparator);
		LOGGER.info("PesAdminServiceImpl.getFunctionalRoles(): END");
		if (roles != null)
			return list;
		else
			return null;
	}

	// Fetching lookup for sf user ids
	@Override
	public List<Map<String, String>> getSfUserIds() {
		LOGGER.info("PesAdminServiceImpl.getSfUserIds(): START");
		List<String> ids = employeeRepository.getAllDistinctSfUserId();
		List<Map<String, String>> list = new ArrayList<>();
		for (String id : ids) {
			Map<String, String> map = new HashMap<>();
			map.put("id", id);
			map.put("displayName", id);
			list.add(map);
		}
		Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
			public int compare(Map<String, String> m1, Map<String, String> m2) {
				return m1.get("displayName").compareTo(m2.get("displayName"));
			}
		};
		Collections.sort(list, mapComparator);
		LOGGER.info("PesAdminServiceImpl.getSfUserIds(): END");
		if (ids != null)
			return list;
		else
			return null;
	}

	// Fetching lookup for profile names
	@Override
	public List<Map<String, String>> getProfileNames() {
		LOGGER.info("PesAdminServiceImpl.getProfileNames(): START");
		List<String> names = employeeRepository.getAllDistinctProfileNames();
		List<Map<String, String>> list = new ArrayList<>();
		for (String name : names) {
			Map<String, String> map = new HashMap<>();
			map.put("id", name);
			map.put("displayName", name);
			list.add(map);
		}
		Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
			public int compare(Map<String, String> m1, Map<String, String> m2) {
				return m1.get("displayName").compareTo(m2.get("displayName"));
			}
		};
		Collections.sort(list, mapComparator);
		LOGGER.info("PesAdminServiceImpl.getProfileNames(): END");
		if (names != null)
			return list;
		else
			return null;
	}

	// Fetching lookup for emails
	@Override
	public List<Map<String, String>> getEmails() {
		LOGGER.info("PesAdminServiceImpl.getEmails(): START");
		List<String> emails = employeeRepository.getAllDistinctEmailIds();
		List<Map<String, String>> list = new ArrayList<>();
		for (String email : emails) {
			Map<String, String> map = new HashMap<>();
			map.put("id", email);
			map.put("displayName", email);
			list.add(map);
		}
		Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
			public int compare(Map<String, String> m1, Map<String, String> m2) {
				return m1.get("displayName").compareTo(m2.get("displayName"));
			}
		};
		Collections.sort(list, mapComparator);
		LOGGER.info("PesAdminServiceImpl.getEmails(): END");
		if (emails != null)
			return list;
		else
			return null;
	}

	// Fetching lookup for security roles
	@Override
	public List<Map<String, String>> getSecurityRoles() {
		LOGGER.info("PesAdminServiceImpl.getSecurityRoles(): START");
		List<SecurityRole> roles = securityRoleRepository.findAll();
		List<Map<String, String>> list = new ArrayList<>();
		for (SecurityRole role : roles) {
			Map<String, String> map = new HashMap<>();
			map.put("id", role.getId() + "");
			map.put("displayName", role.getName());
			list.add(map);
		}
		Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
			public int compare(Map<String, String> m1, Map<String, String> m2) {
				return m1.get("displayName").compareTo(m2.get("displayName"));
			}
		};
		Collections.sort(list, mapComparator);
		LOGGER.info("PesAdminServiceImpl.getSecurityRoles(): END");
		if (roles != null)
			return list;
		else
			return list;
	}

	/*
	 * Search function for employees for employee page
	 */
	@Override
	public List<EmployeeSearchResultDTO> searchEmployees(EmployeeSearchDTO empSearchDto) {
		LOGGER.info("PesAdminServiceImpl.searchEmployees(): START");
		try {
			List<Employee> empList = employeeRepository.findAll(new Specification<Employee>() {

				private static final long serialVersionUID = 1L;

				@Override
				public Predicate toPredicate(Root<Employee> root, CriteriaQuery<?> query,
						CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();

					// Variables from empSearchDto object
					String nameIds[] = empSearchDto.getNames();
					String marketIds[] = empSearchDto.getMarketIds();
					String teamIds[] = empSearchDto.getTeamIds();
					String roleIds[] = empSearchDto.getRoleIds();
					String podLeadIds[] = empSearchDto.getPodLeadIds();
					String userId = empSearchDto.getUserId();
					String profile = empSearchDto.getProfile();
					String email = empSearchDto.getEmail();
					if (nameIds != null && nameIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("id"));
						for (int i = 0; i < nameIds.length; i++) {
							in.value(Long.parseLong(nameIds[i]));
						}
						predicates.add(in);
					}
					if (marketIds != null && marketIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("marketId"));
						for (int i = 0; i < marketIds.length; i++) {
							Long marketId = Long.parseLong(marketIds[i]);
							in.value(marketId);
						}
						predicates.add(in);
					}
					if (teamIds != null && teamIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("teamId"));
						for (int i = 0; i < teamIds.length; i++) {
							Long teamId = Long.parseLong(teamIds[i]);
							in.value(teamId);
						}
						predicates.add(in);
					}
					if (roleIds != null && roleIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("fnRole").get("id"));
						for (int i = 0; i < roleIds.length; i++) {
							Long roleId = Long.parseLong(roleIds[i]);
							in.value(roleId);
						}
						predicates.add(in);
					}
					if (podLeadIds != null && podLeadIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("podLeadId"));
						for (int i = 0; i < podLeadIds.length; i++) {
							Long podLeadId = Long.parseLong(podLeadIds[i]);
							in.value(podLeadId);
						}
						predicates.add(in);
					}
					if (!StringUtils.isEmpty(userId)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("sfUserId"), userId)));
					}
					if (!StringUtils.isEmpty(profile)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("profileName"), profile)));
					}
					if (!StringUtils.isEmpty(email)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("email"), email)));
					}
					// taking only active employees
					predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("status"), "Active")));
					predicates.add(criteriaBuilder.and(criteriaBuilder.notEqual(root.get("id"), -1)));

					LOGGER.info("PesAdminServiceImpl.searchEmployees(): Adding data filters has been successful");
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});

			LOGGER.info("PesAdminServiceImpl.searchWeightage() : END");
			// to return latest records first
			Collections.reverse(empList);
			return prepareEmployeeSearchResults(empList);
		} catch (Exception e) {
			LOGGER.error("Exception while fetching Record: " + e.getMessage() + "::" + e);
			// to send back in case of error
			List<EmployeeSearchResultDTO> emptyList = new ArrayList<>();
			return emptyList;
		}
	}

	@Override
	/**
	 *  Function to filter out the audit history 
	 */
	public List<HistorySearchResultDTO> searchHistory(HistorySearchDTO historySearchDto) {
		LOGGER.info("PesAdminServiceImpl.searchHistory(): START");
		try {
			List<PesAuditHistory> historyList = pesAuditHistoryRepository.findAll(new Specification<PesAuditHistory>() {

				private static final long serialVersionUID = 1L;

				@Override
				public Predicate toPredicate(Root<PesAuditHistory> root, CriteriaQuery<?> query,
						CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();

					// Variables from historySearchDto object
					String[] names = historySearchDto.getNames();
					String[] roles = historySearchDto.getRoles();
					String email = historySearchDto.getEmail();
					String[] nameOfProspects = historySearchDto.getNameOfProspects();
					String[] playNames = historySearchDto.getPlayNames();
					String executionStartDate = historySearchDto.getStartDate();
					String executionEndDate = historySearchDto.getEndDate();
					Date startDate = null;
					Date endDate = null;

					if (!StringUtils.isEmpty(executionStartDate)) {
						LocalDate date = LocalDate.parse(executionStartDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						startDate = Date.valueOf(date);
					}
					// same for end date
					if (!StringUtils.isEmpty(executionEndDate)) {
						// to take all the records till endDate 23:59:59
						LocalDate date = LocalDate.parse(executionEndDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
								.plusDays(1);
						endDate = Date.valueOf(date);
					}
					if (names != null && names.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("userName"));
						for (int i = 0; i < names.length; i++) {
							String name = names[i].substring(0, names[i].indexOf('-') - 1);
							in.value(name);
						}
						predicates.add(in);
					}
					if (roles != null && roles.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("fnRole"));
						for (int i = 0; i < roles.length; i++) {
							in.value(roles[i]);
						}
						predicates.add(in);
					}
					if (nameOfProspects != null && nameOfProspects.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("nameOfProspect"));
						for (int i = 0; i < nameOfProspects.length; i++) {
							in.value(nameOfProspects[i]);
						}
						predicates.add(in);
					}
					if (playNames != null && playNames.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("playName"));
						for (int i = 0; i < playNames.length; i++) {
							in.value(playNames[i]);
						}
						predicates.add(in);
					}
					if (!StringUtils.isEmpty(email))
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("email"), email)));
					if (!StringUtils.isEmpty(executionStartDate)) {
						predicates.add(
								criteriaBuilder.and(criteriaBuilder.greaterThanOrEqualTo(root.get("date"), startDate)));
					}
					if (!StringUtils.isEmpty(executionEndDate)) {
						predicates
								.add(criteriaBuilder.and(criteriaBuilder.lessThanOrEqualTo(root.get("date"), endDate)));
					}
					LOGGER.info("PesAdminServiceImpl.searchHistory(): Adding data filters has been successful");
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});

			LOGGER.info("PesAdminServiceImpl.searchWeightage() : END");
			// to return latest records first
			Collections.reverse(historyList);
			return prepareHistorySearchResults(historyList);
		} catch (Exception e) {
			LOGGER.error("Exception while fetching Record: " + e.getMessage() + "::" + e);
			// to send back in case of error
			List<HistorySearchResultDTO> emptyList = new ArrayList<>();
			return emptyList;
		}
	}

	// delete employees by id
	@Override
	public boolean deleteEmployeesById(String[] ids) {
		try {
			LOGGER.info("PesAdminServiceImpl.deleteEmployeeById() : START");
			for (String id : ids) {
				Long pkId = Long.parseLong(id);
				Employee emp = employeeRepository.getById(pkId);
				emp.setStatus("Inactive");
				employeeRepository.save(emp);
			}
			LOGGER.info("PesAdminServiceImpl.deleteEmployeeById() : END");
			return true;
		} catch (Exception e) {
			LOGGER.info("PesAdminServiceImpl.deleteEmployeeById(): ERROR : " + e);
			e.printStackTrace();
			return false;
		}
	}

	/*
	 * Adds new market
	 */
	@Override
	public GenericResult addMarket(JSONObject marketObj) {
		try {
			LOGGER.info("PesAdminServiceImpl.addMarket() : START");
			Market market = new Market();
			String marketName = (String) marketObj.get("name");
			Market existingMarket = marketRepository.findByName(marketName);
			if(existingMarket != null) {
				GenericResult result = new GenericResult();
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Market already exists!");
				return result;
			}
			market.setName((String) marketObj.get("name"));
			market.setCreatedBy((String) marketObj.get("createdBy"));
			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();
			market.setCreatedDate(currDate);
			marketRepository.save(market);
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.addMarket() : END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.addMarket(): " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add Market with name: " + (String) marketObj.get("name"));
			return result;
		}
	}

	/*
	 * function adding team
	 */
	@Override
	public GenericResult addTeam(JSONObject teamObj) {
		try {
			LOGGER.info("PesAdminServiceImpl.addTeam() : START");
			Team team = new Team();
			String teamName = (String) teamObj.get("name");
			Team existingTeam = teamRepository.findByName(teamName);
			if(existingTeam != null) {
				GenericResult result = new GenericResult();
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Team already exists!");
				return result;
			}
			team.setName(teamName);
			team.setCreatedBy((String) teamObj.get("createdBy"));
			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();
			team.setCreatedDate(currDate);
			teamRepository.save(team);
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.addTeam() : END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.addTeam(): " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add team with name: " + (String) teamObj.get("name"));
			return result;
		}
	}

	/*
	 * Function to add new market-play-weightage records
	 */
	@Override
	public GenericResult addWeightage(MarketPlayWeightageDTO weightageDto) {
		try {
			LOGGER.info("PesAdminServiceImpl.addWeightage(): START");
			Long marketId = null;
			Long teamId = null;
			if(weightageDto.getMarketId() != null)
			marketId = Long.parseLong(weightageDto.getMarketId());
			if(weightageDto.getTeamId() != null)
			teamId = Long.parseLong(weightageDto.getTeamId());
			Long playId = Long.parseLong(weightageDto.getPlayId());
			Long functionalRoleId = Long.parseLong(weightageDto.getRoleId());
			MapPlayMarketWeightage existingWtg = mapPlayMarketWeightageRepository.getByPlayIdNRoleId(playId, functionalRoleId);
			if(existingWtg != null) {
				GenericResult result = new GenericResult();
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Play and Role Weightage already exists");
				return result;
			}
			Long weightage = Long.parseLong(weightageDto.getWeightage());
			MapPlayMarketWeightage mapObj = new MapPlayMarketWeightage();
			mapObj.setMarketId(marketId);
			mapObj.setTeamId(teamId);
			mapObj.setPlayId(playId);
			mapObj.setFuncRoleId(functionalRoleId);
			mapObj.setWeightage(weightage);
			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();
			mapObj.setCreatedDate(currDate);
			mapPlayMarketWeightageRepository.save(mapObj);
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.addWeightage(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.addWeightage(): " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add weightage");
			return result;
		}

	}

	// Update Market-Play-Weightage map records
	@Override
	public GenericResult updateWeightage(MarketPlayWeightageDTO weightageDto) {
		try {
			LOGGER.info("PesAdminServiceImpl.updateWeightage(): START");
			Long weightageId = Long.parseLong(weightageDto.getId());
			Long marketId = Long.parseLong(weightageDto.getMarketId());
			Long teamId = Long.parseLong(weightageDto.getTeamId());
			Long playId = Long.parseLong(weightageDto.getPlayId());
			Long functionalRoleId = Long.parseLong(weightageDto.getRoleId());
			Long weightage = Long.parseLong(weightageDto.getWeightage());
			MapPlayMarketWeightage mapObj = mapPlayMarketWeightageRepository.getById(weightageId);
			mapObj.setMarketId(marketId);
			mapObj.setTeamId(teamId);
			mapObj.setPlayId(playId);
			mapObj.setFuncRoleId(functionalRoleId);
			mapObj.setWeightage(weightage);
			Calendar cal = Calendar.getInstance();
			java.util.Date updateDate = cal.getTime();
			mapObj.setUpdatedDate(updateDate);
			mapPlayMarketWeightageRepository.save(mapObj);
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.updateWeightage(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.updateWeightage(): " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add weightage");
			return result;
		}
	}

	/*
	 * For searching weightage
	 */
	@Override
	public List<MapPlayMarketWeightageSearchResultDTO> searchMarketWeightages(
			MarketPlayWeightageSearchDTO weightageSearchDto) {
		LOGGER.info("PesAdminServiceImpl.searchWeightage(): START");
		try {
			List<MapPlayMarketWeightage> weightageList = mapPlayMarketWeightageRepository
					.findAll(new Specification<MapPlayMarketWeightage>() {

						private static final long serialVersionUID = 1L;

						@Override
						public Predicate toPredicate(Root<MapPlayMarketWeightage> root, CriteriaQuery<?> query,
								CriteriaBuilder criteriaBuilder) {
							List<Predicate> predicates = new ArrayList<>();

							// Variables from empSearchDto object
							String marketIds[] = weightageSearchDto.getMarketId();
							String teamIds[] = weightageSearchDto.getTeamId();
							String playIds[] = weightageSearchDto.getPlayId();
							String roleIds[] = weightageSearchDto.getRoleId();
							if (marketIds != null && marketIds.length != 0) {
								In<Object> in = criteriaBuilder.in(root.get("marketId"));
								for (int i = 0; i < marketIds.length; i++) {
									Long marketId = Long.parseLong(marketIds[i]);
									in.value(marketId);
								}
								predicates.add(in);
							}
							if (teamIds != null && teamIds.length != 0) {
								In<Object> in = criteriaBuilder.in(root.get("teamId"));
								for (int i = 0; i < teamIds.length; i++) {
									Long teamId = Long.parseLong(teamIds[i]);
									in.value(teamId);
								}
								predicates.add(in);
							}
							if (roleIds != null && roleIds.length != 0) {
								In<Object> in = criteriaBuilder.in(root.get("funcRoleId"));
								for (int i = 0; i < roleIds.length; i++) {
									Long roleId = Long.parseLong(roleIds[i]);
									in.value(roleId);
								}
								predicates.add(in);
							}
							if (playIds != null && playIds.length != 0) {
								In<Object> in = criteriaBuilder.in(root.get("playId"));
								for (int i = 0; i < playIds.length; i++) {
									Long playId = Long.parseLong(playIds[i]);
									in.value(playId);
								}
								predicates.add(in);
							}
							LOGGER.info(
									"PesScoringServiceImpl.searchWeightage(): Adding data filters has been successful");
							return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
						}
					});

			LOGGER.info("PesAdminServiceImpl.searchWeightage() : END");
			Collections.reverse(weightageList);
			return prepareWeightageResults(weightageList);
		} catch (Exception e) {
			LOGGER.error("Exception while fetching Record: " + e.getMessage() + "::" + e);
			// to send back in case of error
			List<MapPlayMarketWeightageSearchResultDTO> emptyList = new ArrayList<>();
			return emptyList;
		}
	}

	/*
	 * formatting employee search data to format for objects : {id: "id",
	 * displayName: "displayName"}
	 */
	public List<EmployeeSearchResultDTO> prepareEmployeeSearchResults(List<Employee> empList) {
		LOGGER.info("PesAdminServiceImpl.prepareEmployeeSearchResults(): START");
		List<EmployeeSearchResultDTO> empResult = new ArrayList<>();
		List<Employee> allEmpList = employeeRepository.findAll();
		List<Department> deptList = departmentRepository.findAll();
		List<Designation> dsgnList = designationRepository.findAll();
		List<Market> marketList = marketRepository.findAll();
		List<Team> teamList = teamRepository.findAll();
		
		Map<Long,Employee> empIdMap = new HashMap<>();
		Map<Long,Department> deptIdMap = new HashMap<>();
		Map<Long,Designation> dsgnIdMap = new HashMap<>();
		Map<Long,Market> marketIdMap = new HashMap<>();
		Map<Long,Team> teamIdMap = new HashMap<>();
		
		for(Employee emp: allEmpList) {
			empIdMap.put(emp.getId(),emp);
		}
		for(Department dept: deptList) {
			deptIdMap.put(dept.getId(), dept);
		}
		for(Designation dsgn: dsgnList) {
			dsgnIdMap.put(dsgn.getId(),dsgn);
		}
		for(Market market: marketList) {
			marketIdMap.put(market.getId(), market);
		}
		for(Team team: teamList) {
			teamIdMap.put(team.getId(),	team);
		}
		for (Employee emp : empList) {
			EmployeeSearchResultDTO searchDto = new EmployeeSearchResultDTO();
			searchDto.setId(emp.getId());
			searchDto.setEmpId(emp.getEmpId());
			searchDto.setSf18CharId(emp.getSf18CharId());
			searchDto.setSfUserId(emp.getSfUserId());
			searchDto.setFirstName(emp.getFirstName());
			searchDto.setLastName(emp.getLastName());
			searchDto.setFullName(emp.getFullName());
			searchDto.setAlias(emp.getAlias());
			searchDto.setProfileName(emp.getProfileName());
			searchDto.setEmail(emp.getEmail());
			Employee podLeadObj = empIdMap.get(emp.getPodLeadId());
			if (podLeadObj != null) {
				searchDto.setPodLead(convertValueToMap(podLeadObj.getId() + "", podLeadObj.getFullName()));
			}
			Employee dottedManagerObj = empIdMap.get(emp.getDottedMangerId());
			if (dottedManagerObj != null) {
				searchDto.setDottedManger(
					convertValueToMap(dottedManagerObj.getId() + "", dottedManagerObj.getFullName()));
			}
			Designation designationObj = dsgnIdMap.get(emp.getDesignationId());
			if (designationObj != null) {
				searchDto.setDesignation(convertValueToMap(designationObj.getId() + "", designationObj.getName()));
			}
			Market marketObj = marketIdMap.get(emp.getMarketId());
			if (marketObj != null) {
				searchDto.setMarket(convertValueToMap(marketObj.getId() + "", marketObj.getName()));
			}
			Department departmentObj = deptIdMap.get(emp.getDepartmentId());
			if (departmentObj != null) {
				searchDto.setDepartment(convertValueToMap(departmentObj.getId() + "", departmentObj.getName()));
			}
			FunctionalRole fnRoleObj = emp.getFnRole();
			if (fnRoleObj != null) {
				searchDto.setFnRole(convertValueToMap(fnRoleObj.getId() + "", fnRoleObj.getName()));
			}
			Team teamObj = teamIdMap.get(emp.getTeamId());
			if (teamObj != null) {
				searchDto.setTeam(convertValueToMap(teamObj.getId() + "", teamObj.getName()));
			}
			searchDto.setLocation(emp.getLocation());
			searchDto.setCreatedBy(emp.getCreatedBy());
			searchDto.setCreatedDate(emp.getCreatedDate());
			searchDto.setUpdatedBy(emp.getUpdatedBy());
			searchDto.setUpdatedDate(emp.getUpdatedDate());
			empResult.add(searchDto);
		}
		LOGGER.info("PesAdminServiceImpl.prepareEmployeeSearchResults(): END");
		return empResult;
	}

	/**
	 * prepares the filtered history data in front end ready format
	 * @param historyList
	 * @return
	 */
	public List<HistorySearchResultDTO> prepareHistorySearchResults(List<PesAuditHistory> historyList) {
		LOGGER.info("PesAdminServiceImpl.prepareHistorySearchResults(): START");
		List<HistorySearchResultDTO> historyResult = new ArrayList<>();
		ZoneId zoneKolkata = ZoneId.of("Asia/Kolkata");
		try {
			if (historyList.size() == 0)
				return historyResult;
			for (PesAuditHistory history : historyList) {
				Timestamp date = history.getDate();
				Instant instant = date.toInstant();
				ZonedDateTime zdtKolkata = ZonedDateTime.ofInstant(instant, zoneKolkata);
				HistorySearchResultDTO searchDto = new HistorySearchResultDTO();
				searchDto.setUserName(history.getUserName());
				searchDto.setAction(history.getAction());
				searchDto.setDateOfExecution(zdtKolkata);
				searchDto.setEmail(history.getEmail());
				searchDto.setFnRole(history.getFnRole());
				searchDto.setNameOfProspect(history.getNameOfProspect());
				searchDto.setId(history.getId());
				searchDto.setPlayName(history.getPlayName());
				JSONParser parser = new JSONParser();
				JSONObject inputData = null;
				if (!StringUtils.isEmpty(history.getInputData()))
					inputData = (JSONObject) parser.parse(history.getInputData());
				searchDto.setInputData(inputData);
				searchDto.setId(history.getId());
				historyResult.add(searchDto);
			}
			LOGGER.info("PesAdminServiceImpl.prepareHistorySearchResults(): END");
		} catch (Exception e) {
			LOGGER.info("PesAdminServiceImpl.prepareHistorySearchResults(): ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return historyResult;
	}

	/*
	 * formatting weightage search data to format for objects : {id: "id",
	 * displayName: "displayName"}
	 */
	public List<MapPlayMarketWeightageSearchResultDTO> prepareWeightageResults(List<MapPlayMarketWeightage> weightage) {
		LOGGER.info("PesAdminServiceImpl.prepareWeightageResults(): START");
		List<MapPlayMarketWeightageSearchResultDTO> weightageList = new ArrayList<>();
		for (MapPlayMarketWeightage weight : weightage) {
			MapPlayMarketWeightageSearchResultDTO searchDto = new MapPlayMarketWeightageSearchResultDTO();
			searchDto.setId(weight.getId() + "");
			if (playRepository.getById(weight.getPlayId()) != null) {
				Play play = playRepository.getById(weight.getPlayId());
				searchDto.setPlay(convertValueToMap(play.getId() + "", play.getName()));
			}
			if (marketRepository.getById(weight.getMarketId()) != null) {
				Market marketObj = marketRepository.getById(weight.getMarketId());
				searchDto.setMarket(convertValueToMap(marketObj.getId() + "", marketObj.getName()));
			}
			if (functionalRoleRepository.getById(weight.getFuncRoleId()) != null) {
				FunctionalRole fnRoleObj = functionalRoleRepository.getById(weight.getFuncRoleId());
				searchDto.setFnRole(convertValueToMap(fnRoleObj.getId() + "", fnRoleObj.getName()));
			}
			if (teamRepository.getById(weight.getTeamId()) != null) {
				Team teamObj = teamRepository.getById(weight.getTeamId());
				searchDto.setTeam(convertValueToMap(teamObj.getId() + "", teamObj.getName()));
			}
			searchDto.setWeightage(weight.getWeightage() + "");
			searchDto.setCreatedBy(weight.getCreatedBy());
			searchDto.setCreatedDate(weight.getCreatedDate());
			searchDto.setUpdatedBy(weight.getUpdatedBy());
			searchDto.setUpdatedDate(weight.getUpdatedDate());
			weightageList.add(searchDto);
		}
		LOGGER.info("PesAdminServiceImpl.prepareWeightageResults(): START");
		return weightageList;
	}

	/*
	 * Method to get the all the dynamic field types available from the DB No
	 * parameters
	 */
	@Override
	public List<Map<String, String>> getFieldTypes() {
		LOGGER.info("PesAdminServiceImpl.getFieldTypes(): START");
		List<FieldType> fieldTypes = new ArrayList<>();
		fieldTypes = fieldTypeRepository.findAll();

		List<Map<String, String>> list = new ArrayList<>();
		for (FieldType fieldType : fieldTypes) {
			Map<String, String> map = new HashMap<>();
			map.put("id", fieldType.getId() + "");
			map.put("displayName", fieldType.getName());
			list.add(map);
		}
		Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
			public int compare(Map<String, String> m1, Map<String, String> m2) {
				return m1.get("displayName").compareTo(m2.get("displayName"));
			}
		};
		Collections.sort(list, mapComparator);
		LOGGER.info("PesAdminServiceImpl.getFieldTypes(): END");
		if (fieldTypes != null)
			return list;
		else
			return null;
	}

	/*
	 * Method to get the list of all the Playbooks available in DB No parameters
	 */
	@Override
	public List<Map<String, String>> getPlaybookList() {
		LOGGER.info("PesAdminServiceImpl.getPlaybookList(): START");
		List<Playbook> playbooks = new ArrayList<>();
		playbooks = playbookRepository.findAll();

		List<Map<String, String>> list = new ArrayList<>();
		for (Playbook playbook : playbooks) {
			Map<String, String> map = new HashMap<>();
			map.put("id", playbook.getId() + "");
			map.put("displayName", playbook.getName());
			list.add(map);
		}
		LOGGER.info("PesAdminServiceImpl.getPlaybookList(): END");
		if (playbooks != null)
			return list;
		else
			return null;
	}

	/*
	 * Method to get the list of departments from the DB No parameters
	 */
	@Override
	public List<Map<String, String>> getDepartmentList() {
		LOGGER.info("PesAdminServiceImpl.getDepartmentList(): START");
		List<Department> departments = new ArrayList<>();
		departments = departmentRepository.findAll();

		List<Map<String, String>> list = new ArrayList<>();
		for (Department department : departments) {
			Map<String, String> map = new HashMap<>();
			map.put("id", department.getId() + "");
			map.put("displayName", department.getName());
			list.add(map);
		}
		LOGGER.info("PesAdminServiceImpl.getDepartmentList(): END");
		if (departments != null)
			return list;
		else
			return null;
	}

	/*
	 * Method to get the list of fields based on search filters
	 * 
	 * @Param playbookSearchFields - JSON Object which contains fieldName and
	 * fieldType Return the list of fields based on the above search parameters
	 */
	@Override
	public List<Field> getSearchedFieldsList(JSONObject playbookSearchFields) {
		LOGGER.info("PesAdminServiceImpl.getSearchedFieldsList(): START");
		String fieldName = playbookSearchFields.get("name") == null ? "" : playbookSearchFields.get("name").toString();
		String stringFieldType = playbookSearchFields.get("type").toString();
		List<Field> searchedFields = new ArrayList<>();
		if (StringUtils.isEmpty(stringFieldType) && !StringUtils.isEmpty(fieldName)) {
			Field sField = fieldRepository.findByFieldName(fieldName);
			searchedFields.add(sField);
		} else if (!StringUtils.isEmpty(stringFieldType) && StringUtils.isEmpty(fieldName)) {
			searchedFields = fieldRepository.findByFieldType(Long.parseLong(stringFieldType));
		} else if (!StringUtils.isEmpty(stringFieldType) && !StringUtils.isEmpty(fieldName)) {
			searchedFields = fieldRepository.findSearchedFields(Long.parseLong(stringFieldType), fieldName);
		} else {
			searchedFields = fieldRepository.findAll();
		}
		try {

			for (Field f : searchedFields) {
				if (!StringUtils.isEmpty(f.getViewableBy()))
					f.setViewableByArr(f.getViewableBy().split(","));
				if (!StringUtils.isEmpty(f.getEditableBy()))
					f.setEditableByArr(f.getEditableBy().split(","));
				List<MapFieldOptions> options = mapFieldOptionsRepository.getByFieldId(f.getId());
				f.setOptions(options);
			}
			LOGGER.info("PesAdminServiceImpl.getSearchedFieldsList(): END :: Return Val - " + searchedFields);
			return searchedFields;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.getSearchedFieldsList(): ERROR : " + e.getMessage());
			return null;
		}

	}

	/*
	 * Add a new Field in DB
	 * 
	 * @Param fieldDetails - JSON Object which contains all the required field
	 * details Check if the field already exists or not
	 */
	@Override
	public GenericResult addField(JSONObject fieldDetails) {
		LOGGER.info("PesAdminServiceImpl.addField(): START:");
		try {
			Field field = new Field();
			GenericResult result = new GenericResult();
			String fname = (String) fieldDetails.get("fieldName");

			String[] words = fname.split("[\\W_]+");
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < words.length; i++) {
				String word = words[i];
				if (i == 0) {
					word = word.isEmpty() ? word : word.toLowerCase();
				} else {
					word = word.isEmpty() ? word
							: Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
				}
				builder.append(word);
			}
			String fieldName = builder.toString();
			Field isFieldPresent = fieldRepository.findByFieldName(fieldName);
			if (isFieldPresent != null) {
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Field with the given name already present");
				return result;
			}

			field.setDisplayName(fname);
			field.setDescription((String) fieldDetails.get("description"));
			field.setViewableBy((String) fieldDetails.get("viewableBy"));
			field.setEditableBy((String) fieldDetails.get("editableBy"));
			field.setFieldName(fieldName);
			field.setCreatedBy((String) fieldDetails.get("createdBy"));
			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();
			field.setCreatedDate(currDate);
			FieldType fieldType = fieldTypeRepository.getById(Long.parseLong((String) fieldDetails.get("fieldType")));
			field.setFieldType(fieldType);
			fieldRepository.save(field);
			String optionString = (String) fieldDetails.get("fieldOptions");
			if (StringUtils.isNotEmpty(optionString)) {
				String[] options = optionString.split(",");
				List<MapFieldOptions> optionsList = new ArrayList<>();
				for (String opt : options) {
					MapFieldOptions map = new MapFieldOptions();
					map.setFieldId(field.getId());
					map.setDisplayName(opt.trim());
					map.setValue(opt.trim());
					map.setCreatedDate(currDate);
					map.setCreatedBy((String) fieldDetails.get("createdBy"));
					optionsList.add(map);
				}
				field.setFieldOptions(optionsList);
			}

			fieldRepository.save(field);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.addField(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.addField: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add field");
			return result;
		}
	}

	/*
	 * Add a new Play in the DB
	 * 
	 * @Param playDetails - JSON Object which contains all the required play fields
	 * in key value pairs Check if the given play already exists in for the same
	 * playbook and dept
	 */
	@Override
	public GenericResult addPlay(JSONObject playDetails) {
		LOGGER.info("PesAdminServiceImpl.addPlay(): START:");
		try {
			Play play = new Play();
			GenericResult result = new GenericResult();
			String playName = (String) playDetails.get("play");
			Long deptId = Long.parseLong((String) playDetails.get("department"));
			Long playbookId = Long.parseLong((String) playDetails.get("playbook"));
			Play isPlayPresent = playRepository.findByNameDepartmentPlaybook(playName, deptId, playbookId);
			if (isPlayPresent != null) {
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Play already present for the given department");
				return result;
			}
			play.setName(playName);
			play.setPlayOperaLink((String) playDetails.get("operaUrl"));
			play.setDescription((String) playDetails.get("description"));

			Playbook playbook = playbookRepository.getById(playbookId);
			Department dept = departmentRepository.getById(deptId);

			play.setDepartment(dept);
			play.setPlaybook(playbook);
			String createdBy = (String) playDetails.get("createdBy");
			play.setCreatedBy(createdBy);
			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();
			play.setCreatedDate(currDate);

			Play savedPlay = playRepository.save(play);
			List<MapPlayFields> mapPlayFields = new ArrayList<MapPlayFields>();

			// ? operator verifies that the value is a list
			List<?> map = (List<?>) playDetails.get("mapPlayFields");
			List<?> roleIds = (List<?>) playDetails.get("roles");
			
			if (!map.isEmpty()) {
				for (Object fieldId : map) {
					MapPlayFields mapObj = new MapPlayFields();
					Long fId = Long.parseLong((String)fieldId);
					mapObj.setFieldId(fId);
					mapObj.setPlayId(savedPlay.getId());
					mapObj.setCreatedBy(createdBy);
					mapObj.setCreatedDate(currDate);
					mapPlayFields.add(mapObj);
				}
			}
            
			List<MapPlayRoles> playRoleMap = new ArrayList<>();
			if(roleIds.size() != 0) {
				for(Object roleId:roleIds) {
					MapPlayRoles rec = new MapPlayRoles();
					rec.setPlayId(savedPlay.getId());
					rec.setRoleId(Long.parseLong((String)roleId));
					playRoleMap.add(rec);
					}
				playRoleRepo.saveAll(playRoleMap);
			}
			mapPlayFieldsRepository.saveAll(mapPlayFields);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.addPlay(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.addPlay: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add play");
			return result;
		}
	}

	/*
	 * Method to get the list of Plays based on search filters
	 * 
	 * @Param searchParams - PlaysSearchDTO which contains playbookIds,
	 * departmentIds, playNames Return the list of plays based on the above search
	 * parameters
	 */
	public GenericResult playDetails(PlaysSearchDTO searchParams) {
		LOGGER.info("PesAdminServiceImpl.playDetails(): START:");
		GenericResult result = new GenericResult();
		try {
			List<Play> playsList = playRepository.findAll(new Specification<Play>() {

				private static final long serialVersionUID = 1L;

				@Override
				public Predicate toPredicate(Root<Play> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();

					// Variables from empSearchDto object
					String playbookIds[] = searchParams.getPlaybookIds();
					String departmentIds[] = searchParams.getDepartmentIds();
					String playNames[] = searchParams.getPlayNames();

					if (playbookIds != null && playbookIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("playbook").get("id"));
						for (int i = 0; i < playbookIds.length; i++) {
							Long playbookId = Long.parseLong(playbookIds[i]);
							in.value(playbookId);
						}
						predicates.add(in);
					}
					if (departmentIds != null && departmentIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("department").get("id"));
						for (int i = 0; i < departmentIds.length; i++) {
							Long deptId = Long.parseLong(departmentIds[i]);
							in.value(deptId);
						}
						predicates.add(in);
					}
					if (playNames != null && playNames.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("name"));
						for (int i = 0; i < playNames.length; i++) {
							in.value(playNames[i]);
						}
						predicates.add(in);
					}

					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});

			// to return latest records first
			Collections.reverse(playsList);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			result.setData(playsList);
			LOGGER.info("PesAdminServiceImpl.playDetails() : END");
			return result;
		} catch (Exception e) {
			LOGGER.error("Exception while fetching Record: " + e.getMessage() + "::" + e);
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to fetch plays");
			result.setData(null);
			return result;
		}
	}

	/*
	 * Update the Map Play Fields DB
	 * 
	 * @Param mapDetails - JSON Object which contains playId and the array of mapped
	 * field ids
	 */
	public GenericResult updateMapPlayFields(JSONObject mapDetails) {
		LOGGER.info("PesAdminServiceImpl.updateMapPlayFields(): START:");
		try {
			GenericResult result = new GenericResult();
			Long playId = Long.parseLong(String.valueOf(mapDetails.get("playId")));
			String createdBy = (String) mapDetails.get("createdBy");
			List<?> map = (List<?>) mapDetails.get("newFieldRows");

			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();

			List<MapPlayFields> mapPlayFields = new ArrayList<MapPlayFields>();

			if (!map.isEmpty()) {
				for (Object fieldId : map) {
					MapPlayFields mapObj = new MapPlayFields();
					Long fId = Long.parseLong((String) fieldId);
					mapObj.setFieldId(fId);
					mapObj.setPlayId(playId);
					mapObj.setCreatedBy(createdBy);
					mapObj.setCreatedDate(currDate);
					mapPlayFields.add(mapObj);
				}
			}

			mapPlayFieldsRepository.saveAll(mapPlayFields);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.updateMapPlayFields(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.updateMapPlayFields: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to update the Map Play Fields");
			return result;
		}
	}

	/*
	 * Add a new Playbook in the database
	 * 
	 * @Param playbookDetails - JSON Object which contains the required key value
	 * pairs for saving the playbook Check if the given playbook already exists in
	 * DB or not and send appropriate response
	 */
	public GenericResult addPlaybook(JSONObject playbookDetails) {
		LOGGER.info("PesAdminServiceImpl.addPlaybook(): START:");
		try {
			Playbook playbook = new Playbook();
			GenericResult result = new GenericResult();

			String playbookName = (String) playbookDetails.get("playbookName");
			Long departmentId = Long.parseLong(String.valueOf(playbookDetails.get("departmentId")));
			String description = (String) playbookDetails.get("description");
			String docUrl = (String) playbookDetails.get("docUrl");
			String createdBy = (String) playbookDetails.get("createdBy");

			Department dept = departmentRepository.getById(departmentId);
			if (dept == null) {
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Department not mapped to the playbook");
				result.setData(null);
				return result;
			}
			List<Playbook> isExistingPlaybook = playbookRepository.findByNameAndDepartment(playbookName, departmentId);
			if (!isExistingPlaybook.isEmpty()) {
				result.setSuccess(PesConstants.FALSE);
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Given Playbook already exists for the selected Department");
				result.setData(null);
				return result;
			}

			Calendar cal = Calendar.getInstance();
			java.util.Date currDate = cal.getTime();

			playbook.setName(playbookName);
			playbook.setDescription(description);
			playbook.setDocUrl(docUrl);
			playbook.setCreatedBy(createdBy);
			playbook.setCreatedDate(currDate);
			playbook.setDepartment(dept);
			;

			playbookRepository.save(playbook);

			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesAdminServiceImpl.addPlaybook(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesAdminServiceImpl.addPlaybook: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add the new playbook");
			return result;
		}
	}

	// converts objects to maps with id and displayName keys
	public Map<String, String> convertValueToMap(String id, String name) {
		Map<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("displayName", name);
		return map;
	}
	
	//Gets the reportlist for the reports page
		@Override
		public Map<String, List<Map<String, String>>> getReportsConfigData() {
			LOGGER.info("PesAdminServiceImpl.getReportsConfigData(): START");
			List<Reports> reports = reportsRepo.findAll();
			
			if(reports == null)
				return null;

			Map<String, List<Map<String, String>>> map = new HashMap<>();
			for (Reports report : reports) {
				String category = report.getCategory();
				Map<String,String> reportMap = new HashMap<>();
				reportMap.put("category", report.getCategory());
				reportMap.put("name", report.getName());
				reportMap.put("url", report.getURL());
				reportMap.put("desc", report.getDescription());
				if(map.get(category) != null) {
					List<Map<String, String>> repList = map.get(category);
					if(repList == null) {
						repList = new ArrayList<>();
					}
					repList.add(reportMap);
					map.put(category, repList);
				}
				else {
					List<Map<String, String>> repList = new ArrayList<>();
					repList.add(reportMap);
					map.put(category, repList);
				}
				
			}
			LOGGER.info("PesAdminServiceImpl.getReportsConfigData(): END");
			return map;		
		}
}
