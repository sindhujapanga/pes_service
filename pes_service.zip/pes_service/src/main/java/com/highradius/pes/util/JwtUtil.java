
package com.highradius.pes.util;

import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.InvalidKeySpecException;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.FunctionalRole;
import com.highradius.pes.model.MapApiRoles;
import com.highradius.pes.model.PesAuditHistory;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FunctionalRoleRepository;
import com.highradius.pes.repository.MapApiRolesRepository;
import com.highradius.pes.repository.PesAuditHistoryRepository;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil implements Serializable {
	private static final Logger LOGGER = LogManager.getLogger(JwtUtil.class);
	private static final long serialVersionUID = 7008375124389347049L;
	public static final long TOKEN_VALIDITY = 20 * 60 * 60;

	@Autowired
	EmployeeRepository empRepo;

	@Autowired
	FunctionalRoleRepository fnRoleRepo;

	@Autowired
	MapApiRolesRepository apiRepo;

	@Autowired
	PesAuditHistoryRepository pesAuditHistoryRepository;
	
	@Autowired
	PesPropertiesUtil propertiesUtil;

	@Value("${jwtSecret}")
	private String jwtSecret;
	
	private static String key = null;

	public String generateJwtToken(String email) {

		Employee emp = empRepo.findByEmailId(email);

		Map<String, Object> claims = new HashMap<>();
		claims.put("empRoleId", emp.getFnRole().getId());
		claims.put("empPkId", emp.getId());

		return Jwts.builder().setClaims(claims).setSubject(email).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + TOKEN_VALIDITY * 1000))
				.signWith(SignatureAlgorithm.HS512, jwtSecret).compact();
	}

	public Date getJwtTokenExpiration(String jwtToken) {
		Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(jwtToken).getBody();
		return claims.getExpiration();
	}

	public Boolean validateJwtToken(String token, String email) {
		Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		String userEmail = claims.getSubject();
		Boolean isTokenExpired = claims.getExpiration().before(new Date());
		return (userEmail.equals(email) && !isTokenExpired);
	}

	// Validate and add user data to jwt
	public Map<String, Object> validateJwtToken(String token, String email, String url, String enableApiRoleAccess) {

		Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		String userEmail = claims.getSubject();
		Long userRoleId = ((Number) claims.get("empRoleId")).longValue();
		Long userPkId = ((Number) claims.get("empPkId")).longValue();

		Map<String, Object> empMap = new HashMap<>();
		Boolean isTokenExpired = claims.getExpiration().before(new Date());

		if (enableApiRoleAccess.equalsIgnoreCase("false")) {
			if (userEmail.equals(email) && !isTokenExpired) {
				empMap.put("empPkId", userPkId);
				empMap.put("empRoleId", userRoleId);
				empMap.put("isAuthorized", true);
				LOGGER.info("JwtUtil.validateJwtToken() - EnableRoleApiAcces - false - SUCCESS\n API: " + url
						+ "\n RoleId: " + userRoleId);
				return empMap;
			} else {
				empMap.put("isAuthorized", false);
				LOGGER.info("JwtUtil.validateJwtToken() - EnableRoleApiAcces - false - FAILURE\n API: " + url
						+ "\n RoleId: " + userRoleId);
				return empMap;
			}

		} else {
			MapApiRoles mapApiRoles = apiRepo.getByNameAndRole(url, userRoleId);

			if (!ObjectUtils.isEmpty(mapApiRoles)) {
				if (userEmail.equals(email) && !isTokenExpired) {
					empMap.put("empPkId", userPkId);
					empMap.put("empRoleId", userRoleId);
					empMap.put("isAuthorized", true);
					LOGGER.info("JwtUtil.validateJwtToken() - SUCCESS\n API: " + url + "\n RoleId: " + userRoleId);
					return empMap;
				} else {
					empMap.put("isAuthorized", false);
					LOGGER.info("JwtUtil.validateJwtToken() - FAILURE\n API: " + url + "\n RoleId: " + userRoleId);
					return empMap;
				}
			}

			PesAuditHistory audit = new PesAuditHistory();
			FunctionalRole role = fnRoleRepo.getById(userRoleId);
			audit.setUserName(userEmail);
			audit.setEmail(userEmail);
			audit.setAction("Unauthorized API");
			audit.setFnRole(role != null ? role.getName() : null);
			audit.setInputData("{\"Email\":\"" + userEmail + "\",\"Api\":\"" + url + "\"}");
			Calendar cal = Calendar.getInstance();
			cal.setTimeZone(TimeZone.getTimeZone("IST"));
			java.util.Date currDate = cal.getTime();
			Timestamp currDateTime = new java.sql.Timestamp(currDate.getTime());
			audit.setDate(currDateTime);
			audit.setCreatedDate(currDate);
			audit.setCreatedBy(userEmail);

			pesAuditHistoryRepository.save(audit);
			return empMap;
		}

	}

	public Boolean expireJwtToken(String token) {
		Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody()
				.setExpiration(new Date(System.currentTimeMillis()));
		if (claims.getExpiration().before(new Date(System.currentTimeMillis()))) {
			return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	public GenericResult verifyGoogleTokenId(String idTokenString) throws GeneralSecurityException, IOException {
		GenericResult result = new GenericResult();
		LOGGER.info(idTokenString);
		GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new NetHttpTransport(), new GsonFactory())
				.setAudience(Collections.singletonList(PesConstants.CLIENT_ID)).build();

		try {
			GoogleIdToken idToken = verifier.verify(idTokenString);
			if (idToken != null) {
				Payload payload = idToken.getPayload();
				result.setSuccess(Boolean.TRUE);
				result.setMessage("Google token verification successful");
				JSONObject userObj = new JSONObject();
				String familyName = (String) payload.get("family_name");
				String givenName = (String) payload.get("given_name");
				userObj.put("email", payload.getEmail());
				userObj.put("fullName", givenName + " " + familyName);
				result.setData(userObj);
				return result;
			} else {
				LOGGER.error("Invalid ID token.");
				result.setSuccess(Boolean.FALSE);
				result.setMessage("Google token verification failed");
				result.setData(null);
				return result;
			}
		} catch (Exception e) {
			LOGGER.error("Google token verification Exception :: " + e);
			result.setSuccess(Boolean.FALSE);
			result.setMessage("Something went wrong! Google token verification failed");
			result.setData(null);
			return result;
		}
	}

	public GenericResult verifyAzureTokenId(String token)
			throws NoSuchAlgorithmException, InvalidKeySpecException, CertificateException {
		GenericResult result = new GenericResult();
		if(StringUtils.isEmpty(key)) {
			refreshAzureADAuthToken();
		}
//		String key = "MIIC/jCCAeagAwIBAgIJAOCJOVRxNKcNMA0GCSqGSIb3DQEBCwUAMC0xKzApBgNVBAMTImFjY291bnRzLmFjY2Vzc2NvbnRyb2wud2luZG93cy5uZXQwHhcNMjMwODI4MjAwMjQwWhcNMjgwODI4MjAwMjQwWjAtMSswKQYDVQQDEyJhY2NvdW50cy5hY2Nlc3Njb250cm9sLndpbmRvd3MubmV0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAz/w+5U4eZwenXYnEgt2rCN+753YQ7RN8ykiNprNiLl4ilpwAGLWF1cssoRflsSiBVZcCSwUzUwsifG7sbRq9Vc8RFs72Gg0AUwPsJFUqNttMg3Ot+wTqsZtE5GNSBUSqnI+iWoZfjw+uLsS0u4MfzP8Fpkd+rzRlifuIAYK8Ffi1bldkszeBzQbBZbXFwiw5uTf8vEAkH/IAdB732tQAsNXpWWYDV74nKAiwLlDS5FWVs2S2T+MPNAg28MLxYfRhW2bUpd693inxI8WTSLRncouzMImJF4XeMG2ZRZ0z/KJra/uzzMCLbILtpnLA95ysxWw+4ygm3MxN2iBM2IaJeQIDAQABoyEwHzAdBgNVHQ4EFgQU/wzRzxsifMCz54SZ3HuF4P4jtzowDQYJKoZIhvcNAQELBQADggEBACaWlbJTObDai8+wmskHedKYb3FCfTwvH/sCRsygHIeDIi23CpoWeKt5FwXsSeqDMd0Hb6IMtYDG5rfGvhkNfunt3sutK0VpZZMNdSBmIXaUx4mBRRUsG4hpeWRrHRgTnxweDDVw4Mv+oYCmpY7eZ4SenISkSd/4qrXzFaI9NeZCY7Jg9vg1bev+NaUtD3C4As6GQ+mN8Rm2NG9vzgTDlKf4Wb5Exy7u9dMW1TChiy28ieVkETKdqwXcbhqM8GOLBUFicdmgP2y9aDGjb89BuaeoHJCGpWWCi3UZth14clVzC6p7ZD6fFx5tKMOL/hQvs3ugGtvFDWCsvcT8bB84RO8=";
		String certChart = "-----BEGIN CERTIFICATE-----\n" + key + "\n-----END CERTIFICATE-----";

		try {
			byte[] decodedTokenArr = Base64.getUrlDecoder().decode(token);
			String credentials = new String(decodedTokenArr, "UTF-8");
			String credsArr[] = credentials.split("::emailTokenDelimiter::");
			String email = credsArr[0];
			String decodedToken = credsArr[1];

			LOGGER.info("Token: " + decodedToken);

			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			Certificate cert = cf.generateCertificate(
					new java.io.ByteArrayInputStream(certChart.getBytes(Charset.forName("UTF-8"))));

			Claims claims = Jwts.parser().setSigningKey(cert.getPublicKey()).parseClaimsJws(decodedToken).getBody();
			if (claims.get("unique_name").equals(email)) {
				result.setSuccess(Boolean.TRUE);
				result.setMessage("Login Succesfull");
				result.setData(email);
			} else {
				result.setSuccess(Boolean.FALSE);
				result.setMessage("Login Not Authorized! - Email token mismatch");
				LOGGER.info(
						"JwtUtil.verifyAzureTokenId(): Login Not Authorized - Email token mismatch for email " + email);
			}
		} catch (Exception e) {
			LOGGER.error("JwtUtil.verifyAzureTokenId(): Login Failure - ", e);
			result.setSuccess(Boolean.FALSE);
			result.setMessage("Login Failure! - Something went wrong");
		}
		return result;

	}
	
	public boolean refreshAzureADAuthToken() {
		try {
		key = propertiesUtil.getPropertyByName("AD_AUTH_KEY").getPropertyValue();
		return true;
		}
		catch(Exception e) {
			LOGGER.info("refreshAzureADAuthToken() : error " + e.getMessage());
		}
		return false;
	}

}