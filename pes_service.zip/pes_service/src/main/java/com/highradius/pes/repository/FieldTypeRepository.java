package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.highradius.pes.model.FieldType;

/**
 * Repository class for Field type pojo. Used for queries and crud operations.
 * @author subhayan.mukherjee
 *
 */
public interface FieldTypeRepository extends JpaRepository<FieldType, Long> {
	
    @Query("select f from FieldType f where f.id=?1")
    public FieldType getById(Long id);
    
    @Query("select f from FieldType f where f.name=?1")
    public FieldType getByName(String name);

}
