package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.TxnPlayExecutionData;

/**
 * Repository class for TxnPlayExecutionData pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface TxnPlayExecutionDataRepository extends JpaRepository<TxnPlayExecutionData, Long> {

	//Query to get txnPlayExecutionData by id
	@Query("Select t from TxnPlayExecutionData t where t.id=?1")
	public TxnPlayExecutionData getById(Long id);
	
	//Query to get txnPlayExecutionData by txnPlayExecutionId
	@Query("Select t from TxnPlayExecutionData t where t.txnPlayExecutionId=?1")
	public List<TxnPlayExecutionData> getByTxnPlayExecutionId(Long id);
	
	//Query to get txnPlayExecutionData by fieldId
	@Query("Select t from TxnPlayExecutionData t where t.fieldId=?1")
	public List<TxnPlayExecutionData> getByFieldId(Long id);
	
	//Query to get txnPlayExecutionData by fieldId and txnPlayExecutionId
	@Query("Select t from TxnPlayExecutionData t where t.txnPlayExecutionId=?1 and t.fieldId=?2")
	public TxnPlayExecutionData getByTxnIdNFieldId(Long id,Long fldId);
}
