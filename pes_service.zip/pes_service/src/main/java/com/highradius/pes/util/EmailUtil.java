package com.highradius.pes.util;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.NoSuchProviderException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;


@Component
public class EmailUtil {
	
	
	@Autowired
	private PesPropertiesUtil propertiesUtil;
	
	private JavaMailSenderImpl mailImpl= null;
	private Session session = null;
	private static Transport transport = null;
	
	/**
	 * Function to send mails to emails with attachments
	 * 
	 * @param subject: subject of the mail
	 * @param message: message in the mail
	 * @param emails: emails that need the mail sent to 
	 * @param attachments: any attachments
	 * @throws NoSuchProviderException 
	 */
	
	private static final Logger LOGGER = LogManager.getLogger(EmailUtil.class);
	//function to send mails for single instance or one time
	public void sendEmailWithAttachment(String subject, String message, String emails, String[] attachments) throws Exception {
		Map<String, String> props = new HashMap<>();
		
		String emailId = propertiesUtil.getPropertyByName("MAIL_ID").getPropertyValue();
		props.put("MAIL_ID", emailId);
		
		String emailPassword = propertiesUtil.getPropertyByName("MAIL_PASSWORD").getPropertyValue();
		props.put("MAIL_PASSWORD", emailPassword);
		
		String mailHost = propertiesUtil.getPropertyByName("MAIL_HOST").getPropertyValue();
		props.put("MAIL_HOST", mailHost);

		String mailCC = propertiesUtil.getPropertyByName("MAIL_CC").getPropertyValue();
		props.put("MAIL_CC", mailCC);

		String mailPort = propertiesUtil.getPropertyByName("MAIL_PORT").getPropertyValue();
		props.put("MAIL_PORT", mailPort);

		sendEmailWithAttachment(subject, message, emails, attachments, props);
	}
	
	//function to send multiple mails
	public void sendEmailWithAttachment(String subject, String message, String emails, String[] attachments, Map<String, String> dbProps) throws Exception {

		String emailId = dbProps.get("MAIL_ID");
		String emailPassword = dbProps.get("MAIL_PASSWORD");
		String mailHost = dbProps.get("MAIL_HOST");
		String mailCC = dbProps.get("MAIL_CC");
		Integer mailPort = Integer.parseInt(dbProps.get("MAIL_PORT"));

		if (mailImpl == null) {
			mailImpl = new JavaMailSenderImpl();
		}
		
		if(session == null) {
			LOGGER.info("Creating Session.................");
			Properties props = mailImpl.getJavaMailProperties();
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.port", mailPort);
			props.put("mail.smtp.user", emailId);
			props.put("mail.smtp.host", mailHost);
			props.put("mail.smtp.password",emailPassword);
			props.put("mail.debug", true);
			session = Session.getDefaultInstance(props, 
				    new javax.mail.Authenticator(){
		        protected PasswordAuthentication getPasswordAuthentication() {
		            return new PasswordAuthentication(
		           emailId, emailPassword);
		        }
			});
			transport = session.getTransport("smtp");
//			session.setDebug(true);
            transport.connect();
			}
		if(!transport.isConnected()) {
			LOGGER.info("Re-establising Connection.............");
			transport = session.getTransport("smtp");
			transport.connect();
		}
		Message msg = new MimeMessage(session);
		String allMail = "";
		if (!StringUtils.isEmpty(emails))
			allMail = emails + "," + mailCC;
		else
			allMail = mailCC;
		String[] mails = allMail.split(",");
		Address[] addresses = new Address[mails.length];
		for(int i = 0; i < mails.length; i++) {
			addresses[i] = new InternetAddress(mails[i]);
		}
		MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper((MimeMessage)msg, true);
			helper.setTo(mails);
			helper.setSubject(subject);
			helper.setText(message, true);
			if (attachments != null) {
				for (String attachment : attachments) {
					FileSystemResource file = new FileSystemResource(new File(attachment));
					if (file.exists()) {
						String fileName = file.getFilename();
						helper.addAttachment(fileName, file);
					}
				}
			}

			transport.sendMessage(msg,addresses);

		} catch (Exception e) {
			LOGGER.error("Exception while sending the email: "+e.getMessage()+": "+e.getStackTrace());
			e.printStackTrace();
		}

	}

//	public void sendEmailWithAttachment(String subject, String message, String emails, String[] attachments) throws Exception {
//
//		MimeMessage msg = javaMailSender.createMimeMessage();
//		emailId = propertiesUtil.getPropertyByName("MAIL_ID").getPropertyValue();
//		emailPassword = propertiesUtil.getPropertyByName("MAIL_PASSWORD").getPropertyValue();
//		mailHost = propertiesUtil.getPropertyByName("MAIL_HOST").getPropertyValue();
//		mailCC = propertiesUtil.getPropertyByName("MAIL_CC").getPropertyValue();
//		mailPort = Integer.parseInt(propertiesUtil.getPropertyByName("MAIL_PORT").getPropertyValue());
//
//		if (mailImpl == null) {
//			mailImpl = new JavaMailSenderImpl();
//			mailImpl.setPort(mailPort);
//			mailImpl.setHost(mailHost);
//			mailImpl.setUsername(emailId);
//			mailImpl.setPassword(emailPassword);
//			Properties props = mailImpl.getJavaMailProperties();
//			props.put("mail.transport.protocol", "smtp");
//			props.put("mail.smtp.auth", "true");
//			props.put("mail.smtp.starttls.enable", "true");
////	        props.put("mail.debug", "true");
//			mailImpl.setJavaMailProperties(props);
//		}
//		
//		if(session == null) {
//			Properties props = mailImpl.getJavaMailProperties();
//			props.put("mail.transport.protocol", "smtp");
//			props.put("mail.smtp.auth", "true");
//			props.put("mail.smtp.starttls.enable", "true");
//			props.put("mail.smtp.port", mailPort);
//			props.put("mail.smtp.user", emailId);
//			props.put("mail.smtp.host", mailHost);
//			props.put("mail.smtp.password",emailPassword);
//			session = Session.getInstance(props,null);
//			session.setPasswordAuthentication(
//				    new URLName("smtp", mailHost, -1, null, emailId, null),
//				    new PasswordAuthentication(emailId, emailPassword)
//				);
//            transport = session.getTransport("smtp");
//            transport.connect();
//			}
//		
//
//		String allMail = "";
//		if (!StringUtils.isEmpty(emails))
//			allMail = emails + "," + mailCC;
//		else
//			allMail = mailCC;
//		String[] mails = allMail.split(",");
//		MimeMessageHelper helper;
//		try {
//			helper = new MimeMessageHelper(msg, true);
//			helper.setTo(mails);
//			helper.setSubject(subject);
//			helper.setText(message, true);
//			if (attachments != null) {
//				for (String attachment : attachments) {
//					FileSystemResource file = new FileSystemResource(new File(attachment));
//					if (file.exists()) {
//						String fileName = file.getFilename();
//						helper.addAttachment(fileName, file);
//					}
//				}
//			}
//
//			mailImpl.send(msg);
//
//		} catch (MessagingException e) {
//			e.printStackTrace();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}

}
