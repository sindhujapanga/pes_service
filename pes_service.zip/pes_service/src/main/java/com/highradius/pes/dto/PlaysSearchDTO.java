package com.highradius.pes.dto;

import java.util.Arrays;

public class PlaysSearchDTO {
	
	private String[] playbookIds;
	
	private String[] playNames;
	
	private String[] departmentIds;

	public String[] getPlaybookIds() {
		return playbookIds;
	}

	public void setPlaybookIds(String[] playbookIds) {
		this.playbookIds = playbookIds;
	}

	public String[] getPlayNames() {
		return playNames;
	}

	public void setPlayNames(String[] playNames) {
		this.playNames = playNames;
	}

	public String[] getDepartmentIds() {
		return departmentIds;
	}

	public void setDepartmentIds(String[] departmentIds) {
		this.departmentIds = departmentIds;
	}

	@Override
	public String toString() {
		return "PlaysSearchDTO [playbookIds=" + Arrays.toString(playbookIds) + ", playNames=" + Arrays.toString(playNames)
				+ ", departmentIds=" + Arrays.toString(departmentIds) + "]";
	}
	
}
