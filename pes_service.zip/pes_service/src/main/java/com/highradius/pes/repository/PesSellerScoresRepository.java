package com.highradius.pes.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.PesSellerScores;


@Repository
/**
 * Repository class for PesSellerScores pojo. Used for queries and crud operations.
 * @author subhayan.mukherjee
 *
 */
public interface PesSellerScoresRepository
		extends JpaRepository<PesSellerScores, Long>, JpaSpecificationExecutor<PesSellerScores> {

	// Query to find records by seller name
	@Query("select p from PesSellerScores p where p.email=?1 and p.year=?2")
	public List<PesSellerScores> findBySellerEmail(String email, Long Year);

	// Query to find records by year
	@Query("select p from PesSellerScores p where p.year=?1")
	public List<PesSellerScores> findByYear(Long Year);

	// Query to get distinct employee names
	@Query("select distinct p from PesSellerScores p where p.role=?1 and p.year=?2")
	public List<PesSellerScores> getAllDistinctPlaysByRole(String role, Long year);

	// Query to get distinct employee names by year
	@Query("select p from PesSellerScores p where p.year=?1")
	public List<PesSellerScores> getAllPlays(Long year);

	// Query to get scores with seller name and start and end dates
	@Query(value = "SELECT * FROM pes_seller_scores WHERE start_date >= :startDate AND end_date <= :endDate", nativeQuery = true)
	public List<PesSellerScores> getScoresBetweenDates(@Param("startDate") LocalDateTime startDate,
			@Param("endDate") LocalDateTime endDate);
	
	// Query to get scores with seller name and start and end dates
	@Query(value = "SELECT * FROM pes_seller_scores WHERE start_date >= :startDate AND end_date <= :endDate group by play_name,role", nativeQuery = true)
	public List<PesSellerScores> getUniqueScoresBetweenDates(@Param("startDate") LocalDateTime startDate,
			@Param("endDate") LocalDateTime endDate);

	//Query to get distinct emails
	@Query(value = "SELECT DISTINCT email FROM pes_seller_scores where year=:year", nativeQuery = true)
	public List<String> findDistinctSellers(Long year);
	
	//Query to get distinct plays of each play type
	@Query(value = "SELECT * FROM pes_seller_scores where play_name in (:play1, :play2) and start_date >= :startDate AND end_date <= :endDate group by play_name,role", nativeQuery = true)
	public List<PesSellerScores> getMonthlyOnlyPlays(String play1, String play2, LocalDateTime startDate, LocalDateTime endDate);

	@Query(value = "SELECT * FROM pes_seller_scores where year=:year AND created_date=:createdDate",  nativeQuery = true)
	public List<PesSellerScores> getSellerAttainments(String year, LocalDateTime createdDate);
	
	
	
	
	
}
