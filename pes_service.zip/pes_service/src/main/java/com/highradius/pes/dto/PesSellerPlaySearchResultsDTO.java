package com.highradius.pes.dto;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.highradius.pes.model.TxnPlayExecutionData;
import com.highradius.pes.model.TxnPlayExecutionFeedback;

public class PesSellerPlaySearchResultsDTO {

	private Long id;
	private Map<String,String> play;
	private Date dateOfExecution;
	private String nameOfProspect;
	private String pesStatus;
	private String sfdcStatus;
	private String pesScore;
	private String podLeadScore;
	private String docLink;
	private String pesFeedback;
	private String podLeadFeedback;
	private String overriden;
	private String scoringFor;
	private Map<String, String> playFields = new HashMap<>();
	private List<Map<String,String>> playExecFeedback = new ArrayList<>();
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Map<String, String> getPlay() {
		return play;
	}
	public void setPlay(Map<String, String> play) {
		this.play = play;
	}
	public Date getDateOfExecution() {
		return dateOfExecution;
	}
	public void setDateOfExecution(Date dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}
	public String getNameOfProspect() {
		return nameOfProspect;
	}
	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}
	public String getPesStatus() {
		return pesStatus;
	}
	public void setPesStatus(String pesStatus) {
		this.pesStatus = pesStatus;
	}
	public String getSfdcStatus() {
		return sfdcStatus;
	}
	public void setSfdcStatus(String sfdcStatus) {
		this.sfdcStatus = sfdcStatus;
	}
	public String getPesScore() {
		return pesScore;
	}
	public void setPesScore(String pesScore) {
		this.pesScore = pesScore;
	}
	public String getPodLeadScore() {
		return podLeadScore;
	}
	public void setPodLeadScore(String podLeadScore) {
		this.podLeadScore = podLeadScore;
	}
	public String getDocLink() {
		return docLink;
	}
	public void setDocLink(String docLink) {
		this.docLink = docLink;
	}
	public String getPesFeedback() {
		return pesFeedback;
	}
	public void setPesFeedback(String pesFeedback) {
		this.pesFeedback = pesFeedback;
	}
	public String getPodLeadFeedback() {
		return podLeadFeedback;
	}
	public void setPodLeadFeedback(String podLeadFeedback) {
		this.podLeadFeedback = podLeadFeedback;
	}
	public String getOverriden() {
		return overriden;
	}
	public void setOverriden(String overriden) {
		this.overriden = overriden;
	}
	
	public String getScoringFor() {
		return scoringFor;
	}
	public void setScoringFor(String scoringFor) {
		this.scoringFor = scoringFor;
	}
	public Map<String, String> getPlayFields() {
		return playFields;
	}
	
	public void setPlayFieldsFromTxnDataList(List<TxnPlayExecutionData> txnList) {

		for(TxnPlayExecutionData t: txnList) {

			this.playFields.put(t.getFieldId().toString(), t.getValue());

		}

	}
	public List<Map<String, String>> getPlayExecFeedback() {
		return playExecFeedback;
	}
	public void setPlayExecFeedback(List<TxnPlayExecutionFeedback> txnFeedback) {

		for(TxnPlayExecutionFeedback feedback: txnFeedback) {

		   Map<String,String> map = new HashMap<>();

		   map.put("id", feedback.getId()+"");

		   map.put("criteria",feedback.getCriteria());

		   map.put("pesFeedback", feedback.getPesFeedback());

		   map.put("podLeadFeedback", feedback.getPodLeadFeedback());

		   map.put("pesFeedbackRating",feedback.getPesFeedbackRating());

		   map.put("podLeadFeedbackRating", feedback.getPodLeadFeedbackRating());

		   map.put("status", feedback.getStatus());

		   this.playExecFeedback.add(map);

		}

	}
	@Override
	public String toString() {
		return "PesSellerSearchResultsDTO [id=" + id + ", play=" + play + ", dateOfExecution=" + dateOfExecution
				+ ", nameOfProspect=" + nameOfProspect + ", scoringFor=" + scoringFor+ "pesStatus=" + pesStatus + ", sfdcStatus=" + sfdcStatus
				+ ", pesScore=" + pesScore + ", podLeadScore=" + podLeadScore + ", docLink=" + docLink
				+ ", pesFeedback=" + pesFeedback + ", podLeadFeedback=" + podLeadFeedback + ", overriden=" + overriden
				+ "]";
	}

	
	



}