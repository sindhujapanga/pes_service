package com.highradius.pes.util;

import java.io.IOException;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.FieldType;
import com.highradius.pes.model.PesSellerScores;
import com.highradius.pes.model.PesSellersReports;
import com.highradius.pes.model.TxnPlayExecutionData;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.PesSellerScoresRepository;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.color.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.property.AreaBreakType;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;

@Component
public class PdfUtil {

	@Autowired
	PesSellerScoresRepository pesSellerScoreRepository;

	@Autowired
	PesPropertiesUtil pesPropertiesUtil;

	@Autowired
	TxnPlayExecutionsRepository txnPlayExecutionsRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	private static final Logger LOGGER = LogManager.getLogger(PdfUtil.class);

	private Document document;

	private PdfFont bold;
	
	private float tableFont = 8;
	
	private float headerFont1 = 12;
	
	private float headerFont2 = 10;
	
	private Set<String> reqDynamicCols = new HashSet<>();
	
	private Map<String,String> reqComparisonCols = new HashMap<>();
	
	private Map<String,Integer> dynamicColumnsSize = new HashMap<>();
	
	private Set<String> playsWithDocLink = new HashSet<>();
	
	

	//private String pdfFolder = null;
	//private String imageLocation = null;
	//private ImageData imageData = null;
	
	public PesSellersReports createMonthlyReport(Employee emp, List<PesSellerScores> plays, 
			List<PesSellerScores> playsWithoutMonthlyExclusive,
			Map<String, Map<String, PesSellerScores>> monthlyScoreMap,
			Map<String, Map<String, PesSellerScores>> weeklyScoreMap, Map<String, List<TxnPlayExecutions>> monthlyTxns,
			Map<String, List<TxnPlayExecutions>> weeklyTxns, Map<Long, Field> fieldIdMap, Date wStartDate,
			Date wEndDate, Map<String,String> fieldIdOptionsMap,Map<String,String> properties, String sellerRole) {
		LOGGER.info("Creating Monthly Report for : " + emp.getFullName() + ".......");
		PesSellersReports report = new PesSellersReports();
		try {
			if(reqComparisonCols.size() == 0 || reqDynamicCols.size() == 0 || dynamicColumnsSize.size() == 0 
					|| playsWithDocLink.size() == 0) {
				setRequiredColumns(fieldIdMap);
			}
			Calendar cal = Calendar.getInstance();
			// Long longYear = Long.parseLong(cal.get(Calendar.YEAR) + "");
			bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
			String sellerEmail = emp.getEmail();// TODO:Change name to dynamic
			String sellerName = emp.getFullName();
			String role = sellerRole;
			int currMonth = cal.get(Calendar.MONTH) + 1;
			int currYear = currMonth - 2 == -1?cal.get(Calendar.YEAR)-1:cal.get(Calendar.YEAR);
			
			String pdfName = sellerName + "-" + role + "-" + PesConstants.Months[currMonth - 2 == -1?11:currMonth - 2] + "-"
					+ currYear;
			/*if(pdfFolder == null) {
				pdfFolder = pesPropertiesUtil.getPropertyByName("PDF_LOC").getPropertyValue();
			}*/
			String pdfFolder = properties.get("PDF_LOC");
			String pdfLocation = pdfFolder + pdfName + ".pdf";
			/*
			 if(imageLocation == null) { 
			 	imageLocation = pesPropertiesUtil.getPropertyByName("HRC_LOGO_LOC").getPropertyValue();
			 	imageData = ImageDataFactory.create(imageLocation); 
			 }*/
			String imageLocation = properties.get("HRC_LOGO_LOC");
			ImageData imageData = ImageDataFactory.create(imageLocation);
			
			Image image = new Image(imageData);
			image.setFixedPosition(540, 500);
			image.setHeight(70);
			PdfWriter writer = new PdfWriter(pdfLocation);
			PdfDocument pdf = new PdfDocument(writer);
			PageSize ps = PageSize.A4;
			document = new Document(pdf, ps.rotate());
			document.setFontSize(tableFont);
			document.setTextAlignment(TextAlignment.CENTER);
			document.add(image);
			Table table = null;

			// adding employee info table
			table = new Table(new float[] { 1, 2 }).setWidth(UnitValue.createPercentValue(30));
			Cell cell = new Cell().add(new Paragraph("Sales Rep")).setFont(bold).setFontSize(tableFont)
					.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(DeviceRgb.WHITE);
			table.addCell(cell);
			cell = new Cell().add(new Paragraph(sellerName).setFont(bold));
			table.addCell(cell);
			cell = new Cell().add(new Paragraph("Role")).setFont(bold).setFontSize(tableFont)
					.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(DeviceRgb.WHITE);
			table.addCell(cell);
			cell = new Cell().add(new Paragraph(role).setFont(bold));// TODO:Change to dynamic
			table.addCell(cell);
			cell = new Cell().add(new Paragraph("Fiscal Year")).setFont(bold).setFontSize(tableFont)
					.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(DeviceRgb.WHITE);
			table.addCell(cell);
			cell = new Cell().add(new Paragraph(currYear + "").setFont(bold));
			table.addCell(cell);
			document.add(table);

			// space between seller information table and summary table
			document.add(new Paragraph("\n\n"));
			addSummaryPage(monthlyScoreMap, plays, sellerEmail, role);
			document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
			document.add(new Paragraph(new Text("Weekly Highlights \n\n").setFontColor(PesConstants.HRCORANGE)
					.setFont(bold).setFontSize(headerFont1)).setTextAlignment(TextAlignment.CENTER));
			
			// getting the summary table for weekly tab
			Table weeklySummaryTable = getWeeklySummaryTable(playsWithoutMonthlyExclusive, sellerEmail, role, weeklyScoreMap.get(sellerEmail+"-"+role),
					wStartDate, wEndDate);
			document.add(weeklySummaryTable);
			
			// space between seller information summary and insights table
			document.add(new Paragraph("\n\n"));
			document.add(new Paragraph(
					new Text("Insights\n\n").setFont(bold).setFontSize(headerFont1).setFontColor(PesConstants.HRCGREEN)));
			
			// getting the insights table of weekly tab
			getWeeklyInsightsTable(sellerEmail, playsWithoutMonthlyExclusive, role, weeklyTxns, wStartDate, wEndDate, emp, fieldIdMap, fieldIdOptionsMap);
			document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));

			document.add(new Paragraph(new Text("Historical Insights \n\n").setFontColor(PesConstants.HRCORANGE)
					.setFont(bold).setFontSize(headerFont1)).setTextAlignment(TextAlignment.CENTER));
			
			getHistory(sellerEmail, plays, role, emp, monthlyTxns, fieldIdMap, fieldIdOptionsMap, monthlyScoreMap);
			document.close();
			// creating the report record
			report.setEmail(sellerEmail);
			report.setReportUrl(pdfLocation);
			report.setSellerName(sellerName);
			report.setType(PesConstants.MONTHLY);
		} catch (Exception e) {
			LOGGER.error("PdfUtil.createPDF(): ERROR: " + e.getMessage());
			e.printStackTrace();
			return null;
		}

		return report;
	}

	public PesSellersReports createWeeklyReport(Employee emp, List<PesSellerScores> plays,
			Map<String, Map<String, PesSellerScores>> weeklyScoreMap, Map<String, List<TxnPlayExecutions>> weeklyTxns,
			Map<Long, Field> fieldIdMap, Date wStartDate, Date wEndDate, Map<String,String> fieldIdOptionsMap, Map<String,String> properties
			,String sellerRole) {

		LOGGER.info("Creating Weekly Report for : " + emp.getFullName() + ".......");
		PesSellersReports report = new PesSellersReports();

		try {
			
			if(reqComparisonCols.size() == 0 || reqDynamicCols.size() == 0 || dynamicColumnsSize.size() == 0
					|| playsWithDocLink.size() == 0) {
				setRequiredColumns(fieldIdMap);
			}
			
			PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
			
			String sellerName = emp.getFullName();// TODO:Change name to dynamic
			String sellerEmail = emp.getEmail();
			String role = sellerRole;
			String weekName = wStartDate.getDate() +PesConstants.Months[wStartDate.getMonth()]+(wEndDate.getYear() + 1900) + "_"
					+ wEndDate.getDate() + PesConstants.Months[wEndDate.getMonth()] + (wEndDate.getYear() + 1900);
			String pdfName = sellerName + "-" + role + "-" + weekName;
			/*if(pdfFolder == null) {
				pdfFolder = pesPropertiesUtil.getPropertyByName("PDF_LOC").getPropertyValue();
			}*/
			String pdfFolder = properties.get("PDF_LOC");
			String pdfLocation = pdfFolder + pdfName + ".pdf";
			//if(imageLocation == null) {
				String imageLocation = properties.get("HRC_LOGO_LOC");//pesPropertiesUtil.getPropertyByName("HRC_LOGO_LOC").getPropertyValue();
				ImageData imageData = ImageDataFactory.create(imageLocation);
			//}
			
			Image image = new Image(imageData);
			image.setFixedPosition(540, 500);
			image.setHeight(70);
			PdfWriter writer = new PdfWriter(pdfLocation);
			PdfDocument pdf = new PdfDocument(writer);
			PageSize ps = PageSize.A4;
			document = new Document(pdf, ps.rotate());
			document.setFontSize(tableFont);
			document.setTextAlignment(TextAlignment.CENTER);

			// adding employee info table
			Table table = new Table(new float[] { 1, 2 }).setWidth(UnitValue.createPercentValue(30));
			Cell cell = new Cell().add(new Paragraph("Sales Rep")).setFont(bold).setFontSize(tableFont)
					.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(DeviceRgb.WHITE);
			table.addCell(cell);
			cell = new Cell().add(new Paragraph(sellerName).setFont(bold));
			table.addCell(cell);
			cell = new Cell().add(new Paragraph("Role")).setFont(bold).setFontSize(tableFont)
					.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(DeviceRgb.WHITE);
			table.addCell(cell);
			cell = new Cell().add(new Paragraph(role).setFont(bold));// TODO:Change to dynamic
			table.addCell(cell);
			cell = new Cell().add(new Paragraph("Fiscal Year")).setFont(bold).setFontSize(tableFont)
					.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(DeviceRgb.WHITE);
			table.addCell(cell);
			cell = new Cell().add(new Paragraph(Calendar.getInstance().get(Calendar.YEAR) + "").setFont(bold));
			table.addCell(cell);
			document.add(table);

			document.add(new Paragraph("\n\n\n\n\n"));
			document.add(new Paragraph(new Text("Weekly Highlights \n\n").setFont(bold).setFontSize(headerFont1))
					.setTextAlignment(TextAlignment.CENTER).setFontColor(PesConstants.HRCORANGE));
			document.add(image);

			// getting the summary table for weekly tab
			Table weeklySummaryTable = getWeeklySummaryTable(plays, sellerEmail, role, weeklyScoreMap.get(sellerEmail+"-"+role),
					wStartDate, wEndDate);
			document.add(weeklySummaryTable);
			
			// space between seller information summary and insights table
			document.add(new Paragraph("\n\n"));
			document.add(new Paragraph(
					new Text("Insights\n\n").setFont(bold).setFontSize(headerFont1).setFontColor(PesConstants.HRCGREEN)));
			
			// getting the insights table of weekly tab
			getWeeklyInsightsTable(sellerEmail, plays, role, weeklyTxns, wStartDate, wEndDate, emp, fieldIdMap, fieldIdOptionsMap);
			document.close();
			
			// creating report record
			report.setEmail(emp.getEmail());
			report.setReportUrl(pdfLocation);
			report.setStartDate(wStartDate);
			report.setEndDate(wEndDate);
			report.setSellerName(sellerName);
			report.setType(PesConstants.WEEKLY);
		} catch (Exception e) {
			LOGGER.error("PdfUtil.createWeeklyReport(): ERROR : " + e.getMessage());
			e.printStackTrace();
			return null;
		}
		return report;
	}

	public void addSummaryPage(Map<String, Map<String, PesSellerScores>> scoreMap, List<PesSellerScores> playRecords,
			String sellerEmail, String sellerRole) {
		Map<String, Long> playWtgMap = new HashMap<>();
		Calendar cal = Calendar.getInstance();

		// creating playName: playwtg map
		// TODO: get lookup at once for all the reports
		for (PesSellerScores playRecord : playRecords) {
			if (!StringUtils.isEmpty(playRecord.getPlayName()))
				playWtgMap.put(playRecord.getPlayName(), playRecord.getWeightage());
		}
		float[] columnSize = new float[playWtgMap.size() + 2];
		float[] attainmentLength = new float[cal.get(Calendar.MONTH)];// +1 for months and +1 for labels -1 for last
																		// month

		// for month and vertical labels
		columnSize[0] = 1f;
		columnSize[1] = 1f;
		for (int i = 0; i < attainmentLength.length; i++) {
			attainmentLength[i] = 1f;
		}
		for (int i = 0; i < playWtgMap.size(); i++) {
			columnSize[i + 2] = 2f;
		}
		document.add(new Paragraph("\n\n"));
		// creating a new table
		Text tabName = new Text("PES Summary \n\n");
		tabName.setFont(bold).setFontSize(headerFont1).setFontColor(PesConstants.HRCORANGE);
		document.add(new Paragraph(tabName).setTextAlignment(TextAlignment.CENTER));
		Table table = new Table(columnSize).setWidth(UnitValue.createPercentValue(100)).setFixedLayout();
		try {
			PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);

			// play weightageMap = number of unique plays + 2 columns for month and vertical
			// labels
			Cell cellHeader = new Cell(1, playWtgMap.size() + 2)
					.add(new Paragraph("Monthly PE Scoring Attainment Summary"))
					.setBackgroundColor(PesConstants.HRCBLUE).setFontColor(PesConstants.HRCWHITE).setFont(bold)
					.setFontSize(headerFont2);
			table.addHeaderCell(cellHeader.setTextAlignment(TextAlignment.CENTER));
			cellHeader = new Cell(3, 1).add(new Paragraph("Month")).setBackgroundColor(PesConstants.HRCORANGE, 3)
					.setFontColor(PesConstants.HRCWHITE).setFont(bold).setFontSize(tableFont);
			table.addHeaderCell(cellHeader);
			Cell cell = new Cell();

			// static code for headers
			for (int i = 0; i < 2; i++) {
				// row 1
				if (i == 0) {
					cellHeader = new Cell().add(new Paragraph("Plays")).setBackgroundColor(PesConstants.HRCORANGE, 3)
							.setFontColor(PesConstants.HRCWHITE).setFont(bold).setFontSize(tableFont);
					table.addHeaderCell(cellHeader);
					for (String play : playWtgMap.keySet()) {
						if (!StringUtils.isEmpty(play)) {
							cellHeader = new Cell().add(new Paragraph(play))
									.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
							table.addHeaderCell(cellHeader.setFontSize(tableFont).setFont(bold));
						}
					}
				}
				// row 2
				else {
					cellHeader = new Cell().add(new Paragraph("Weight Of Play"))
							.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE)
							.setFont(bold).setFontSize(tableFont);
					table.addHeaderCell(cellHeader);
					for (String play : playWtgMap.keySet()) {
						if (!StringUtils.isEmpty(play)) {
							cell = new Cell().add(new Paragraph(playWtgMap.get(play) + ""))
									.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE)
									.setFont(bold);
							table.addHeaderCell(cell);
						}
					}
				}

			}

			// going through the map wise
			for (String month : PesConstants.Months) {
				if (scoreMap.get(month + "-" + sellerEmail + "-"+sellerRole) == null)
					continue;
				Map<String, PesSellerScores> scores = scoreMap.get(month + "-" + sellerEmail+"-"+sellerRole);
				cellHeader = new Cell(2, 1).add(new Paragraph(month));
				table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
				// loop for dynamic monthly field play scored row
				cellHeader = new Cell().add(new Paragraph("Plays Scored")).setFont(bold).setFontSize(tableFont);
				table.addCell(cellHeader);

				// looping through all plays
				for (String play : playWtgMap.keySet()) {
					if (!StringUtils.isEmpty(play)) {
						String playScored = "";
						if (scores.get(play) != null)
							playScored = scores.get(play).getPlaysScored() + "";
						if (StringUtils.isEmpty(playScored) || playScored.equals("0"))
							playScored = "No Plays Scored";
						cell = new Cell().add(new Paragraph(playScored));
						table.addCell(cell);
					}
				}

				// score row
				cellHeader = new Cell().add(new Paragraph("Score")).setFont(bold).setFontSize(tableFont);
				table.addCell(cellHeader);

				// looping through all plays
				for (String play : playWtgMap.keySet()) {
					if (!StringUtils.isEmpty(play)) {
						String playScored = "";
						String score = "";
						// checking if play exists for a month
						if (scores.get(play) != null) {
							playScored = scores.get(play).getPlaysScored() + "";
							score = Math.round(scores.get(play).getAvgScore()) + "";
						}
						if (StringUtils.isEmpty(playScored) || playScored.equals("0")) {
							score = "No Plays Scored";
						}
						cell = new Cell().add(new Paragraph(score));
						table.addCell(cell);
					}
				}
				String attainment = scores.get("Attainment") == null ? "0"
						: Math.round(scores.get("Attainment").getPlayAttainmentPercentage()) + "%";

				// since number of plays = size of keys in playWtgMap and 2 extra header
				// columns, month and vertical labels
				// Overall Attainment
				cell = new Cell(1, playWtgMap.keySet().size() + 2)
						.add(new Paragraph(month + " Overall Attainment (%)							" + attainment));
				cell.setTextAlignment(TextAlignment.CENTER).setFont(bold).setFontSize(tableFont)
						.setBackgroundColor(PesConstants.HRCLORANGE, 3);
				table.addCell(cell);
			}
		} catch (IOException e) {
			LOGGER.error("PdfUtil.addSummaryPage() : ERROR: " + e.getMessage());
		}
		document.add(table);
	}

	public Table getWeeklySummaryTable(List<PesSellerScores> plays, String sellerEmail, String role,
			Map<String, PesSellerScores> playScoreMap, Date startDate, Date endDate) {
		Map<String, Long> playWtgMap = new HashMap<>();

		if(plays == null)
			System.out.println(role + " - " + sellerEmail);
		// creating play : wtg map
		for (PesSellerScores play : plays) {
			if (!StringUtils.isEmpty(play.getPlayName()))
				playWtgMap.put(play.getPlayName(), play.getWeightage());
		}
		float[] columnSize = new float[playWtgMap.size() + 1];

		// for month and vertical labels
		columnSize[0] = 1f;
		columnSize[1] = 3f;
		// for dynamic play columns adding column sizes

		for (int i = 0; i < playWtgMap.size(); i++) {
			columnSize[i + 1] = 2f;
		}

		// creating a new table
		Table table = new Table(columnSize).setWidth(UnitValue.createPercentValue(100));
		try {
			PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
			// play weightageMap = number of unique plays + 2 columns for month and vertical
			// labels
			Cell cellHeader = new Cell().add(new Paragraph("Week Of")).setBackgroundColor(PesConstants.HRCBLUE, 3)
					.setFontColor(PesConstants.HRCWHITE).setTextAlignment(TextAlignment.CENTER);
			table.addHeaderCell(cellHeader.setFont(bold).setFontSize(tableFont));
			String weekName = PesConstants.Months[startDate.getMonth()] + " " + startDate.getDate() + "-"
					+ PesConstants.Months[endDate.getMonth()] + " " + endDate.getDate() + " ,"
					+ (startDate.getYear() + 1900);
			cellHeader = new Cell(1, playWtgMap.size())
					.add(new Paragraph(new Text(weekName).setFont(bold).setFontSize(tableFont)))
					.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(PesConstants.HRCWHITE);
			table.addHeaderCell(cellHeader);
			Cell cell = new Cell();

			// static code for headers
			for (int i = 0; i < 2; i++) {
				// row 1
				if (i == 0) {
					cellHeader = new Cell().add(new Paragraph("Plays")).setFont(bold).setFontSize(tableFont);
					table.addHeaderCell(cellHeader);
					for (String play : playWtgMap.keySet()) {
						if (!StringUtils.isEmpty(play)) {
							cellHeader = new Cell().add(new Paragraph(play));
							table.addHeaderCell(cellHeader.setFontSize(tableFont).setFont(bold));
						}
					}
				}
				// row 2
				else {
					cellHeader = new Cell().add(new Paragraph("Weight Of Play")).setFont(bold).setFontSize(tableFont);
					table.addHeaderCell(cellHeader);
					for (String play : playWtgMap.keySet()) {
						if (!StringUtils.isEmpty(play)) {
							cell = new Cell().add(new Paragraph(playWtgMap.get(play) + "")).setFont(bold);
							table.addHeaderCell(cell);
						}
					}
				}

			}

			cellHeader = new Cell().add(new Paragraph("Plays Scored")).setFont(bold).setFontSize(tableFont);
			table.addCell(cellHeader);

			// looping through all plays
			for (String play : playWtgMap.keySet()) {
				if (!StringUtils.isEmpty(play)) {
					String playScored = "";
					if (playScoreMap != null && playScoreMap.get(play) != null)
						playScored = playScoreMap.get(play).getPlaysScored() + "";
					if (StringUtils.isEmpty(playScored) || playScored.equals("0"))
						playScored = "No Plays Scored";
					cell = new Cell().add(new Paragraph(playScored));
					table.addCell(cell);
				}
			}

			// score row
			cellHeader = new Cell().add(new Paragraph("Score")).setFont(bold).setFontSize(tableFont);
			table.addCell(cellHeader);

			// looping through all plays
			for (String play : playWtgMap.keySet()) {
				if (!StringUtils.isEmpty(play)) {
					String score = "";
					String playScored = "";
					// checking if play exists for a month
					if (playScoreMap != null && playScoreMap.get(play) != null) {
						score = Math.round(playScoreMap.get(play).getAvgScore()) + "";
						playScored = playScoreMap.get(play).getPlaysScored() + "";
					}
					if (StringUtils.isEmpty(score) || playScored.equals("0"))
						score = "No Plays Scored";
					cell = new Cell().add(new Paragraph(score));
					table.addCell(cell);
				}
			}
			String attainment = "0 %";
			if(playScoreMap != null)
			    attainment = playScoreMap.get("Attainment") == null ? "0 %"
					: Math.round(playScoreMap.get("Attainment").getPlayAttainmentPercentage()) + "%";

			// since number of plays = size of keys in playWtgMap and 2 extra header
			// columns, month and vertical labels
			// Overall Attainment
			cell = new Cell(1, playWtgMap.keySet().size() + 1)
					.add(new Paragraph("Weekly Attainment (%)							" + attainment));
			cell.setTextAlignment(TextAlignment.CENTER).setFont(bold).setFontSize(tableFont).setFontColor(PesConstants.HRCWHITE)
					.setBackgroundColor(PesConstants.HRCBLUE, 3);
			table.addCell(cell);

		} catch (Exception e) {
			LOGGER.error("PdfUtil.getWeeklySummaryTable() : ERROR: " + e.getMessage());
			e.printStackTrace();
		}
		return table;
	}

	// insights table code weekly
	public void getWeeklyInsightsTable(String sellerEmail, List<PesSellerScores> distinctPlays, String role,
			Map<String, List<TxnPlayExecutions>> plays, Date startDate, Date endDate, Employee emp,
			Map<Long, Field> fieldIdMap, Map<String,String> fieldIdOptionsMap) {
		float[] defaultColSize = { 2, 2, 2, 2, 2 };
		Comparator<TxnPlayExecutionData> listComparator = new Comparator<TxnPlayExecutionData>() {
			public int compare(TxnPlayExecutionData m1, TxnPlayExecutionData m2) {
				return m1.getFieldId().compareTo(m2.getFieldId());
			}
		};
		Map<String,String> txnDataMap = null;
		
		try {
			PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
			// adding headers
			Cell cell = null;
			if (plays != null) {
				for (PesSellerScores p : distinctPlays) {
					if (p == null || p.getPlayName() == null)
						continue;
					String key = emp.getEmail() + "-" + p.getPlayName() + "-" + role;
					
					document.add(new Paragraph(p.getPlayName() + "\n\n").setFont(bold).setTextAlignment(TextAlignment.CENTER)
									.setFontSize(headerFont2).setFontColor(PesConstants.HRCORANGE));
					
					if (plays.get(key) == null) 
					{	document.add(new Paragraph("No Plays To Show \n\n").setFont(bold)
								.setTextAlignment(TextAlignment.CENTER).setFontSize(tableFont).setFontColor(Color.BLACK));
						continue;
					}
					
					TxnPlayExecutions firstPlay = plays.get(key).get(0);
					for(TxnPlayExecutions txn : plays.get(key)) {
						if(firstPlay.getTxnPlayExecutionData().size() < txn.getTxnPlayExecutionData().size()) {
							firstPlay = txn;
						}
					}
					List<TxnPlayExecutionData> playData = firstPlay.getTxnPlayExecutionData();
					
					int dynamicClmSize = 0;
					if(dynamicColumnsSize.get(p.getPlayName()) != null)
						dynamicClmSize = dynamicColumnsSize.get(p.getPlayName());
					int totalColSize = defaultColSize.length + dynamicClmSize;
					
					//since if the play is one of the plays with Doc Link needed to be shown
					if(playsWithDocLink.contains(p.getPlayName()))
						totalColSize++;
					
					float[] colSize = new float[totalColSize];
					// adding all column sizes
					for (int i = 0; i < colSize.length; i++) {
						colSize[i] = 1;
					}
					Table table = new Table(colSize).setWidth(UnitValue.createPercentValue(100)).setFixedLayout();
					Cell cellHeader = new Cell().add(new Paragraph("Prospect")).setFont(bold)
							.setFontSize(tableFont);
					table.addCell(cellHeader.setBackgroundColor(PesConstants.HRCORANGE, 3)
							.setFontColor(PesConstants.HRCWHITE));
					cellHeader = new Cell().add(new Paragraph("Date")).setBackgroundColor(PesConstants.HRCORANGE, 3)
							.setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					cellHeader = new Cell().add(new Paragraph("Rating")).setBackgroundColor(PesConstants.HRCORANGE, 3)
							.setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					cellHeader = new Cell().add(new Paragraph("Feedback"))
							.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					cellHeader = new Cell().add(new Paragraph("Team name\r\n"+ "AE/SP/On-Site\r\n"+ "SP/POD leads"))
							.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					
					if(playsWithDocLink.contains(p.getPlayName())) {
						cellHeader = new Cell().add(new Paragraph("Reference Link"))
						.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
						table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					}

					//sorting playData to sync columns
                    Collections.sort(playData,listComparator);
                    
                  //check to not add any unnecessary columns if there are no dynamic columns required
                    if(dynamicClmSize != 0) {
					for (TxnPlayExecutionData data : playData) {
						Field field = fieldIdMap.get(data.getFieldId());
						String fldName = field.getDisplayName();
						if((reqComparisonCols.containsKey(field.getFieldName()) && reqComparisonCols.containsKey
								(reqComparisonCols.get(field.getFieldName())))){
							String newFldName = fldName.substring(0,fldName.indexOf("By")-1);
							cellHeader = new Cell().add(new Paragraph(newFldName))
									.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
							table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
						}
						else if(reqDynamicCols.contains(field.getFieldName())) {
							cellHeader = new Cell().add(new Paragraph(fldName))
									.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
							table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
						}
					}
                   }

					
					for (TxnPlayExecutions play : plays.get(key)) {
						cell = new Cell().add(new Paragraph(play.getNameOfProspect()).setTextAlignment(TextAlignment.LEFT));
						table.addCell(cell);
						if (play.getDateOfExecution() == null)
							cell = new Cell().add(new Paragraph(""));
						else {
							Date dateOfExec = play.getDateOfExecution();
							String date = (dateOfExec.getYear() + 1900) + "-" + (dateOfExec.getMonth() + 1) + "-"
									+ dateOfExec.getDate();
							cell = new Cell().add(new Paragraph(date));
						}

						table.addCell(cell);
						Map<String, Color> color = scoreToRating(play.getPodLeadScore());
						String colorString = color.keySet().iterator().next();
						cell = new Cell().add(new Paragraph(colorString)).setFontColor(PesConstants.HRCWHITE)
								.setBackgroundColor(color.get(colorString));
						table.addCell(cell);
						if (play.getHighLevelFeedback() != null)
							cell = new Cell().add(new Paragraph(play.getHighLevelFeedback()).setTextAlignment(TextAlignment.LEFT));
						else
							cell = new Cell().add(new Paragraph("").setTextAlignment(TextAlignment.LEFT));
						table.addCell(cell);
						
						//includes team name, ae, sp, pod lead.
						StringBuilder sellerInfo = new StringBuilder();
						if(play.getMarket() != null)
							sellerInfo.append(play.getMarket().getName()).append("\r\n");
						if(play.getTeam() != null)
							sellerInfo.append(play.getTeam().getName()).append("\r\n");
						if(play.getAe() != null)
							sellerInfo.append("AE : ").append(play.getAe().getFullName()).append("\r\n");
						if(play.getSp() != null)
							sellerInfo.append("SP : ").append(play.getSp().getFullName()).append("\r\n");
						if(play.getOnsiteSp() != null)
							sellerInfo.append("Onsite SP : ").append(play.getOnsiteSp().getFullName()).append("\r\n");
						if(play.getDta() != null)
							sellerInfo.append("DTA : ").append(play.getDta().getFullName()).append("\r\n");
						if(play.getDsa() != null)
							sellerInfo.append("DSA : ").append(play.getDsa().getFullName()).append("\r\n");
						if(play.getPodLead() != null)
							sellerInfo.append(role +" Pod Lead : ").append(play.getPodLead().getFullName()).append("\r\n");
						
						cell = new Cell().add(new Paragraph(sellerInfo.toString()).setTextAlignment(TextAlignment.LEFT));
						table.addCell(cell);
						
						if(playsWithDocLink.contains(play.getPlay().getName())) {
							if(play.getDocLink() != null) {
								cell = new Cell().add(new Paragraph(play.getDocLink()).setTextAlignment(TextAlignment.LEFT));
								cell.setFontColor(PesConstants.HRCBLUE).setUnderline();
							}
							else
								cell = new Cell().add(new Paragraph("").setTextAlignment(TextAlignment.LEFT));
							table.addCell(cell);
						}
							
						
						List<TxnPlayExecutionData> txnData = play.getTxnPlayExecutionData();
						txnDataMap = new HashMap<>();
						for(TxnPlayExecutionData data : txnData) {
							txnDataMap.put(data.getFieldId()+"", data.getValue());
						}
						Collections.sort(txnData,listComparator);
						
						//check to not add any unecessary columns if there are no dynamic columns
						if(dynamicClmSize != 0) {
						for (TxnPlayExecutionData data : play.getTxnPlayExecutionData()) {
							Field field = fieldIdMap.get(data.getFieldId());
							String dataValue = "";
							String fieldId = "";
							if((reqComparisonCols.containsKey(field.getFieldName()) && reqComparisonCols.containsKey
									(reqComparisonCols.get(field.getFieldName())))){
								String podLeadFieldId = reqComparisonCols.get(reqComparisonCols.get(field.getFieldName()));
								String pesValue = data.getValue();
								String podLeadValue = txnDataMap.get(podLeadFieldId);
								if(!StringUtils.isEmpty(podLeadValue)) {
									dataValue = podLeadValue;
									fieldId = podLeadFieldId;
								}
								else
									dataValue = pesValue;
							}
							else if(reqDynamicCols.contains(field.getFieldName())) {
								dataValue = data.getValue();
							}
							else {
								continue;
							}
							FieldType fldType = field.getFieldType();
							String cellData = null;
							if(StringUtils.isEmpty(fieldId))
								fieldId = data.getFieldId()+"";
							if(fldType.getName().equals("Select")) {
								String cellKey = fieldId + "-" + dataValue;
								cellData = fieldIdOptionsMap.get(cellKey) == null?"":fieldIdOptionsMap.get(cellKey);
							}
							else
								cellData = dataValue;
							cell = new Cell().add(new Paragraph(cellData));
							if (fldType.getName().equals("Url"))
								cell.setFontColor(PesConstants.HRCBLUE).setUnderline();
							table.addCell(cell);
						}
					}
					}
					document.add(table);
					document.add(new Paragraph("\n\n"));
				}
			}
		} catch (Exception e) {
			LOGGER.error("PdfUtil.getWeeklyInsightsTable: ERROR: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public Table getMonthlySummaryTable(Map<String, Map<String, PesSellerScores>> monthlyScoreMap,
			List<PesSellerScores> plays, String sellerEmail, String role, String month) {
		// creating play : wtg map
		Calendar cal = Calendar.getInstance();
		Map<String, PesSellerScores> playScoreMap = monthlyScoreMap.get(month + "-" + sellerEmail + "-" + role);
		Map<String, Long> playWtgMap = new HashMap<>();
		// creating play : wtg map
		for (PesSellerScores play : plays) {
			if (!StringUtils.isEmpty(play.getPlayName()))
				playWtgMap.put(play.getPlayName(), play.getWeightage());
		}
		float[] columnSize = new float[playWtgMap.size() + 1];
		// for month and vertical labels
		columnSize[0] = 1f;
		columnSize[1] = 3f;
		// for dynamic play columns adding column size
		// creating a new table
		Table table = new Table(columnSize).setWidth(UnitValue.createPercentValue(100));
		try {
			PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
			// play weightageMap = number of unique plays + 2 columns for month and vertical
			// labels
			Cell cellHeader = new Cell().add(new Paragraph("Month")).setBackgroundColor(PesConstants.HRCBLUE, 3)
					.setFontColor(PesConstants.HRCWHITE);
			table.addHeaderCell(cellHeader.setFont(bold).setFontSize(tableFont));
			cellHeader = new Cell(1, playWtgMap.size())
					.add(new Paragraph(new Text(month).setFont(bold).setFontSize(tableFont)));
			table.addHeaderCell(
					cellHeader.setBackgroundColor(PesConstants.HRCBLUE, 3).setFontColor(PesConstants.HRCWHITE));
			Cell cell = new Cell();

			// static code for headers
			for (int i = 0; i < 2; i++) {
				// row 1
				if (i == 0) {
					cellHeader = new Cell().add(new Paragraph("Plays")).setFont(bold).setFontSize(tableFont);
					table.addHeaderCell(cellHeader);
					for (String play : playWtgMap.keySet()) {
						if (!StringUtils.isEmpty(play)) {
							cellHeader = new Cell().add(new Paragraph(play));
							table.addHeaderCell(cellHeader.setFontSize(tableFont).setFont(bold));
						}
					}
				}
				// row 2
				else {
					cellHeader = new Cell().add(new Paragraph("Weight Of Play")).setFont(bold).setFontSize(tableFont);
					table.addHeaderCell(cellHeader);
					for (String play : playWtgMap.keySet()) {
						if (!StringUtils.isEmpty(play)) {
							cell = new Cell().add(new Paragraph(playWtgMap.get(play) + "")).setFont(bold);
							table.addHeaderCell(cell);
						}
					}
				}

			}

			cellHeader = new Cell().add(new Paragraph("Plays Scored")).setFont(bold).setFontSize(tableFont);
			table.addCell(cellHeader);

			// looping through all plays
			for (String play : playWtgMap.keySet()) {
				if (!StringUtils.isEmpty(play)) {
					String playScored = "";
					if (playScoreMap != null && playScoreMap.get(play) != null)
						playScored = playScoreMap.get(play).getPlaysScored() + "";
					if (StringUtils.isEmpty(playScored) || playScored.equals("0"))
						playScored = "No Plays Scored";
					cell = new Cell().add(new Paragraph(playScored));
					table.addCell(cell);
				}
			}

			// score row
			cellHeader = new Cell().add(new Paragraph("Score")).setFont(bold).setFontSize(tableFont);
			table.addCell(cellHeader);

			// looping through all plays
			for (String play : playWtgMap.keySet()) {
				if (!StringUtils.isEmpty(play)) {
					String score = "";
					String playScored = "";
					// checking if play exists for a month
					if (playScoreMap != null && playScoreMap.get(play) != null) {
						score = Math.round(playScoreMap.get(play).getAvgScore()) + "";
						playScored = playScoreMap.get(play).getPlaysScored() + "";
					}
					if (StringUtils.isEmpty(playScored) || playScored.equals("0"))
						score = "No Plays Scored";
					cell = new Cell().add(new Paragraph(score));
					table.addCell(cell);
				}
			}
			
			String attainment = playScoreMap.get("Attainment") == null ? "0 %"
					: Math.round(playScoreMap.get("Attainment").getPlayAttainmentPercentage()) + "%";

			// since number of plays = size of keys in playWtgMap and 2 extra header
			// columns, month and vertical labels
			// Overall Attainment
			cell = new Cell(1, playWtgMap.keySet().size() + 1)
					.add(new Paragraph("Monthly Attainment (%)							" + attainment));
			cell.setTextAlignment(TextAlignment.CENTER).setFont(bold).setFontSize(tableFont).setFontColor(PesConstants.HRCWHITE)
					.setBackgroundColor(PesConstants.HRCBLUE, 3);
			table.addCell(cell);

		} catch (Exception e) {
			LOGGER.error("PdfUtil.getWeeklySummaryTable() : ERROR: " + e.getMessage());
			e.printStackTrace();
		}
		return table;
	}

	// insights table code weekly
	public void getMonthlyInsightsTable(String sellerEmail, List<PesSellerScores> distinctPlays, String role,
			Employee emp, Map<String, List<TxnPlayExecutions>> plays, Map<Long, Field> fieldIdMap,
			Map<String,String> fieldIdOptionsMap,String month) {
//		Calendar cal = Calendar.getInstance();
//		cal.setTime(new Date());
//		// set day to minimum
//		cal.add(Calendar.MONTH, -1);
//		cal.set(Calendar.DATE, 1);
		Comparator<TxnPlayExecutionData> listComparator = new Comparator<TxnPlayExecutionData>() {
			public int compare(TxnPlayExecutionData m1, TxnPlayExecutionData m2) {
				return m1.getFieldId().compareTo(m2.getFieldId());
			}
		};
		Map<String,String> txnDataMap = null;
		try {
			PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
			float[] defaultColSize = { 2, 1, 1, 2, 2 };
			Cell cell = null;
			if (plays != null) {
				for (PesSellerScores distp : distinctPlays) {
					if (distp == null || distp.getPlayName() == null)
						continue;
					String key = emp.getEmail() + "-" + distp.getPlayName() + "-" + month + "-" + role;
					document.add(new Paragraph(distp.getPlayName() + "\n\n").setFont(bold)
							.setTextAlignment(TextAlignment.CENTER).setFontSize(headerFont2)
							.setFontColor(PesConstants.HRCORANGE));
					// skip if txns doesnot exist
					if (plays.get(key) == null) {
						document.add(new Paragraph("No Plays To Show \n\n").setFont(bold)
								.setTextAlignment(TextAlignment.CENTER).setFontSize(tableFont).setFontColor(Color.BLACK));
						continue;
					}
					TxnPlayExecutions firstPlay = plays.get(key).get(0);
					for(TxnPlayExecutions txn : plays.get(key)) {
						if(firstPlay.getTxnPlayExecutionData().size() < txn.getTxnPlayExecutionData().size()) {
							firstPlay = txn;
						}
					}
					List<TxnPlayExecutionData> playData = firstPlay.getTxnPlayExecutionData();
					Collections.sort(playData, listComparator);
					int dynamicClmSize = 0;
					if (dynamicColumnsSize.get(distp.getPlayName()) != null)
						dynamicClmSize = dynamicColumnsSize.get(distp.getPlayName());
					
                    int totalColSize = defaultColSize.length + dynamicClmSize;
					
					//since if the play is one of the plays with Doc Link needed to be shown
					if(playsWithDocLink.contains(distp.getPlayName()))
						totalColSize++;
					
					float[] colSize = new float[totalColSize];

					for (int i = 0; i < colSize.length; i++) {
						colSize[i] = 1;
					}
					Table table = new Table(colSize).setWidth(UnitValue.createPercentValue(100)).setFixedLayout();					// adding headers
					Cell cellHeader = new Cell().add(new Paragraph("Prospect"))
							.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					cellHeader = new Cell().add(new Paragraph("Date")).setBackgroundColor(PesConstants.HRCORANGE, 3)
							.setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					cellHeader = new Cell().add(new Paragraph("Rating")).setBackgroundColor(PesConstants.HRCORANGE, 3)
							.setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					cellHeader = new Cell().add(new Paragraph("Feedback"))
							.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
					table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
                    cellHeader = new Cell().add(new Paragraph("Team name\r\n" + "AE/SP/On-Site\r\n" + "SP/POD leads"))
                                     .setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
                    table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
                    
                    if(playsWithDocLink.contains(distp.getPlayName())) {
						cellHeader = new Cell().add(new Paragraph("Reference Link"))
						.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
						table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
					}
                     
                     //check to not add any unecessary columns if there are no dynamic columns
                     if(dynamicClmSize != 0) {
                    	 
					// adding dynamic table columns
                     for (TxnPlayExecutionData data : playData) {
 						Field field = fieldIdMap.get(data.getFieldId());
 						String fldName = field.getDisplayName();
 						if((reqComparisonCols.containsKey(field.getFieldName()) && reqComparisonCols.containsKey
 								(reqComparisonCols.get(field.getFieldName())))){
 							//for columns with name ..... By PES Agent/ By Pod Lead
 							String newFldName = fldName.substring(0,fldName.indexOf("By")-1);
 							cellHeader = new Cell().add(new Paragraph(newFldName))
 									.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
 							table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
 						}
 						else if(reqDynamicCols.contains(field.getFieldName())) {
 							cellHeader = new Cell().add(new Paragraph(fldName))
 									.setBackgroundColor(PesConstants.HRCORANGE, 3).setFontColor(PesConstants.HRCWHITE);
 							table.addCell(cellHeader.setFont(bold).setFontSize(tableFont));
 						}
 					}
                  }
                     
					for (TxnPlayExecutions play : plays.get(key)) {
						cell = new Cell().add(new Paragraph(play.getNameOfProspect()).setTextAlignment(TextAlignment.LEFT));
						table.addCell(cell);
						if (play.getDateOfExecution() == null)
							cell = new Cell().add(new Paragraph(""));
						else {
							Date dateOfExec = play.getDateOfExecution();
							String date = (dateOfExec.getYear() + 1900) + "-" + (dateOfExec.getMonth() + 1) + "-"
									+ dateOfExec.getDate();
							cell = new Cell().add(new Paragraph(date));
						}
						table.addCell(cell);
						Map<String, Color> color = scoreToRating(play.getPodLeadScore());
						String colorString = color.keySet().iterator().next();
						cell = new Cell().add(new Paragraph(colorString)).setFontColor(PesConstants.HRCWHITE)
								.setBackgroundColor(color.get(colorString));
						table.addCell(cell);
						if (play.getHighLevelFeedback() != null)
							cell = new Cell().add(new Paragraph(play.getHighLevelFeedback()).setTextAlignment(TextAlignment.LEFT));
						else
							cell = new Cell().add(new Paragraph("").setTextAlignment(TextAlignment.LEFT));
						table.addCell(cell);
						
						//includes team name, ae, sp, pod lead.
						StringBuilder sellerInfo = new StringBuilder();
						if(play.getMarket() != null)
							sellerInfo.append(play.getMarket().getName()).append("\r\n");
						if(play.getTeam() != null)
							sellerInfo.append(play.getTeam().getName()).append("\r\n");
						if(play.getAe() != null)
							sellerInfo.append("AE : ").append(play.getAe().getFullName()).append("\r\n");
						if(play.getSp() != null)
							sellerInfo.append("SP : ").append(play.getSp().getFullName()).append("\r\n");
						if(play.getOnsiteSp() != null)
							sellerInfo.append("Onsite SP : ").append(play.getOnsiteSp().getFullName()).append("\r\n");
						if(play.getDta() != null)
							sellerInfo.append("DTA : ").append(play.getDta().getFullName()).append("\r\n");
						if(play.getDsa() != null)
							sellerInfo.append("DSA : ").append(play.getDsa().getFullName()).append("\r\n");
						if(play.getPodLead() != null)
							sellerInfo.append(role +" Pod Lead : ").append(play.getPodLead().getFullName()).append("\r\n");
						
						cell = new Cell().add(new Paragraph(sellerInfo.toString()).setTextAlignment(TextAlignment.LEFT));
						table.addCell(cell);
						
						if(playsWithDocLink.contains(play.getPlay().getName())) {
							if(play.getDocLink() != null) {
								cell = new Cell().add(new Paragraph(play.getDocLink()).setTextAlignment(TextAlignment.LEFT));
								cell.setFontColor(PesConstants.HRCBLUE).setUnderline();
							}
							else
								cell = new Cell().add(new Paragraph("").setTextAlignment(TextAlignment.LEFT));
							table.addCell(cell);
						}
						
						List<TxnPlayExecutionData> txnData = play.getTxnPlayExecutionData();
						Collections.sort(txnData,listComparator);
						txnDataMap = new HashMap<>();
                        for(TxnPlayExecutionData data : txnData) {
                                txnDataMap.put(data.getFieldId()+"", data.getValue());
                        }
                        
                      //check to not add any unecessary columns if there are no dynamic columns
                        if(dynamicClmSize != 0) {
						for (TxnPlayExecutionData data : play.getTxnPlayExecutionData()) {
							Field field = fieldIdMap.get(data.getFieldId());
							String dataValue = "";
							String fieldId = "";
							if((reqComparisonCols.containsKey(field.getFieldName()) && reqComparisonCols.containsKey
									(reqComparisonCols.get(field.getFieldName())))){
								String podLeadFieldId = reqComparisonCols.get(reqComparisonCols.get(field.getFieldName()));
								String pesValue = data.getValue();
								String podLeadValue = txnDataMap.get(podLeadFieldId);
								if(!StringUtils.isEmpty(podLeadValue)) {
									dataValue = podLeadValue;
									fieldId = podLeadFieldId;
								}
								else
									dataValue = pesValue;
							}
							else if(reqDynamicCols.contains(field.getFieldName())) {
								dataValue = data.getValue();
							}
							else {
								continue;
							}
							FieldType fldType = field.getFieldType();
							String cellData = null;
							if(StringUtils.isEmpty(fieldId))
								fieldId = data.getFieldId()+"";
							if(fldType.getName().equals("Select")) {
								String cellKey = fieldId + "-" + dataValue;
								cellData = fieldIdOptionsMap.get(cellKey) == null?"":fieldIdOptionsMap.get(cellKey);
							}
							else
								cellData = dataValue;
							cell = new Cell().add(new Paragraph(cellData));
							if (fldType.getName().equals("Url"))
								cell.setFontColor(PesConstants.HRCBLUE).setUnderline();
							table.addCell(cell);
						}
                      }
					}
					document.add(table);
					document.add(new Paragraph("\n\n"));
				}
			}
		} catch (Exception e) {
			LOGGER.error("PdfUtil.getWeeklyInsightsTable: ERROR: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void getHistory(String sellerEmail, List<PesSellerScores> distinctPlays, String role,
			Employee emp, Map<String, List<TxnPlayExecutions>> plays, Map<Long, Field> fieldIdMap,
			Map<String,String> fieldIdOptionsMap, Map<String, Map<String, PesSellerScores>> monthlyScoreMap) {
		Date currentDate = new Date();
		int currMonthIndex = currentDate.getMonth() == 0? 12: currentDate.getMonth();
		for(int i = currMonthIndex-1; i > -1; i--) {
			String month = PesConstants.Months[i];
			Map<String, PesSellerScores> scoreMap = monthlyScoreMap.get(month + "-" + sellerEmail + "-" + role);
			
			if(scoreMap != null) {
				document.add(new Paragraph(new Text(month+"\n\n").setFontColor(PesConstants.HRCORANGE)
						.setFont(bold).setFontSize(headerFont2)).setTextAlignment(TextAlignment.CENTER));
				// getting the summary table for weekly tab
				Table monthlySummaryTable = getMonthlySummaryTable(monthlyScoreMap, distinctPlays, sellerEmail, role, month);
				document.add(monthlySummaryTable);
				document.add(new Paragraph("\n\n"));
				document.add(new Paragraph(
						new Text("Insights\n\n").setFont(bold).setFontSize(headerFont1).setFontColor(PesConstants.HRCGREEN)));
				
				// getting the insights table of weekly tab
				getMonthlyInsightsTable(sellerEmail, distinctPlays, role, emp, plays, fieldIdMap, fieldIdOptionsMap, month);
				document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
			}
		}
		
	}


	public Map<String, Color> scoreToRating(String score) {
		Map<String, Color> color = new HashMap<>();
		if (score.equals(PesConstants.GREEN))
			color.put(PesConstants.GREEN, PesConstants.HRCGREEN);
		else if (score.equals(PesConstants.YELLOW))
			color.put(PesConstants.YELLOW, PesConstants.HRCYELLOW);
		else
			color.put(PesConstants.RED, PesConstants.HRCRED);
		return color;
	}
	
	public void setRequiredColumns(Map<Long,Field> fieldIdMap) {
		// Set of Dynamic fields across all plays that need to be added to respective play reports
		reqDynamicCols.add("linkToChorusAiRec");
		reqDynamicCols.add("opportunityName");
		
		/*
		 * Map of Dynamic fields which have both Pod Lead part and Pes part and these two parts need to be compared
		 * Key is field for PES Agent : Value is field name of POD lead
		 */
		reqComparisonCols.put("discoveryCallOutcomePesAgent", "discoveryCallOutcomePodLead");
		reqComparisonCols.put("outcomeRationalePesAgent", "outcomeRationalePodLead");
		reqComparisonCols.put("buyerModePesAgent", "buyerModePodLead");
		
		//Setting the number of dynamic columns required for each play
		dynamicColumnsSize.put("Discovery STRAP",1);
		dynamicColumnsSize.put("Discovery Execute Call", 4);
		dynamicColumnsSize.put("OTC Whitespace Analysis - GI Stage", 1);
		dynamicColumnsSize.put("OTC Whitespace Analysis - FA Stage", 1);
		dynamicColumnsSize.put("OTC Whitespace Web Research", 1);
		
		/*
		 * Creating set for unique plays which require the doc link/reference link in their report
		 */
		playsWithDocLink.add("Champions");
		playsWithDocLink.add("ZZTop");
		playsWithDocLink.add("STRAP");
		
		
		Set<String> podLeadClmNames = new HashSet<>(reqComparisonCols.values());
		//adding ids for the podlead names in reqComparisonCols as values with key as column name
		for(Long id : fieldIdMap.keySet()) {
			Field field = fieldIdMap.get(id);
			String fieldName = field.getFieldName();
			if(podLeadClmNames.contains(fieldName)) {
				reqComparisonCols.put(fieldName, field.getId()+"");
			}
		}
	}

}