package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.MapPlayFields;

/**
 * Repository class for PlayFieldsMap pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface MapPlayFieldsRepository extends JpaRepository<MapPlayFields, Long> {
	
	//Query to get PlayFieldsMap with id
		@Query("select p from MapPlayFields p where p.id=?1")
		public MapPlayFields getById(Long id);
		
		//Query to get PlayFieldsMap with play id
		@Query("select p from MapPlayFields p where p.playId=?1")
		public List<MapPlayFields> getByPlayId(Long id);
		
		//Query to get PlayFieldsMap with field id
		@Query("select p from MapPlayFields p where p.fieldId=?1")
		public List<MapPlayFields> getByFieldId(Long id);
		
		//Query to get distict play ids
		//@Query("select distinct p.playId from MapPlayFields p")
		@Query(value = "SELECT DISTINCT play_id FROM map_play_fields", nativeQuery = true)
		public List<Long> getDistinctPlayId();
		
		//Query to get distinct field ids for play ids
		@Query("select p.fieldId from MapPlayFields p where p.playId=?1")
		public List<Long> getFieldIdsWithPlayId(Long playId);

}
