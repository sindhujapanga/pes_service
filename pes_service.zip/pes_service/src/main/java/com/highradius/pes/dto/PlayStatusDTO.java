package com.highradius.pes.dto;

import java.util.Arrays;

import org.json.simple.JSONObject;

public class PlayStatusDTO {

	private String[] plays;
	private String nameOfProspect;
	private String createdDateStart;
	private String createdDateEnd;
	private String pesRating;
	private String pesStatus;
	private String podLeadRating;
	private String[] sellerIds;
	
	public String[] getPlays() {
		return plays;
	}
	public void setPlays(String[] plays) {
		this.plays = plays;
	}
	public String getNameOfProspect() {
		return nameOfProspect;
	}
	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}
	public String getCreatedDateStart() {
		return createdDateStart;
	}
	public void setCreatedDateStart(String createdDateStart) {
		this.createdDateStart = createdDateStart;
	}
	public String getCreatedDateEnd() {
		return createdDateEnd;
	}
	public void setCreatedDateEnd(String createdDateEnd) {
		this.createdDateEnd = createdDateEnd;
	}
	public String getPesRating() {
		return pesRating;
	}
	public void setPesRating(String pesRating) {
		this.pesRating = pesRating;
	}
	public String getPesStatus() {
		return pesStatus;
	}
	public void setPesStatus(String pesStatus) {
		this.pesStatus = pesStatus;
	}
	public String getPodLeadRating() {
		return podLeadRating;
	}
	public void setPodLeadRating(String podLeadRating) {
		this.podLeadRating = podLeadRating;
	}	
	public String[] getSellerIds() {
		return sellerIds;
	}
	public void setSellerIds(String[] sellerIds) {
		this.sellerIds = sellerIds;
	}
	@Override
	public String toString() {
		return "PlayStatusDTO [plays=" + Arrays.toString(plays) + ", nameOfProspect=" + nameOfProspect
				+ ", createdDateStart=" + createdDateStart + ", createdDateEnd=" + createdDateEnd + ", pesRating="
				+ pesRating + ", pesStatus=" + pesStatus + ", podLeadRating=" + podLeadRating + ", sellerIds=" + sellerIds
				+ "]";
	}
	
}
