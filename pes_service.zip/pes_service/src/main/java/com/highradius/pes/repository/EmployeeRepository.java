package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Employee;

/**
 * Repository class for Employee pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>, JpaSpecificationExecutor<Employee> {

	// Query to get employee by Id
	@Query("select e from Employee e where e.id=?1 and e.status='Active'")
	public Employee getById(Long id);

	// Query to get employee by full name
	@Query("select e from Employee e where e.fullName=?1 and e.status='Active'")
	public Employee findByFullName(String name);

	// Query to get employee by SF user Id
	@Query("select e from Employee e where e.sf18CharId=?1 and e.status='Active'")
	public Employee findBySf18Id(String userId);

	// Query to get employee by EmpId
	@Query("select e from Employee e where e.empId=?1 and e.status='Active'")
	public Employee findByEmpId(Long empId);

	// Query to get employee by EmailId
	@Query("select e from Employee e where e.email=?1 and e.status='Active'")
	public Employee findByEmailId(String email);

	// Query to delete employee by empId
	@Query("Delete from Employee e where e.empId=?1 and e.status='Active'")
	public void deleteByEmpId(Long empId);

	// Query to get employee list from functional role
	@Query("select e from Employee e where e.fnRole.id=?1 and e.status='Active'")
	public List<Employee> getByFunctionalRole(Long fnId);

	// Query to get distinct employee names
	@Query("select distinct e from Employee e where e.status='Active' and e.id != -1")
	public List<Employee> getAllDistinctEmployeeNames();

	// Query to get distinct sf user ids
	@Query("select distinct e.sfUserId from Employee e where e.status='Active' and e.id != -1")
	public List<String> getAllDistinctSfUserId();

	// Query to get distinct profileNames
	@Query("select distinct e.profileName from Employee e where e.status='Active' and e.id != -1")
	public List<String> getAllDistinctProfileNames();

	// Query to get distinct employee email ids
	@Query("select distinct e.email from Employee e where e.status='Active' and e.id != -1")
	public List<String> getAllDistinctEmailIds();

	// overriding findAll function
	@Query("select e from Employee e where e.status='Active' and e.id != -1")
	public List<Employee> findAll();
	
	@Query("select e from Employee e where e.id != -1")
	public List<Employee> getActiveAndInactiveEmployees();

	// For sales force records
	@Query("select e from Employee e where e.sf18CharId=?1 and e.id != -1")
	public Employee findBySf18IdForSF(String userId);

	// getting sellers list
	@Query(value = "SELECT * FROM lu_employee e,lu_functional_role f WHERE e.id != -1 and e.fn_role_id = f.id AND f.name IN ('AE','SP','Onsite SP','DSA','DTA')", nativeQuery = true)
	public List<Employee> getSellersList();
	
	 @Query("SELECT e FROM Employee e WHERE e.id IN (:ids)")
	List<Employee> findEmployeeByIds(@Param("ids")List<Long> ids);
	 
	@Query("Select e from Employee e where e.podLeadId =?1 and e.status='Active'")
	List<Employee> getReporteeList(Long id);

}
