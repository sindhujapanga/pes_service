package com.highradius.pes.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.highradius.pes.dto.DiscoveryCallDTO;
import com.highradius.pes.model.Employee;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.service.PesSalesSFDCService;
import com.highradius.pes.util.PesPropertiesUtil;

@Service
public class PesSalesSFDCServiceimpl implements PesSalesSFDCService {
	@Autowired
	PesPropertiesUtil propertiesService;
	
	@Autowired
	EmployeeRepository empRepo;
	
	private static final Logger LOGGER = LogManager.getLogger(PesSalesForceServiceImpl.class);
	
	public Date getDCFilterDate() {
		try {
		String dayNames[] = new DateFormatSymbols().getWeekdays(); 
		TimeZone tz = TimeZone.getTimeZone("Asia/Kolkata");
		Calendar cal = Calendar.getInstance(tz);  
		
		System.out.println("Today is "+ dayNames[cal.get(Calendar.DAY_OF_WEEK)]); 
		
		Date filetrDate = new Date();
		String day = dayNames[cal.get(Calendar.DAY_OF_WEEK)];
		int noOfDays = -2;
		if(day.equals("Sunday")){
			noOfDays = -4;
		} if(day.equals("Monday") || day.equals("Tuesday")) {
			noOfDays = -4;
		}
		cal.add(Calendar.DATE, noOfDays);
		String fltrDtStr = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH)+1) + "-" + cal.get(Calendar.DATE);
		filetrDate = new SimpleDateFormat("yyyy-MM-dd").parse(fltrDtStr);
		
		return filetrDate;
		}catch(Exception e) {
			LOGGER.info("Error in fetching filter date");
			return null;
		}
	}
//
//	@Override
//	public List<DiscoveryCallDTO> getSFDCReportData(String start, String end) {
//		// TODO Auto-generated method stub
//		String reportId = propertiesService.getPropertyByName("MIDMARKET_REPORT_ID").getPropertyValue();
//		String url = constructSOQLQuery(jsonObj,soql);
//		List<String> reportData = getSFDCData(reportId);
//		Date startDate = null;
//		Date endDate = null;
//		if(start != null) {
//			try {
//			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
//			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
//			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
//			}
//			catch(Exception e) {
//				LOGGER.error("Error in getting manual filter dates");
//			}
//		}
//		//new arraylist to add the fetched records
//		List<DiscoveryCallDTO> recList = new ArrayList<>();
//		for(String json : reportData) {
//			try {
//				Date filterDate = getDCFilterDate();
////				 List<Employee> allSellers = empRepo.findAll();
////			        Map<String,String> nameSfIdMap = new HashMap<>();
////			        for(Employee emp: allSellers) {
////			        	nameSfIdMap.put(emp.getFullName(), emp.getSf18CharId());
////			        }
//			    //getting the Array from the Json
//				JSONArray jsonArray = new JSONArray(json);
//				//checking the length
//				if(jsonArray.length()>0) {
//					//get jsonObject from jsonArray
//					JSONObject jsonObj = jsonArray.getJSONObject(0);
//					//get the "records" array from the JsonObj
//					JSONArray array = jsonObj.getJSONArray("records");
//					//// iterating through records of array 
//					for(int i=0; i<array.length();i++) {
//						try {
//							//get json Object from the array
//							JSONObject rec = array.getJSONObject(i);
//							//
//							DiscoveryCallDTO reportRecord = new DiscoveryCallDTO();
//							//
//							String nameOfProspect = rec.getJSONObject("Lead__r").getString("Company");
//							String dcId = rec.get("Name").toString();
//							String ae = rec.get("AE__c").toString();
//							String sp = rec.get("SP__c").toString();
//							//String activityId = rec.get("Id").toString();
//	//						String aeSf = "";
//	//						String spSf = "";
//	//						if(!StringUtils.isEmpty(ae)) {
//	//							aeSf = nameSfIdMap.get(ae);
//	//						}
//	//						if(!StringUtils.isEmpty(sp)) {
//	//							spSf = nameSfIdMap.get(sp);
//	//						}
//							
//							String sfdcStatus = rec.getString("DC_Status__c");
//							String tam = rec.getJSONObject("Lead__r").getString("TAM__c");
//							String aeTeam = rec.get("AE_Team__c").toString();
//							String execDate = rec.get("Start_Date__c").toString();
//							if(execDate!= null && !execDate.contains("null")){
//								Date dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(execDate.toString());
//								//								LocalDate date = LocalDate.parse(execDate,
//								//										DateTimeFormatter.ofPattern("yyyy-MM-dd"));
//								java.sql.Date dateOfExec = new java.sql.Date(dateOfExecution.getTime());
//								/*checking if the startdate and dateof exec are equal or not
//								 * < 0 if the date is before the given date and > 0 if date is after the given date
//								 */				
//								if (startDate != null
//										&& (startDate.compareTo(dateOfExec) <= 0 && endDate.compareTo(dateOfExec) >= 0)) {
//									reportRecord.setDateOfExecution(dateOfExec.toString()+'T');
//								} else if (startDate == null && filterDate.compareTo(dateOfExec) != 0) {
//									reportRecord.setDateOfExecution(dateOfExec.toString()+'T');
//								}
//								else
//									continue;
//							}
//							else 
//								reportRecord.setDateOfExecution("");
//							
//							if(dcId != null) 
//								reportRecord.setDcId(dcId);
//							else
//								reportRecord.setDcId("");
//													
//							if(sp != null) 
//								reportRecord.setSpSfId(sp);
//							else
//								reportRecord.setSpSfId("");
//							if(ae != null)
//								reportRecord.setAeSfId(ae);
//							else
//								reportRecord.setAeSfId("");
//							if(sfdcStatus != null)
//								reportRecord.setSfdcStatus(sfdcStatus);
//							else
//								reportRecord.setSfdcStatus("");
//							if(aeTeam != null)
//								reportRecord.setTeam(aeTeam);
//							else
//								reportRecord.setTeam("");
//							if (nameOfProspect!=null)
//								reportRecord.setNameOfProspect(nameOfProspect);
//							else
//								reportRecord.setNameOfProspect("");
//							if(tam != null)
//								reportRecord.setMarket(tam);
//							else
//								reportRecord.setMarket("");
//								//reportRecord.setActivityId(activityId);
//							recList.add(reportRecord);
//						}
//						
//						catch(Exception e) {
//							LOGGER.error("PesSalesSFDCServiceImpl.getSFDCReportData(): ERROR: " + e.getMessage());
//						}
//						
//						
//					}
//					LOGGER.info("No. of records queried - " + recList.size());
//					
//				}
//			}
//			catch (Exception e) {
//				LOGGER.error(e.getMessage(), e);
//			}
//			
//		
//		}
//		return recList;
//		
//	}
		
//	
//	public List<String> getSFDCData(String reportId){
//	List<String> reportData = new ArrayList<>();
//		try {
//			String jsonData = getReportFilter(reportId);
//			JSONObject jsonObj = new JSONObject(jsonData);
//			String url = constructSOQLQuery(jsonObj,soql);
//			List<String> records = getReportData(url);
//			reportData.add(records.toString());
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		
//		return reportData;
//		
//	}
	
	public String getReportFilter(String reportId) throws ClientProtocolException, IOException {
		// TODO Auto-generated method stub
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		//reportId = propertiesService.getPropertyByName("MIDMARKET_REPORT_ID").getPropertyValue();
		int timeout = 500;
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
				.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
			HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId + "/describe");
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		httpClient.execute(request);
		response = httpClient.execute(request);
		String json = EntityUtils.toString(response.getEntity());
		JSONObject resp = new JSONObject(json);
		JSONObject metaData = resp.getJSONObject("reportMetadata");
		//JSONArray jsonArray = metaData.getJSONArray("reportFilters");  
		//LOGGER.info("Resp " + jsonArray);
		return metaData.toString();
	}

	public static String constructSOQLQuery(JSONObject filterJson, String soql) {
			
		// getting the array from the JSON Object and storing it into a JSON Array
			JSONArray arrayValues = filterJson.getJSONArray("reportFilters");
			Map<Integer, String> map = new HashMap<>();
			int count = 1;
			 
			// iterating json array
			for (int i = 0; i < arrayValues.length(); i++) {
				// Storing each object in a string
				JSONObject rowObj = arrayValues.getJSONObject(i);
				//getting the string from the jsonobj 
				String columnValue = rowObj.getString("value");
				/*
				 *  {eg : "value" : 'disqualified', 'converted, notconverted}
				 *  split the each string in a value
				 *  \s* represents a whitespace
				 * 
				 */
				
				String[] split = columnValue.split(",\\s*");
				StringBuilder result = new StringBuilder();
				//iterating each and value and appending it with the single quotes for start and end of a string
				for(String stringValue : split) {
					result.append("'").append(stringValue.trim()).append("'").append(",");
				}
				//removing the comma at the end of the string
				if(result.length()>0) {
					result.setLength(result.length()-1);
				}
				result.insert(0,'(').append(')');
				if(rowObj.getString("column").contains("Lead")) {				
					rowObj.getString("operator").replace("contains", "like");
				}
				if(rowObj.getString("column").contains("Lead__r.Market_Type__c")) {
					rowObj.getString("operator").replace("equals", "like");
				}
				String filters = rowObj.getString("column").replace("Discovery_Call__c.","").replace("Lead", "Lead__r").replace("FTA__c", "FTA__r")
						+ rowObj.getString("operator").replace("equals", " IN ").replace("contains", " IN ")
						.replace("notContain", " NOT IN")+ result;
				map.put(count, filters);
				count++;
							
				}
			
			StringBuilder soqlQuery = new StringBuilder(soql);
			String filterCondition = filterJson.getString("reportBooleanFilter");
			filterCondition = replaceNumeric(filterCondition, map);
			soqlQuery.append(filterCondition.toString());

		String url = "https://highradius.my.salesforce.com/services/data/v59.0/query/?q=" + URLEncoder.encode(soqlQuery.toString(), StandardCharsets.UTF_8);
		return url;
		
	}

	private static String replaceNumeric(String filterCondition, Map<Integer, String> map) {
		//define a regular expression to find numeric values in the filtercondition
		Pattern p = Pattern.compile("\\b(\\d+)\\b");
		//use a matcher to find and replace numeric value
		Matcher matcher = p.matcher(filterCondition);
		StringBuffer result = new StringBuffer();
		while(matcher.find()) {
			int key = Integer.parseInt(matcher.group(1));
			//check if map contains key
			if(map.containsKey(key)) {
				matcher.appendReplacement(result, Matcher.quoteReplacement(map.get(key)));
			}
		}
		//appending to the result
		matcher.appendTail(result);
		return result.toString();
		
	}
	
	public List<String> getReportData(String url){
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		List<String> records = new ArrayList<>();
		
		try {
			URL stringUrl = new URL(url);
			HttpURLConnection connection = (HttpURLConnection) stringUrl.openConnection();
			connection.addRequestProperty("Authorization", "Bearer " + authToken);
			connection.setRequestMethod("GET");
			//int responseCode = connection.getResponseCode();
			//if(responseCode == HttpURLConnection.HTTP_OK) {
			 BufferedReader reader = new BufferedReader(new InputStreamReader(
				                     connection.getInputStream()));
			 StringBuilder response = new StringBuilder();
				String inputLine;
				while ((inputLine = reader.readLine()) != null) {
					//records.add(inputLine);
				 response.append(inputLine);
			}
			reader.close();
			records.add(response.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return records;
		
	}
	
	public List<String> getSFDCReportData(String reportId, String soql) {
		List<String> reportData = new ArrayList<>();
		try {
			//get the report filters
			String jsonData = getReportFilter(reportId);
			JSONObject jsonObj = new JSONObject(jsonData);
			String url = constructSOQLQuery(jsonObj,soql);
			List<String> records = getReportData(url);
			reportData.add(records.toString());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return reportData;
		
	}
	/*
	 * getReport1Data() refers to the MIDMarket Report
	 */
	@Override
	public List<DiscoveryCallDTO> getReport1Data(String start, String end) {
		String reportId  = propertiesService.getPropertyByName("MIDMARKET_REPORT_ID").getPropertyValue();
		String soql = "SELECT Id,Lead__r.Company,name,Start_Date__c,SP__c,AE__c,DC_Status__c,Lead__r.TAM__c,AE_Team__c FROM Discovery_Call__c where ";
		List<String> reportData = getSFDCReportData(reportId,soql);
		Date startDate = null;
		Date endDate = null;
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}
			catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		//new arraylist to add the fetched records
		List<DiscoveryCallDTO> recList = new ArrayList<>();
		for(String json : reportData) {
			try {
				Date filterDate = getDCFilterDate();
			    //getting the Array from the Json
				JSONArray jsonArray = new JSONArray(json);
				//checking the length
				if(jsonArray.length()>0) {
					//get jsonObject from jsonArray
					JSONObject jsonObj = jsonArray.getJSONObject(0);
					//get the "records" array from the JsonObj
					JSONArray array = jsonObj.getJSONArray("records");
					//// iterating through records of array 
					for(int i=0; i<array.length();i++) {
						try {
							//get json Object from the array
							JSONObject rec = array.getJSONObject(i);
							//
							DiscoveryCallDTO reportRecord = new DiscoveryCallDTO();
							//
							String nameOfProspect = rec.getJSONObject("Lead__r").getString("Company");
							String dcId = rec.get("Name").toString();
							String ae = rec.get("AE__c").toString();
							String sp = rec.get("SP__c").toString();
							String activityId = rec.get("Id").toString();
							String sfdcStatus = rec.getString("DC_Status__c");
							String tam = rec.getJSONObject("Lead__r").getString("TAM__c");
							String aeTeam = rec.get("AE_Team__c").toString();
							if(activityId!=null) 
								reportRecord.setActivityId(activityId);
							else
								reportRecord.setActivityId("");
							if(dcId != null) 
								reportRecord.setDcId(dcId);
							else
								reportRecord.setDcId("");
													
							if(sp != null) 
								reportRecord.setSpSfId(sp);
							else
								reportRecord.setSpSfId("");
							if(ae != null)
								reportRecord.setAeSfId(ae);
							else
								reportRecord.setAeSfId("");
							if(sfdcStatus != null)
								reportRecord.setSfdcStatus(sfdcStatus);
							else
								reportRecord.setSfdcStatus("");
							if(aeTeam != null)
								reportRecord.setTeam(aeTeam);
							else
								reportRecord.setTeam("");
							if (nameOfProspect!=null)
								reportRecord.setNameOfProspect(nameOfProspect);
							else
								reportRecord.setNameOfProspect("");
							if(tam != null)
								reportRecord.setMarket(tam);
							else
								reportRecord.setMarket("");
							String execDate = rec.get("Start_Date__c").toString();
							if(execDate!= null && !execDate.equals("null")){
								Date dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(execDate.toString());
								//								LocalDate date = LocalDate.parse(execDate,
								//										DateTimeFormatter.ofPattern("yyyy-MM-dd"));
								java.sql.Date dateOfExec = new java.sql.Date(dateOfExecution.getTime());
								/*checking if the startdate and dateof exec are equal or not
								 * < 0 if the date is before the given date and > 0 if date is after the given date
								 */				
								if (startDate != null
										&& (startDate.compareTo(dateOfExec) <= 0 && endDate.compareTo(dateOfExec) >= 0)) {
									reportRecord.setDateOfExecution(dateOfExec.toString()+'T');
								} else if (startDate == null && filterDate.compareTo(dateOfExec) != 0) {
									reportRecord.setDateOfExecution(dateOfExec.toString()+'T');
								}
								else
									continue;
							}
							else 
								reportRecord.setDateOfExecution("");
							
							recList.add(reportRecord);
						}
						
						catch(Exception e) {
							LOGGER.error("PesSalesSFDCServiceImpl.getSFDCReportData(): ERROR: " + e.getMessage());
						}
						
						
					}
					LOGGER.info("No. of records queried - " + recList.size());
					
				}
			}
			catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			}
			
		
		}
		return recList;
		
	}

	/*
	 * getReport2Data() refers to the Enterprise NA Report
	 */
	@Override
	public List<DiscoveryCallDTO> getReport2Data(String start, String end) {
		String reportId  = propertiesService.getPropertyByName("ENTERPRISE_NA_DCCREPORT_ID").getPropertyValue();
		String soql = "SELECT Legacy_Activity_ID__c,Name, Account__r.Name, Start_Date__c,FTA__r.Name, AE__r.Name, SP__r.Name,DC_Strap_Huddle_Link__c,Lead__r.Market_Type__c,DC_Status__c FROM Discovery_Call__c where";
		List<String> reportData = getSFDCReportData(reportId,soql);
		Date startDate = null;
		Date endDate = null;
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}
			catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		//new arraylist to add the fetched records
		List<DiscoveryCallDTO> recList = new ArrayList<>();
		for(String json : reportData) {
			try {
				Date filterDate = getDCFilterDate();
				 List<Employee> allSellers = empRepo.findAll();
			     Map<String,String> nameSfIdMap = new HashMap<>();
			        for(Employee emp: allSellers) {
			        	nameSfIdMap.put(emp.getFullName(),emp.getSf18CharId());
			        }
			    //getting the Array from the Json
				JSONArray jsonArray = new JSONArray(json);
				//checking the length
				if(jsonArray.length()>0) {
					//get jsonObject from jsonArray
					JSONObject jsonObj = jsonArray.getJSONObject(0);
					//get the "records" array from the JsonObj
					JSONArray array = jsonObj.getJSONArray("records");
					//// iterating through records of array 
					for(int i=0; i<array.length();i++) {
						try {
							//get json Object from the array
							JSONObject rec = array.getJSONObject(i);
							//
							DiscoveryCallDTO reportRecord = new DiscoveryCallDTO();
							String aeSf = "";
							String spSf = "";
							String ftaSf = "";
							String nameOfProspect = rec.getJSONObject("Account__r").getString("Name");
							String dcId = rec.get("Name").toString();

							if(rec.has("AE__r") && !rec.isNull("AE__r")) {
								JSONObject aeObj = rec.getJSONObject("AE__r");
								if(aeObj.has("Name") && !aeObj.isNull("Name")) {
									String ae = aeObj.getString("Name");
									if(!StringUtils.isEmpty(ae)) 
										aeSf = nameSfIdMap.get(ae);
									reportRecord.setAeSfId(aeSf);
									}
								else
									reportRecord.setAeSfId("");
								}
							
//							String ae = rec.get("AE__r").toString();
						//	String sp = rec.get("SP__r").toString();
							if(rec.has("SP__r") && !rec.isNull("SP__r")) {
								JSONObject spObj = rec.getJSONObject("SP__r");
								if(spObj.has("Name") && !spObj.isNull("Name")) {
									String sp = spObj.getString("Name");
									if(!StringUtils.isEmpty(sp)) 
										spSf = nameSfIdMap.get(sp);
									reportRecord.setSpSfId(spSf);
									}
								else
									reportRecord.setSpSfId("");
								}
							String activityId = rec.get("Legacy_Activity_ID__c").toString();
							
//							
							if(rec.has("FTA__r") && !rec.isNull("FTA__r")) {	
								JSONObject ftaObj = rec.getJSONObject("FTA__r");
								if(ftaObj.has("Name") && !ftaObj.isNull("Name")) {
									String fta = ftaObj.getString("Name");
									if(!StringUtils.isEmpty(fta)) 
										ftaSf = nameSfIdMap.get(fta);
										reportRecord.setFtaSfId(ftaSf);
									}
								}
							
							String sfdcStatus = rec.getString("DC_Status__c");
							String market = rec.get("Lead__r").toString();
							String docLink = rec.get("DC_Strap_Huddle_Link__c").toString();
							String execDate = rec.get("Start_Date__c").toString();
//							String execDate = rec.getString("Start_Date__c").substring(0,
//									rec.getString("Start_Date__c").indexOf('T'));
//							
							if(execDate!= null && !execDate.equals("null")){
								Date dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(execDate);
								//								LocalDate date = LocalDate.parse(execDate,
								//										DateTimeFormatter.ofPattern("yyyy-MM-dd"));
								java.sql.Date dateOfExec = new java.sql.Date(dateOfExecution.getTime());
								/*checking if the startdate and dateof exec are equal or not
								 * < 0 if the date is before the given date and > 0 if date is after the given date
								 */				
								if (startDate != null
										&& (startDate.compareTo(dateOfExec) <= 0 && endDate.compareTo(dateOfExec) >= 0)) {
									reportRecord.setDateOfExecution(dateOfExec.toString()+'T');
								} else if (startDate == null && filterDate.compareTo(dateOfExec) != 0) {
									reportRecord.setDateOfExecution(dateOfExec.toString()+'T');
								}
								else
									continue;
							}
							else 
								reportRecord.setDateOfExecution("");
							
							if(dcId != null) 
								reportRecord.setDcId(dcId);
							else
								reportRecord.setDcId("");
							
							if(sfdcStatus != null)
								reportRecord.setSfdcStatus(sfdcStatus);
							else
								reportRecord.setSfdcStatus("");
							if (nameOfProspect!=null)
								reportRecord.setNameOfProspect(nameOfProspect);
							else
								reportRecord.setNameOfProspect("");
							if(market != null)
								reportRecord.setMarket(market);
							else
								reportRecord.setMarket("");
							if(activityId!=null)
								reportRecord.setActivityId(activityId);
							else
								reportRecord.setActivityId("");
							if(docLink!=null)
								reportRecord.setDocLink(docLink);
							else
								reportRecord.setDocLink("");
							recList.add(reportRecord);
						}
						
						catch(Exception e) {
							LOGGER.error("PesSalesSFDCServiceImpl.getSFDCReportData(): ERROR: " + e.getMessage());
						}
						
						
					}
					LOGGER.info("No. of records queried - " + recList.size());
					
				}
			}
			catch (Exception e) {
				LOGGER.error(e.getMessage(), e);
			}
			
		
		}
		return recList;
		
	}

}

	

