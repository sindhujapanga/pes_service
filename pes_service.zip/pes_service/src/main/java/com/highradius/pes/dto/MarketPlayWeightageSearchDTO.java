package com.highradius.pes.dto;

import java.util.Arrays;

public class MarketPlayWeightageSearchDTO {
	
	private String[] marketId;
	
	private String[] roleId;
	
	private String[] teamId;
	
	private String[] playId;

	public String[] getMarketId() {
		return marketId;
	}

	public void setMarketId(String[] marketId) {
		this.marketId = marketId;
	}

	public String[] getRoleId() {
		return roleId;
	}

	public void setRoleId(String[] roleId) {
		this.roleId = roleId;
	}

	public String[] getTeamId() {
		return teamId;
	}

	public void setTeamId(String[] teamId) {
		this.teamId = teamId;
	}

	public String[] getPlayId() {
		return playId;
	}

	public void setPlayId(String[] playId) {
		this.playId = playId;
	}

	@Override
	public String toString() {
		return "MarketPlayWeightageSearchDTO [marketId=" + Arrays.toString(marketId) + ", roleId="
				+ Arrays.toString(roleId) + ", teamId=" + Arrays.toString(teamId) + ", playId="
				+ Arrays.toString(playId) + "]";
	}
}
