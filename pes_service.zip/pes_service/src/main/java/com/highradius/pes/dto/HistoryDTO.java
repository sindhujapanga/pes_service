package com.highradius.pes.dto;

import org.json.simple.JSONObject;

public class HistoryDTO {
	
	private String id;
	private String fnRole;
	private String userName;
	private String playName;
	private String nameOfProspect;
	private String email;
	private String action;
	private JSONObject inputData;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFnRole() {
		return fnRole;
	}
	public void setFnRole(String fnRole) {
		this.fnRole = fnRole;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPlayName() {
		return playName;
	}
	public void setPlayName(String playName) {
		this.playName = playName;
	}
	public String getNameOfProspect() {
		return nameOfProspect;
	}
	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public JSONObject getInputData() {
		return inputData;
	}
	public void setInputData(JSONObject inputData) {
		this.inputData = inputData;
	}
	@Override
	public String toString() {
		return "HistoryDTO [id=" + id + ", fnRole=" + fnRole + ", userName=" + userName + ", playName=" + playName
				+ ", nameOfProspect=" + nameOfProspect + ", email=" + email + ", action=" + action + ", inputData="
				+ inputData + "]";
	}
	
}
