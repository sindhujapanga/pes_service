package com.highradius.pes.scheduler;

import java.sql.Timestamp;
import java.util.Date;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.highradius.pes.model.PesSchedulerExecHistory;
import com.highradius.pes.service.PesCommonService;
import com.highradius.pes.service.PesReportService;
import com.highradius.pes.service.PesSalesForceService;
import com.highradius.pes.service.PesScoringService;

@Service
@Transactional
public class PesSalesForceScheduler {
	
	@Autowired
	PesSalesForceService pesSalesForceService;
	
	@Autowired
	PesScoringService pesScoringService;
	
	@Autowired
	PesCommonService pesCommonService;
	
	@Autowired
	PesReportService reportService;
	
	private static final Logger LOGGER = LogManager.getLogger(PesSalesForceScheduler.class); 
	//TODO:Add cron expressions
	
	
	//Scheduler for employee update
//	@Scheduled(cron = "0 0 13 * * *", zone="Asia/Calcutta")
//	public void processEmployeeReport()throws Exception {
//		String usermail = "";
//		LOGGER.info("pesSalesForceScheduler.processEmployeeReport(): START");
//		PesSchedulerExecHistory execHistory = null;
//		try {
//			execHistory = reportService.saveSchedulerExecutionHistory("processEmployeeReport", "Initiated");
//			pesCommonService.getEmployeeSfData(usermail); // Enterprise_EMEA_DCC_Report ID
//			execHistory.setEndTime(new Timestamp(new Date().getTime()));
//			execHistory.setStatus("SUCCESS");
//			reportService.updateSchedulerExecutionHistory(execHistory);
//		} catch (Exception e) {
//			LOGGER.error("processEmployeeReport: Exception while updating the status "+e.getMessage());
//			execHistory.setEndTime(new Timestamp(new Date().getTime()));
//			execHistory.setStatus("FAILED");
//			execHistory.setMessage(e.getMessage()+"-"+e);
//			reportService.updateSchedulerExecutionHistory(execHistory);
//		}
//		LOGGER.info("pesSalesForceScheduler.processEmployeeReport(): END");
//	}
	//Discovery Call Reports Fetch end
	//Daily
	@Scheduled(cron = "0 15 11 * * *", zone="Asia/Calcutta")
	public void processEnterpriseEMEADCCReport() {
		String usermail = "";
		LOGGER.info("pesSalesForceScheduler.processEnterpriseEMEADCCReport(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("processEnterpriseEMEADCCReport", "Initiated");
			pesScoringService.processDiscoveryCallRecords("Enterprise EMEA", usermail,null,null); // Enterprise_EMEA_DCC_Report ID
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("processEnterpriseEMEADCCReport: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesSalesForceScheduler.processEnterpriseEMEADCCReport(): END");
	}
	
	//Daily
	@Scheduled(cron = "0 30 11 * * *", zone="Asia/Calcutta")
	public void processEnterpriseNADCCReport() {
		String usermail = "";
		LOGGER.info("pesSalesForceScheduler.processEnterpriseNADCCReport(): START");
		 PesSchedulerExecHistory execHistory = null;
			try {
				execHistory = reportService.saveSchedulerExecutionHistory("processEnterpriseNADCCReport", "Initiated");
				pesScoringService.processDiscoveryCallRecords("Enterprise NA", usermail,null,null); // Enterprise_NA_DCC_Report ID
				execHistory.setEndTime(new Timestamp(new Date().getTime()));
				execHistory.setStatus("SUCCESS");
				reportService.updateSchedulerExecutionHistory(execHistory);
			} catch (Exception e) {
				LOGGER.error("processEnterpriseNADCCReport: Exception while updating the status "+e.getMessage());
				execHistory.setEndTime(new Timestamp(new Date().getTime()));
				execHistory.setStatus("FAILED");
				execHistory.setMessage(e.getMessage()+"-"+e);
				reportService.updateSchedulerExecutionHistory(execHistory);
			}
		 LOGGER.info("pesSalesForceScheduler.processEnterpriseNADCCReport(): END");
	}
	
	//Daily
	@Scheduled(cron = "0 45 11 * * *", zone="Asia/Calcutta")
	public void processMidMarketReport() {
		String usermail = "";
		LOGGER.info("pesSalesForceScheduler.processMidMarketReport(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("processMidMarketReport", "Initiated");
			pesScoringService.processDiscoveryCallRecords("MidMarket",usermail,null,null); // MidMarket_Report ID
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("processMidMarketReport: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
	 LOGGER.info("pesSalesForceScheduler.processEnterpriseNADCCReport(): END");
		LOGGER.info("pesSalesForceScheduler.processMidMarketReport(): END");
	}
	
	public void processTreasuryReport() {
		String usermail = "";
		LOGGER.info("pesSalesForceScheduler.processTreasuryReport(): START");
		pesScoringService.processDiscoveryCallRecords("Treasury",usermail,null,null); // Treasury_Report ID
		LOGGER.info("pesSalesForceScheduler.processTreasuryReport(): END");
	}
    //Discovery Call Reports Fetch end
	//Otc Report Fetch start
	//Monday
	@Scheduled(cron = "0 0 12 * * *", zone="Asia/Calcutta")
	public void processSalesPipelineOTCWhiteSpace() {
		LOGGER.info("pesSalesForceScheduler.processSalesPipelineOTCWhiteSpace(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("processSalesPipelineOTCWhiteSpace", "Initiated");
			pesScoringService.processSalesPipelineOTCWhiteSpaceRecords("",null,null);//blank user email
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("processSalesPipelineOTCWhiteSpace: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesSalesForceScheduler.processSalesPipelineOTCWhiteSpace(): END");
	}
	
	//Monday
	@Scheduled(cron = "0 15 12 * * *", zone="Asia/Calcutta")
	public void processWebResearchOTC() {
		LOGGER.info("pesSalesForceScheduler.processWebResearchOTC(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("processWebResearchOTC", "Initiated");
			pesScoringService.processWebResearchOTCRecords("", null, null); // blank user email
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("processWebResearchOTC: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesSalesForceScheduler.processWebResearchOTC(): END");
	}
	
	//CPR | SIH report fetch ***Only on Mondays***
//	@Scheduled(cron = "0 15 13 * * Mon", zone="Asia/Calcutta")
//	public void processCPRSIHReport()throws Exception {
//		String usermail = "";
//		LOGGER.info("pesSalesForceScheduler.processCPRSIHReport(): START");
//		PesSchedulerExecHistory execHistory = null;
//		try {
//			execHistory = reportService.saveSchedulerExecutionHistory("processCPRSIHReport", "Initiated");
//			pesScoringService.processCPRSIHRecords(usermail, null, null); // Enterprise_EMEA_DCC_Report ID
//			execHistory.setEndTime(new Timestamp(new Date().getTime()));
//			execHistory.setStatus("SUCCESS");
//			reportService.updateSchedulerExecutionHistory(execHistory);
//		} catch (Exception e) {
//			LOGGER.error("processCPRSIHReport: Exception while updating the status "+e.getMessage());
//			execHistory.setEndTime(new Timestamp(new Date().getTime()));
//			execHistory.setStatus("FAILED");
//			execHistory.setMessage(e.getMessage()+"-"+e);
//			reportService.updateSchedulerExecutionHistory(execHistory);
//		}
//		LOGGER.info("pesSalesForceScheduler.processCPRSIHReport(): END");
//	}
	
	//Monday
		@Scheduled(cron = "0 30 12 1 * *", zone="Asia/Calcutta")
		public void processChampionsnZZTop() {
			LOGGER.info("pesSalesForceScheduler.processChampionsnZZTop(): START");
			PesSchedulerExecHistory execHistory = null;
			try {
				execHistory = reportService.saveSchedulerExecutionHistory("processChampionsnZZTop", "Initiated");
				pesScoringService.processChampionsnZZTop(""); // blank user email
				execHistory.setEndTime(new Timestamp(new Date().getTime()));
				execHistory.setStatus("SUCCESS");
				reportService.updateSchedulerExecutionHistory(execHistory);
			} catch (Exception e) {
				LOGGER.error("processChampionsnZZTop: Exception while updating the status "+e.getMessage());
				execHistory.setEndTime(new Timestamp(new Date().getTime()));
				execHistory.setStatus("FAILED");
				execHistory.setMessage(e.getMessage()+"-"+e);
				reportService.updateSchedulerExecutionHistory(execHistory);
			}
			LOGGER.info("pesSalesForceScheduler.processChampionsnZZTop(): END");
		}
		
		//Monday
			@Scheduled(cron = "0 45 12 * * MON", zone="Asia/Calcutta")
			public void processSTRAP() {
				LOGGER.info("pesSalesForceScheduler.processSTRAP(): START");
				PesSchedulerExecHistory execHistory = null;
				try {
					execHistory = reportService.saveSchedulerExecutionHistory("processSTRAP", "Initiated");
					pesScoringService.processSTRAPRecords("", null, null); // blank user email
					execHistory.setEndTime(new Timestamp(new Date().getTime()));
					execHistory.setStatus("SUCCESS");
					reportService.updateSchedulerExecutionHistory(execHistory);
				} catch (Exception e) {
					LOGGER.error("processSTRAP: Exception while updating the status "+e.getMessage());
					execHistory.setEndTime(new Timestamp(new Date().getTime()));
					execHistory.setStatus("FAILED");
					execHistory.setMessage(e.getMessage()+"-"+e);
					reportService.updateSchedulerExecutionHistory(execHistory);
				}
				LOGGER.info("pesSalesForceScheduler.processSTRAP(): END");
			}
			
			@Scheduled(cron = "0 30 13 * * MON", zone="Asia/Calcutta")
			public void processDEMO() {
				LOGGER.info("pesSalesForceScheduler.processDEMO(): START");
				PesSchedulerExecHistory execHistory = null;
				try {
					execHistory = reportService.saveSchedulerExecutionHistory("processDEMO", "Initiated");
					pesScoringService.processDemoPlay("", null, null); // blank user email
					execHistory.setEndTime(new Timestamp(new Date().getTime()));
					execHistory.setStatus("SUCCESS");
					reportService.updateSchedulerExecutionHistory(execHistory);
				} catch (Exception e) {
					LOGGER.error("processDEMO: Exception while updating the status "+e.getMessage());
					execHistory.setEndTime(new Timestamp(new Date().getTime()));
					execHistory.setStatus("FAILED");
					execHistory.setMessage(e.getMessage()+"-"+e);
					reportService.updateSchedulerExecutionHistory(execHistory);
				}
				LOGGER.info("pesSalesForceScheduler.processDEMO(): END");
			}

}
