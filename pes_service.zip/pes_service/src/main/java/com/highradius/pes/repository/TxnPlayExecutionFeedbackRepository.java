package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.TxnPlayExecutionFeedback;


@Repository
/**
 * Repository class for TxnPlayExecutionFeedback pojo. Used for queries and crud operations.
 * @author subhayan.mukherjee
 *
 */
public interface TxnPlayExecutionFeedbackRepository extends JpaRepository<TxnPlayExecutionFeedback, Long> {
	
	@Query("Select t from TxnPlayExecutionFeedback t where t.id=?1")
	public TxnPlayExecutionFeedback getById(Long id);
	
	@Query("Select t from TxnPlayExecutionFeedback t where t.txnPlayExecutionId=?1")
	public List<TxnPlayExecutionFeedback> findByTxnPlayExecutionId(Long id);
	
	@Query("Select t from TxnPlayExecutionFeedback t where t.status=?1")
	public List<TxnPlayExecutionFeedback> findByPlayStatus(String status);

}
