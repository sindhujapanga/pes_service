package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Market;
/**
 * Repository class for market pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface MarketRepository extends JpaRepository<Market, Long>{
	
	//Query to get market by id
	@Query("Select m from Market m where m.id=?1")
	public Market getById(Long id);
	
	//Query to get market by name
	@Query("Select m from Market m where m.name=?1")
	public Market findByName(String name);

}
