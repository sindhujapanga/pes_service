package com.highradius.pes.controller;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.highradius.pes.dto.EmployeeDTO;
import com.highradius.pes.dto.EmployeeSearchDTO;
import com.highradius.pes.dto.EmployeeSearchResultDTO;
import com.highradius.pes.dto.HistoryDTO;
import com.highradius.pes.dto.HistorySearchDTO;
import com.highradius.pes.dto.HistorySearchResultDTO;
import com.highradius.pes.dto.MapPlayMarketWeightageSearchResultDTO;
import com.highradius.pes.dto.MarketPlayWeightageDTO;
import com.highradius.pes.dto.MarketPlayWeightageSearchDTO;
import com.highradius.pes.dto.PlaysSearchDTO;
import com.highradius.pes.model.Field;
import com.highradius.pes.service.PesAdminService;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.JwtUtil;
import com.highradius.pes.util.PesConstants;

@RestController
@CrossOrigin(origins = {"http://localhost:3000","https://pestest.highradius.com","https://pestest-sb.highradius.com",
		"https://pes.highradius.com","https://pes-sb.highradius.com"})
@RequestMapping(value = "/admin")
public class PesAdminController {
	private static final Logger LOGGER = LogManager.getLogger(PesAdminController.class);

	@Autowired
	PesAdminService pesAdminService;
	
	@Autowired
	JwtUtil jwtUtil;
	
	/**
	 * Adds an employee from the start
	 * 
	 * @param empDto
	 * @return
	 */
	@PostMapping(value = "/employee/add")
	public GenericResult addEmployee(@RequestBody EmployeeDTO empDto) {
		LOGGER.info("PesAdminController.addEmployee() : empDto = " + empDto.toString());
		GenericResult result = pesAdminService.addEmployee(empDto);
		LOGGER.info("PesAdminController.addEmployee() : END");
		return result;
	}
	
	/**
	 * Saves audit history for nay user based action
	 * @param historyDto
	 * @return
	 */
	@PostMapping(value = "/history/data")
	public GenericResult saveHistory(@RequestBody HistoryDTO historyDto) {
		LOGGER.info("PesAdminController.saveHistory() : historyDto = " + historyDto.toString());
		GenericResult result = pesAdminService.saveHistory(historyDto);
		LOGGER.info("PesAdminController.saveHistory() : END");
		return result;
	}
	
	/**
	 * Updates exiting employee 
	 * @param empDto
	 * @return
	 */
	@PostMapping(value = "/employee/update")
	public GenericResult updateEmployee(@RequestBody EmployeeDTO empDto) {
		LOGGER.info("PesAdminController.updateEmployee() : empDto = " + empDto.toString());
		GenericResult result = pesAdminService.updateEmployee(empDto);
		LOGGER.info("PesAdminController.updateEmployee() : END");
		return result;
	}
	
	/**
	 * Conditions for filtering employee page
	 * @param empSearchDto
	 * @return
	 */
	@PostMapping(value = "/employee/search")
	public GenericResult searchEmployees(@RequestBody EmployeeSearchDTO empSearchDto) {
		LOGGER.info("PesAdminController.searchEmployees() : empDto = " + empSearchDto.toString());
		GenericResult result = new GenericResult();
		List<EmployeeSearchResultDTO> data = pesAdminService.searchEmployees(empSearchDto);
		if(data == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Employee data");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.searchEmployees() : END");
		return result;
	}
	
	/**
	 * Accepts search DTO and sends back filtered results
	 * @param historySearchDto
	 * @return
	 */
	@PostMapping(value = "/history/search")
	public GenericResult searchHistory(@RequestBody HistorySearchDTO historySearchDto) {
		LOGGER.info("PesAdminController.searchHistory() : historySearchDto = " + historySearchDto.toString());
		GenericResult result = new GenericResult();
		List<HistorySearchResultDTO> data = pesAdminService.searchHistory(historySearchDto);
		if(data == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the History data");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.searchHistory() : END");
		return result;
	}
	
	/**
	 * Getting employee records by name
	 * @return
	 */
	@GetMapping(value = "/employee/names")
	public GenericResult getEmployeeNames() {
		LOGGER.info("PesAdminController.getEmployeeNames(): START");
		GenericResult result = new GenericResult();
		List<Map<String,String>> empNames = pesAdminService.getEmployeeNames();
		if(empNames == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Employee names");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(empNames);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getEmployeeNames(): END");
		return result;
	}
	
	/**
	 * Getting functional roles from 
	 * @return
	 */
	@GetMapping(value = "/employee/functionalRoles")
	public GenericResult getFunctionalRoles() {
		LOGGER.info("PesAdminController.getFunctionalRoles(): START");
		GenericResult result = new GenericResult();
		List<Map<String,String>> fnRoles = pesAdminService.getFunctionalRoles();
		if(fnRoles == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Functional Roles");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(fnRoles);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getFunctionalRoles(): END");
		return result;
	}

	/**
	 * Gets employees w.r.t sfuserIds
	 * @return
	 */
	@GetMapping(value = "/employee/sfUserIds")
	public GenericResult getSfUserIds() {
		LOGGER.info("PesAdminController.getSfUserIds(): START");
		GenericResult result = new GenericResult();
		List<Map<String,String>> userIds = pesAdminService.getSfUserIds();
		if(userIds == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the SalesForce User Ids");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(userIds);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getSfUserIds(): END");
		return result;
	}
	
	/**
	 * Get all the profiles present in the system
	 * @return
	 */
	@GetMapping(value = "/employee/profileNames")
	public GenericResult getProfileNames() {
		LOGGER.info("PesAdminController.getProfileNames(): START");
		GenericResult result = new GenericResult();
		List<Map<String,String>> profileNames = pesAdminService.getProfileNames();
		if(profileNames == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the SalesForce User Ids");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(profileNames);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getProfileNames(): END");
		return result;
	}
	
	/**
	 * get all emails of all employees present in the system
	 * @return
	 */
	@GetMapping(value = "/employee/emails")
	public GenericResult getEmails() {
		LOGGER.info("PesAdminController.getEmails(): START");
		GenericResult result = new GenericResult();
		List<Map<String,String>> emails = pesAdminService.getEmails();
		if(emails == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the employee emails");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(emails);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getEmails(): END");
		return result;
	}
	
	/**
	 * get all security roles in the system
	 * @return
	 */
	@GetMapping(value = "/employee/securityRoles")
	public GenericResult getSecurityRoles() {
		LOGGER.info("PesAdminController.getSecurityRoles(): START");
		GenericResult result = new GenericResult();
		List<Map<String,String>> secRoles = pesAdminService.getSecurityRoles();
		if(secRoles == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Security Roles");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(secRoles);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getSecurityRoles(): END");
		return result;
	}
	
	/**
	 * Sends back list of ids to delete from system
	 * @param ids
	 * @return
	 */
	@PostMapping(value = "/employee/deleteEmployee")
	public GenericResult deleteEmployeesById(@RequestBody final String[] ids) {
		LOGGER.info("PesAdminController.deleteEmployeesById(): START");
		GenericResult result = new GenericResult();
		boolean success = pesAdminService.deleteEmployeesById(ids);
		if(success == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to delete employees");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.deleteEmployeesById(): END");
		return result;
	}
	
	/**
	 * Adds a market with following definition in the parameter
	 * @param market
	 * @return
	 */
	@PostMapping(value = "/market/addMarket")
	public GenericResult addMarket(@RequestBody final JSONObject market) {
		LOGGER.info("PesAdminController.addMarket(): START");
		GenericResult result = pesAdminService.addMarket(market);
		LOGGER.info("PesAdminController.addMarket(): END");
		return result;
	}
	
	/**
	 * Adds a team with following definition in the parameter
	 * @param team
	 * @return
	 */
	@PostMapping(value = "/market/addTeam")
	public GenericResult addTeam(@RequestBody final JSONObject team) {
		LOGGER.info("PesAdminController.addTeam(): START");
		GenericResult result = pesAdminService.addTeam(team);
		LOGGER.info("PesAdminController.addTeam(): END");
		return result;
	}
	
	/**
	 * Adds a mapping between the market, play, role and its weightage
	 * @param weightageDto
	 * @return
	 */
	@PostMapping(value = "/market/addWeightage")
	public GenericResult addWeightage(@RequestBody final MarketPlayWeightageDTO weightageDto) {
		LOGGER.info("PesAdminController.addWeightage(): MarketPlayWeightageDTO: " + weightageDto.toString());
		GenericResult result = pesAdminService.addWeightage(weightageDto);
		LOGGER.info("PesAdminController.addWeightage(): END");
		return result;
	}
	
	/**
	 * Updates prexisting weightage mapping in the system
	 * @param weightageDto
	 * @return
	 */
	@PostMapping(value = "/market/updateWeightage")
	public GenericResult updateWeightage(@RequestBody final MarketPlayWeightageDTO weightageDto) {
		LOGGER.info("PesAdminController.updateWeightage(): MarketPlayWeightageDTO: " + weightageDto.toString());
		GenericResult result = pesAdminService.updateWeightage(weightageDto);
		LOGGER.info("PesAdminController.updateWeightage(): END");
		return result;
	}
	
	/**
	 * Returns search results for markets, role and weightage
	 * @param weightageSearchDto
	 * @return
	 */
	@PostMapping(value = "/market/search")
	public GenericResult searchWeightage(@RequestBody final MarketPlayWeightageSearchDTO weightageSearchDto) {
		LOGGER.info("PesAdminController.searchWeightage(): MarketPlayWeightageSearchDTO: " + weightageSearchDto.toString());
		List<MapPlayMarketWeightageSearchResultDTO> data= pesAdminService.searchMarketWeightages(weightageSearchDto);
		GenericResult result = new GenericResult();
		if(data == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the weightages");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.searchWeightage(): END");
		return result;
	}
	
	/**
	 * Gets the list of types of field
	 * @return
	 */
	@GetMapping(value = "/playbook/fieldTypes")
	public GenericResult getFieldTypes() {
		LOGGER.info("PesAdminController.getFieldTypes(): START");
		GenericResult result = new GenericResult();
		List<Map<String,String>> fields = pesAdminService.getFieldTypes();
		if(fields == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Field Types");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(fields);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getFieldTypes(): END");
		return result;
	}
	
	/**
	 * Gets all the playbooks
	 * @return
	 */
	@GetMapping(value = "/playbook/playbookList")
	public GenericResult getPlaybookList() {
		LOGGER.info("PesAdminController.getPlaybookList(): START");
		GenericResult result = new GenericResult();
		List<Map<String, String>> playbooks = pesAdminService.getPlaybookList();
		if(playbooks == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the list of Playbooks");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(playbooks);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getPlaybookList(): END");
		return result;
	}
	
	/**
	 * Get list of all departments from the system
	 * @return
	 */
	@GetMapping(value = "/playbook/departmentList")
	public GenericResult getDepartmentList() {
		LOGGER.info("PesAdminController.getDepartmentList(): START");
		GenericResult result = new GenericResult();
		List<Map<String, String>> departments = pesAdminService.getDepartmentList();
		if(departments == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the list of Departments");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(departments);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getDepartmentList(): END");
		return result;
	}
	
	/**
	 * Return for all the plays in the system
	 * @param playbookSearchFields
	 * @return
	 */
	@PostMapping(value = "/playbook/searchFields")
	public GenericResult searchFields(@RequestBody final JSONObject playbookSearchFields) {
		LOGGER.info("PesAdminController.searchFields(): " + playbookSearchFields.toString());
		GenericResult result = new GenericResult();
        List<Field> data = pesAdminService.getSearchedFieldsList(playbookSearchFields);
		if(data == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the searched fields");
		}else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.searchFields(): END");
		return result;
	}
	
	/**
	 * Adding a new field along with its type in the system
	 * @param fieldDetails
	 * @return
	 */
	@PostMapping(value = "/playbook/addField")
	public GenericResult addField(@RequestBody JSONObject fieldDetails) {
		LOGGER.info("PesAdminController.addField() : fieldDetails = " + fieldDetails.toString());
		GenericResult result = pesAdminService.addField(fieldDetails);
		LOGGER.info("PesAdminController.addField() : END");
		return result;
	}
	
	/**
	 * Adding a new play into the system
	 * @param playDetails
	 * @return
	 */
	@PostMapping(value = "/playbook/addPlay")
	public GenericResult addPlay(@RequestBody JSONObject playDetails) {
		LOGGER.info("PesAdminController.addPlay() : playDetails = " + playDetails.toString());
		GenericResult result = pesAdminService.addPlay(playDetails);
		LOGGER.info("PesAdminController.addPlay() : END");
		return result;
	}
	
	/**
	 * Return plays w.r.t search filters
	 * @param searchParams
	 * @return
	 */
	@PostMapping(value = "/playbook/playDetails")
	public GenericResult playDetails(@RequestBody PlaysSearchDTO searchParams) {
		LOGGER.info("PesAdminController.playDetails() : searchParams = " + searchParams.toString());
		GenericResult result = pesAdminService.playDetails(searchParams);
		LOGGER.info("PesAdminController.playDetails() : END");
		return result;
	}
	
	/**
	 * Addition of fields into a new play
	 * @param mapDetails
	 * @return
	 */
	@PostMapping(value = "/playbook/updateMapPlayFields")
	public GenericResult updateMapPlayFields(@RequestBody JSONObject mapDetails) {
		LOGGER.info("PesAdminController.updateMapPlayFields() : mapDetails = " + mapDetails.toString());
		GenericResult result = pesAdminService.updateMapPlayFields(mapDetails);
		LOGGER.info("PesAdminController.updateMapPlayFields() : END");
		return result;
	}
	
	/**
	 * Add a new playbook into the system
	 * @param playbookDetails
	 * @return
	 */
	@PostMapping(value = "/playbook/addPlaybook")
	public GenericResult addPlaybook(@RequestBody JSONObject playbookDetails) {
		LOGGER.info("PesAdminController.addPlaybook() : playbookDetails = " + playbookDetails.toString());
		GenericResult result = pesAdminService.addPlaybook(playbookDetails);
		LOGGER.info("PesAdminController.addPlaybook() : END");
		return result;
	}
	
	/**
	 * Gets the config for reports in format
	 * { category : [{report record}]}
	 * @return
	 */
	@GetMapping(value = "/reportConfig")
	public GenericResult getReportsConfigData() {
		LOGGER.info("PesAdminController.getReportsConfigData(): START");
		GenericResult result = new GenericResult();
		Map<String,List<Map<String,String>>> reports = pesAdminService.getReportsConfigData();
		if(reports == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the reports");
		}
		else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(reports);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getReportsConfigData(): END");
		return result;
	}
	
	@GetMapping(value = "/refreshADAuthToken")
	public GenericResult refreshAzureADAuthToken() {
		LOGGER.info("PesAdminController.refreshingADAuthToken(): START");
		GenericResult result = new GenericResult();
		boolean success = jwtUtil.refreshAzureADAuthToken();
		if(!success) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to refresh AD token");
		}
		else {
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesAdminController.getReportsConfigData(): END");
		return result;
	}
}
