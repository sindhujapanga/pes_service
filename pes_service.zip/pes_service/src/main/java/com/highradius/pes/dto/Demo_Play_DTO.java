package com.highradius.pes.dto;

public class Demo_Play_DTO {
    private String accountName;
	
	private String opportunityName;
	
	private String activityId;

	private String AE;
	
	private String SP;
	
	private String onSiteSp;
	
	private String market;
	
	private String AETeam;
	
	private String stageName;
	
	private String opportunityId;
	
	private String playName;
	
	private String onsiteSP;
	
	private String dateOfExecution;

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getAE() {
		return AE;
	}

	public void setAE(String aE) {
		AE = aE;
	}

	public String getSP() {
		return SP;
	}

	public void setSP(String sP) {
		SP = sP;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getAETeam() {
		return AETeam;
	}

	public void setAETeam(String aETeam) {
		AETeam = aETeam;
	}

	public String getStageName() {
		return stageName;
	}

	public void setStageName(String stageName) {
		this.stageName = stageName;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getPlayName() {
		return playName;
	}

	public void setPlayName(String playName) {
		this.playName = playName;
	}

	public String getOnsiteSP() {
		return onsiteSP;
	}

	public void setOnsiteSP(String onsiteSP) {
		this.onsiteSP = onsiteSP;
	}

	public String getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(String dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}

	public String getOnSiteSp() {
		return onSiteSp;
	}

	public void setOnSiteSp(String onSiteSp) {
		this.onSiteSp = onSiteSp;
	}

	@Override
	public String toString() {
		return "Demo_Play_DTO [accountName=" + accountName + ", opportunityName=" + opportunityName + ", activityId="
				+ activityId + ", AE=" + AE + ", SP=" + SP + ", onSiteSp=" + onSiteSp + ", market=" + market
				+ ", AETeam=" + AETeam + ", stageName=" + stageName + ", opportunityId=" + opportunityId + ", playName="
				+ playName + ", onsiteSP=" + onsiteSP + ", dateOfExecution="
				+ dateOfExecution + "]";
	}
	
	public String toStringForMail() {
		return "Demo_Play_DTO [accountName=" + accountName + ", opportunityName=" + opportunityName + ", AE=" + AE + ", SP=" + SP + ", onSiteSp=" + onSiteSp
				+ ", market=" + market + ", AETeam=" + AETeam + ", onsiteSP=" + onsiteSP+ ", dateOfExecution=" + dateOfExecution + "]";
	}
}
