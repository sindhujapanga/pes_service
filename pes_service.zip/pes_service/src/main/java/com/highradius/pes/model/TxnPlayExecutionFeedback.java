package com.highradius.pes.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "txn_play_execution_feedback")
public class TxnPlayExecutionFeedback implements Serializable {
	
	private static final long serialVersionUID = 2L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "txn_play_execution_id")
	private Long txnPlayExecutionId;
	
	@Column(name = "pes_feedback")
	private String pesFeedback;
	
	@Column(name = "pes_feedback_rating")
	private String pesFeedbackRating;
	
	@Column(name = "pod_lead_feedback")
	private String podLeadFeedback;
	
	@Column(name = "pod_lead_feedback_rating")
	private String podLeadFeedbackRating;
	
	@Column(name = "criteria")
	private String criteria;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "updated_date")
	private Date updatedDate;
	
	@Column(name = "updated_by")
	private String updatedBy;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTxnPlayExecutionId() {
		return txnPlayExecutionId;
	}

	public void setTxnPlayExecutionId(Long txnPlayExecutionId) {
		this.txnPlayExecutionId = txnPlayExecutionId;
	}

	public String getPesFeedback() {
		return pesFeedback;
	}

	public void setPesFeedback(String pesFeedback) {
		this.pesFeedback = pesFeedback;
	}

	public String getPodLeadFeedback() {
		return podLeadFeedback;
	}

	public String getPesFeedbackRating() {
		return pesFeedbackRating;
	}

	public void setPesFeedbackRating(String pesFeedbackRating) {
		this.pesFeedbackRating = pesFeedbackRating;
	}

	public String getPodLeadFeedbackRating() {
		return podLeadFeedbackRating;
	}

	public void setPodLeadFeedbackRating(String podLeadFeedbackRating) {
		this.podLeadFeedbackRating = podLeadFeedbackRating;
	}
	
	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	
	public void setPodLeadFeedback(String podLeadFeedback) {
		this.podLeadFeedback = podLeadFeedback;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public void copy(TxnPlayExecutionFeedback txnFDBK){
			this.setCriteria(txnFDBK.getCriteria());
			this.setPesFeedbackRating(txnFDBK.getPesFeedbackRating());
			this.setPodLeadFeedbackRating(txnFDBK.getPodLeadFeedbackRating());
			this.setPesFeedback(txnFDBK.getPesFeedback());
			this.setPodLeadFeedback(txnFDBK.getPodLeadFeedback());
			this.setStatus(txnFDBK.getStatus());
		}
	
	

}
