package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.SecurityRole;

/**
 * Repository class for Team pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface SecurityRoleRepository extends JpaRepository<SecurityRole, Long> {
	
	//Query to get security role by id
	@Query("Select s from SecurityRole s where s.id=?1")
	public SecurityRole getById(Long id);
	
	//Query to get security role by name
	@Query("Select s from SecurityRole s where s.name=?1")
	public SecurityRole getByName(String name);

}
