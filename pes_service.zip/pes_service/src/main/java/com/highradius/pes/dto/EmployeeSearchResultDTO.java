package com.highradius.pes.dto;

import java.util.Date;
import java.util.Map;

public class EmployeeSearchResultDTO {

	private Long id;

	private Long empId;

	private String sf18CharId;

	private String sfUserId;

	private String firstName;

	private String lastName;

	private String fullName;

	private String alias;

	private String profileName;

	private String email;

	private Map<String,String> podLead;

	private Map<String,String> dottedManger;

	private Map<String,String> designation;

	private Map<String,String> market;

	private Map<String,String> department;

	private Map<String,String> securityRole;

	private Map<String,String> fnRole;

	private Map<String,String> gh;

	private Map<String,String> team;

	private String location;

	private String createdBy;

	private Date createdDate;

	private String updatedBy;

	private Date updatedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getSf18CharId() {
		return sf18CharId;
	}

	public void setSf18CharId(String sf18CharId) {
		this.sf18CharId = sf18CharId;
	}

	public String getSfUserId() {
		return sfUserId;
	}

	public void setSfUserId(String sfUserId) {
		this.sfUserId = sfUserId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Map<String,String> getPodLead() {
		return podLead;
	}

	public void setPodLead(Map<String,String> podLead) {
		this.podLead = podLead;
	}

	public Map<String,String> getDottedManger() {
		return dottedManger;
	}

	public void setDottedManger(Map<String,String> dottedManger) {
		this.dottedManger = dottedManger;
	}

	public Map<String,String> getDesignation() {
		return designation;
	}

	public void setDesignation(Map<String,String> designation) {
		this.designation = designation;
	}

	public Map<String,String> getMarket() {
		return market;
	}

	public void setMarket(Map<String,String> market) {
		this.market = market;
	}

	public Map<String,String> getDepartment() {
		return department;
	}

	public void setDepartment(Map<String,String> department) {
		this.department = department;
	}

	public Map<String,String> getSecurityRole() {
		return securityRole;
	}

	public void setSecurityRole(Map<String,String> securityRole) {
		this.securityRole = securityRole;
	}

	public Map<String,String> getFnRole() {
		return fnRole;
	}

	public void setFnRole(Map<String,String> fnRole) {
		this.fnRole = fnRole;
	}

	public Map<String,String> getGh() {
		return gh;
	}

	public void setGh(Map<String,String> gh) {
		this.gh = gh;
	}

	public Map<String,String> getTeam() {
		return team;
	}

	public void setTeam(Map<String,String> team) {
		this.team = team;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "EmployeeSearchResultDTO [id=" + id + ", empId=" + empId + ", sf18CharId=" + sf18CharId + ", sfUserId="
				+ sfUserId + ", firstName=" + firstName + ", lastName=" + lastName + ", fullName=" + fullName
				+ ", alias=" + alias + ", profileName=" + profileName + ", email=" + email + ", podLead=" + podLead
				+ ", dottedManger=" + dottedManger + ", designation=" + designation + ", market=" + market
				+ ", department=" + department + ", securityRole=" + securityRole + ", fnRole=" + fnRole + ", gh=" + gh
				+ ", team=" + team + ", location=" + location + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + "]";
	}


}