package com.highradius.pes.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "lu_reports")
/**
 * Model class for reports pojo.Handles transactions for lu_reports table.
 *
 *
 */

public class Reports implements Serializable{
	
    private static final long serialVersionUID = -4941097951139472569L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    

	@Column(name = "name")
	private String name;
	
	@Column(name = "category")
	private String category;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "url")
	private String url;
	
//	@Transient
//	private List<Map<String,String>> options;
//	
//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = MapFieldOptions.class)
//	@JoinColumn(name = "field_id", referencedColumnName = "id")
//	List<MapFieldOptions> fieldOptions;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name =name;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category =category;
	}
	
	public String getURL() {
		return url;
	}

	public void setURL(String url) {
		this.url =url;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description =description;
	}
	
//	public List<Map<String, String>> getOptions() {
//		return options;
//	}
//
//	public void setOptions(List<Reports> options) {
//		this.options = new ArrayList<>();
//		for(Reports option: options) {
//			Map<String,String> map = new HashMap<>();
//			map.put("id", option.getId()+"");
//			map.put("name", option.getName());
//			this.options.add(map);
//		}
//	}
//	
//	public List<MapFieldOptions> getFieldOptions() {
//		return fieldOptions;
//	}
//
//	public void setFieldOptions(List<MapFieldOptions> fieldOptions) {
//		this.fieldOptions = fieldOptions;
//	}
	
	
}
