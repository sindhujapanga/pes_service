package com.highradius.pes.dto;

import java.util.ArrayList;

import java.util.HashMap;

import java.util.List;

import java.util.Map;

import com.highradius.pes.model.TxnPlayExecutionData;

import com.highradius.pes.model.TxnPlayExecutionFeedback;

import java.sql.Date;

public class ScoringSearchResultsDTO {

	private Long id;

	private boolean isStarred;

	private String activityId;

	private Map<String, String> play;

	private Map<String, String> assignedToPesAgent;

	private Map<String, String> assignedByPesLead;

	private Date dateOfExecution;

	private String opportunityName;

	private String nameOfProspect;

	private String pesStatus;

	private String sfdcStatus;

	private Map<String, String> sp;

	private Map<String, String> ae;

	private Map<String, String> fta;

	private Map<String, String> onsiteSp;

	private Map<String, String> dta;

	private Map<String, String> dsa;

	private Map<String, String> podLead;

	private Map<String, String> market;

	private Map<String, String> team;

	private Map<String, String> reviewedBy;

	private Map<String, String> scoringFor;

	private Map<String, String> playFields = new HashMap<>();

	private String pesComments;

	private String leaderComments;

	private String pesScore;

	private String podLeadScore;

	private String finalScore;

	private String docLink;

	private String createdDate;

	private String pesFeedback;

	private String podLeadFeedback;

	private String overriden;

	private String ratingAccuracy;

	private String feedbackAccuracy;

	private String overallPesEffectiveness;

	private Integer valid_override;

	private String rationale;

	private String manager_comments;

	public boolean getIsStarred() {
		return isStarred;
	}

	public void setIsStarred(boolean isStarred) {
		this.isStarred = isStarred;
	}

	public Integer getValid_override() {

		return valid_override;

	}

	public void setValid_override(Integer valid_override) {

		this.valid_override = valid_override;

	}

	public String getRationale() {

		return rationale;

	}

	public void setRationale(String rationale) {

		this.rationale = rationale;

	}

	public String getManager_comments() {

		return manager_comments;

	}

	public void setManager_comments(String manager_comments) {

		this.manager_comments = manager_comments;

	}

	public String getPesFeedback() {

		return pesFeedback;

	}

	public void setPesFeedback(String pesFeedback) {

		this.pesFeedback = pesFeedback;

	}

	public String getPodLeadFeedback() {

		return podLeadFeedback;

	}

	public void setPodLeadFeedback(String podLeadFeedback) {

		this.podLeadFeedback = podLeadFeedback;

	}

	private List<Map<String, String>> playExecFeedback = new ArrayList<>();

	public Long getId() {

		return id;

	}

	public void setId(Long id) {

		this.id = id;

	}

	public Map<String, String> getPlay() {

		return play;

	}

	public void setPlay(Map<String, String> play) {

		this.play = play;

	}

	public Map<String, String> getAssignedToPesAgent() {

		return assignedToPesAgent;

	}

	public void setAssignedToPesAgent(Map<String, String> assignedToPesAgent) {

		this.assignedToPesAgent = assignedToPesAgent;

	}

	public Map<String, String> getAssignedByPesLead() {

		return assignedByPesLead;

	}

	public void setAssignedByPesLead(Map<String, String> assignedByPesLead) {

		this.assignedByPesLead = assignedByPesLead;

	}

	public Date getDateOfExecution() {

		return dateOfExecution;

	}

	public void setDateOfExecution(Date dateOfExecution) {

		this.dateOfExecution = dateOfExecution;

	}

	public String getOpportunityName() {

		return opportunityName;

	}

	public void setOpportunityName(String opportunityName) {

		this.opportunityName = opportunityName;

	}

	public String getNameOfProspect() {

		return nameOfProspect;

	}

	public void setNameOfProspect(String nameOfProspect) {

		this.nameOfProspect = nameOfProspect;

	}

	public String getPesStatus() {

		return pesStatus;

	}

	public void setPesStatus(String pesStatus) {

		this.pesStatus = pesStatus;

	}

	public String getSfdcStatus() {

		return sfdcStatus;

	}

	public void setSfdcStatus(String sfdcStatus) {

		this.sfdcStatus = sfdcStatus;

	}

	public Map<String, String> getReviewedBy() {

		return reviewedBy;

	}

	public void setReviewedBy(Map<String, String> reviewedBy) {

		this.reviewedBy = reviewedBy;

	}

	public Map<String, String> getScoringFor() {

		return scoringFor;

	}

	public void setScoringFor(Map<String, String> scoringFor) {

		this.scoringFor = scoringFor;

	}

	public void setPlayFields(Map<String, String> playFields) {

		this.playFields = playFields;

	}

	public String getPesScore() {

		return pesScore;

	}

	public void setPesScore(String pesScore) {

		this.pesScore = pesScore;

	}

	public String getPodLeadScore() {

		return podLeadScore;

	}

	public void setPodLeadScore(String podLeadScore) {

		this.podLeadScore = podLeadScore;

	}

	public String getFinalScore() {

		return finalScore;

	}

	public void setFinalScore(String finalScore) {

		this.finalScore = finalScore;

	}

	public String getDocLink() {

		return docLink;

	}

	public void setDocLink(String docLink) {

		this.docLink = docLink;

	}

	public Map<String, String> getSp() {

		return sp;

	}

	public void setSp(Map<String, String> sp) {

		this.sp = sp;

	}

	public Map<String, String> getAe() {

		return ae;

	}

	public void setAe(Map<String, String> ae) {

		this.ae = ae;

	}

	public Map<String, String> getFta() {

		return fta;

	}

	public void setFta(Map<String, String> fta) {

		this.fta = fta;

	}

	public Map<String, String> getOnsiteSp() {

		return onsiteSp;

	}

	public void setOnsiteSp(Map<String, String> onsiteSp) {

		this.onsiteSp = onsiteSp;

	}

	public Map<String, String> getPodLead() {

		return podLead;

	}

	public void setPodLead(Map<String, String> podLead) {

		this.podLead = podLead;

	}

	public Map<String, String> getMarket() {

		return market;

	}

	public void setMarket(Map<String, String> market) {

		this.market = market;

	}

	public Map<String, String> getTeam() {

		return team;

	}

	public void setTeam(Map<String, String> team) {

		this.team = team;

	}

	public Map<String, String> getPlayFields() {

		return playFields;

	}

	public void setPlayFieldsFromTxnDataList(List<TxnPlayExecutionData> txnList) {

		for (TxnPlayExecutionData t : txnList) {

			this.playFields.put(t.getFieldId().toString(), t.getValue());

		}

	}

	public String getPesComments() {

		return pesComments;

	}

	public void setPesComments(String pesComments) {

		this.pesComments = pesComments;

	}

	public String getLeaderComments() {

		return leaderComments;

	}

	public void setLeaderComments(String leaderComments) {

		this.leaderComments = leaderComments;

	}

	public List<Map<String, String>> getPlayExecFeedback() {

		return playExecFeedback;

	}

	public String getCreatedDate() {

		return createdDate;

	}

	public void setCreatedDate(String createdDate) {

		this.createdDate = createdDate;

	}

	public String getOverriden() {

		return overriden;

	}

	public void setOverriden(String overriden) {

		this.overriden = overriden;

	}

	public Map<String, String> getDta() {

		return dta;

	}

	public void setDta(Map<String, String> dta) {

		this.dta = dta;

	}

	public Map<String, String> getDsa() {

		return dsa;

	}

	public void setDsa(Map<String, String> dsa) {

		this.dsa = dsa;

	}

	public String getRatingAccuracy() {

		return ratingAccuracy;

	}

	public void setRatingAccuracy(String ratingAccuracy) {

		this.ratingAccuracy = ratingAccuracy;

	}

	public String getFeedbackAccuracy() {

		return feedbackAccuracy;

	}

	public void setFeedbackAccuracy(String feedbackAccuracy) {

		this.feedbackAccuracy = feedbackAccuracy;

	}

	public String getOverallPesEffectiveness() {

		return overallPesEffectiveness;

	}

	public void setOverallPesEffectiveness(String overallPesEffectiveness) {

		this.overallPesEffectiveness = overallPesEffectiveness;

	}

	public void setPlayExecFeedback(List<TxnPlayExecutionFeedback> txnFeedback) {

		for (TxnPlayExecutionFeedback feedback : txnFeedback) {

			Map<String, String> map = new HashMap<>();

			map.put("id", feedback.getId() + "");

			map.put("criteria", feedback.getCriteria());

			map.put("pesFeedback", feedback.getPesFeedback());

			map.put("podLeadFeedback", feedback.getPodLeadFeedback());

			map.put("pesFeedbackRating", feedback.getPesFeedbackRating());

			map.put("podLeadFeedbackRating", feedback.getPodLeadFeedbackRating());

			map.put("status", feedback.getStatus());

			this.playExecFeedback.add(map);

		}

	}

	public String getActivityId() {

		return activityId;

	}

	public void setActivityId(String activityId) {

		this.activityId = activityId;

	}

	@Override
	public String toString() {
		return "ScoringSearchResultsDTO [id=" + id + ", isStarred=" + isStarred + ", activityId=" + activityId
				+ ", play=" + play + ", assignedToPesAgent=" + assignedToPesAgent + ", assignedByPesLead="
				+ assignedByPesLead + ", dateOfExecution=" + dateOfExecution + ", opportunityName=" + opportunityName
				+ ", nameOfProspect=" + nameOfProspect + ", pesStatus=" + pesStatus + ", sfdcStatus=" + sfdcStatus
				+ ", sp=" + sp + ", ae=" + ae + ", fta=" + fta + ", onsiteSp=" + onsiteSp + ", dta=" + dta + ", dsa="
				+ dsa + ", podLead=" + podLead + ", market=" + market + ", team=" + team + ", reviewedBy=" + reviewedBy
				+ ", scoringFor=" + scoringFor + ", playFields=" + playFields + ", pesComments=" + pesComments
				+ ", leaderComments=" + leaderComments + ", pesScore=" + pesScore + ", podLeadScore=" + podLeadScore
				+ ", finalScore=" + finalScore + ", docLink=" + docLink + ", createdDate=" + createdDate
				+ ", pesFeedback=" + pesFeedback + ", podLeadFeedback=" + podLeadFeedback + ", overriden=" + overriden
				+ ", ratingAccuracy=" + ratingAccuracy + ", feedbackAccuracy=" + feedbackAccuracy
				+ ", overallPesEffectiveness=" + overallPesEffectiveness + ", valid_override=" + valid_override
				+ ", rationale=" + rationale + ", manager_comments=" + manager_comments + ", playExecFeedback="
				+ playExecFeedback + "]";
	}

}
