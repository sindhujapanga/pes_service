/**
 * 
 */
package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.highradius.pes.model.MapPlayRoles;

/**Repository class for mapPlayRoles pojo. Used for queries and crud operations.
 * @author vamshi.bonagiri
 *
 */
public interface MapPlayRolesRepository  extends JpaRepository<MapPlayRoles, Long> {
	@Query("select distinct m.playId from MapPlayRoles m")
    public List<Long> getUniquePlayIds();
	
	@Query("select m from MapPlayRoles m where m.playId=?1")
	public List<MapPlayRoles> findByPlayId(Long id);
}
