package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.FunctionalRole;

/**
 * Repository class for FunctionalRole pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface FunctionalRoleRepository extends JpaRepository<FunctionalRole, Long> {
	
	//Query to get functional Role with id
	@Query("Select f from FunctionalRole f where f.id=?1")
	public FunctionalRole getById(Long id);
	
	//Query to get functional Role with name
	@Query("Select f from FunctionalRole f where f.name=?1")
	public FunctionalRole getByName(String name);
	

}
