package com.highradius.pes.dto;

public class ScoringGridSearchDTO {

	private boolean isStarred;
	private String play;
	private String nameOfProspect;
	private String market;
	private String team;
	private String createdDate;
	private String dateOfExecution;
	private String sfdcStatus;
	private String pesStatus;
	private String assignedToPesAgent;
	private String reviewedBy;
	private String scoringFor;
	private String overriden;
	private String sp;
	private String ae;
	private String fta;
	private String onsiteSp;
	private String dta;
	private String dsa;
	private String podLead;
	private String pesScore;
	private String valid_override;
	private String rationale;
	private String manager_comments;
	private String ratingAccuracy;
	private String feedbackAccuracy;
	private String overallPesEffectiveness;
	private String pesComments;
	private String podLeadScore;
	private String docLink;
	private String pesFeedback;
	private String podLeadFeedback;

	public boolean getIsStarred() {
		return isStarred;
	}

	public void setStarred(boolean isStarred) {
		this.isStarred = isStarred;
	}

	public String getPlay() {
		return play;
	}

	public void setPlay(String play) {
		this.play = play;
	}

	public String getNameOfProspect() {
		return nameOfProspect;
	}

	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(String dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}

	public String getSfdcStatus() {
		return sfdcStatus;
	}

	public void setSfdcStatus(String sfdcStatus) {
		this.sfdcStatus = sfdcStatus;
	}

	public String getPesStatus() {
		return pesStatus;
	}

	public void setPesStatus(String pesStatus) {
		this.pesStatus = pesStatus;
	}

	public String getAssignedToPesAgent() {
		return assignedToPesAgent;
	}

	public void setAssignedToPesAgent(String assignedToPesAgent) {
		this.assignedToPesAgent = assignedToPesAgent;
	}

	public String getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(String reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public String getScoringFor() {
		return scoringFor;
	}

	public void setScoringFor(String scoringFor) {
		this.scoringFor = scoringFor;
	}

	public String getOverriden() {
		return overriden;
	}

	public void setOverriden(String overriden) {
		this.overriden = overriden;
	}

	public String getSp() {
		return sp;
	}

	public void setSp(String sp) {
		this.sp = sp;
	}

	public String getAe() {
		return ae;
	}

	public void setAe(String ae) {
		this.ae = ae;
	}

	public String getFta() {
		return fta;
	}

	public void setFta(String fta) {
		this.fta = fta;
	}

	public String getOnsiteSp() {
		return onsiteSp;
	}

	public void setOnsiteSp(String onsiteSp) {
		this.onsiteSp = onsiteSp;
	}

	public String getDta() {
		return dta;
	}

	public void setDta(String dta) {
		this.dta = dta;
	}

	public String getDsa() {
		return dsa;
	}

	public void setDsa(String dsa) {
		this.dsa = dsa;
	}

	public String getPodLead() {
		return podLead;
	}

	public void setPodLead(String podLead) {
		this.podLead = podLead;
	}

	public String getPesScore() {
		return pesScore;
	}

	public void setPesScore(String pesScore) {
		this.pesScore = pesScore;
	}

	public String getValid_override() {
		return valid_override;
	}

	public void setValid_override(String valid_override) {
		this.valid_override = valid_override;
	}

	public String getRationale() {
		return rationale;
	}

	public void setRationale(String rationale) {
		this.rationale = rationale;
	}

	public String getManager_comments() {
		return manager_comments;
	}

	public void setManager_comments(String manager_comments) {
		this.manager_comments = manager_comments;
	}

	public String getRatingAccuracy() {
		return ratingAccuracy;
	}

	public void setRatingAccuracy(String ratingAccuracy) {
		this.ratingAccuracy = ratingAccuracy;
	}

	public String getFeedbackAccuracy() {
		return feedbackAccuracy;
	}

	public void setFeedbackAccuracy(String feedbackAccuracy) {
		this.feedbackAccuracy = feedbackAccuracy;
	}

	public String getOverallPesEffectiveness() {
		return overallPesEffectiveness;
	}

	public void setOverallPesEffectiveness(String overallPesEffectiveness) {
		this.overallPesEffectiveness = overallPesEffectiveness;
	}

	public String getPesComments() {
		return pesComments;
	}

	public void setPesComments(String pesComments) {
		this.pesComments = pesComments;
	}

	public String getPodLeadScore() {
		return podLeadScore;
	}

	public void setPodLeadScore(String podLeadScore) {
		this.podLeadScore = podLeadScore;
	}

	public String getDocLink() {
		return docLink;
	}

	public void setDocLink(String docLink) {
		this.docLink = docLink;
	}

	public String getPesFeedback() {
		return pesFeedback;
	}

	public void setPesFeedback(String pesFeedback) {
		this.pesFeedback = pesFeedback;
	}

	public String getPodLeadFeedback() {
		return podLeadFeedback;
	}

	public void setPodLeadFeedback(String podLeadFeedback) {
		this.podLeadFeedback = podLeadFeedback;
	}

	@Override
	public String toString() {
		return "ScoringGridSearchDTO [play=" + play + ", nameOfProspect=" + nameOfProspect + ", market=" + market
				+ ", team=" + team + ", createdDate=" + createdDate + ", dateOfExecution=" + dateOfExecution
				+ ", sfdcStatus=" + sfdcStatus + ", pesStatus=" + pesStatus + ", assignedToPesAgent="
				+ assignedToPesAgent + ", reviewedBy=" + reviewedBy + ", scoringFor=" + scoringFor + ", overriden="
				+ overriden + ", sp=" + sp + ", ae=" + ae + ", fta=" + fta + ", onsiteSp=" + onsiteSp + ", dta=" + dta
				+ ", dsa=" + dsa + ", podLead=" + podLead + ", pesScore=" + pesScore + ", valid_override="
				+ valid_override + ", rationale=" + rationale + ", manager_comments=" + manager_comments
				+ ", ratingAccuracy=" + ratingAccuracy + ", feedbackAccuracy=" + feedbackAccuracy
				+ ", overallPesEffectiveness=" + overallPesEffectiveness + ", pesComments=" + pesComments
				+ ", podLeadScore=" + podLeadScore + ", docLink=" + docLink + ", pesFeedback=" + pesFeedback
				+ ", podLeadFeedback=" + podLeadFeedback + "]";
	}

}
