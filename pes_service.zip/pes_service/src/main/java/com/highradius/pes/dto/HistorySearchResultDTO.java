package com.highradius.pes.dto;

import java.time.ZonedDateTime;

import org.json.simple.JSONObject;

public class HistorySearchResultDTO {
	
	private Long id;
	
	private ZonedDateTime dateOfExecution;
	
	private String userName;
	
	private String email;
	
	private String playName;
	
	private String nameOfProspect;
	
	private String fnRole;
	
	private String action;
	
	private JSONObject inputData;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ZonedDateTime getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(ZonedDateTime time) {
		this.dateOfExecution = time;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPlayName() {
		return playName;
	}

	public void setPlayName(String playName) {
		this.playName = playName;
	}

	public String getNameOfProspect() {
		return nameOfProspect;
	}

	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}

	public String getFnRole() {
		return fnRole;
	}

	public void setFnRole(String fnRole) {
		this.fnRole = fnRole;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public JSONObject getInputData() {
		return inputData;
	}

	public void setInputData(JSONObject inputData) {
		this.inputData = inputData;
	}

	@Override
	public String toString() {
		return "HistorySearchResultDTO [id=" + id + ", dateOfExecution=" + dateOfExecution + ", userName=" + userName
				+ ", email=" + email + ", playName=" + playName + ", nameOfProspect=" + nameOfProspect + ", fnRole="
				+ fnRole + ", action=" + action + ", inputData=" + inputData + "]";
	}
	
	

}
