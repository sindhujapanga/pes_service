/**
 * 
 */
package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.highradius.pes.model.PesSchedulerExecHistory;
import com.highradius.pes.model.PesSellerScores;

/**
 * @author vamshi.bonagiri
 * PesSchedulerExecHistoryRepository
 *
 */
public interface PesSchedulerExecHistoryRepository extends JpaRepository<PesSchedulerExecHistory, Long>, JpaSpecificationExecutor<PesSellerScores>{

}
