package com.highradius.pes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.CrossOrigin;


@CrossOrigin(origins = {"http://localhost:3000","https://pestest.highradius.com","https://pestest-sb.highradius.com"
		, "https://pes.highradius.com","https://pes-sb.highradius.com"})
@SpringBootApplication
@EnableAsync
@EnableScheduling
@ComponentScan(basePackages = "com.highradius.pes")
public class PesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PesApplication.class, args);
	}

}
