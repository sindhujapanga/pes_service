package com.highradius.pes.util;

import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.color.DeviceRgb;
import com.itextpdf.kernel.color.WebColors;

public interface PesConstants {
	public static final String SUCCESS = "SUCCESS";
	public static final String FAIL = "FAIL";
	
	public static final String NEW = "New";
	public static final String ASSIGNED = "Assigned";
	public static final String INITIATED = "Initiated";
	public static final String PENDING_REVIEW = "Pending Review";
	public static final String REVIEWED_BY_PES = "Reviewed by PES";
	public static final String PUSH_TO_POD_LEAD = "Push To POD Lead";
	public static final String COMPLETED = "Completed";
	public static final String CONVERTED = "Converted";
	public static final String NOT_CONVERTED_SELLER_NOT_INTERESTED = "Not Converted - Seller Not Interested";
	public static final String NOT_CONVERTED_PROSPECT_NOT_INTERESTED = "Not Converted - Prospect Not Interested";
	public static final String NOT_CONVERTED_FOLLOWUP_WITHIN_4WEEKS = "Not Converted - Followup within 4 weeks";

	public static final String OPPTY_CREATED = "Oppty Created";
	public static final String DISQUALIFIED = "Disqualified";
	public static final String DEEP_DIVE = "Deep Dive";
	public static final String Active = "Active";
	public static final String Inactive = "Inactive";
	public static final String CANCELLED = "Cancelled";
	public static final String NO_SHOW = "No Show";
	public static final String[] Months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
	public static final Color HRCBLUE = WebColors.getRGBColor("#4fc4f7");
	public static final Color HRCORANGE = WebColors.getRGBColor("#fc7500");
	public static final Color HRCWHITE = DeviceRgb.WHITE;
	public static final Color HRCLORANGE = WebColors.getRGBColor("#f8d0ad");
	public static final Color HRCGREEN = WebColors.getRGBColor("#8FD163");
	public static final Color HRCYELLOW = WebColors.getRGBColor("#F4B400");
	public static final Color HRCRED = WebColors.getRGBColor("#DB4437");
	public static final String MONTHLY = "MONTHLY";
	public static final String WEEKLY = "WEEKLY";
	public static final String REPORT_SUBJECT = "PE Scoring";
	public static final String PES_OPERA_LINK = "https://docs.google.com/document/d/1DIy48cFrlCBnq5xw-3nj-5hxf-wl6tdiFNuAM6SwL6U/edit?hl=en&forcehl=1#heading=h.iae2f1sgk5jd";
	public static final String GREEN = "Green";
	public static final String YELLOW = "Yellow";
	public static final String RED = "Red";
	public static final String CLIENT_ID = "984065014191-q04r1lp1tt917vr0dav7ip7jp42foim6.apps.googleusercontent.com";
	public static final String USERS_TO_ENABLE_SF_DATA = "REFRESH_SF_DATA_ACTION_ENABLE";
	public static final String ACCEPTED = "Accepted";
	public static final String DECLINED = "Declined";

	public static final boolean TRUE = true;
	public static final boolean FALSE = false;
	public static final String SCHEDULED = "Scheduled";
	
}
