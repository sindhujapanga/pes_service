package com.highradius.pes.dto;

public class OTCWebResearchDTO {
	
	private String activityId;
	
	private String dateOfExecution;
	
	private String sfdcStatus;
	
	private String accountName;
	
	private String opportunityName;
	
	private String aeSf;
	
	private String spSf;
	
	private String dsaSf;

	private String stage;
	
	private String market;
	
	private String team;
	
	private String dcId;

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(String dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}

	public String getSfdcStatus() {
		return sfdcStatus;
	}

	public void setSfdcStatus(String sfdcStatus) {
		this.sfdcStatus = sfdcStatus;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getAeSf() {
		return aeSf;
	}

	public void setAeSf(String aeSf) {
		this.aeSf = aeSf;
	}

	public String getSpSf() {
		return spSf;
	}

	public void setSpSf(String spSf) {
		this.spSf = spSf;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}
	
	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}
	
	public String getDsaSf() {
		return dsaSf;
	}

	public void setDsaSf(String dsaSf) {
		this.dsaSf = dsaSf;
	}	
	
	public String getDcId() {
		return dcId;
	}

	public void setDcId(String dcId) {
		this.dcId = dcId;
	}

	@Override
	public String toString() {
		return "OTCWebResearchDTO [activityId=" + activityId + ", dateOfExecution=" + dateOfExecution + ", sfdcStatus="
				+ sfdcStatus + ", accountName=" + accountName + ", opportunityName=" + opportunityName + ", aeSf="
				+ aeSf + ", spSf=" + spSf + ", dsaSf=" + dsaSf + ", stage=" + stage + ", market=" + market + ", team="
				+ team + "]";
	}

	public String toStringForMail() {
		return "Date Of Execution = " + dateOfExecution + ", Account Name = " + 
	            accountName + ", Opportunity Name = " + opportunityName + ", SP = "
				+ spSf + ", stage = " + stage + ", market = " + market + ",team = " + team;
	}
	
}
