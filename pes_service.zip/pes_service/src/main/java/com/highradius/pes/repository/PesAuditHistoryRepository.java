package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.PesAuditHistory;

/**
 * Repository class for PesAuditHistory pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface PesAuditHistoryRepository extends JpaRepository<PesAuditHistory, Long>, JpaSpecificationExecutor<PesAuditHistory>{

	//Query to get PesAuditHistory by id
	@Query("Select p from PesAuditHistory p where p.id=?1")
	public PesAuditHistory getById(Long id);
	
	//Query to get PesAuditHistory by action
	@Query("Select p from PesAuditHistory p where p.action=?1")
	public List<PesAuditHistory> getByAction(String action);
}
