package com.highradius.pes.dto;

import java.util.Arrays;

public class EmployeeSearchDTO {

	private String[] names;
	
	private String[] marketIds;
	
	private String[] teamIds;
	
	private String[] roleIds;
	
	private String[] podLeadIds;
	
	private String userId;
	
	private String profile;
	
	private String email;

	public String[] getNames() {
		return names;
	}

	public void setNames(String[] names) {
		this.names = names;
	}

	public String[] getMarketIds() {
		return marketIds;
	}

	public void setMarketIds(String[] marketIds) {
		this.marketIds = marketIds;
	}

	public String[] getTeamIds() {
		return teamIds;
	}

	public void setTeamIds(String[] teamIds) {
		this.teamIds = teamIds;
	}

	public String[] getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(String[] roleIds) {
		this.roleIds = roleIds;
	}

	public String[] getPodLeadIds() {
		return podLeadIds;
	}

	public void setPodLeadIds(String[] podLeadIds) {
		this.podLeadIds = podLeadIds;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "EmployeeSearchDTO [names=" + Arrays.toString(names) + ", marketIds=" + Arrays.toString(marketIds)
				+ ", teamIds=" + Arrays.toString(teamIds) + ", roleIds=" + Arrays.toString(roleIds) + ", podLeadIds="
				+ Arrays.toString(podLeadIds) + ", userId=" + userId + ", profile=" + profile + ", email=" + email
				+ "]";
	}

	
}
