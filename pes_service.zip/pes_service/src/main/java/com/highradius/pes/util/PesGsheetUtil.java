package com.highradius.pes.util;

import static java.time.DayOfWeek.MONDAY;
import static java.time.temporal.TemporalAdjusters.previousOrSame;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.AppendValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.highradius.pes.dto.CPR_SIHDTO;
import com.highradius.pes.dto.ChampionsnZZTopDTO;
import com.highradius.pes.dto.DataExportDTO;
import com.highradius.pes.dto.DiscoveryCallDTO;
import com.highradius.pes.dto.EmployeeSFDTO;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.FieldType;
import com.highradius.pes.model.MapFieldOptions;
import com.highradius.pes.model.Play;
import com.highradius.pes.model.TxnPlayExecutionData;
import com.highradius.pes.model.TxnPlayExecutionFeedback;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FieldRepository;
import com.highradius.pes.repository.MapFieldOptionsRepository;
import com.highradius.pes.repository.PlayRepository;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;
import com.highradius.pes.service.PesSalesForceService;
import com.highradius.pes.service.impl.PesReportServiceImpl;
import com.highradius.pes.service.impl.PesSalesForceServiceImpl;


@Service
@Transactional
public class PesGsheetUtil {
	//properties Util class
	@Autowired
	PesPropertiesUtil propertiesService;

	@Autowired
	TxnPlayExecutionsRepository txnPlayExecRepo;
	
	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	MapFieldOptionsRepository mapFieldOptionsRepo;
	
	@Autowired
	FieldRepository fieldRepo;
	
	@Autowired
	PesReportServiceImpl reportService;
	
	@Autowired
	PlayRepository playRepo;
	
	@Autowired
	PesSalesForceServiceImpl salesForceServiceImpl;
	
	//Logger for logging
	private static final Logger LOGGER = LogManager.getLogger(PesGsheetUtil.class);
	private Sheets sheetsService;
	private String sheetTest = "PES";
	
	private JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	
	/*path where the tokens from Google Api cloud will be stored.Make sure it does 
	*not interfere with Google OAuth token*/
//	private String TOKENS_DIRECTORY_PATH = propertiesService.getPropertyByName("GSHEET_TOKEN_LOC").getPropertyValue();
	
	//path for the credential for gsheet integration
	private String CREDENTIALS_FILE_PATH = "/Credentials/Credentials.json";
	private List<String> scopes = Arrays.asList(SheetsScopes.SPREADSHEETS);
	
	//function to generate credentials object and authorize data flow from sheet
	public Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws Exception {
		String TOKENS_DIRECTORY_PATH = propertiesService.getPropertyByName("GSHEET_TOKEN_LOC").getPropertyValue();
		
        // Load client secrets.
        InputStream in = PesGsheetUtil.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
        if (in == null) {
            throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
        }
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

        // Build flow and trigger user authorization request.
        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, scopes)
                .setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
                .setAccessType("offline")
                .setApprovalPrompt("force")
                .build();
        LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
        return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
    }

	//builds sheet service
	public Sheets getSheetsService() throws Exception{
		LOGGER.info("In get sheets service");
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
        Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
                .setApplicationName(sheetTest)
                .build();
        return service;
	}
	//fetching data from sheet	
	//Commenting employee gsheet data fetch code as per PES team use case as they are now adding data manually through system
//	public List<EmployeeSFDTO> getEmployeeData()throws Exception{
//		LOGGER.info("GsheetUtil.getEmployeeData(): START");
//		//sheet service call
//		sheetsService = getSheetsService();	
//		//setting range
//		String dataRange = "Consolidated Data!A2:AA";
//		String sheetId = propertiesService.getPropertyByName("EMPLOYEE_CONSOLIDATED_SHEET_ID").getPropertyValue();
//		
//		//storing the response
//		ValueRange response = sheetsService.spreadsheets().values()
//				.get(sheetId, dataRange).execute();
//		
//		//response we get in list<list<object>> format
//		List<List<Object>> values = response.getValues();
//		List<EmployeeSFDTO> empRecords = new ArrayList<>();
//		
////		Code we implement to use the response got
//		if(values == null) {
//			LOGGER.error("Data is not present in Employee Sheet");
//		}
//	    else {
//	    	for(List<Object> row : values) {
//	    	     EmployeeSFDTO emp = new EmployeeSFDTO();
//	    	     String sf18CharId = row.get(0).toString();
//	    	     String userId = row.get(1).toString();
//	    	     String firstName = row.get(2).toString();
//	    	     String lastName = row.get(3).toString();
//	    	     String fullName = row.get(4).toString();
//	    	     String profileName = row.get(5).toString();
//	    	     String role = row.get(6).toString();
//	    	     String team = row.get(7).toString();
//	    	     String market = row.get(8).toString();
//	    	     String email = row.get(9).toString();
//	    	     String alias = row.get(10).toString();
//	    	     String status = row.get(11).toString();
//	    	     String activeOrNot = "";
//	    	     if(status.equals("0") || status.equalsIgnoreCase("FALSE"))
//	    	    	 activeOrNot = "FALSE";
//	    	     else if(status.equals("1") || status.equalsIgnoreCase("TRUE"))
//	    	    	 activeOrNot = "TRUE";
//	    	     String podLeadName = row.get(12).toString();
//	    	     String podLead18CharId = row.get(13).toString();
//	    	     String departmentName = row.get(14).toString();
//	    	     
//	    	     //setting the values in empDTO
//	    	     emp.setActive(activeOrNot);
//	    	     emp.setSf18CharacterID(sf18CharId);
//	    	     emp.setUserId(userId);
//	    	     emp.setFirstName(firstName);
//	    	     emp.setLastName(lastName);
//	    	     emp.setFullName(fullName);
//	    	     emp.setProfile(profileName);
//	    	     emp.setRole(role);
//	    	     emp.setTeam(team);
//	    	     emp.setMarket(market);
//	    	     emp.setEmail(email);
//	    	     emp.setAlias(alias);
//	    	     emp.setPodLeadName(podLeadName);
//	    	     emp.setPodLead18CharId(podLead18CharId);
//	    	     emp.setDepartment(departmentName);
//	    	     empRecords.add(emp);
//	    		}
//	    	}
//		return empRecords;	
//		}
	
	    /**
	     * Method used to dump txn data weekly from last week monday to last Sunday to a google sheet
	     * Sheet Id referenced from db.
	     */
		@Async
		public void setReportGsheetData() {
			LOGGER.info("PesGsheetUtil.setReportGsheetData(): START");
			// sheet service call
			try {
				sheetsService = getSheetsService();
				List<Employee> allEmp = empRepo.getActiveAndInactiveEmployees();
				List<MapFieldOptions> fieldOptions = mapFieldOptionsRepo.findAll();
				List<Field> fields = fieldRepo.findAll();
				Long championPlayId = playRepo.findByName("Champions").getId();
				Long zzTopPlayId = playRepo.findByName("ZZTop").getId();
				String originalRating = "";
				String finalRating = "";

				// Map for dynamic fields
				Map<String, Integer> sheetFieldMap = new HashMap<>();
				// creating the map for dynamic fields
				sheetFieldMap.put("discoveryCallOutcomePesAgent", 14);
				sheetFieldMap.put("outcomeRationalePesAgent", 15);
				sheetFieldMap.put("discoveryCallOutcomePodLead", 16);
				sheetFieldMap.put("outcomeRationalePodLead", 17);
				sheetFieldMap.put("otcWhitespaceStage", 18);
				sheetFieldMap.put("linkToChorusAiRec", 19);

				Map<Long, String> empIdMap = new HashMap<>();
				Map<Long, MapFieldOptions> fieldOptionsMap = new HashMap<>();
				Map<Long, Field> fieldMap = new HashMap<>();
				for (Field field : fields) {
					fieldMap.put(field.getId(), field);
				}
				for (MapFieldOptions option : fieldOptions) {
					fieldOptionsMap.put(option.getId(), option);
				}
				for (Employee emp : allEmp) {
					empIdMap.put(emp.getId(), emp.getFullName());
				}
				LocalDate today = LocalDate.now();
				LocalDate monday = today.with(previousOrSame(MONDAY));
				LocalDate prePreMonday = monday.minusDays(14);
				LocalDate prePreSunday = monday.minusDays(8);
				LocalDate preMonday = monday.minusDays(7);
				LocalDate yesterday = today.minusDays(1);
				Calendar cal = Calendar.getInstance();
				int year = cal.get(Calendar.YEAR);
				int month = cal.get(Calendar.MONTH);
				// add -1 month to current month
				cal.add(Calendar.MONTH, -1);
				// set DATE to 1, so first date of previous month
				cal.set(Calendar.DATE, 1);
				Date firstDateOfPreviousMonth = cal.getTime();

				// set actual maximum date of previous month
				cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
				Date lastDateOfPreviousMonth = cal.getTime();
				LocalDate startDt = new java.sql.Date(firstDateOfPreviousMonth.getTime()).toLocalDate();
				LocalDate endDt = new java.sql.Date(lastDateOfPreviousMonth.getTime()).toLocalDate();

				LocalDateTime monthStartDate = LocalDateTime.of(LocalDate.from(startDt), LocalTime.of(0, 0, 0));
				LocalDateTime monthEndDate = LocalDateTime.of(LocalDate.from(endDt), LocalTime.of(23, 59, 59));
				LocalDateTime startDateCompleted = LocalDateTime.of(LocalDate.from(prePreMonday), LocalTime.of(0, 0, 0));
				LocalDateTime endDateCompleted = LocalDateTime.of(LocalDate.from(prePreSunday), LocalTime.of(23, 59, 59));
				LocalDateTime startDateRest = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
				LocalDateTime endDateRest = LocalDateTime.of(LocalDate.from(yesterday), LocalTime.of(23, 59, 59));
				// setting range
				String dataRange = propertiesService.getPropertyByName("PES_REPORT_GSHEET_SHEET_NAME").getPropertyValue();;
				String sheetId = propertiesService.getPropertyByName("PES_REPORT_GSHEET_ID").getPropertyValue();
				List<List<Object>> appendList = new ArrayList<>();
				List<TxnPlayExecutions> Txns = txnPlayExecRepo.getScoresBetweenDates(startDateCompleted, endDateCompleted);
				List<TxnPlayExecutions> TxnsRest = txnPlayExecRepo.getScoresBetweenDatesNonCompletedRecs(startDateRest, endDateRest);
				List<TxnPlayExecutions> championsnZZTop = txnPlayExecRepo.getScoresBetweenDatesChampionsAndZZTop(monthStartDate, monthEndDate, championPlayId,zzTopPlayId);
				List<TxnPlayExecutions> allTxns = new ArrayList<>();
				allTxns.addAll(Txns);
				allTxns.addAll(TxnsRest);
				allTxns.addAll(championsnZZTop);
				LOGGER.info("Number of records fetched : " + allTxns.size() + " from startDate : " + startDateCompleted
						+ " , endDate : " + endDateRest);
				reportService.updateFeedbackSummary(Txns);
				for (TxnPlayExecutions txn : allTxns) {
					try {
						List<Object> row = new ArrayList<>();
						String playName = txn.getPlay().getName();
						Employee seller = txn.getScoringFor();
						// index 0
						row.add(txn.getId());
						row.add(txn.getNameOfProspect());
						// index 1
						if (txn.getMarket() != null)
							row.add(txn.getMarket().getName());
						else
							row.add("");
						// index 2
						if (txn.getTeam() != null)
							row.add(txn.getTeam().getName());
						else
							row.add("");
						// index 3
						if(txn.getCompletedOn() != null)
						    row.add(txn.getCompletedOn().toString());
						else
							row.add("");
						if(txn.getDateOfExecution() != null)
							row.add(txn.getDateOfExecution().toString());
						else 
							row.add("");
						row.add(playName);
						row.add(txn.getPesStatus());
						finalRating = colorToScore(txn.getPodLeadScore());
						originalRating = colorToScore(txn.getPesScore());
						row.add(finalRating);
						row.add(originalRating);
						row.add(txn.getPodLeadScore());
						row.add(txn.getPesScore());
						//original feedback
						row.add(StringUtils.isEmpty(txn.getPesFeedback())?"":txn.getPesFeedback());
						//detailed feedback
						row.add(StringUtils.isEmpty(txn.getHighLevelFeedback())?"":txn.getHighLevelFeedback());
						// adding default values for dynamic columns
						row.add("");
						row.add("");
						row.add("");
						row.add("");
						row.add("");
						row.add("");
						List<TxnPlayExecutionData> data = txn.getTxnPlayExecutionData();
						for (TxnPlayExecutionData txnData : data) {
							Long fieldId = txnData.getFieldId();
							String value = txnData.getValue();
							Field fld = fieldMap.get(fieldId);
							FieldType type = fld.getFieldType();
							if (type.getName().equals("Select") && !StringUtils.isEmpty(value)) {
								value = fieldOptionsMap.get(Long.parseLong(value)).getValue();
							}
							Integer index = sheetFieldMap.get(fld.getFieldName());
							if (index != null)
								row.set(index, value);
						}
						if(txn.getDocLink() != null)
							row.add(20, txn.getDocLink());
						else 
							row.add(20,"");
						if (seller != null && seller.getId() != -1) {
							row.add(21, seller.getFullName());
							row.add(22, seller.getFnRole().getName());
							if (seller.getPodLeadId() != null && empIdMap.get(seller.getPodLeadId()) != null)
								row.add(23, empIdMap.get(seller.getPodLeadId()));
							else
								row.add(23, "");
						} else {
							row.add(21, "");
							row.add(22, "");
							row.add(23, "");
						}
						if(txn.getAe() != null) {
							row.add(24,txn.getAe().getFullName());
							Long podLead = txn.getAe().getPodLeadId();
							if(podLead != null && empIdMap.get(podLead) != null)
								row.add(25,empIdMap.get(podLead));
							else
								row.add(25,"");
						}
						else {
							row.add(24,"");
							row.add(25,"");
						}
						if(txn.getSp() != null) {
							row.add(26,txn.getSp().getFullName());
							Long podLead = txn.getSp().getPodLeadId();
							if(podLead != null && empIdMap.get(podLead) != null)
								row.add(27,empIdMap.get(podLead));
							else
								row.add(27,"");
						}
						else {
							row.add(26,"");
							row.add(27,"");
						}
						if(txn.getOnsiteSp() != null) {
							row.add(28,txn.getOnsiteSp().getFullName());
							Long podLead = txn.getOnsiteSp().getPodLeadId();
							if(podLead != null && empIdMap.get(podLead) != null)
								row.add(29,empIdMap.get(podLead));
							else
								row.add(29,"");
						}
						else {
							row.add(28,"");
							row.add(29,"");
						}
						if(txn.getAssignedToPesAgent() != null)
							row.add(30, txn.getAssignedToPesAgent().getFullName());
						else 
							row.add(30, "");
						
						if(txn.getOverriden() != null) {
							if(txn.getOverriden().equalsIgnoreCase("YES")) {
								row.add(1);
							}
							else {
								row.add(0);
							}
						}else
						{
						row.add("");
					}
						
						
						row.add(txn.getCreatedDate().toString());
						if(txn.getDta() != null) {
							row.add(33,txn.getDta().getFullName());
							Long podLead = txn.getDta().getPodLeadId();
							if(podLead != null && empIdMap.get(podLead) != null)
								row.add(34,empIdMap.get(podLead));
							else
								row.add(34,"");
						}
						else {
							row.add(33,"");
							row.add(34,"");
						}
						if(txn.getDsa() != null) {
							row.add(35,txn.getDsa().getFullName());
							Long podLead = txn.getDsa().getPodLeadId();
							if(podLead != null && empIdMap.get(podLead) != null)
								row.add(36,empIdMap.get(podLead));
							else
								row.add(36,"");
						}
						else {
							row.add(35,"");
							row.add(36,"");
						}
						
						if(txn.getValid_override() != null) {
							String value = "";
							if(txn.getValid_override() == 1) {
								value = "Yes";
								row.add(37,value);
							}
							else {
								value ="No";
								row.add(37,value);
							}
						}
						else
							{
							row.add(37,"");
						}
						
						if(txn.getRationale() !=null) {
							row.add(38,txn.getRationale());
						}
						else {
							row.add(38,"");
						}
						
						appendList.add(row);
					} catch (Exception e) {
						LOGGER.error("PesGsheetUtil.setReportGsheetData(): ERROR : " + e.getMessage());
						e.printStackTrace();
					}
				}
				ValueRange appendBody = new ValueRange().setValues(appendList);
				AppendValuesResponse appendResult = sheetsService.spreadsheets().values()
						.append(sheetId, dataRange, appendBody).setValueInputOption("USER_ENTERED")
						.setInsertDataOption("INSERT_ROWS").setIncludeValuesInResponse(true).execute();
			} catch (Exception e) {
				LOGGER.error("PesGsheetUtil.setReportGsheetData(): ERROR : " + e.getMessage());
				e.printStackTrace();
			}
			LOGGER.info("PesGsheetUtil.setReportGsheetData(): END");
		}
	
		
		public String colorToScore(String color) {
		    String score = "0";
		    if(color == null)
		    	return "";
			if (color.equals(PesConstants.GREEN))
				score = "10";
			else if (color.equals(PesConstants.YELLOW))
				score = "5";
			return score;
		}
		
		public List<CPR_SIHDTO> getCPRSIHData(Date startDate, Date endDate){
			LOGGER.info("GsheetUtil.getCPRSIHData(): START");
			try {
				
			if(startDate == null || endDate == null) {
		    ZoneId z = ZoneId.of("Asia/Kolkata");
			LocalDate today = LocalDate.now(z);
			LocalDate monday = today.with(previousOrSame(MONDAY));
			LocalDate preMonday = monday.minusDays(7);
			LocalDate preSunday = monday.minusDays(1);
			startDate = Date.from(preMonday.atStartOfDay(z).toInstant());
			endDate = Date.from(preSunday.atTime(23, 59, 59).atZone(z).toInstant());
			}
			
			//sheet service call
			sheetsService = getSheetsService();	
			//setting range
			String dataRange = "Weekly Data!A2:K";
			String sheetId = propertiesService.getPropertyByName("CPR_SIH_GSHEET_URL").getPropertyValue();
			
			//storing the response
			ValueRange response = sheetsService.spreadsheets().values()
					.get(sheetId, dataRange).execute();
			
			List<List<Object>> values = response.getValues();
			List<CPR_SIHDTO> playsList = new ArrayList<>();
			LOGGER.info(values.size());
			
			for(List<Object> row : values) {
				
				String execDate = row.get(3).toString();
				Date dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(execDate);
				if(dateOfExecution.compareTo(startDate) < 0 || dateOfExecution.compareTo(endDate) > 0)
					continue;
				String nameOfProspect = row.get(0).toString();
				String ae = row.get(1).toString();
				String sp = row.get(2).toString();
				
				String docUrl = row.get(4).toString();
				String aePodLead = row.get(5).toString();
				String spPodLead = row.get(6).toString();
				String market = row.get(7).toString();
				String aeTeam = row.get(8).toString();
				String spTeam = row.get(9).toString();
				
				CPR_SIHDTO rowObj = new CPR_SIHDTO();
				rowObj.setNameOfProspect(nameOfProspect);
				rowObj.setAE(ae);
				rowObj.setSP(sp);
				rowObj.setMarket(market);
				rowObj.setDateOfExecution(execDate);
				rowObj.setDocUrl(docUrl);
				rowObj.setAePodLead(aePodLead);
				rowObj.setSpPodLead(spPodLead);
				rowObj.setAeTeam(aeTeam);
				rowObj.setSpTeam(spTeam);
				
				playsList.add(rowObj);
			}
			return playsList;
			}
			catch(Exception e) {
				LOGGER.error("PesGsheetUtil.getCPRSIHData(): ERROR: "+e.getMessage());
				e.printStackTrace();
		    }
			return null;
		}
		
		/*
		 * function to fetch Champions and ZZTop play records from gsheet provided by pes team
		 * link : https://docs.google.com/spreadsheets/d/1W20psRIch-e1fXglk1xTXnOD0Pc918oNHO1r78rST8s/edit#gid=1688789774
		 */
		public List<ChampionsnZZTopDTO> getChampionsnZZTopExpansionData(Date startDate, Date endDate){
			LOGGER.info("GsheetUtil.getChampionsnZZTopExpansionData(): START");
			try {
				
			if(startDate == null || endDate == null) {
		    ZoneId z = ZoneId.of("Asia/Kolkata");
		    Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			// add -1 month to current month
			cal.add(Calendar.MONTH, -1);
			// set DATE to 1, so first date of previous month
			cal.set(Calendar.DATE, 1);
			Date firstDateOfPreviousMonth = cal.getTime();

			// set actual maximum date of previous month
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			Date lastDateOfPreviousMonth = cal.getTime();

			// get the records from txn_play_executions where date of execution between
			// startdate and enddate inclusive
			LocalDate startDt = new java.sql.Date(firstDateOfPreviousMonth.getTime()).toLocalDate();
			LocalDate endDt = new java.sql.Date(lastDateOfPreviousMonth.getTime()).toLocalDate();
			startDate = Date.from(startDt.atStartOfDay(z).toInstant());
			endDate = Date.from(endDt.atTime(23, 59, 59).atZone(z).toInstant());
			}
			
			//sheet service call
			sheetsService = getSheetsService();	
			//setting range
			String champions_dataRange = "Champion!A2:G";
			String zzTop_dataRange = "ZZTop!A2:G";
			String sheetId = propertiesService.getPropertyByName("CHAMPIONS_ZZTOP_GSHEET_URL").getPropertyValue();
			
			//storing the response
			ValueRange champion_response = sheetsService.spreadsheets().values()
					.get(sheetId, champions_dataRange).execute();
			
			ValueRange zzTop_response = sheetsService.spreadsheets().values()
					.get(sheetId, zzTop_dataRange).execute();
			
			List<List<Object>> champion_values = champion_response.getValues();
			List<List<Object>> zzTop_values = zzTop_response.getValues();
			List<ChampionsnZZTopDTO> playsList = new ArrayList<>();
			
			if(champion_values != null) {
			for(List<Object> row : champion_values) {
				String dateString = row.get(0).toString();
				String accountName = row.get(1).toString();
				String ae = row.get(2).toString();
				String aePodLead = row.get(3).toString();
				ChampionsnZZTopDTO rowObj = new ChampionsnZZTopDTO();
				String team = row.get(4).toString();
				String market = row.get(5).toString();
				
				Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
				
				if(startDate.compareTo(date) > 0 && endDate.compareTo(date) < 0)
					continue;
				
				rowObj.setAccountName(accountName);
				rowObj.setAE(ae);
				rowObj.setPlayName("Champions");
				rowObj.setMarket(market);
				rowObj.setDateOfExecution(dateString);
				rowObj.setPodLeadSFId(aePodLead);
				rowObj.setAETeam(team);
				
				playsList.add(rowObj);
			}
		}
			if(zzTop_values != null) {
			for(List<Object> row : zzTop_values) {
				String dateString = row.get(0).toString();
				String accountName = row.get(1).toString();
				String ae = row.get(2).toString();
				String aePodLead = row.get(3).toString();
				ChampionsnZZTopDTO rowObj = new ChampionsnZZTopDTO();
				String team = row.get(4).toString();
				String market = row.get(5).toString();
				
				Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
				
				if(startDate.compareTo(date) > 0 && endDate.compareTo(date) < 0)
					continue;
				
				rowObj.setAccountName(accountName);
				rowObj.setAE(ae);
				rowObj.setMarket(market);
				rowObj.setPlayName("ZZTop");
				rowObj.setDateOfExecution(dateString);
				rowObj.setPodLeadSFId(aePodLead);
				rowObj.setAETeam(team);
				
				playsList.add(rowObj);
			}
		}
			return playsList;
			}
			catch(Exception e) {
				LOGGER.error("PesGsheetUtil.getChampionnZZTopData(): ERROR: "+e.getMessage());
				e.printStackTrace();
		    }
			return null;
		}

		//Function to get the required txns data from the repo using Query and then massage the data to fit into sheets
		@Async
		public void exportPlaysDataToSheet(String strtDate, String ndDate, List<String> playIds,
				List<String> statusList) {
		try {
			//Property name of sheet in DB
			String dataDumpSheet = "DATA_EXPORT_SHEET";
			//Parse the date to LocalDate as per query written in Repo
			LocalDate startDate = LocalDate.parse(strtDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			LocalDate endDate = LocalDate.parse(ndDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			//Get the List of Objects of All the Txns with the play details/status between start and end date
			List<TxnPlayExecutions> txns = txnPlayExecRepo.getAllScoresBetweenDates(startDate, endDate, statusList,playIds);
			
			exportScoringData(txns, dataDumpSheet,playIds);
			//LOGGER.info("TXN= " + txns.get(0) );
			LOGGER.info("Number of records fetched : " + txns.size() + " from startDate : " + startDate
					+ " , endDate : " + endDate);

			LOGGER.error("GSheetUtil.retrieveScoringDataForExport(): END");

		}catch(Exception e) {
			LOGGER.error("GSheetUtil.retrieveScoringDataForExport(): Error at data pulling "+e.getMessage());
			
		}
			
		}


private Map<String, List<List<Object>>> exportScoringData(List<TxnPlayExecutions> alltxns, String dataDumpSheet, List<String> playIds) {
		LOGGER.info("GSheetUtil.exportScoringData(): START");
			try {
				//Connect to the Gheet Service
				sheetsService = getSheetsService();
				//Get All field List from Lu Fields
				List<Field> fieldList = fieldRepo.findAll();
				//Get all Field optiins from Map Field Options
				List<MapFieldOptions> optionList = mapFieldOptionsRepo.findAll();
				
				//Get all the playsneed this for sheet specific data loading
				List<Play> playList = playRepo.findAll();
				//Make Maps FIeld vs ID/name
				Map<String,Field> fieldNameMap = new HashMap<>();
				Map<Long,Field> fieldIdMap = new HashMap<>();
				//Make Map of Play name vs the transcations
				Map<String,List<TxnPlayExecutions>> playWiseTxnMap = new HashMap<>();
				Map<Long, MapFieldOptions> optionsIdMap = new HashMap<>();
				Map<String,Play> playIdMap = new HashMap<>();
			
				//Making Maps
				for(Field fld: fieldList) {
					fieldNameMap.put(fld.getDisplayName(), fld);
					fieldIdMap.put(fld.getId(), fld);
				}
				
				for(MapFieldOptions option: optionList) {
					optionsIdMap.put(option.getId(),option);
				}
				
				for(Play pl: playList) {
					playIdMap.put(pl.getId() + "", pl);
				}
				
				//Iterate through all the query returned final txns
				for(TxnPlayExecutions txn: alltxns) {
					//Get the name of Play from the txn obj
					String playName = txn.getPlay().getName();
					List<TxnPlayExecutions> txns = playWiseTxnMap.get(playName);
					if(txns == null) {
						txns = new ArrayList<TxnPlayExecutions>();
						txns.add(txn);
					}
					else 
						txns.add(txn);
					//adding the txns vs the play in play wise Txn map
					playWiseTxnMap.put(playName, txns);
				}
				
				Map<String,List<List<Object>>> playWiseData = new HashMap<>();		
				//Pushing the list returned by each play specific function to the final list to be exported to Gsheet
				playWiseData.put("Discovery Execute Call",discoveryExecuteCallExport(playWiseTxnMap,"Discovery Execute Call",fieldNameMap,optionsIdMap));
				playWiseData.put("Discovery STRAP",discoverySTRAPExport(playWiseTxnMap,"Discovery STRAP",fieldNameMap));
				playWiseData.put("OTC Whitespace Analysis - GI Stage",otcWhitespaceAnalysisGIStageExport(playWiseTxnMap,"OTC Whitespace Analysis - GI Stage",fieldNameMap,optionsIdMap));
				playWiseData.put("Company and People Research (CPR)",cprExport(playWiseTxnMap,"Company and People Research (CPR)",fieldNameMap));
				playWiseData.put("Champions",championsExport(playWiseTxnMap,"Champions",fieldNameMap, optionsIdMap));
				playWiseData.put("Sales Interaction History (SIH)",sihExport(playWiseTxnMap,"Sales Interaction History (SIH)",fieldNameMap));
				playWiseData.put("OTC Whitespace Web Research",otcWebResearchExport(playWiseTxnMap,"OTC Whitespace Web Research",fieldNameMap, optionsIdMap));
				playWiseData.put("OTC Whitespace Analysis - FA Stage",otcWhitespaceAnalysisFAStageExport(playWiseTxnMap,"OTC Whitespace Analysis - FA Stage",fieldNameMap, optionsIdMap));
				playWiseData.put("STRAP",strapExport(playWiseTxnMap,"STRAP",fieldNameMap, optionsIdMap));
				playWiseData.put("ZZTop",zztopExport(playWiseTxnMap,"ZZTop",fieldNameMap, optionsIdMap));
				playWiseData.put("DEMO",demoExport(playWiseTxnMap,"DEMO",fieldNameMap, optionsIdMap));

				String sheetId = propertiesService.getPropertyByName(dataDumpSheet).getPropertyValue();
				
				for(String id: playIds) {
					//Getting the name of Play as Sheet Name is same as Play name in DB
					Play play = playIdMap.get(id);
					String sheetName = play.getName();
					try {
					List<List<Object>> appendList = playWiseData.get(play.getName());
					sheetsService.spreadsheets().values().clear(sheetId, sheetName+"!A2:ZZ", null).execute();
					ValueRange appendBody = new ValueRange().setValues(appendList);
					sheetsService.spreadsheets().values()
							.append(sheetId, sheetName, appendBody).setValueInputOption("USER_ENTERED")
							.setInsertDataOption("INSERT_ROWS").setIncludeValuesInResponse(true).execute();
					if(sheetName.equals("STRAP")) {
						List<List<Object>> appendListFeedback = playWiseData.get("STRAP Feedback");
						sheetsService.spreadsheets().values().clear(sheetId, "STRAP Feedback!A2:ZZ", null).execute();
						ValueRange appendFeedbackBody = new ValueRange().setValues(appendListFeedback);
						sheetsService.spreadsheets().values()
								.append(sheetId, "STRAP Feedback", appendFeedbackBody).setValueInputOption("USER_ENTERED")
								.setInsertDataOption("INSERT_ROWS").setIncludeValuesInResponse(true).execute();
					}
					}
					catch(Exception e) {
						LOGGER.error("GsheetUtil.exportScoringData(): ERROR while exporting play data to sheet "+ sheetName 
								+ " ERROR : " +e.getMessage());
						e.printStackTrace();
					}
				}
				
				LOGGER.info("GSheetUtil.exportScoringData(): END");
				return playWiseData;
				
		}
			catch(Exception e) {
				LOGGER.error("GsheetUtil.exportScoringData(): ERROR " + e.getMessage());
				e.printStackTrace();
			}
			return null;
}

public List<List<Object>> discoveryExecuteCallExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName,Map<String, Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	//Get the txnList for this play
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		Field DiscoveryCallOutcomeByPESID = fieldNameMap.get("Discovery Call Outcome By PES");
		Field DiscoveryCallOutcomeByPODLeadID = fieldNameMap.get("Discovery Call Outcome By POD Lead");
		Field OutcomeRationaleByPESID = fieldNameMap.get("Outcome Rationale By PES");
		Field OutcomeRationaleByPODLeadID = fieldNameMap.get("Outcome Rationale By POD Lead");
		Field BuyerModeByPESID = fieldNameMap.get("Buyer Mode By PES");
		Field BuyerModeByPODLeadID = fieldNameMap.get("Buyer Mode By POD Lead");
		Field LinktoChorusairecID = fieldNameMap.get("Link to Chorus.ai rec");
		Field DCIDFld = fieldNameMap.get("DC ID");		
		
		String DiscoveryCallOutcomeByPES ="";
		String DiscoveryCallOutcomeByPODLead = "";
		String OutcomeRationaleByPES = "";
		String OutcomeRationaleByPODLead = "";
		String BuyerModeByPES ="";
		String BuyerModeByPODLead ="";
		String LinktoChorusairec ="";
		String DCId = "";
		

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
	
		
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();

			if(fieldId == DiscoveryCallOutcomeByPESID.getId()) {
				DiscoveryCallOutcomeByPES = StringUtils.isEmpty(value) ? "" : optionsIdMap.get(Long.parseLong(value)).getDisplayName();

			}
			else if(fieldId == DiscoveryCallOutcomeByPODLeadID.getId()) {
				DiscoveryCallOutcomeByPODLead = StringUtils.isEmpty(value) ? "" : optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}			
			else if(fieldId == OutcomeRationaleByPESID.getId()) {
				OutcomeRationaleByPES = value;
			}
			else if(fieldId == OutcomeRationaleByPODLeadID.getId()) {
				OutcomeRationaleByPODLead = value;
			}
			else if(fieldId == BuyerModeByPESID.getId()) {
				BuyerModeByPES = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == BuyerModeByPODLeadID.getId()) {
				BuyerModeByPODLead = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == LinktoChorusairecID.getId()) {
				LinktoChorusairec = value;
			}
			else if(fieldId == DCIDFld.getId())
				DCId = value;
		}
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(DiscoveryCallOutcomeByPES);
		row.add(DiscoveryCallOutcomeByPODLead);
		row.add(OutcomeRationaleByPES);
		row.add(OutcomeRationaleByPODLead);
		row.add(BuyerModeByPES);
		row.add(BuyerModeByPODLead);
		row.add(LinktoChorusairec);
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(DCId);
		row.add(activityId);
		
		appendList.add(row);
	}
	
	return appendList;
	
}


public List<List<Object>> discoverySTRAPExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap){
	//Get the txnList for this play
		List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
		List<List<Object>> appendList = new ArrayList<>();
		// check if txn list is empty or not
		if(txnList == null || txnList.size() == 0)
			return null;
		
		//Iterate though the txn list if data is there
		for(TxnPlayExecutions txn: txnList) {
			List<Object> row = new ArrayList<>(); 
			//Common Fields setting as per the sequence
			String accName = txn.getNameOfProspect();
			//getting the id from the fieldNameIdMap so that we can add data succesfully
			
			Field LinktoChorusairecID = fieldNameMap.get("Link to Chorus.ai rec");
			Field DCIdFld = fieldNameMap.get("DC ID");
			
			
			
			String LinktoChorusairec ="";
			String DCId = "";

			String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
			String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
			String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
			String market = txn.getMarket() == null ? "":txn.getMarket().getName();
			String team = txn.getTeam() == null ? "":txn.getTeam().getName();
			String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
			String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
			String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
			String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
			String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
			String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
			String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
			String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
			String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
			String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
			String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
			String pesStatus = txn.getPesStatus();
			String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
			String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
			String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
			String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
			String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
			
		
			List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
			for(TxnPlayExecutionData data: txnData) {
				Long fieldId = data.getFieldId();
				String value = data.getValue();

				
				if(fieldId == LinktoChorusairecID.getId()) {
					LinktoChorusairec = value;
				}
				else if(fieldId == DCIdFld.getId()) {
					DCId = value;
				}
			}
			row.add(playName);
			row.add(accName);
			row.add(assignTo);
			row.add(createdDate);
			row.add(dateOfExec);
			row.add(market);
			row.add(team);
			row.add(sp);
			row.add(ae);
			row.add(onSiteSp);
			row.add(dta);
			row.add(dsa);
			row.add(fta);
			row.add(podLead);
			row.add(sfdcStatus);
			row.add(referenceLink);
			row.add(LinktoChorusairec);
			row.add(scoringFor);
			row.add(pesComment);
			row.add(pesStatus);
			row.add(pesRating);
			row.add(pesFeedback);
			row.add(podLeadRating);
			row.add(podLeadFeedback);
			row.add(DCId);
			row.add(activityId);
			
			appendList.add(row);
		}
		
		return appendList;

}

public List<List<Object>> otcWhitespaceAnalysisGIStageExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		
		Field genererateInterestDateID = fieldNameMap.get("Generate Interest Date");
		Field functionalAlignmentDateID = fieldNameMap.get("Functional Alignment Date");
		Field valueAlignmentDateID = fieldNameMap.get("Value Alignment Date");
		Field otcwhitespaceStageID = fieldNameMap.get("OTC Whitespace Stage");
		Field aeTeamID = fieldNameMap.get("AE Team");
		Field stageID = fieldNameMap.get("Stage");
		Field opportunityNameID = fieldNameMap.get("Opportunity Name");

		
		String genererateInterestDate = "";
		String functionalAlignmentDate= "";
		String valueAlignmentDate= "";
		String otcwhitespaceStage= "";
		String aeTeam= "";
		String stage= "";
		String opportunityName ="";
		

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();

			
			if(fieldId == genererateInterestDateID.getId()) {
				genererateInterestDate = StringUtils.isEmpty(value) ? "" : value;
			}
			else if(fieldId == functionalAlignmentDateID.getId()) {
				functionalAlignmentDate = StringUtils.isEmpty(value) ? "" : value;
			}			
			else if(fieldId == valueAlignmentDateID.getId()) {
				valueAlignmentDate = StringUtils.isEmpty(value) ? "" : value;;
			}
			else if(fieldId == otcwhitespaceStageID.getId()) {
				otcwhitespaceStage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();;
			}
			else if(fieldId == aeTeamID.getId()) {
				aeTeam = value == null? "":value;
			}
			else if(fieldId == stageID.getId()) {
				stage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == opportunityNameID.getId()) {
				opportunityName = value;
			}
			
		}
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(genererateInterestDate);
		row.add(functionalAlignmentDate);
		row.add(valueAlignmentDate);
		row.add(otcwhitespaceStage);
		row.add(aeTeam);
		row.add(stage);
		row.add(opportunityName);		
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(activityId);
		
		appendList.add(row);
	}
	return appendList;
}


public List<List<Object>> otcWebResearchExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		

		Field opportunityNameID = fieldNameMap.get("Opportunity Name");
		Field DCIdFld = fieldNameMap.get("DC ID");
	
		String opportunityName ="";
		String DCId = "";

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();
			if(fieldId == opportunityNameID.getId()) {
				opportunityName = value;			
				}
			else if(fieldId == DCIdFld.getId()) {
				DCId = value;
			}
			}
			
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(opportunityName);			
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(DCId);
		row.add(activityId);
		
		appendList.add(row);
	}
	return appendList;

	}

public List<List<Object>> championsExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		
		
		Field SFDCOpportunityLinkID = fieldNameMap.get("SFDC Opportunity Link");
		Field aeTeamID = fieldNameMap.get("AE Team");
		Field stageID = fieldNameMap.get("Stage");
		Field opportunityNameID = fieldNameMap.get("Opportunity Name");
		Field opportunityOwnerID = fieldNameMap.get("Opportunity Owner");


		
		
		String SFDCOpportunityLink= "";
		String aeTeam= "";
		String stage= "";
		String opportunityName ="";
		String opportunityOwner= "";

		

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();

			
			if(fieldId == SFDCOpportunityLinkID.getId()) {
				SFDCOpportunityLink = value == null? "":value;
			}
			else if(fieldId == aeTeamID.getId()) {
				aeTeam = value == null? "":value;
			}
			else if(fieldId == stageID.getId()) {
				stage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == opportunityNameID.getId()) {
				opportunityName = value;
			}
			else if(fieldId == opportunityOwnerID.getId()) {
				opportunityOwner = value;
			}
			
		}
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(aeTeam);
		row.add(stage);
		row.add(opportunityName);		
		row.add(opportunityOwner);		
		row.add(SFDCOpportunityLink);		
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(activityId);
		
		
		appendList.add(row);
	}
	return appendList;
}

public List<List<Object>> otcWhitespaceAnalysisFAStageExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		
		Field genererateInterestDateID = fieldNameMap.get("Generate Interest Date");
		Field functionalAlignmentDateID = fieldNameMap.get("Functional Alignment Date");
		Field valueAlignmentDateID = fieldNameMap.get("Value Alignment Date");
		Field otcwhitespaceStageID = fieldNameMap.get("OTC Whitespace Stage");
		Field aeTeamID = fieldNameMap.get("AE Team");
		Field stageID = fieldNameMap.get("Stage");
		Field opportunityNameID = fieldNameMap.get("Opportunity Name");

		
		String genererateInterestDate = "";
		String functionalAlignmentDate= "";
		String valueAlignmentDate= "";
		String otcwhitespaceStage= "";
		String aeTeam= "";
		String stage= "";
		String opportunityName ="";
		

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();

			
			if(fieldId == genererateInterestDateID.getId()) {
				genererateInterestDate = StringUtils.isEmpty(value) ? "" : value;
			}
			else if(fieldId == functionalAlignmentDateID.getId()) {
				functionalAlignmentDate = StringUtils.isEmpty(value) ? "" : value;
			}			
			else if(fieldId == valueAlignmentDateID.getId()) {
				valueAlignmentDate = StringUtils.isEmpty(value) ? "" : value;;
			}
			else if(fieldId == otcwhitespaceStageID.getId()) {
				otcwhitespaceStage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();;
			}
			else if(fieldId == aeTeamID.getId()) {
				aeTeam = value == null? "":value;
			}
			else if(fieldId == stageID.getId()) {
				stage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == opportunityNameID.getId()) {
				opportunityName = value;
			}
			
		}
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(genererateInterestDate);
		row.add(functionalAlignmentDate);
		row.add(valueAlignmentDate);
		row.add(otcwhitespaceStage);
		row.add(aeTeam);
		row.add(stage);
		row.add(opportunityName);		
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(activityId);
		
		appendList.add(row);
	}
	return appendList;
}

public List<List<Object>> strapExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		
		
		Field strapOpiumLinkID = fieldNameMap.get("STRAP Opium Link");
		Field aeTeamID = fieldNameMap.get("AE Team");
		Field strapID = fieldNameMap.get("STRAP Id");
		Field stageID = fieldNameMap.get("Stage");
		Field opportunityNameID = fieldNameMap.get("Opportunity Name");
		Field opportunityOwnerID = fieldNameMap.get("Opportunity Owner");


		
		
		String strapOpiumLink= "";
		String aeTeam= "";
		String strapid = "";
		String stage= "";
		String opportunityName ="";
		String opportunityOwner= "";

		

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		Map<String,String> criteriaFeedbackMap = new HashMap<>();
		
	
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();

			
			if(fieldId == strapOpiumLinkID.getId()) {
				strapOpiumLink = value == null? "":value;
			}
			else if(fieldId == aeTeamID.getId()) {
				aeTeam = value == null? "":value;
			}
			else if(fieldId == stageID.getId()) {
				stage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == opportunityNameID.getId()) {
				opportunityName = value;
			}
			else if(fieldId == strapID.getId()) {
				strapid = value;
			}
			else if(fieldId == opportunityOwnerID.getId()) {
				opportunityOwner = value;
			}
			
		}
		List<TxnPlayExecutionFeedback> feedbackList = txn.getTxnPlayExecutionFeedback();
		for(TxnPlayExecutionFeedback feedback: feedbackList) {
			String criteria = feedback.getCriteria();
			if(!StringUtils.isEmpty(criteria) && (criteria.indexOf("Top Hurdle") != -1 || criteria.indexOf("Action Plan") != -1
					|| criteria.indexOf("Strategy") != -1)) {
				String status = feedback.getStatus();
				String pesFeedbackRating = feedback.getPesFeedbackRating();
				String curPesFeedback = feedback.getPesFeedback();
				String podLeadFeedbackRating = feedback.getPodLeadFeedbackRating();
				String curPodLeadFeedback = feedback.getPodLeadFeedback();
				if(status.equals("Accepted") ) {
					criteriaFeedbackMap.put(criteria + "-rating", pesFeedbackRating);
					criteriaFeedbackMap.put(criteria + "-feedback", curPesFeedback);
				}
				else {
					criteriaFeedbackMap.put(criteria + "-rating", podLeadFeedbackRating);
					criteriaFeedbackMap.put(criteria + "-feedback", curPodLeadFeedback);
				}
					
			}
		}
		
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(aeTeam);
		row.add(stage);
		row.add(opportunityName);		
		row.add(opportunityOwner);		
		row.add(strapid);
		row.add(strapOpiumLink);
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(criteriaFeedbackMap.get("Top Hurdle-rating"));
		row.add(criteriaFeedbackMap.get("Top Hurdle-feedback"));
		row.add(criteriaFeedbackMap.get("Action Plan-rating"));
		row.add(criteriaFeedbackMap.get("Action Plan-feedback"));
		row.add(criteriaFeedbackMap.get("Strategy-rating"));
		row.add(criteriaFeedbackMap.get("Strategy-feedback"));
		row.add(activityId);
		appendList.add(row);
	}
	return appendList;

}

public List<List<Object>> zztopExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		
		
		Field sfdcOpportunityLinkID = fieldNameMap.get("SFDC Opportunity Link");
		Field aeTeamID = fieldNameMap.get("AE Team");
		Field stageID = fieldNameMap.get("Stage");
		Field opportunityNameID = fieldNameMap.get("Opportunity Name");
		Field opportunityOwnerID = fieldNameMap.get("Opportunity Owner");


		
		
		String sfdcOpportunityLink= "";
		String aeTeam= "";
		String stage= "";
		String opportunityName ="";
		String opportunityOwner= "";

		

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();

			
			
			if(fieldId == aeTeamID.getId()) {
				aeTeam = value == null? "":value;
			}
			else if(fieldId == stageID.getId()) {
				stage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == opportunityNameID.getId()) {
				opportunityName = value;
			}
			else if(fieldId == sfdcOpportunityLinkID.getId()) {
				sfdcOpportunityLink = value;
			}
			else if(fieldId == opportunityOwnerID.getId()) {
				opportunityOwner = value;
			}
			
		}
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(aeTeam);
		row.add(stage);
		row.add(opportunityName);		
		row.add(opportunityOwner);		
		row.add(sfdcOpportunityLink);
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(activityId);
		
		appendList.add(row);
	}
	return appendList;

}

public List<List<Object>> demoExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap,Map<Long,MapFieldOptions> optionsIdMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();
		//getting the id from the fieldNameIdMap so that we can add data succesfully
		
		
		Field aeTeamID = fieldNameMap.get("AE Team");
		Field stageID = fieldNameMap.get("Stage");
		Field opportunityNameID = fieldNameMap.get("Opportunity Name");
		Field opportunityOwnerID = fieldNameMap.get("Opportunity Owner");


		String aeTeam= "";
		String stage= "";
		String opportunityName ="";
		String opportunityOwner= "";

		

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		List<TxnPlayExecutionData> txnData = txn.getTxnPlayExecutionData();
		for(TxnPlayExecutionData data: txnData) {
			Long fieldId = data.getFieldId();
			String value = data.getValue();

			
			
			if(fieldId == aeTeamID.getId()) {
				aeTeam = value == null? "":value;
			}
			else if(fieldId == stageID.getId()) {
				stage = StringUtils.isEmpty(value) ? "" :  optionsIdMap.get(Long.parseLong(value)).getDisplayName();
			}
			else if(fieldId == opportunityNameID.getId()) {
				opportunityName = value;
			}
			else if(fieldId == opportunityOwnerID.getId()) {
				opportunityOwner = value;
			}
			
		}
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(aeTeam);
		row.add(stage);
		row.add(opportunityName);		
		row.add(opportunityOwner);		
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(activityId);
		
		appendList.add(row);
	}
	return appendList;

}


public List<List<Object>> cprExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(activityId);
		
		appendList.add(row);
	}
	return appendList;

}


public List<List<Object>> sihExport(Map<String, List<TxnPlayExecutions>> playWiseTxnMap,String playName, Map<String,Field> fieldNameMap){
	List<TxnPlayExecutions> txnList = playWiseTxnMap.get(playName);
	List<List<Object>> appendList = new ArrayList<>();
	// check if txn list is empty or not
	if(txnList == null || txnList.size() == 0)
		return null;
	
	//Iterate though the txn list if data is there
	for(TxnPlayExecutions txn: txnList) {
		List<Object> row = new ArrayList<>(); 
		//Common Fields setting as per the sequence
		String accName = txn.getNameOfProspect();

		String assignTo =txn.getAssignedToPesAgent() == null? "" :txn.getAssignedToPesAgent().getEmail();
		String dateOfExec = txn.getDateOfExecution() == null ? "":txn.getDateOfExecution().toString();
		String createdDate = txn.getCreatedDate() == null ? "":txn.getCreatedDate().toString();
		String market = txn.getMarket() == null ? "":txn.getMarket().getName();
		String team = txn.getTeam() == null ? "":txn.getTeam().getName();
		String sp = txn.getSp() == null ? "":txn.getSp().getEmail();
		String ae = txn.getAe() == null ? "":txn.getAe().getEmail();
		String onSiteSp = txn.getOnsiteSp() == null ? "":txn.getOnsiteSp().getEmail();
		String dta = txn.getDta() == null ? "":txn.getDta().getEmail();
		String dsa = txn.getDsa() == null ? "":txn.getDsa().getEmail();
		String fta = txn.getFta() == null ? "":txn.getFta().getEmail();
		String podLead = txn.getPodLead() == null ? "":txn.getPodLead().getEmail();
		String sfdcStatus = StringUtils.isEmpty(txn.getSfdcStatus())?"":txn.getSfdcStatus();
		String referenceLink =StringUtils.isEmpty(txn.getDocLink())?"":txn.getDocLink();
		String scoringFor = txn.getScoringFor() == null ? "":txn.getScoringFor().getEmail();
		String pesComment = StringUtils.isEmpty(txn.getPesComments())? "":txn.getPesComments();
		String pesStatus = txn.getPesStatus();
		String pesRating = StringUtils.isEmpty(txn.getPesScore()) ? "" : txn.getPesScore();
		String pesFeedback = StringUtils.isEmpty(txn.getPesFeedback())? "":txn.getPesFeedback();
		String podLeadRating = StringUtils.isEmpty(txn.getPodLeadScore()) ? "" : txn.getPodLeadScore();
		String podLeadFeedback = StringUtils.isEmpty(txn.getPodLeadFeedback())?"":txn.getPodLeadFeedback();
		String activityId = StringUtils.isEmpty(txn.getActivityId()) ? "": txn.getActivityId();
		
	
		row.add(playName);
		row.add(accName);
		row.add(assignTo);
		row.add(createdDate);
		row.add(dateOfExec);
		row.add(market);
		row.add(team);
		row.add(sp);
		row.add(ae);
		row.add(onSiteSp);
		row.add(dta);
		row.add(dsa);
		row.add(fta);
		row.add(podLead);
		row.add(sfdcStatus);
		row.add(referenceLink);
		row.add(scoringFor);
		row.add(pesComment);
		row.add(pesStatus);
		row.add(pesRating);
		row.add(pesFeedback);
		row.add(podLeadRating);
		row.add(podLeadFeedback);
		row.add(activityId);
		
		appendList.add(row);
	}
	return appendList;

}

public List<DiscoveryCallDTO> getMidMarketDCData(String start, String end){
    LOGGER.info("GsheetUtil.getMidMarketDCData(): START");
    try {
        //Getting last 
        Date filterDate = salesForceServiceImpl.getDCFilterDate();
        LOGGER.info("DATE " + filterDate);
        // sheet
        sheetsService = getSheetsService();
        // setting range
        String dataRange = "PES App Data!A2:I";
        String sheetId = propertiesService.getPropertyByName("MIDMARKET_NEW_REPORT_ID").getPropertyValue();
        Date startDate = null;
        Date endDate = null;
        if(!StringUtils.isEmpty(start)) {
             startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
             endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
        }
        
        List<Employee> allSellers = empRepo.findAll();
        
        Map<String,String> nameSfIdMap = new HashMap<>();
        
        for(Employee emp: allSellers) {
        	nameSfIdMap.put(emp.getFullName(), emp.getSf18CharId());
        }

        // storing the response
        ValueRange response = sheetsService.spreadsheets().values().get(sheetId, dataRange).execute();
        //data from gsheet
        List<List<Object>> values = response.getValues();
        //Final plays List
        List<DiscoveryCallDTO> playsList = new ArrayList<>();
        //Iterate row by row on records fetched
        for (List<Object> row : values) {
			try {
				// One by one iterate and get row attributes
				String nameOfProspect = row.get(0).toString();
				String dcId = row.get(1).toString();
				String execDate = row.get(2).toString();
				Date dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(execDate);
				// Skip based on some condition
				if (startDate != null
						&& (startDate.compareTo(dateOfExecution) > 0 || endDate.compareTo(dateOfExecution) < 0)) {
					continue;
				} else if (startDate == null && filterDate.compareTo(dateOfExecution) != 0) {
					continue;
				}
				String activityId = generateActivityId(dcId,execDate);
				String ae = row.get(4).toString();
				String aeSf = "";
				String sp = row.get(3).toString();
				String spSf = "";
				
				if(!StringUtils.isEmpty(ae)) {
					aeSf = nameSfIdMap.get(ae);
				}
				
				if(!StringUtils.isEmpty(sp)) {
					spSf = nameSfIdMap.get(sp);
				}
				String sfdcStatus = row.get(5).toString();
				String tam = row.get(6).toString();
				String aeTeam = row.get(7).toString();
				// Create Obj for Discovery Call DTO
				DiscoveryCallDTO rowObj = new DiscoveryCallDTO();
				rowObj.setNameOfProspect(nameOfProspect);
				rowObj.setActivityId(activityId);
				rowObj.setDcId(dcId);
				//to satisfy the existing date format adding T
				rowObj.setDateOfExecution(execDate+"T");
				rowObj.setAeSfId(aeSf);
				rowObj.setSpSfId(spSf);
				rowObj.setSfdcStatus(sfdcStatus);
				rowObj.setMarket(tam);
				rowObj.setTeam(aeTeam);
				playsList.add(rowObj);
			} catch (Exception e) {
				LOGGER.error("PesGsheetUtil.getMidMarketDCData(): ERROR: " + e.getMessage());
			}
            
        }
        LOGGER.info("Fetched List size:"+playsList.size());

        return playsList;
    } catch (Exception e) {
        LOGGER.error("PesGsheetUtil.getMidMarketDCData(): ERROR: " + e.getMessage());
        e.printStackTrace();
    }
    return null;
}

//returns the UUID from two strings
public String generateActivityId(String DCId, String date) {
	return UUID.nameUUIDFromBytes((DCId + date).getBytes()).toString().replace("-", "").substring(0, 18);
}
}