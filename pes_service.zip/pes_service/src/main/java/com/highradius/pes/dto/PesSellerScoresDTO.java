package com.highradius.pes.dto;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;

public class PesSellerScoresDTO {

	private Long id;

	private String year;
	
	private String email;

	private List<String> playGroup;

	private String role;

	private Long weightage;

	private Long playsScored;

	private Double avgScore;

	private Double playAttainmentPercentage;

	private String startDate;
	
	private String endDate;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public List<String> getPlayGroup() {
		return playGroup;
	}

	public void setPlayGroup(List<String> playGroup) {
		this.playGroup = playGroup;
	}
	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Long getWeightage() {
		return weightage;
	}

	public void setWeightage(Long weightage) {
		this.weightage = weightage;
	}

	public Long getPlaysScored() {
		return playsScored;
	}

	public void setPlaysScored(Long playsScored) {
		this.playsScored = playsScored;
	}

	public Double getAvgScore() {
		return avgScore;
	}

	public void setAvgScore(Double avgScore) {
		this.avgScore = avgScore;
	}

	public Double getPlayAttainmentPercentage() {
		return playAttainmentPercentage;
	}

	public void setPlayAttainmentPercentage(Double playAttainmentPercentage) {
		this.playAttainmentPercentage = playAttainmentPercentage;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	
	
}