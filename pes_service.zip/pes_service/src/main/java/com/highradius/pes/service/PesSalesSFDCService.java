package com.highradius.pes.service;

import java.util.List;

import com.highradius.pes.dto.DiscoveryCallDTO;

public interface PesSalesSFDCService {

	//List<DiscoveryCallDTO> getSFDCReportData(String startDate, String endDate);

	List<DiscoveryCallDTO> getReport1Data(String start, String end);

	List<DiscoveryCallDTO> getReport2Data(String start, String end);

}
