package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.MapFieldOptions;

/**
 * Repository class for MapFieldOptions pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface MapFieldOptionsRepository extends JpaRepository<MapFieldOptions, Long> {

	//Query to get fieldOptions with field id
	@Query("select f from MapFieldOptions f where f.fieldId=?1")
	public List<MapFieldOptions> getByFieldId(Long id);
	
	//Query to get fieldOptions with id
	@Query("select f from MapFieldOptions f where f.id=?1")
	public MapFieldOptions getById(Long id);
	
	//Query to get fieldOptions with display name
	@Query("select f from MapFieldOptions f where f.displayName=?1")
	public MapFieldOptions getByDisplayName(String name);
	
}
