package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Reports;

/**
 * Repository class for Reports pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface ReportRepository extends JpaRepository<Reports, Long>,  JpaSpecificationExecutor<Reports> {
	
	//Query to get field by id
	@Query("select r from Reports r where r.id=?1")
	public Reports getById(Long id);
	
	//Query to get field by name
	@Query("select r from Reports r where r.name=?1")
	public Reports findByReportsName(String name);
	
	//Query to get field by category
	@Query("select r from Reports r where r.category=?1")
	public Reports findByReportCategory(String name);
	
	//Query to get field by category
	@Query("select r from Reports r where r.description=?1")
	public Reports findByReportDescription(String description);
	
	@Query("select r from Reports r where r.category=?1 and r.name=?2")
	public Reports findByCategoryAndName(String category, String name);
	
	@Query("delete from Reports r where r.category=?1 and r.name=?2")
	public void deleteByCategoryAndName(String category, String name);
//	//Query to delete Reports by id
//	@Query("delete from Reports r where r.id=?1")
//	public void deleteById(Long id);
	


}
