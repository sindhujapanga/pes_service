package com.highradius.pes.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.highradius.pes.dto.ChampionsnZZTopDTO;
import com.highradius.pes.dto.DataExportDTO;
import com.highradius.pes.dto.DiscoveryCallDTO;
import com.highradius.pes.dto.EmployeeSFDTO;
import com.highradius.pes.dto.OverriddenCommentsDTO;
import com.highradius.pes.dto.Reports_DTO;
import com.highradius.pes.dto.SalesPipelineOTCDTO;
import com.highradius.pes.dto.ScoringSearchDTO;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.PesSchedulerExecHistory;
import com.highradius.pes.model.Reports;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.scheduler.PesSalesForceScheduler;
import com.highradius.pes.service.PesCommonService;
import com.highradius.pes.service.PesReportService;
import com.highradius.pes.service.PesSalesForceService;
import com.highradius.pes.util.EmailUtil;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.JwtUtil;
import com.highradius.pes.util.PesGsheetUtil;
import com.highradius.pes.util.PdfUtil;
import com.highradius.pes.util.PesConstants;

@RestController
@CrossOrigin(origins = { "http://localhost:3000", "https://pestest.highradius.com", "https://pestest-sb.highradius.com",
		"https://pes.highradius.com", "https://pes-sb.highradius.com" })
@RequestMapping(value = "/common")
public class PesCommonController {

	@Autowired
	PesCommonService pesCommonService;

	@Autowired
	PesSalesForceScheduler pesSalesForceScheduler;

	@Autowired
	PesSalesForceService pesSalesForceService;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	EmployeeRepository empRepo;

	@Autowired
	PdfUtil pdfUtil;

	@Autowired
	PesGsheetUtil gsheetUtil;

	@Autowired
	PesReportService reportService;

	@Autowired
	PesGsheetUtil sheetUtil;

	@Autowired
	JwtUtil jwtUtil;

	private static final Logger LOGGER = LogManager.getLogger(PesCommonController.class);

	/**
	 * Gets credentials from user and authenticates an user
	 * 
	 * @param credential
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/login")
	public GenericResult loginEmployee(@RequestBody JSONObject credential) {
		LOGGER.info("PesCommonController.loginEmployee(): START");
		GenericResult result = new GenericResult();

		GenericResult loginRes;
		JSONObject data = new JSONObject();
		try {
			loginRes = jwtUtil.verifyGoogleTokenId(credential.get("cred").toString());
			if (loginRes.getSuccess()) {
				;
				JSONObject ob = (JSONObject) loginRes.getData();
				String email = (String) ob.get("email");
				String fullName = (String) ob.get("fullName");
				String jwt = jwtUtil.generateJwtToken(email);
				Date exp = jwtUtil.getJwtTokenExpiration(jwt);
				data.put("email", email);
				data.put("fullName", fullName);
				data.put("token", jwt);
				data.put("exp", exp);
				result.setSuccess(Boolean.TRUE);
				result.setMessage("User Logged in");
				LOGGER.info("PesCommonController.loginEmployee(): User logged in " + email);
			} else {
				result.setSuccess(Boolean.FALSE);
				result.setMessage("User Login Failed");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			result.setSuccess(Boolean.FALSE);
			result.setMessage("PesCommonController.loginEmployee(): User Login Failed " + e);
			e.printStackTrace();
		}

		result.setData(data);
		LOGGER.info("PesCommonController.loginEmployee(): END");
		return result;
	}

	@SuppressWarnings("unchecked")
	@PostMapping(value = "/adLogin")
	public GenericResult loginADEmployee(@RequestBody String credential) {
		LOGGER.info("PesCommonController.loginADEmployee(): START");
		GenericResult result = new GenericResult();

		GenericResult loginRes;
		JSONObject data = new JSONObject();
		try {
			loginRes = jwtUtil.verifyAzureTokenId(credential);
			if (loginRes.getSuccess()) {
				String email = (String) loginRes.getData();
				Employee emp = empRepo.findByEmailId(email);
				if (emp == null) {
					LOGGER.error("PesCommonController.loginADEmployee(): Login not authorized for " + email);
					result.setSuccess(Boolean.FALSE);
					result.setMessage("User Login Not Authorized!");
					result.setStatus(PesConstants.FAIL);
					return result;
				}
				String jwt = jwtUtil.generateJwtToken(email);
				Date exp = jwtUtil.getJwtTokenExpiration(jwt);
				data.put("email", email);
				data.put("token", jwt);
				data.put("exp", exp);
				result.setSuccess(Boolean.TRUE);
				result.setMessage("User Logged in");
				result.setStatus(PesConstants.SUCCESS);
			} else {
				result.setSuccess(Boolean.FALSE);
				result.setMessage("User Login Failed");
				result.setStatus(PesConstants.FAIL);
			}
		} catch (Exception e) {
			result.setSuccess(Boolean.FALSE);
			result.setMessage("Some went wrong! User Login Failed");
			result.setStatus(PesConstants.FAIL);
			LOGGER.error("PesCommonController.loginADEmployee(): Some went wrong! User Authentication Failed :: "
					+ e.getMessage());
		}

		result.setData(data);

		LOGGER.info("PesCommonController.loginADEmployee(): END");
		return result;
	}

	/**
	 * Validate email and jwt token of the user whether it is valid or not
	 * 
	 * @param credentials
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/authValidate")
	public GenericResult validateLoggedInEmployee(@RequestBody JSONObject credentials) {
		LOGGER.info("PesCommonController.validateLoggedInEmployee(): START");
		GenericResult result = new GenericResult();
		String email = credentials.get("email").toString();
		String token = credentials.get("token").toString();
		try {
			Boolean isAuthenticated = jwtUtil.validateJwtToken(token, email);
			if (isAuthenticated == true) {
				Date exp = jwtUtil.getJwtTokenExpiration(token);
				JSONObject data = new JSONObject();
				data.put("email", email);
				data.put("exp", exp);
				result.setData(data);
				result.setMessage("User Authenticated");
				result.setSuccess(Boolean.TRUE);
				LOGGER.info("PesCommonController.validateLoggedInEmployee(): User Authenticated :: Email " + email);
			} else {
				result.setData(null);
				result.setMessage("User Authentication Failed");
				result.setSuccess(Boolean.FALSE);
				LOGGER.error("PesCommonController.validateLoggedInEmployee(): User Authentication Failed :: Email " + email);
			}
		} catch (Exception e) {
			result.setData(null);
			result.setMessage("Some went wrong! User Authentication Failed");
			result.setSuccess(Boolean.FALSE);
			LOGGER.error("PesCommonController.validateLoggedInEmployee(): Some went wrong! User Authentication Failed :: Email "
							+ email + " error " + e.getMessage());
		}
		return result;
	}

	/**
	 * Refresh the jwt token of an user before it expires
	 * 
	 * @param credentials
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/refreshAuth")
	public GenericResult refershJwtToken(@RequestBody JSONObject credentials) {
		LOGGER.info("PesCommonController.validateLoggedInEmployee(): START");
		LOGGER.info(credentials);
		GenericResult result = new GenericResult();
		String email = credentials.get("email").toString();
		String token = credentials.get("token").toString();
		try {
			Boolean isAuthenticated = jwtUtil.validateJwtToken(token, email);
			if (isAuthenticated == true) {
				String jwt = jwtUtil.generateJwtToken(email);
				Date exp = jwtUtil.getJwtTokenExpiration(jwt);
				JSONObject data = new JSONObject();
				data.put("email", email);
				data.put("token", jwt);
				data.put("exp", exp);
				result.setData(data);
				result.setMessage("Jwt Token Refreshed");
				result.setSuccess(Boolean.TRUE);
				LOGGER.info("PesCommonController.refershJwtToken(): Jwt Token Refreshed :: Email " + email);
			} else {
				result.setData(null);
				result.setMessage("Jwt Token Refresh Failed");
				result.setSuccess(Boolean.FALSE);
				LOGGER.error("PesCommonController.refershJwtToken(): Jwt Token Refresh Failed :: Email " + email);
			}
		} catch (Exception e) {
			result.setData(null);
			result.setMessage("Some went wrong! Jwt Token Refresh Failed");
			result.setSuccess(Boolean.FALSE);
			LOGGER.error("PesCommonController.refershJwtToken(): Some went wrong! Jwt Token Refresh Failed :: Email "
					+ email);
		}
		return result;
	}

	/**
	 * handles logout action
	 * 
	 * @param token
	 * @return
	 */
	@PostMapping(value = "/logout")
	public GenericResult logoutEmployee(@RequestAttribute String token) {
		LOGGER.info("PesCommonController.logoutEmployee(): START " + token);
		GenericResult result = new GenericResult();
		try {
			Boolean logoutSuccess = jwtUtil.expireJwtToken(token);
			if (logoutSuccess) {
				result.setSuccess(Boolean.TRUE);
				result.setMessage("Logout Successful");
			} else {
				result.setSuccess(Boolean.FALSE);
				result.setMessage("Logout Failed");
			}
		} catch (Exception e) {
			result.setSuccess(Boolean.FALSE);
			result.setMessage("Some error occured! Logout Failed");
			LOGGER.error("PesCommonController.logoutEmployee(): Some error occured! Logout Failed " + e);
		}
		return result;
	}

	/**
	 * Gets employee record by role
	 * 
	 * @param role
	 * @return
	 */
	@PostMapping(value = "/empByRole")
	public GenericResult getEmployeeByRole(@RequestBody JSONObject obj) {
		LOGGER.info("PesCommonController.getEmployeeByRole(): Role = " + obj.get("role"));
		GenericResult result = new GenericResult();
		List<Map<String, String>> roles = pesCommonService.getEmployeeByRole(obj.get("role").toString());
		if (roles == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Employees with given roles");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(roles);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getEmployeeByRole(): END");
		return result;
	}

	/**
	 * Gets all the markets present in the system
	 * 
	 * @return
	 */
	@GetMapping(value = "/markets")
	public GenericResult getMarketList() {
		LOGGER.info("PesCommonController.getMarketList(): START");
		GenericResult result = new GenericResult();
		List<Map<String, String>> markets = pesCommonService.getMarketList();
		if (markets == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the markets");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(markets);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getMarketList(): END");
		return result;
	}
	
	@GetMapping(value = "/employeeRoleMap")
	public GenericResult getEmployeeRoleMap() {
		LOGGER.info("PesCommonController.getEmployeeRoleMap(): START");
		GenericResult result = new GenericResult();
		List<Map<String, String>> employeeRoleMap = pesCommonService.getEmployeeRoleMap();
		if(employeeRoleMap == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the employee and role maps");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(employeeRoleMap);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getEmployeeRoleMap(): END");
		return result;
	}

	/**
	 * Gets the list of plays present in the system
	 * 
	 * @return
	 */
	@GetMapping(value = "/plays")
	public GenericResult getPlayList() {
		LOGGER.info("PesCommonController.getPlayList(): START");
		GenericResult result = new GenericResult();
		List<Map<String, String>> plays = pesCommonService.getPlayList();
		if (plays == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the plays");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(plays);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getPlayList(): END");
		return result;
	}

	/*
	 * function to get all the prospects from the db
	 */
	@GetMapping(value = "/prospects")
	public GenericResult getProspectList() {
		LOGGER.info("PesCommonController.getProspectList(): START");
		GenericResult result = new GenericResult();
		List<Map<String, String>> prospects = pesCommonService.getProspectList();
		if (prospects == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the prospects");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(prospects);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getProspectList(): END");
		return result;
	}

	/**
	 * Gets all the teams from the system
	 * 
	 * @return
	 */
	@GetMapping(value = "/teams")
	public GenericResult getTeamList() {
		LOGGER.info("PesCommonController.getTeamsList(): START");
		GenericResult result = new GenericResult();
		List<Map<String, String>> teams = pesCommonService.getTeamList();
		if (teams == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the teams");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(teams);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getTeamsList(): END");
		return result;
	}

	/**
	 * Gets the logged in user data w.r.t user email
	 * 
	 * @param email
	 * @return
	 */
	@PostMapping(value = "/employee")
	public GenericResult getLoginUserData(@RequestBody JSONObject obj) {
		LOGGER.info("PesCommonController.getLoginUserData(): START");
		GenericResult result = new GenericResult();
		Employee emp = pesCommonService.getLoginUserData(obj.get("email").toString());
		if (emp == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("User not found in records");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(emp);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getLoginUserData(): END");
		return result;
	}

	/**
	 * Returns play field map data present in the system
	 * 
	 * @return
	 */
	@GetMapping(value = "/mapPlayFields")
	public GenericResult getPlayFieldsMapData() {
		LOGGER.info("PesCommonController.getPlayFieldsMapData() : START");
		GenericResult result = new GenericResult();
		Map<Long, List<Long>> map = pesCommonService.getPlayFieldsMapData();
		if (map == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the play field map data");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(map);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getPlayFieldsMapData() : END");
		return result;
	}

	/**
	 * Gets list of fields present in the system
	 * 
	 * @return
	 */
	@GetMapping(value = "/fields")
	public GenericResult getFieldsList() {
		LOGGER.info("PesCommonController.getFieldsList() : START");
		GenericResult result = new GenericResult();
		Map<Long, Field> map = pesCommonService.getFieldsList();
		if (map == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the fields data");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(map);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getFieldsList() : END");
		return result;
	}

	/**
	 * Gets list of reports present in the system
	 * 
	 * @return
	 */
	@GetMapping(value = "/reports")
	public GenericResult getReportList() {
		LOGGER.info("PesCommonController.getReportsList(): START");
		GenericResult result = new GenericResult();
		List<Reports_DTO> reports = pesCommonService.getReportsList();
		if (reports == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the reports");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(reports);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getReportsList(): END");
		return result;
	}

	/*
	 * Function to Add Report
	 */

	@PostMapping(value = "/report/add")
	public GenericResult addReport(@RequestBody Reports_DTO reportDto) {
		LOGGER.info("PesCommonController.addReport() : reportDto = " + reportDto.toString());
		GenericResult result = pesCommonService.addReport(reportDto);
		LOGGER.info("PesCommonController.addReport() : END");
		return result;
	}

	/**
	 * Adds supervisor override comments to records
	 * 
	 * @param overrideCommentDto
	 * @return
	 */
	@PostMapping(value = "/override/add")
	public GenericResult addOverrideComments(@RequestBody OverriddenCommentsDTO overrideCommentDto) {
		LOGGER.info("PesCommonController.addOverrideComments() : overrideCommentDto = " + overrideCommentDto.toString());
		GenericResult result = new GenericResult();
		boolean changeResult = pesCommonService.addOverriddenComments(overrideCommentDto);
		if (changeResult == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add Override Comments");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(true);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.addOverridenComments() : END");
		return result;
	}

	/**
	 * Gets all the roles to be scored for a play
	 * 
	 * @return
	 */
	@GetMapping(value = "/mapPlayRoles")
	public GenericResult getMapPlayRoles() {
		LOGGER.info("PesCommonController.getMapPlayRoles() : START");
		GenericResult result = new GenericResult();
		Map<Long, List<Long>> map = pesCommonService.getMapPlayRoles();
		if (map == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the fields data");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(map);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getMapPlayRoles() : END");
		return result;
	}

	// for getting full data back to postman
	@GetMapping(value = "/sfCheck")
	public List<DiscoveryCallDTO> getEMEAData() {
		return pesSalesForceService.getMidMarketReport(null, null);
	}

	// for getting full otc data back to postman
	@GetMapping(value = "/otcSfCheck")
	public List<SalesPipelineOTCDTO> getOTCDiscoveryCallReports() {
		return pesSalesForceService.getOTCSalesPipelineReport(null, null);
	}

	// for getting full employee data back to postman
	@GetMapping(value = "/employeeSfUpdate")
	public List<EmployeeSFDTO> getEmployeeSFReport() {
		return pesSalesForceService.getEmployeeSFReport();
	}

	// checking mail system
	@GetMapping(value = "/mailSend")
	public void sendMailTest() throws Exception {
		String emails = "subhayan.mukherjee@highradius.com";
		StringBuilder sbBody = new StringBuilder();
		String body = sbBody.append("<p>Hello ").append(",\n").append("			<br/>\n").append("			<br/>\n")
				.append("Hope you are doing well. We wanted to share with you, how the last week looked like for you.\n")
				.append("			<br/>\n").append("			<br/>\n")
				.append("Please find the weekly report pdf below which will help you gain more insight into each of the scores for the plays executed along with specific feedback.\n")
				.append("			<br/>\n").append("			<br/>\n")
				.append("Details on scoring criteria and rationales can be found in the <a href='")
				.append(PesConstants.PES_OPERA_LINK).append("'>PES OPERA.</a>\n").append("			</p><br/>\n")
				.append("<p style =\"text-decoration:underline\"> Note: This report is in the form of a standardized template used across all markets."
						+ " The Plays for which the sellers do not get scored for will be mentioned as \"No plays scored\""
						+ "and thus, their scores will not be affected.</p>")
				.append("			<br/>\n").append("All the best for the next week. Happy Selling!\n")
				.append("			<br/>\n").append("			<br/>\n").append("With Best Regards,\n")
				.append("			<br/>\n").append("Sales - Strategy & Ops\n").append("		</p>").toString();
		emailUtil.sendEmailWithAttachment("This is a test mail", body.toString(), emails, null);
	}

	// employee update
	//Commenting employee gsheet data fetch code as per PES team use case as they are now adding data manually through system
//	@PostMapping(value = "/sfEmpUpdate")
//	public GenericResult getEmployeeSfData(@RequestBody org.json.simple.JSONObject User) throws Exception {
//		LOGGER.info("PesCommonController.getEmployeeSFData(): START");
//		PesSchedulerExecHistory execHistory = null;
//		try {
//			execHistory = reportService.saveSchedulerExecutionHistory("manual: getEmployeeSFData", "Initiated");
//			pesCommonService.getEmployeeSfData((String) User.get("user"));
//			execHistory.setEndTime(new Timestamp(new Date().getTime()));
//			execHistory.setStatus("SUCCESS");
//			reportService.updateSchedulerExecutionHistory(execHistory);
//		} catch (Exception e) {
//			LOGGER.error("manual: getEmployeeSFData: Exception while updating the status " + e.getMessage());
//			execHistory.setEndTime(new Timestamp(new Date().getTime()));
//			execHistory.setStatus("FAILED");
//			execHistory.setMessage(e.getMessage() + "-" + e);
//			reportService.updateSchedulerExecutionHistory(execHistory);
//		}
//		GenericResult result = new GenericResult();
//		result.setSuccess(PesConstants.TRUE);
//		result.setMessage("Operation Started");
//		LOGGER.info("PesCommonController.getEmployeeSFData(): END");
//		return result;
//	}

	/**
	 * Returns a employee lookup with id and display name as key and value
	 * 
	 * @return
	 */
	@GetMapping(value = "/empLookupData")
	public GenericResult getEmployeesLookupData(@RequestAttribute Long roleId, 
			@RequestAttribute Long pkId) {
		LOGGER.info("PesCommonController.getEmployeesLookupData():Start");
		GenericResult result = new GenericResult();
		Map<String, List<Map<String, String>>> roles = pesCommonService.getEmployeesLookupData(roleId,pkId);
		if (roles == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Employees with given roles");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(roles);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getEmployeesLookupData(): END");
		return result;
	}

	/**
	 * Returns all common lookup data like market,teams,prospect list,etc
	 * 
	 * @return
	 */
	@GetMapping(value = "/commonLookupData")
	public GenericResult getCommonLookupData() {
		LOGGER.info("PesCommonController.getCommonLookupData():Start");
		GenericResult result = new GenericResult();
		Map<String, List<Map<String, String>>> lookupData = pesCommonService.getCommonLookupData();
		if (lookupData == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the Employees with given roles");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(lookupData);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getCommonLookupData(): END");
		return result;
	}

	/*
	 * Gets the server property from db
	 */
	@PostMapping(value = "/getServerProperties")
	public GenericResult getServerProperties(@RequestBody JSONObject obj) {
		LOGGER.info("PesCommonController.getServerProperties():Start");
		GenericResult result = new GenericResult();
		String data = pesCommonService.getServerProperties(obj.get("actionType").toString());
		if (data == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get the properties data");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getServerProperties(): END");
		return result;
	}

	/*
	 * Removes server property from db
	 */
	@GetMapping(value = "/clearServerProperty/{propName}")
	public GenericResult clearServerProperty(@PathVariable String propName) {
		LOGGER.info("PesCommonController.clearServerProperty():Start");
		GenericResult result = new GenericResult();
		boolean data = pesCommonService.clearServerProperties(propName);
		if (data == false) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to clear the properties data");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.clearServerProperty(): END");
		return result;
	}

	@GetMapping(value = "/championsZZTopGsheet")
	public GenericResult getChampionsGsheet() {
		LOGGER.info("PesCommonController.getChampionsGsheet():Start");
		GenericResult result = new GenericResult();
		List<ChampionsnZZTopDTO> data = gsheetUtil.getChampionsnZZTopExpansionData(null, null);
		if (data == null) {
			result.setData(data);
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to get Champions and ZZTop data");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesCommonController.getChampionsGsheet(): END");
		return result;
	}

//	@GetMapping(value = "/checkEmployeeGsheetData")
//	public List<EmployeeSFDTO> getEmployeeGsheetData() throws Exception {
//		return gsheetUtil.getEmployeeData();
//	}

	/**
	 * Sends the daily data dump
	 * 
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/setReportGsheetData")
	public GenericResult getReportGsheetData() throws Exception {
		LOGGER.info("PesCommonController.getReportGsheetData() : START");
		GenericResult result = new GenericResult();
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual:getReportGsheetData", "Initiated");
			sheetUtil.setReportGsheetData();
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("manual:getReportGsheetData : Exception while updating the status " + e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage() + "-" + e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started");
		LOGGER.info("PesScoringController.getReportGsheetData() : END");
		return result;
	}

	/**
	 * exporting play wise data into a dump sheet
	 * 
	 * @param dataExportDto
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/exportPlaysData")
	// Gets the data entered by the user and filters all txns based on
	// PlayName,PesStatus,startDate and endDate
	public GenericResult exportPlaysData(@RequestBody DataExportDTO dataExportDto) throws Exception {
		LOGGER.info("PesCommonController.exportPlaysData() : START");
		LOGGER.info("PesAdminController.exportPlaysData() : Export Details = " + dataExportDto.toString());
		// To capture History
		// PesSchedulerExecHistory execHistory = null;
		// Get the data from the DTO
		List<JSONObject> plays = dataExportDto.getPlay();
		// Convert Json object to simple list of Play IDs
		List<String> playIds = new ArrayList<>();
		for (JSONObject play : plays) {
			playIds.add((String) play.get("id"));
		}
		List<JSONObject> pesStatus = dataExportDto.getPesStatus();
		List<String> statusList = new ArrayList<>();
		// Convert Json object to simple list of Pes Status
		for (JSONObject status : pesStatus) {
			statusList.add((String) status.get("displayName"));
		}
		String startDate = dataExportDto.getStartDate();
		String endDate = dataExportDto.getEndDate();
		PesSchedulerExecHistory execHistory = null;

		try {
			execHistory = reportService.saveSchedulerExecutionHistory("manual:exportPlaysData", "Initated");
			LOGGER.info("Export Play Data , Data sent to Final Function with filter:" + playIds + statusList + startDate
					+ endDate);
			// Pass the values obtained from DTO to func
			sheetUtil.exportPlaysDataToSheet(startDate, endDate, playIds, statusList);
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);

		} catch (Exception e) {
			LOGGER.error("ExportPlaysDsata : Exception while Exporting the Data " + e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage() + "-" + e);
			reportService.updateSchedulerExecutionHistory(execHistory);

		}
		GenericResult result = new GenericResult();
		result.setSuccess(PesConstants.TRUE);
		result.setData(true);
		result.setMessage("Operation Started");
		LOGGER.info("PesScoringController.exportPlaysData() : END");
		return result;
	}

	@PostMapping(value = "/report/edit")
	public GenericResult editReport(@RequestBody Reports_DTO reportDto) {
		LOGGER.info("PesCommonController.editReport() : reportDto = " + reportDto.toString());
		GenericResult result = pesCommonService.editReport(reportDto);
		LOGGER.info("PesCommonController.editReport() : END");
		return result;
	}

	@PostMapping(value = "/report/delete")
	public GenericResult deleteReport(@RequestBody Reports_DTO reportDto) {
		LOGGER.info("PesCommonController.deleteReport() : reportDto = " + reportDto.toString());
		GenericResult result = pesCommonService.deleteReport(reportDto);
		LOGGER.info("PesCommonController.deleteReport() : END");
		return result;
	}

}