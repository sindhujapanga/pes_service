package com.highradius.pes.service;

import java.util.List;
import java.util.Map;

import com.highradius.pes.dto.EmployeeDTO;
import com.highradius.pes.dto.OverriddenCommentsDTO;
import com.highradius.pes.dto.Reports_DTO;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.Reports;
import com.highradius.pes.util.GenericResult;


public interface PesCommonService {

	
	public List<Map<String,String>> getEmployeeByRole(String role);
	
	public List<Map<String,String>> getMarketList();
	
	public List<Map<String,String>> getPlayList();
	
	public List<Map<String,String>> getProspectList();
	
	public List<Map<String,String>> getTeamList();
	
	public Employee getLoginUserData(String email);
	
	public Map<Long,List<Long>> getPlayFieldsMapData();
	
	public Map<Long,Field> getFieldsList();

	public List<Reports_DTO> getReportsList(); //Added by VC

	GenericResult addReport(Reports_DTO reportDto); //Added by VC
	
	boolean addOverriddenComments(OverriddenCommentsDTO overrideCommentDto); 

	//Commenting employee gsheet data fetch code as per PES team use case as they are now adding data manually through system
//	public void getEmployeeSfData(String user) throws Exception;
	
	public String getServerProperties(String propName);
	
	public boolean clearServerProperties(String propName);
	
	public Map<Long, List<Long>> getMapPlayRoles();

	Map<String, List<Map<String, String>>> getEmployeesLookupData(Long roleId, Long pkId);

	Map<String, List<Map<String, String>>> getCommonLookupData();
	
//	public Map<String, Object> getLookUpData();
	
	public GenericResult editReport(Reports_DTO reportDto);
	
	public GenericResult deleteReport(Reports_DTO reportDto);

	public List<Map<String, String>> getEmployeeRoleMap();
}
