package com.highradius.pes.dto;

import java.util.Arrays;

public class ScoringSearchDTO {

	private String[] playIds;

	private String assignedToPesAgentId;

	private String nameOfProspect;

	private String podLeadId;

	private String reviewer;
	
	private String[] marketIds;
	
	private String[] teamIds;

	private String podLeadRating;
	
	private String pesRating;

	private String executionStartDate;

	private String executionEndDate;
	
	private String createdStartDate;
	
	private String createdEndDate;
	
	private String isOverridden; 

	private String pesStatus;

	private String[] aeIds;

	private String[] spIds;
	
	private String[] dtaIds;
	
	private String[] dsaIds;

	private String[] onsiteSpIds;
	
	private String[] scoringForIds;

	public String[] getScoringForIds() {
		return scoringForIds;
	}

	public void setScoringForIds(String[] scoringForIds) {
		this.scoringForIds = scoringForIds;
	}

	private String[] sfdcStatus;

	public String[] getPlayIds() {
		return playIds;
	}

	public void setPlayIds(String[] playIds) {
		this.playIds = playIds;
	}

	public String getAssignedToPesAgentId() {
		return assignedToPesAgentId;
	}

	public void setAssignedToPesAgentId(String assignedToPesAgentId) {
		this.assignedToPesAgentId = assignedToPesAgentId;
	}

	public String getNameOfProspect() {
		return nameOfProspect;
	}

	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}

	public String getPodLeadId() {
		return podLeadId;
	}

	public void setPodLeadId(String podLeadId) {
		this.podLeadId = podLeadId;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public String getPodLeadRating() {
		return podLeadRating;
	}

	public void setPodLeadRating(String podLeadRating) {
		this.podLeadRating = podLeadRating;
	}
	
	public String getPesRating() {
		return pesRating;
	}

	public void setPesRating(String pesRating) {
		this.pesRating = pesRating;
	}
	
	public String getExecutionStartDate() {
		return executionStartDate;
	}

	public void setExecutionStartDate(String executionStartDate) {
		this.executionStartDate = executionStartDate;
	}
	
	public String getCreatedStartDate() {  //Added by VC
		return createdStartDate;
	}

	public void setCreatedStartDate(String createdStartDate) {  //Added by VC
		this.createdStartDate = createdStartDate;
	}

	public String getCreatedEndDate() {  //Added by VC
		return createdEndDate;
	}

	public void setCreatedEndDate(String createdEndDate) {  //Added by VC
		this.createdEndDate = createdEndDate;
	}

	
	public String getIsOverridden() {
		return isOverridden;
	}

	public void setIsOverridden(String isOverridden) {
		this.isOverridden = isOverridden;
	}

	public String getExecutionEndDate() {
		return executionEndDate;
	}

	public void setExecutionEndDate(String executionEndDate) {
		this.executionEndDate = executionEndDate;
	}

	public String getPesStatus() {
		return pesStatus;
	}

	public void setPesStatus(String pesStatus) {
		this.pesStatus = pesStatus;
	}

	public String[] getAeIds() {
		return aeIds;
	}

	public void setAeIds(String[] aeIds) {
		this.aeIds = aeIds;
	}

	public String[] getMarketIds() {
		return marketIds;
	}

	public void setMarketIds(String[] marketIds) {
		this.marketIds = marketIds;
	}

	public String[] getTeamIds() {
		return teamIds;
	}

	public void setTeamIds(String[] teamIds) {
		this.teamIds = teamIds;
	}

	public String[] getSpIds() {
		return spIds;
	}

	public void setSpIds(String[] spIds) {
		this.spIds = spIds;
	}

	
	public String[] getOnsiteSpIds() {
		return onsiteSpIds;
	}

	public void setOnsiteSpIds(String[] onsiteSpIds) {
		this.onsiteSpIds = onsiteSpIds;
	}

	public String[] getSfdcStatus() {
		return sfdcStatus;
	}

	public void setSfdcStatus(String[] sfdcStatus) {
		this.sfdcStatus = sfdcStatus;
	}
	
	public String[] getDtaIds() {
		return dtaIds;
	}

	public void setDtaIds(String[] dtaIds) {
		this.dtaIds = dtaIds;
	}

	public String[] getDsaIds() {
		return dsaIds;
	}

	public void setDsaIds(String[] dsaIds) {
		this.dsaIds = dsaIds;
	}

	@Override
	public String toString() {
		return "ScoringSearchDTO [playIds=" + Arrays.toString(playIds) + ", assignedToPesAgentId="
				+ assignedToPesAgentId + ", nameOfProspect=" + nameOfProspect + ", podLeadId=" + podLeadId
				+ ", reviewer=" + reviewer + ", marketIds=" + Arrays.toString(marketIds) + ", teamIds="
				+ Arrays.toString(teamIds) + ", podLeadRating=" + podLeadRating + ", pesRating=" + pesRating
				+ ", executionStartDate=" + executionStartDate + ", executionEndDate=" + executionEndDate
				+ ", createdStartDate=" + createdStartDate + ", createdEndDate=" + createdEndDate + ", isOverridden="
				+ isOverridden + ", pesStatus=" + pesStatus + ", aeIds=" + Arrays.toString(aeIds) + ", spIds="
				+ Arrays.toString(spIds) + ", dtaIds=" + Arrays.toString(dtaIds) + ", dsaIds=" + Arrays.toString(dsaIds)
				+ ", onsiteSpIds=" + Arrays.toString(onsiteSpIds) + ", scoringForIds=" + Arrays.toString(scoringForIds)
				+ ", sfdcStatus=" + Arrays.toString(sfdcStatus) + "]";
	}

	

	
	
}
