package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.highradius.pes.model.Team;

/**
 * Repository class for Team pojo. Used for queries and crud operations.
 * @author subhayan.mukherjee
 *
 */
public interface TeamRepository extends JpaRepository<Team, Long> {

	//Query to get by id
	@Query("select t from Team t where t.id=?1")
	public Team getById(Long id);
	
	//Query to get by name
		@Query("select t from Team t where t.name=?1")
		public Team findByName(String name);
	
	
}
