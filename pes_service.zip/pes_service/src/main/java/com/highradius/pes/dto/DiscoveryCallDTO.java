package com.highradius.pes.dto;

public class DiscoveryCallDTO {
	
	private String activityId;
	
	private String dateOfExecution;
	
	private String nameOfProspect;
	
	private String ftaSfId;
	
	private String aeSfId;
	
	private String spSfId;
	
	private String sfdcStatus;
	
	private String docLink;
	
	private String market;
	
    private String team;
    
    private String dcId;

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(String dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}
	
	public String getNameOfProspect() {
		return nameOfProspect;
	}

	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}

	public String getFtaSfId() {
		return ftaSfId;
	}

	public void setFtaSfId(String ftaSfId) {
		this.ftaSfId = ftaSfId;
	}

	public String getAeSfId() {
		return aeSfId;
	}

	public void setAeSfId(String aeSfId) {
		this.aeSfId = aeSfId;
	}

	public String getSpSfId() {
		return spSfId;
	}

	public void setSpSfId(String spSfId) {
		this.spSfId = spSfId;
	}

	public String getSfdcStatus() {
		return sfdcStatus;
	}

	public void setSfdcStatus(String sfdcStatus) {
		this.sfdcStatus = sfdcStatus;
	}

	public String getDocLink() {
		return docLink;
	}

	public void setDocLink(String docLink) {
		this.docLink = docLink;
	}
	
	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getDcId() {
		return dcId;
	}

	public void setDcId(String dcId) {
		this.dcId = dcId;
	}

	@Override
	public String toString() {
		return "DiscoveryCallDTO [activityId=" + activityId + ", dateOfExecution=" + dateOfExecution
				+ ", nameOfProspect=" + nameOfProspect + ", ftaSfId=" + ftaSfId + ", aeSfId=" + aeSfId + ", spSfId="
				+ spSfId + ", sfdcStatus=" + sfdcStatus + ", docLink=" + docLink + ", market=" + market + ", team="
				+ team + "]";
	}
	
	public String toStringForMail() {
		return " Date Of Execution = " + dateOfExecution
				+ ", Account Name = " + nameOfProspect + ", AE SF ID=" + aeSfId + ", SP Name = "
				+ spSfId + ", SFDC Status = " + sfdcStatus + ", Market = " + market + ", Team = "
				+ team;
	}

}
