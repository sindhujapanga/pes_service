package com.highradius.pes.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "map_market_team")
/**
 * Model class for marketPodMap pojo.Handles transactions for marketPodMap table.
 * Mapping between market and pod.
 *
 */
public class MapMarketTeam implements Serializable{
	
	private static final long serialVersionUID = 21L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "team_name")
	private String teamName;
	
	@Column(name = "pod_lead_id")
	private Long podLeadId;
	
	@Column(name = "market_id")
	private Long marketId;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_date")
	private Date updatedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public Long getPodLeadId() {
		return podLeadId;
	}

	public void setPodLeadId(Long podLeadId) {
		this.podLeadId = podLeadId;
	}

	public Long getMarket() {
		return marketId;
	}

	public void setMarket(Long marketId) {
		this.marketId = marketId;
	}
    
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public MapMarketTeam() {
		super();
	}
}
