package com.highradius.pes.service;

import com.highradius.pes.dto.PesSellerPlaySearchDTO;
import com.highradius.pes.dto.PesSellerSearchDTO;
import com.highradius.pes.dto.PlayStatusDTO;
import com.highradius.pes.util.GenericResult;

public interface PesSellerScoresService {

	public GenericResult searchSellerAttainments(PesSellerSearchDTO sellerSearchDTO, Long roleId, Long pkId);
	
	public GenericResult scoredPlayDetails(PesSellerPlaySearchDTO sellerSearchDTO, Long roleId, Long pkId);
	
	public GenericResult getPlayExecutions(Long id, Long roleId, Long pkId);
	
	public GenericResult searchSellerPlayExecutions(PlayStatusDTO sellerSearchDto, Long roleId);

}
