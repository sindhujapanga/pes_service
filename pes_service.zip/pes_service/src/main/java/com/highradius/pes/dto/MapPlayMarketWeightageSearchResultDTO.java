package com.highradius.pes.dto;

import java.util.Date;
import java.util.Map;

public class MapPlayMarketWeightageSearchResultDTO {

	private String id;
	
	private Map<String,String> play;
	
	private Map<String,String> market;
	
	private Map<String,String> team;
	
	private Map<String,String> fnRole;
	
	private String weightage;
	
	private String createdBy;
	
	private Date createdDate;
	
	private String updatedBy;
	
	private Date updatedDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Map<String, String> getPlay() {
		return play;
	}

	public void setPlay(Map<String, String> play) {
		this.play = play;
	}

	public Map<String, String> getMarket() {
		return market;
	}

	public void setMarket(Map<String, String> market) {
		this.market = market;
	}

	public Map<String, String> getTeam() {
		return team;
	}

	public void setTeam(Map<String, String> team) {
		this.team = team;
	}

	public Map<String, String> getFnRole() {
		return fnRole;
	}

	public void setFnRole(Map<String, String> fnRole) {
		this.fnRole = fnRole;
	}

	public String getWeightage() {
		return weightage;
	}

	public void setWeightage(String weightage) {
		this.weightage = weightage;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "MapPlayMarketWeightageSearchResultDTO [id=" + id + ", play=" + play + ", market=" + market + ", team="
				+ team + ", fnRole=" + fnRole + ", weightage=" + weightage + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + "]";
	}
	
	
}
