package com.highradius.pes.dto;

public class PesSellerPlaySearchDTO {
	
	
	private String playName;
	
	private Long month;
	
	private Long year;
	
	private Long sellerId;
	
	private String role;
	
	private String weekDate;

	
	
	public String getPlayName() {
		return playName;
	}

	public void setPlayName(String playName) {
		this.playName = playName;
	}

	public Long getMonth() {
		return month;
	}

	public void setMonth(Long month) {
		this.month = month;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getWeekDate() {
		return weekDate;
	}

	public void setWeekDate(String weekDate) {
		this.weekDate = weekDate;
	}

	@Override
	public String toString() {
		return "PesSellerPlaySearchDTO [playName=" + playName + ", month=" + month + ", year=" + year + ", sellerId="
				+ sellerId + ", role=" + role + ", weekDate=" + weekDate + "]";
	}
}
