/**
 * 
 */
package com.highradius.pes.service;

import java.text.ParseException;

import com.highradius.pes.model.PesSchedulerExecHistory;

/**
 * @author vamshi.bonagiri
 *
 */
public interface PesReportService {
	
	/** Method to read all the play execution scores done in previous week for each seller and calculate the weekly score**/
	public void processWeeklySellerReports() throws ParseException;
	
	public void sendWeeklySellerReports();
	
	public void generateWeeklySellerReports() throws ParseException;
	
	/** Method to read all the play execution scores done in previous week for each seller and calculate the weekly score
	 * @throws ParseException **/
	public void processMonthlySellerReports() throws ParseException;
	
	public void sendMonthlySellerReports();
	
	public void generateMonthlySellerReports() throws ParseException;

	PesSchedulerExecHistory saveSchedulerExecutionHistory(String name, String status);
	
	void updateSchedulerExecutionHistory(PesSchedulerExecHistory execHistory);

}
