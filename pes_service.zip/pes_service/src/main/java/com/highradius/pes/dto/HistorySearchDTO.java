package com.highradius.pes.dto;

import java.util.Arrays;

public class HistorySearchDTO {
	
	private String[] names;
	
	private String[] roles;
	
	private String email;
	
	private String[] nameOfProspects;
	
	private String[] playNames;
	
	private String startDate;
	
	private String endDate;
	
	public String[] getNames() {
		return names;
	}

	public void setNames(String[] names) {
		this.names = names;
	}

	public String[] getRoles() {
		return roles;
	}

	public void setRoles(String[] roles) {
		this.roles = roles;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String[] getNameOfProspects() {
		return nameOfProspects;
	}

	public void setNameOfProspects(String[] nameOfProspects) {
		this.nameOfProspects = nameOfProspects;
	}

	public String[] getPlayNames() {
		return playNames;
	}

	public void setPlayNames(String[] playNames) {
		this.playNames = playNames;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "HistorySearchDTO [names=" + Arrays.toString(names) + ", roles=" + Arrays.toString(roles) + ", email="
				+ email + ", nameOfProspects=" + Arrays.toString(nameOfProspects) + ", playNames="
				+ Arrays.toString(playNames) + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}

}
