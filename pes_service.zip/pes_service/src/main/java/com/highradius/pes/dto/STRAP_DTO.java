package com.highradius.pes.dto;

public class STRAP_DTO {

    private String accountName;
	
	private String opportunityName;
	
	private String activityId;

	private String AE;
	
	private String SP;
	
	private String DTA;
	
	private String DSA;
	
	private String market;
	
	private String AETeam;
	
	private String stageName;
	
	private String opportunityId;
	
	private String playName;
	
	private String strapOpiumLink;
	
	private String onsiteSP;
	
	private String strapId;
	
	private String dateOfExecution;

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getAE() {
		return AE;
	}

	public void setAE(String aE) {
		AE = aE;
	}

	public String getSP() {
		return SP;
	}

	public void setSP(String sP) {
		SP = sP;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getAETeam() {
		return AETeam;
	}

	public void setAETeam(String aETeam) {
		AETeam = aETeam;
	}

	public String getStageName() {
		return stageName;
	}

	public void setStageName(String stageName) {
		this.stageName = stageName;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getPlayName() {
		return playName;
	}

	public void setPlayName(String playName) {
		this.playName = playName;
	}

	public String getStrapOpiumLink() {
		return strapOpiumLink;
	}

	public void setStrapOpiumLink(String strapOpiumLink) {
		this.strapOpiumLink = strapOpiumLink;
	}

	public String getOnsiteSP() {
		return onsiteSP;
	}

	public void setOnsiteSP(String onsiteSP) {
		this.onsiteSP = onsiteSP;
	}

	public String getStrapId() {
		return strapId;
	}

	public void setStrapId(String strapId) {
		this.strapId = strapId;
	}

	public String getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(String dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}
	
	public String getDTA() {
		return DTA;
	}

	public void setDTA(String dTA) {
		DTA = dTA;
	}

	public String getDSA() {
		return DSA;
	}

	public void setDSA(String dSA) {
		DSA = dSA;
	}	

	@Override
	public String toString() {
		return "STRAP_DTO [accountName=" + accountName + ", opportunityName=" + opportunityName + ", activityId="
				+ activityId + ", AE=" + AE + ", SP=" + SP + ", DTA=" + DTA + ", DSA=" + DSA + ", market=" + market
				+ ", AETeam=" + AETeam + ", stageName=" + stageName + ", opportunityId=" + opportunityId + ", playName="
				+ playName + ", strapOpiumLink=" + strapOpiumLink + ", onsiteSP=" + onsiteSP + ", strapId=" + strapId
				+ ", dateOfExecution=" + dateOfExecution + "]";
	}

	public String toStringForMail() {
		return "Account Name = " + accountName + ", Opportunity Name=" + opportunityName + ", AE = " + AE + ", "
				+ " SP = " + SP + ", Market = " + market + ", AE Team = " + AETeam
				+ ", StageName = " + stageName + ", Play Name=" + playName;
	}
}
