package com.highradius.pes.dto;

public class SalesPipelineOTCDTO {
	
	     private String AE_Team__c;
	     private String ACTIVITY_ID;
	     private String ACCOUNT_NAME;
	     private String OPPORTUNITY_NAME;
	     private String STAGE_NAME;
	     private String Generate_Interest_Date__c;
	     private String Functional_Allignment_Date__c;
	     private String Value_Alignment_Date__c;
	     private String Stakeholders_Buy_in_Date__c;
	     private String Budget_Approval_Date__c;
	     private String Contracts_Date__c;
		 private String Onsite_SP__c;
	     private String Solution_Principal__c;
	     private String dsa;
	     private String marketName;
	     private String playName;
	     
		public String getAE_Team__c() {
			return AE_Team__c;
		}
		
		public void setAE_Team__c(String aE_Team__c) {
			AE_Team__c = aE_Team__c;
		}
		
		public String getACTIVITY_ID() {
			return ACTIVITY_ID;
		}
		
		public String getDsa() {
			return dsa;
		}

		public void setDsa(String dsa) {
			this.dsa = dsa;
		}

		public void setACTIVITY_ID(String aCTIVITY_ID) {
			ACTIVITY_ID = aCTIVITY_ID;
		}
		
		public String getACCOUNT_NAME() {
			return ACCOUNT_NAME;
		}
		
		public void setACCOUNT_NAME(String aCCOUNT_NAME) {
			ACCOUNT_NAME = aCCOUNT_NAME;
		}
		
		public String getOPPORTUNITY_NAME() {
			return OPPORTUNITY_NAME;
		}
		
		public void setOPPORTUNITY_NAME(String oPPORTUNITY_NAME) {
			OPPORTUNITY_NAME = oPPORTUNITY_NAME;
		}
		
		public String getSTAGE_NAME() {
			return STAGE_NAME;
		}
		
		public void setSTAGE_NAME(String sTAGE_NAME) {
			STAGE_NAME = sTAGE_NAME;
		}
		
		public String getGenerate_Interest_Date__c() {
			return Generate_Interest_Date__c;
		}
		
		public void setGenerate_Interest_Date__c(String generate_Interest_Date__c) {
			Generate_Interest_Date__c = generate_Interest_Date__c;
		}
		
		public String getFunctional_Allignment_Date__c() {
			return Functional_Allignment_Date__c;
		}
		
		public void setFunctional_Allignment_Date__c(String functional_Allignment_Date__c) {
			Functional_Allignment_Date__c = functional_Allignment_Date__c;
		}
		
		public String getValue_Alignment_Date__c() {
			return Value_Alignment_Date__c;
		}
		
		public void setValue_Alignment_Date__c(String value_Alignment_Date__c) {
			Value_Alignment_Date__c = value_Alignment_Date__c;
		}
		
		public String getOnsite_SP__c() {
			return Onsite_SP__c;
		}
		
		public void setOnsite_SP__c(String onsite_SP__c) {
			Onsite_SP__c = onsite_SP__c;
		}
		
		public String getSolution_Principal__c() {
			return Solution_Principal__c;
		}
		
		public void setSolution_Principal__c(String solution_Principal__c) {
			Solution_Principal__c = solution_Principal__c;
		}
		
		
		public String getMarketName() {
			return marketName;
		}
		
		public void setMarketName(String marketName) {
			this.marketName = marketName;
		}
		
		public String getPlayName() {
			return playName;
		}
		
		public void setPlayName(String playName) {
			this.playName = playName;
		}		
		
	    public String getStakeholders_Buy_in_Date__c() {
			return Stakeholders_Buy_in_Date__c;
		}

		public void setStakeholders_Buy_in_Date__c(String stakeholders_Buy_in_Date__c) {
			Stakeholders_Buy_in_Date__c = stakeholders_Buy_in_Date__c;
		}

		public String getBudget_Approval_Date__c() {
			return Budget_Approval_Date__c;
		}

		public void setBudget_Approval_Date__c(String budget_Approval_Date__c) {
			Budget_Approval_Date__c = budget_Approval_Date__c;
		}

		public String getContracts_Date__c() {
			return Contracts_Date__c;
		}

		public void setContracts_Date__c(String contracts_Date__c) {
			Contracts_Date__c = contracts_Date__c;
		}

		@Override
		public String toString() {
			return "SalesPipelineOTCDTO [AE_Team__c=" + AE_Team__c + ", ACTIVITY_ID=" + ACTIVITY_ID + ", ACCOUNT_NAME="
					+ ACCOUNT_NAME + ", OPPORTUNITY_NAME=" + OPPORTUNITY_NAME + ", STAGE_NAME=" + STAGE_NAME
					+ ", Generate_Interest_Date__c=" + Generate_Interest_Date__c + ", Functional_Allignment_Date__c="
					+ Functional_Allignment_Date__c + ", Value_Alignment_Date__c=" + Value_Alignment_Date__c
					+ ", Stakeholders_Buy_in_Date__c=" + Stakeholders_Buy_in_Date__c + ", Budget_Approval_Date__c="
					+ Budget_Approval_Date__c + ", Contracts_Date__c=" + Contracts_Date__c + ", Onsite_SP__c="
					+ Onsite_SP__c + ", Solution_Principal__c=" + Solution_Principal__c + ", dsa=" + dsa
					+ ", marketName=" + marketName + ", playName=" + playName + "]";
		}
		
		public String toStringForMail() {
			return "ACCOUNT_NAME = " + ACCOUNT_NAME + ", OPPORTUNITY NAME = " + OPPORTUNITY_NAME + ", STAGE NAME = " + STAGE_NAME
					+", Onsite SP = " + Onsite_SP__c + ", Solution Principal = " + Solution_Principal__c + ", Market Name=" + marketName
					+ ", Play Name = " + playName;
		}
		
		
}
