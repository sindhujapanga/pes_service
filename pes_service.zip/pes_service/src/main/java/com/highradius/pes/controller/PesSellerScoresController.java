package com.highradius.pes.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.highradius.pes.dto.PesSellerPlaySearchDTO;
import com.highradius.pes.dto.PesSellerPlaySearchResultsDTO;
import com.highradius.pes.dto.PesSellerScoresDTO;
import com.highradius.pes.dto.PesSellerSearchDTO;
import com.highradius.pes.dto.PlayStatusDTO;
import com.highradius.pes.service.PesSellerScoresService;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.PesConstants;

@RestController
@CrossOrigin(origins = { "http://localhost:3000", "https://pestest.highradius.com", "https://pestest-sb.highradius.com",
		"https://pes.highradius.com", "https://pes-sb.highradius.com" })
@RequestMapping(value = "/seller")

public class PesSellerScoresController {

	@Autowired
	PesSellerScoresService pesSellerScoresService;

	private static final Logger LOGGER = LogManager.getLogger(PesSellerScoresController.class);

	@PostMapping(value = "/search")
	public GenericResult searchSellerAttainments(@RequestAttribute Long roleId, 
			@RequestAttribute Long pkId, @RequestBody PesSellerSearchDTO sellerSearchDTO) {
		LOGGER.info("PesSellerScoresController.searchSellerAttainments(): START");
		GenericResult result = pesSellerScoresService.searchSellerAttainments(sellerSearchDTO, roleId, pkId);
		List<PesSellerScoresDTO> data = (List<PesSellerScoresDTO>) result.getData();
		LOGGER.info(result);
		if (data == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			//result.setMessage("Unable to get the seller data");
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(data);
			result.setMessage("Operation Successful");
		}
		LOGGER.info("PesSellerScoresController.searchSellerAttainments(): END");
		return result;
	}
	
	@PostMapping(value = "/playStatusSearch")
	public GenericResult searchSellerPlayExecutions(@RequestBody PlayStatusDTO sellerSearchDto, @RequestAttribute Long roleId) {
		LOGGER.info("PesScoringController.searchSellerPlayExecutions() : SellerSearchDTO = " + sellerSearchDto.toString());
		try {
			GenericResult searchResult = pesSellerScoresService.searchSellerPlayExecutions(sellerSearchDto, roleId);
			return searchResult;
		}
		catch(Exception e) {
			LOGGER.error("PesScoringController.searchPlayExecutions() : ScoringSearchDTO : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	
	@PostMapping(value = "/scoredPlayDetails")
	public GenericResult scoredPlayDetails(@RequestAttribute Long roleId,@RequestAttribute Long pkId, @RequestBody PesSellerPlaySearchDTO pesSellerSearchDTO) {
		try {
		LOGGER.info("PesSellerScoringController.searchPlayDetails() : pesSellerSearchDTO = " + pesSellerSearchDTO.toString());
		
		//Making Generic result object to get the data and return message to Client 
		GenericResult result = pesSellerScoresService.scoredPlayDetails(pesSellerSearchDTO, roleId, pkId);
		@SuppressWarnings("unchecked")
		List<PesSellerPlaySearchResultsDTO> searchList  = (List<PesSellerPlaySearchResultsDTO>) result.getData();
		if (searchList == null) {
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Search Failed Please check with the Administrator");
			LOGGER.info(result);
		} else {
			result.setSuccess(PesConstants.TRUE);
			result.setData(searchList);
			result.setMessage("Operation Successful");
		}
		return result;
		}
		catch(Exception e) {
			LOGGER.error("PesSellerScoringController.searchPlayDetails() : pesSellerSearchDTO : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Gets the particular record from the id
	 * @param id
	 * @return
	 */
	@PostMapping(value = "/getPlayExc")
	public GenericResult getPlayExecForScoringById(@RequestAttribute Long roleId,@RequestAttribute Long pkId, @RequestBody Long id) {
		LOGGER.info("PesSellerScoringController.getPlayExecForScoringById : Play Id = " + id);
		GenericResult result = pesSellerScoresService.getPlayExecutions(id, roleId, pkId);
		LOGGER.info("PesSellerScoringController.updatePlayExecForScoring : END");
		return result;
	}
	
}
