package com.highradius.pes.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "txn_play_executions")
/**
 * Model class transactionPlayExectutions pojo.Handles transactions for
 * transactionPlayExectutions table. Stores transactionPlayExecutions data
 * without data of fields specific to a play. Has data of all common fields.
 * 
 */
public class TxnPlayExecutions implements Serializable {

	public static final long serialVersionUID = 27L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "is_starred")
	private boolean isStarred = false;

	@Column(name = "activity_id")
	private String activityId;

	@Column(name = "name_of_prospect")
	private String nameOfProspect;

	@Column(name = "opportunity_name")
	private String opportunityName;

	@Column(name = "date_of_execution")
	private Date dateOfExecution;

	@Column(name = "pes_status")
	private String pesStatus;

	@Column(name = "sfdc_status")
	private String sfdcStatus;

	@Column(name = "pes_score")
	private String pesScore;

	@Column(name = "high_level_feedback")
	private String highLevelFeedback;

	@Column(name = "detailed_feedback")
	private String detailed_feedback;

	@Column(name = "pod_lead_score")
	private String podLeadScore;

	@Column(name = "pes_feedback")
	private String pesFeedback;

	@Column(name = "pod_lead_feedback")
	private String podLeadFeedback;

	@Column(name = "completed_on")
	private Date completedOn;

	@Column(name = "final_score")
	private String finalScore;

	@Column(name = "doc_link")
	private String docLink;

	@Column(name = "pes_comments")
	private String pesComments;

	@Column(name = "leader_comments")
	private String leaderComments;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date")
	private Date updatedDate;

	@Column(name = "overriden")
	private String overriden;

	@Column(name = "rating_accuracy")
	private String ratingAccuracy;

	@Column(name = "feedback_accuracy")
	private String feedbackAccuracy;

	@Column(name = "overall_pes_effectiveness")
	private String overallPesEffectiveness;

	@Column(name = "valid_override")
	private Integer valid_override;

	@Column(name = "rationale")
	private String rationale;

	@Column(name = "manager_comments")
	private String manager_comments;
	
	@Column(name = "submitted_date")
	private Date submittedDate;

	public Integer getValid_override() {
		return valid_override;
	}

	public void setValid_override(Integer valid_override) {
		this.valid_override = valid_override;
	}

	public String getRationale() {
		return rationale;
	}

	public void setRationale(String rationale) {
		this.rationale = rationale;
	}

	public String getManager_comments() {
		return manager_comments;
	}

	public void setManager_comments(String manager_comments) {
		this.manager_comments = manager_comments;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = TxnPlayExecutionData.class)
	@JoinColumn(name = "txn_play_execution_id", referencedColumnName = "id")
	private List<TxnPlayExecutionData> txnPlayExecutionData;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, targetEntity = TxnPlayExecutionFeedback.class)
	@JoinColumn(name = "txn_play_execution_id", referencedColumnName = "id")
	private List<TxnPlayExecutionFeedback> txnPlayExecutionFeedback;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Market.class)
	@JoinColumn(name = "market_id", referencedColumnName = "id")
	private Market market;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Team.class)
	@JoinColumn(name = "team_id", referencedColumnName = "id")
	private Team team;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Play.class)
	@JoinColumn(name = "play_id", referencedColumnName = "id")
	private Play play;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "ae_id", referencedColumnName = "id")
	private Employee ae;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "sp_id", referencedColumnName = "id")
	private Employee sp;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "fta_id", referencedColumnName = "id")
	private Employee fta;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "dta_id", referencedColumnName = "id")
	private Employee dta;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "dsa_id", referencedColumnName = "id")
	private Employee dsa;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "reviewed_by", referencedColumnName = "id")
	private Employee reviewedBy;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "onsiteSp_id", referencedColumnName = "id")
	private Employee onsiteSp;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "assigned_to_pes_agent_id", referencedColumnName = "id")
	private Employee assignedToPesAgent;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "assigned_by_pes_lead_id", referencedColumnName = "id")
	private Employee assignedByPesLead;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "pod_lead_id", referencedColumnName = "id")
	private Employee podLead;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = Employee.class)
	@JoinColumn(name = "scoring_for", referencedColumnName = "id")
	private Employee scoringFor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Boolean getIsStarred() {
		return isStarred;
	}

	public void setIsStarred(Boolean isStarred) {
		this.isStarred = isStarred;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getNameOfProspect() {
		return nameOfProspect;
	}

	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public Date getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(Date dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}

	public String getPesStatus() {
		return pesStatus;
	}

	public void setPesStatus(String pesStatus) {
		this.pesStatus = pesStatus;
	}

	public String getSfdcStatus() {
		return sfdcStatus;
	}

	public void setSfdcStatus(String sfdcStatus) {
		this.sfdcStatus = sfdcStatus;
	}

	public String getPesScore() {
		return pesScore;
	}

	public void setPesScore(String pesScore) {
		this.pesScore = pesScore;
	}

	public String getHighLevelFeedback() {
		return highLevelFeedback;
	}

	public void setHighLevelFeedback(String highLevelFeedback) {
		this.highLevelFeedback = highLevelFeedback;
	}

	public String getDetailed_feedback() {
		return detailed_feedback;
	}

	public void setDetailed_feedback(String detailed_feedback) {
		this.detailed_feedback = detailed_feedback;
	}

	public String getPodLeadScore() {
		return podLeadScore;
	}

	public void setPodLeadScore(String podLeadScore) {
		this.podLeadScore = podLeadScore;
	}

	public String getPesFeedback() {
		return pesFeedback;
	}

	public void setPesFeedback(String podLeadHighLevelFeedback) {
		this.pesFeedback = podLeadHighLevelFeedback;
	}

	public String getPodLeadFeedback() {
		return podLeadFeedback;
	}

	public void setPodLeadFeedback(String podLeadDetailedFeedback) {
		this.podLeadFeedback = podLeadDetailedFeedback;
	}

	public Date getCompletedOn() {
		return completedOn;
	}

	public void setCompletedOn(Date completedOn) {
		this.completedOn = completedOn;
	}

	public String getFinalScore() {
		return finalScore;
	}

	public void setFinalScore(String finalScore) {
		this.finalScore = finalScore;
	}

	public String getDocLink() {
		return docLink;
	}

	public void setDocLink(String docLink) {
		this.docLink = docLink;
	}

	public String getPesComments() {
		return pesComments;
	}

	public void setPesComments(String pesComments) {
		this.pesComments = pesComments;
	}

	public String getLeaderComments() {
		return leaderComments;
	}

	public void setLeaderComments(String leaderComments) {
		this.leaderComments = leaderComments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public List<TxnPlayExecutionData> getTxnPlayExecutionData() {
		return txnPlayExecutionData;
	}

	public void setTxnPlayExecutionData(List<TxnPlayExecutionData> txnPlayExecutionData) {
		this.txnPlayExecutionData = txnPlayExecutionData;
	}

	public List<TxnPlayExecutionFeedback> getTxnPlayExecutionFeedback() {
		return txnPlayExecutionFeedback;
	}

	public void setTxnPlayExecutionFeedback(List<TxnPlayExecutionFeedback> txnPlayExecutionFeedback) {
		this.txnPlayExecutionFeedback = txnPlayExecutionFeedback;
	}

	public Market getMarket() {
		return market;
	}

	public void setMarket(Market market) {
		this.market = market;
	}

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}

	public Play getPlay() {
		return play;
	}

	public void setPlay(Play play) {
		this.play = play;
	}

	public Employee getAe() {
		return ae;
	}

	public void setAe(Employee ae) {
		this.ae = ae;
	}

	public Employee getSp() {
		return sp;
	}

	public void setSp(Employee sp) {
		this.sp = sp;
	}

	public Employee getFta() {
		return fta;
	}

	public void setFta(Employee fta) {
		this.fta = fta;
	}

	public Employee getReviewedBy() {
		return reviewedBy;
	}

	public void setReviewedBy(Employee reviewedBy) {
		this.reviewedBy = reviewedBy;
	}

	public Employee getOnsiteSp() {
		return onsiteSp;
	}

	public void setOnsiteSp(Employee onsiteSp) {
		this.onsiteSp = onsiteSp;
	}

	public Employee getAssignedToPesAgent() {
		return assignedToPesAgent;
	}

	public void setAssignedToPesAgent(Employee assignedToPesAgent) {
		this.assignedToPesAgent = assignedToPesAgent;
	}

	public Employee getAssignedByPesLead() {
		return assignedByPesLead;
	}

	public void setAssignedByPesLead(Employee assignedByPesLead) {
		this.assignedByPesLead = assignedByPesLead;
	}

	public Employee getPodLead() {
		return podLead;
	}

	public void setPodLead(Employee podLead) {
		this.podLead = podLead;
	}

	public Employee getScoringFor() {
		return scoringFor;
	}

	public void setScoringFor(Employee scoringFor) {
		this.scoringFor = scoringFor;
	}

	public String getOverriden() {
		return overriden;
	}

	public void setOverriden(String overriden) {
		this.overriden = overriden;
	}

	public Employee getDta() {
		return dta;
	}

	public void setDta(Employee dta) {
		this.dta = dta;
	}

	public Employee getDsa() {
		return dsa;
	}

	public void setDsa(Employee dsa) {
		this.dsa = dsa;
	}

	public String getRatingAccuracy() {
		return ratingAccuracy;
	}

	public void setRatingAccuracy(String ratingAccuracy) {
		this.ratingAccuracy = ratingAccuracy;
	}

	public String getFeedbackAccuracy() {
		return feedbackAccuracy;
	}

	public void setFeedbackAccuracy(String feedbackAccuracy) {
		this.feedbackAccuracy = feedbackAccuracy;
	}

	public String getOverallPesEffectiveness() {
		return overallPesEffectiveness;
	}

	public void setOverallPesEffectiveness(String overallPesEffectiveness) {
		this.overallPesEffectiveness = overallPesEffectiveness;
	}

	public Date getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}

	public void copy(TxnPlayExecutions txn) {
		this.setIsStarred(txn.getIsStarred());
		this.setActivityId(txn.getActivityId());
		this.setNameOfProspect(txn.getNameOfProspect());
		this.setOpportunityName(txn.getOpportunityName());
		this.setDateOfExecution(txn.getDateOfExecution());
		this.setPesStatus(txn.getPesStatus());
		this.setSfdcStatus(txn.getSfdcStatus());
		this.setPesScore(txn.getPesScore());
		this.setHighLevelFeedback(txn.getHighLevelFeedback());
		this.setDetailed_feedback(txn.getDetailed_feedback());
		this.setPodLeadScore(txn.getPodLeadScore());
		this.setPesFeedback(txn.getPesFeedback());
		this.setPodLeadFeedback(txn.getPodLeadFeedback());
		this.setFinalScore(txn.getFinalScore());
		this.setDocLink(txn.getDocLink());
		this.setPesComments(txn.getPesComments());
		this.setLeaderComments(txn.getLeaderComments());
		this.setCreatedBy(txn.getCreatedBy());
		this.setCreatedDate(txn.getCreatedDate());
		this.setUpdatedBy(txn.getUpdatedBy());
		this.setUpdatedDate(txn.getUpdatedDate());
		this.setMarket(txn.getMarket());
		this.setTeam(txn.getTeam());
		this.setPlay(txn.getPlay());
		this.setAe(txn.getAe());
		this.setSp(txn.getSp());
		this.setFta(txn.getFta());
		this.setDta(txn.getDta());
		this.setDsa(txn.getDsa());
		this.setReviewedBy(txn.getReviewedBy());
		this.setOnsiteSp(txn.getOnsiteSp());
		this.setAssignedToPesAgent(txn.getAssignedToPesAgent());
		this.setAssignedByPesLead(txn.getAssignedByPesLead());
		this.setScoringFor(txn.getScoringFor());
		this.setRatingAccuracy(txn.getRatingAccuracy());
		this.setFeedbackAccuracy(txn.getFeedbackAccuracy());
		this.setOverallPesEffectiveness(txn.getOverallPesEffectiveness());
		this.setValid_override(txn.getValid_override());
		this.setRationale(txn.getRationale());
		this.setManager_comments(txn.getManager_comments());
		this.setSubmittedDate(txn.getSubmittedDate());
	}

	@Override
	public String toString() {
		return "TxnPlayExecutions [id=" + id + ", isStarred=" + isStarred + ", activityId=" + activityId
				+ ", nameOfProspect=" + nameOfProspect + ", opportunityName=" + opportunityName + ", dateOfExecution="
				+ dateOfExecution + ", pesStatus=" + pesStatus + ", sfdcStatus=" + sfdcStatus + ", pesScore=" + pesScore
				+ ", highLevelFeedback=" + highLevelFeedback + ", detailed_feedback=" + detailed_feedback
				+ ", podLeadScore=" + podLeadScore + ", pesFeedback=" + pesFeedback + ", podLeadFeedback="
				+ podLeadFeedback + ", completedOn=" + completedOn + ", finalScore=" + finalScore + ", docLink="
				+ docLink + ", pesComments=" + pesComments + ", leaderComments=" + leaderComments + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate="
				+ updatedDate + ", overriden=" + overriden + ", ratingAccuracy=" + ratingAccuracy
				+ ", feedbackAccuracy=" + feedbackAccuracy + ", overallPesEffectiveness=" + overallPesEffectiveness
				+ ", valid_override=" + valid_override + ", rationale=" + rationale + ", manager_comments="
				+ manager_comments + ", submittedDate=" + submittedDate + ", txnPlayExecutionData="
				+ txnPlayExecutionData + ", txnPlayExecutionFeedback=" + txnPlayExecutionFeedback + ", market=" + market
				+ ", team=" + team + ", play=" + play + ", ae=" + ae + ", sp=" + sp + ", fta=" + fta + ", dta=" + dta
				+ ", dsa=" + dsa + ", reviewedBy=" + reviewedBy + ", onsiteSp=" + onsiteSp + ", assignedToPesAgent="
				+ assignedToPesAgent + ", assignedByPesLead=" + assignedByPesLead + ", podLead=" + podLead
				+ ", scoringFor=" + scoringFor + "]";
	}

}
