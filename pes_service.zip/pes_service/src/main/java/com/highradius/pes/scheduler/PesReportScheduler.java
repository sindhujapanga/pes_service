/**
 * 
 */
package com.highradius.pes.scheduler;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.highradius.pes.model.PesSchedulerExecHistory;
import com.highradius.pes.service.PesReportService;
import com.highradius.pes.service.PesScoringService;
import com.highradius.pes.util.PesGsheetUtil;
import com.highradius.pes.util.PesPropertiesUtil;

/**
 * @author vamshi.bonagiri
 *
 */
@Component
public class PesReportScheduler {
	
	@Autowired
	PesScoringService pesScoringService;
	
	@Autowired
	PesReportService reportService;
	
	@Autowired
	PesGsheetUtil gsheetUtil;
	
	@Autowired
	PesPropertiesUtil properties;
	
	private static final Logger LOGGER = LogManager.getLogger(PesReportScheduler.class); 
	
	//Every Friday:5AM: Schedule job to update the scoring status to completed and set the completed on date
	@Scheduled(cron = "0 0 18 * * FRI", zone="Asia/Calcutta")
	public void updatePesStatusToCompleted() {
		LOGGER.info("pesReportScheduler.updatePesStatusToCompleted(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("updatePesStatusToCompleted", "Initiated");
			pesScoringService.updateStatusToCompleted();
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (Exception e) {
			LOGGER.error("updatePesStatusToCompleted: Exception while updating the status "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesReportScheduler.updatePesStatusToCompleted(): END");
	}
	
	//Every Friday:5AM: Schedule job to process the seller scores
	//TODO:scheduler audit table
	@Scheduled(cron = "0 0 19 1-7 * FRI", zone="Asia/Calcutta")
	public void processWeeklySellerFirstWeekScores() {
		LOGGER.info("pesReportScheduler.processSellerScores(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("processWeeklySellerScores", "Initiated");
			reportService.processWeeklySellerReports();
			reportService.generateWeeklySellerReports();
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (ParseException e) {
			LOGGER.error("processWeeklySellerScores: Exception while processing the weekly score: "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesReportScheduler.processSellerScores(): END");
	}
	
	//Every Friday:5AM: Schedule job to process the seller scores
		//TODO:scheduler audit table
		@Scheduled(cron = "0 0 19 15-31 * FRI", zone="Asia/Calcutta")
		public void processWeeklySellerRestWeekScores() {
			LOGGER.info("pesReportScheduler.processSellerScores(): START");
			PesSchedulerExecHistory execHistory = null;
			try {
				execHistory = reportService.saveSchedulerExecutionHistory("processWeeklySellerScores", "Initiated");
				reportService.processWeeklySellerReports();
				reportService.generateWeeklySellerReports();
				execHistory.setEndTime(new Timestamp(new Date().getTime()));
				execHistory.setStatus("SUCCESS");
				reportService.updateSchedulerExecutionHistory(execHistory);
			} catch (ParseException e) {
				LOGGER.error("processWeeklySellerScores: Exception while processing the weekly score: "+e.getMessage());
				execHistory.setEndTime(new Timestamp(new Date().getTime()));
				execHistory.setStatus("FAILED");
				execHistory.setMessage(e.getMessage()+"-"+e);
				reportService.updateSchedulerExecutionHistory(execHistory);
			}
			LOGGER.info("pesReportScheduler.processSellerScores(): END");
		}
	
	//Every Friday:5AM: Schedule job to process the monthly seller scores
	//TODO:scheduler audit table
	@Scheduled(cron = "0 30 19 8-14 * FRI", zone="Asia/Calcutta")
	public void processMonthlySellerScores() {
		LOGGER.info("pesReportScheduler.processMonthlySellerScores(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("processMonthlySellerScores", "Initiated");
			reportService.processWeeklySellerReports();
			reportService.processMonthlySellerReports();
			reportService.generateMonthlySellerReports();
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("SUCCESS");
			reportService.updateSchedulerExecutionHistory(execHistory);
		} catch (ParseException e) {
			LOGGER.error("processMonthlySellerScores: Exception while processing the Monthly score: "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesReportScheduler.processMonthlySellerScores(): END");
	}
		
	//Every Friday:8AM: Schedule job to send the weekly seller scores
	//TODO:scheduler audit table
	@Scheduled(cron = "0 0 20 1-7 * FRI", zone="Asia/Calcutta")
	public void sendFirstWeeklySellerReports() {
		LOGGER.info("pesReportScheduler.sendWeeklySellerReports(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("sendWeeklySellerReports", "Initiated");
			boolean enableGlobalMail = Boolean.parseBoolean(properties.getPropertyByName("ENABLE_GLOBAL_EMAIL").getPropertyValue());
			if (enableGlobalMail) {
					reportService.sendWeeklySellerReports();
					execHistory.setEndTime(new Timestamp(new Date().getTime()));
					execHistory.setStatus("SUCCESS");
					reportService.updateSchedulerExecutionHistory(execHistory);
			}
		} catch (Exception e) {
			LOGGER.error("sendWeeklySellerReports: Exception while sending the weekly report: "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesReportScheduler.sendWeeklySellerReports(): END");
	}
	
	@Scheduled(cron = "0 0 20 15-31 * FRI", zone="Asia/Calcutta")
	public void sendRestWeeklySellerReports() {
		LOGGER.info("pesReportScheduler.sendWeeklySellerReports(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("sendWeeklySellerReports", "Initiated");
			boolean enableGlobalMail = Boolean.parseBoolean(properties.getPropertyByName("ENABLE_GLOBAL_EMAIL").getPropertyValue());
			if (enableGlobalMail) {
					reportService.sendWeeklySellerReports();
					execHistory.setEndTime(new Timestamp(new Date().getTime()));
					execHistory.setStatus("SUCCESS");
					reportService.updateSchedulerExecutionHistory(execHistory);
			}
		} catch (Exception e) {
			LOGGER.error("sendWeeklySellerReports: Exception while sending the weekly report: "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesReportScheduler.sendWeeklySellerReports(): END");
	}
	
	//Every second Friday 10AM: Schedule job to process the seller scores
	@Scheduled(cron = "0 0 21 8-14 * FRI", zone="Asia/Calcutta")
	public void sendMonthlySellerReports() {
		LOGGER.info("pesReportScheduler.sendMonthlySellerReports(): START");
		PesSchedulerExecHistory execHistory = null;
		try {
			execHistory = reportService.saveSchedulerExecutionHistory("sendMonthlySellerReports", "Initiated");
			boolean enableGlobalMail = Boolean.parseBoolean(properties.getPropertyByName("ENABLE_GLOBAL_EMAIL").getPropertyValue());
			if (enableGlobalMail) {
				reportService.sendMonthlySellerReports();
				execHistory.setEndTime(new Timestamp(new Date().getTime()));
				execHistory.setStatus("SUCCESS");
				reportService.updateSchedulerExecutionHistory(execHistory);
			}
		} catch (Exception e) {
			LOGGER.error("sendMonthlySellerReports: Exception while sending the Monthly report: "+e.getMessage());
			execHistory.setEndTime(new Timestamp(new Date().getTime()));
			execHistory.setStatus("FAILED");
			execHistory.setMessage(e.getMessage()+"-"+e);
			reportService.updateSchedulerExecutionHistory(execHistory);
		}
		LOGGER.info("pesReportScheduler.sendMonthlySellerReports(): END");
	}
	
	@Scheduled(cron = "0 */5 * * * *", zone="Asia/Calcutta")
	public void schedulerTest() {
	}
	
	//Daily Data Dump at 12:00 am
	@Scheduled(cron = "0 0 0 * * *", zone="Asia/Calcutta")
	public void setReportGsheetData1() {
		gsheetUtil.setReportGsheetData();
	}
	
	//Daily Data Dump at 12:00 pm
	@Scheduled(cron = "0 0 12 * * *", zone="Asia/Calcutta")
	public void setReportGsheetData2() {
		gsheetUtil.setReportGsheetData();
	}
	
	//Schedule the Export Plays Data with filters for Today - 30 Days every 4 hours dump.
	@Scheduled(cron = "0 0 */4 * * * ", zone="Asia/Calcutta")
	public void exportPlaysDataToSheet() {
		    ZoneId z = ZoneId.of("Asia/Kolkata");
		    Calendar cal = Calendar.getInstance();
		    String  endDate= LocalDate.now().toString();
		    String startDate = LocalDate.now(z).minusDays(30).toString();
		    List<String> playId = new ArrayList<>(Arrays.asList("9", "10", "11"));
		    List<String> pesStatus = new ArrayList<>(Arrays.asList("New", "Assigned", "Initiated", "Pending Review", "Reviewed by PES", "Push To POD Lead", "Completed"));
		    LOGGER.info("Export Plays Data Scheduler:"+startDate + " " + endDate + " " + playId + " " + pesStatus );

		    gsheetUtil.exportPlaysDataToSheet(startDate, endDate, playId,pesStatus);
		}
	}

