package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Field;

/**
 * Repository class for Field pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface FieldRepository extends JpaRepository<Field, Long>,  JpaSpecificationExecutor<Field> {
	
	//Query to get field by id
	@Query("select f from Field f where f.id=?1")
	public Field getById(Long id);
	
	//Query to get field by name
	@Query("select f from Field f where f.fieldName=?1")
	public Field findByFieldName(String name);
	
	//Query to get field by display name
	@Query("select f from Field f where f.displayName=?1")
	public Field findByDisplayName(String name);
	
	//Query to delete field by id
	@Query("delete from Field f where f.id=?1")
	public void deleteById(Long id);
	
	@Query("select f from Field f where f.fieldType.id=?1 and f.fieldName=?2")
	public List<Field> findSearchedFields(Long type, String fieldName);
	
	@Query("select f from Field f where f.fieldType.id=?1")
	public List<Field> findByFieldType(Long type);

}
