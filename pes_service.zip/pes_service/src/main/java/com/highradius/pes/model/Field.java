package com.highradius.pes.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "lu_field")
/**
 * Model class for fields pojo.Handles transactions for fields table.
 * The pojo handles all the fields for different plays.Fields are generalized not play related.
 *
 */
public class Field implements Serializable {
	
    private static final long serialVersionUID = 16L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "display_name")
	private String displayName;
	
	@Column(name = "field_name")
	private String fieldName;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "list_type")
	private Long listType;
	
	@Column(name = "viewable_by")
	private String viewableBy;
	
	@Column(name = "editable_by")
	private String editableBy;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_date")
	private Date updatedDate;
	
	@Transient
	private String[] viewableByArr;
	
	@Transient
	private String[] editableByArr;
	
	@Transient
	private List<Map<String,String>> options;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = FieldType.class)
	@JoinColumn(name = "field_type_id", referencedColumnName = "id")
    FieldType fieldType;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = MapFieldOptions.class)
	@JoinColumn(name = "field_id", referencedColumnName = "id")
	List<MapFieldOptions> fieldOptions;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
    
	public Long getListType() {
		return listType;
	}

	public void setListType(Long listType) {
		this.listType = listType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getViewableBy() {
		return viewableBy;
	}

	public void setViewableBy(String viewableBy) {
		this.viewableBy = viewableBy;
	}
	
	public void setViewableByArr(String[] v) {
		this.viewableByArr = v;
	}

	public String getEditableBy() {
		return editableBy;
	}

	public void setEditableBy(String editableBy) {
		this.editableBy = editableBy;
	}

	public String[] getViewableByArr() {
		return viewableByArr;
	}

	public String[] getEditableByArr() {
		return editableByArr;
	}
	
	public void setEditableByArr(String[] v) {
	    this.editableByArr = v;
	}
	
	public List<Map<String, String>> getOptions() {
		return options;
	}

	public void setOptions(List<MapFieldOptions> options) {
		this.options = new ArrayList<>();
		for(MapFieldOptions option: options) {
			Map<String,String> map = new HashMap<>();
			map.put("id", option.getId()+"");
			map.put("displayName", option.getDisplayName());
			this.options.add(map);
		}
	}
	
	public List<MapFieldOptions> getFieldOptions() {
		return fieldOptions;
	}

	public void setFieldOptions(List<MapFieldOptions> fieldOptions) {
		this.fieldOptions = fieldOptions;
	}

	public FieldType getFieldType() {
		return fieldType;
	}

	public void setFieldType(FieldType fieldType) {
		this.fieldType = fieldType;
	}

	@Override
	public String toString() {
		return "Field [id=" + id + ", displayName=" + displayName + ", fieldName=" + fieldName + ", description="
				+ description + ", listType=" + listType + ", viewableBy=" + viewableBy + ", editableBy=" + editableBy
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy
				+ ", updatedDate=" + updatedDate + ", viewableByArr=" + Arrays.toString(viewableByArr)
				+ ", editableByArr=" + Arrays.toString(editableByArr) + ", options=" + options + ", fieldType="
				+ fieldType + ", fieldOptions=" + fieldOptions + "]";
	}
	
	
}
