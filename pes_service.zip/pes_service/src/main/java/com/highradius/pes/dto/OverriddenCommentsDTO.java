package com.highradius.pes.dto;

import java.util.Arrays;

public class OverriddenCommentsDTO {

		private String[] ids;		
	
		
		private Integer  valid_override;
		
		
		private String rationale;
		

		private String manager_comments;


		private String loginUserId;

		public String[] getIds() {
			return ids;
		}


		public void setIds(String[] ids) {
			this.ids = ids;
		}


		public String getLoginUserId() {
			return loginUserId;
		}


		public void setLoginUserId(String loginUserId) {
			this.loginUserId = loginUserId;
		}

		public Integer getValid_override() {
			return valid_override;
		}


		public void setValid_override(Integer valid_override) {
			this.valid_override = valid_override;
		}


		public String getRationale() {
			return rationale;
		}


		public void setRationale(String rationale) {
			this.rationale = rationale;
		}


		public String getManager_comments() {
			return manager_comments;
		}


		public void setManager_comments(String manager_comments) {
			this.manager_comments = manager_comments;
		}

		
		@Override
		public String toString() {
			return "OverriddenCommentsDTO [ids=" + Arrays.toString(ids) + ", valid_override=" + valid_override
					+ ", rationale=" + rationale + ", manager_comments=" + manager_comments + ", loginUserId="
					+ loginUserId + "]";
		}
}
