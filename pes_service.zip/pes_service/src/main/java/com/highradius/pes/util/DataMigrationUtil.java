package com.highradius.pes.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.highradius.pes.dto.EmployeeSFDTO;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.MapFieldOptions;
import com.highradius.pes.model.Market;
import com.highradius.pes.model.Play;
import com.highradius.pes.model.Team;
import com.highradius.pes.model.TxnPlayExecutionData;
import com.highradius.pes.model.TxnPlayExecutionFeedback;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FieldRepository;
import com.highradius.pes.repository.MapFieldOptionsRepository;
import com.highradius.pes.repository.MarketRepository;
import com.highradius.pes.repository.PlayRepository;
import com.highradius.pes.repository.TeamRepository;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;

@Service
@Transactional
public class DataMigrationUtil {
	
	@Autowired
	PesGsheetUtil gsheetUtil;
	
	@Autowired
	PesPropertiesUtil propertiesUtil;
	
	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	MapFieldOptionsRepository mapFieldOptionsRepo;
	
	@Autowired
	FieldRepository fieldRepo;
	
	@Autowired
	MarketRepository marketRepo;
	
	@Autowired
	TeamRepository teamRepo;
	
	@Autowired
	PlayRepository playRepo;
	
	@Autowired
	TxnPlayExecutionsRepository txnRepo;
	
	//Logger for logging
	private static final Logger LOGGER = LogManager.getLogger(PesGsheetUtil.class);
	private Sheets sheetsService;
	private String sheetTest = "Developer - PES Data Migration Dump | Q3-YTD | All Markets (SNOW)";
	
	public boolean processDCSTRAPRecords() {
		try {
		LOGGER.info("DataMigrationUtil.processDCSTRAPRecords() : START");
		sheetsService = gsheetUtil.getSheetsService();
		String sheet = "Discovery STRAP";
		String sheetId = propertiesUtil.getPropertyByName("DATA_MIGRATION_SHEET_ID").getPropertyValue();
		String dataRange = sheet + "!A2:V";
		
		ValueRange response = sheetsService.spreadsheets().values()
				.get(sheetId, dataRange).execute();
		
		List<TxnPlayExecutions> txns = new ArrayList<>();
		
		
		//response we get in list<list<object>> format
		List<List<Object>> values = response.getValues();
		
//		lookups
		List<Employee> allEmp = empRepo.findAll();
		List<Market> allMarkets = marketRepo.findAll();
		List<Team> allTeams = teamRepo.findAll();
		Field chorusAIField = fieldRepo.findByFieldName("linkToChorusAiRec");
		
		Map<String, Employee> empNameMap = new HashMap<>();
		Map<String, Market> marketNameMap = new HashMap<>();
		Map<String, Team> teamNameMap = new HashMap<>();
		Play play = playRepo.findByName("Discovery STRAP");
		
		
		for(Employee emp : allEmp) {
			empNameMap.put(emp.getFullName(), emp);
		}
		
		for(Market market : allMarkets) {
			marketNameMap.put(market.getName(), market);
		}
		
		for(Team team : allTeams) {
			teamNameMap.put(team.getName(), team);
		}
				
//	    Code we implement to use the response got
		if(values == null) {
			LOGGER.error("Data is not present in Discovery STRAP Sheet");
		}
	    else {
	    	for(List<Object> row : values) {
	    		TxnPlayExecutions txn = new TxnPlayExecutions();
	    		String createdDate = row.get(0).toString();
	    		Date createdDt = new SimpleDateFormat("MM/dd/yyyy").parse(createdDate);
	    		String nameOfProspect = row.get(1).toString();
	    		String dateOfExecution = row.get(3).toString();
	    		Date dateOfExec = new SimpleDateFormat("MM/dd/yyyy").parse(dateOfExecution);
	    		String marketName = row.get(4).toString();
	    		String teamName = row.get(5).toString();
	    		String score = row.get(8).toString();
	    		String docLink = row.get(9).toString();
	    		String summaryFeedback = row.get(11).toString();
	    		String detailedFeedback = row.get(12).toString();
	    		String aeName = row.get(13).toString();
	    		String spName = row.get(14).toString();
	    		String aePodLead = row.get(17).toString();
	    		String spPodLead = row.get(18).toString();
	    		
	    		txn.setNameOfProspect(nameOfProspect);
	    		txn.setDateOfExecution(dateOfExec);
	    		txn.setCreatedDate(createdDt);
	    		txn.setCompletedOn(createdDt);
	    		
	    		if(marketNameMap.get(marketName) != null)
	    			txn.setMarket(marketNameMap.get(marketName));
	    		
	    		if(teamNameMap.get(teamName) != null)
	    			txn.setTeam(teamNameMap.get(teamName));
	    		txn.setPlay(play);
	    		txn.setPesStatus(PesConstants.COMPLETED);
	    		txn.setCreatedBy("SYSTEM");
	    		txn.setPesScore(score);
	    		txn.setPodLeadScore(score);
	    		txn.setDocLink(docLink);
	    		txn.setDetailed_feedback(detailedFeedback);
	    		txn.setHighLevelFeedback(detailedFeedback);
	    		
				if (!StringUtils.isEmpty(aeName)) {
					Employee seller = empNameMap.get(aeName);
					Employee podLead = empNameMap.get(aePodLead);
					if (seller == null)
						LOGGER.info(aeName + " AE not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setAe(seller);
						if (podLead == null)
							LOGGER.info(aePodLead + " AE Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
				if (!StringUtils.isEmpty(spName)) {
					Employee seller = empNameMap.get(spName);
					Employee podLead = empNameMap.get(spPodLead);
					if (seller == null)
						LOGGER.info(spName + " SP not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setSp(seller);
						if (podLead == null)
							LOGGER.info(spPodLead + " SP Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
				txnRepo.save(txn);
				//playfields
				List<TxnPlayExecutionData> txnDatas = new ArrayList<>();
				TxnPlayExecutionData txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(chorusAIField.getId());
				txnData.setValue("");
				txnDatas.add(txnData);
				txn.setTxnPlayExecutionData(txnDatas);
				 
				//feedback 
				List<TxnPlayExecutionFeedback> txnFeedback = new ArrayList<>();
				TxnPlayExecutionFeedback feedback = new TxnPlayExecutionFeedback();
				feedback.setPesFeedback(detailedFeedback);
				feedback.setPodLeadFeedback(detailedFeedback);
				feedback.setTxnPlayExecutionId(txn.getId());
				feedback.setStatus("Declined");
				txnFeedback.add(feedback);
				txn.setTxnPlayExecutionFeedback(txnFeedback);
				
				txns.add(txn);
	    	}
	    	txnRepo.saveAll(txns);
	        LOGGER.info("Discovery STRAP data migration completed");
	        return true;
	    		
	    	}
		}
		catch (Exception e) {
			LOGGER.error("DataMigrationUtil.processDCSTRAPRecords() : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean processDCExecCallRecords() {
		try {
		LOGGER.info("DataMigrationUtil.processDCExecCallRecords() : START");
		sheetsService = gsheetUtil.getSheetsService();
		String sheet = "Discovery Execute Calls";
		String sheetId = propertiesUtil.getPropertyByName("DATA_MIGRATION_SHEET_ID").getPropertyValue();
		String dataRange = sheet + "!A2:AB";
		
		ValueRange response = sheetsService.spreadsheets().values()
				.get(sheetId, dataRange).execute();
		
		List<TxnPlayExecutions> txns = new ArrayList<>();
		
		
		//response we get in list<list<object>> format
		List<List<Object>> values = response.getValues();
		
//		lookups
		List<Employee> allEmp = empRepo.findAll();
		List<Market> allMarkets = marketRepo.findAll();
		List<Team> allTeams = teamRepo.findAll();
		List<MapFieldOptions> allOptions = mapFieldOptionsRepo.findAll();
		//dynamic fields
		Field chorusAIField = fieldRepo.findByFieldName("linkToChorusAiRec");
		Field discoveryCallOutcomeByPES = fieldRepo.findByFieldName("discoveryCallOutcomePesAgent");
		Field discoveryCallOutcomePodLead = fieldRepo.findByFieldName("discoveryCallOutcomePodLead");
		Field outcomeRationalePesAgent = fieldRepo.findByFieldName("outcomeRationalePesAgent");
	    Field outcomeRationalePodLead = fieldRepo.findByFieldName("outcomeRationalePodLead");
	    Field buyerModePes = fieldRepo.findByFieldName("buyerModePesAgent");
	    Field buyerModePod = fieldRepo.findByFieldName("buyerModePodLead");
	    
		
		Map<String, Employee> empNameMap = new HashMap<>();
		Map<String, Market> marketNameMap = new HashMap<>();
		Map<String, Team> teamNameMap = new HashMap<>();
		Map<String, MapFieldOptions> optionsNameMap = new HashMap<>();
		Play play = playRepo.findByName("Discovery Execute Call");
		
		
		for(Employee emp : allEmp) {
			empNameMap.put(emp.getFullName(), emp);
		}
		
		for(Market market : allMarkets) {
			marketNameMap.put(market.getName(), market);
		}
		
		for(Team team : allTeams) {
			teamNameMap.put(team.getName(), team);
		}
		
		for(MapFieldOptions option : allOptions) {
			String key = option.getFieldId() + "-" + option.getDisplayName();
			optionsNameMap.put(key, option);
		}
				
//	    Code we implement to use the response got
		if(values == null) {
			LOGGER.error("Data is not present in Discovery Exec Sheet");
		}
	    else {
	    	for(List<Object> row : values) {
	    		TxnPlayExecutions txn = new TxnPlayExecutions();
	    		String createdDate = row.get(0).toString();
	    		Date createdDt = new SimpleDateFormat("MM/dd/yyyy").parse(createdDate);
	    		String nameOfProspect = row.get(1).toString();
	    		String dateOfExecution = row.get(3).toString();
	    		Date dateOfExec = new SimpleDateFormat("MM/dd/yyyy").parse(dateOfExecution);
	    		String marketName = row.get(4).toString();
	    		String teamName = row.get(5).toString();
	    		String score = row.get(8).toString();
	    		String docLink = row.get(9).toString();
	    		String detailedFeedback = row.get(12).toString();
	    		String aeName = row.get(13).toString();
	    		String aePodLead = row.get(17).toString();
	    		String discoveryOutcome = row.get(20).toString();
	    		String discoveryRationale = row.get(21).toString();
	    		String chorusAi = row.get(26).toString();
	    		
	    		txn.setNameOfProspect(nameOfProspect);
	    		txn.setDateOfExecution(dateOfExec);
	    		txn.setCreatedDate(createdDt);
	    		txn.setCompletedOn(createdDt);
	    		
	    		if(marketNameMap.get(marketName) != null)
	    			txn.setMarket(marketNameMap.get(marketName));
	    		
	    		if(teamNameMap.get(teamName) != null)
	    			txn.setTeam(teamNameMap.get(teamName));
	    		txn.setPlay(play);
	    		txn.setPesStatus(PesConstants.COMPLETED);
	    		txn.setCreatedBy("SYSTEM");
	    		txn.setPesScore(score);
	    		txn.setPodLeadScore(score);
	    		txn.setDocLink(docLink);
	    		txn.setDetailed_feedback(detailedFeedback);
	    		txn.setHighLevelFeedback(detailedFeedback);
	    		
				if (!StringUtils.isEmpty(aeName)) {
					Employee seller = empNameMap.get(aeName);
					Employee podLead = empNameMap.get(aePodLead);
					if (seller == null)
						LOGGER.info(aeName + " AE not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setAe(seller);
						if (podLead == null)
							LOGGER.info(aePodLead + " AE Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
				txnRepo.save(txn);
				//playfields
				List<TxnPlayExecutionData> txnDatas = new ArrayList<>();
				TxnPlayExecutionData txnData = new TxnPlayExecutionData();
				//chorus AI
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(chorusAIField.getId());
				txnData.setValue(chorusAi);
				txnDatas.add(txnData);
				
				//outcome rationale
				txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(discoveryCallOutcomeByPES.getId());
				txnData.setValue(optionsNameMap.get(discoveryCallOutcomeByPES.getId() + "-" + discoveryOutcome).getId() + "");
				txnDatas.add(txnData);
				
				txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(discoveryCallOutcomePodLead.getId());
				txnData.setValue(optionsNameMap.get(discoveryCallOutcomePodLead.getId() + "-" + discoveryOutcome).getId()+"");
				txnDatas.add(txnData);

				txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(outcomeRationalePesAgent.getId());
				txnData.setValue(discoveryRationale);
				txnDatas.add(txnData);
				
				txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(outcomeRationalePodLead.getId());
				txnData.setValue(discoveryRationale);
				txnDatas.add(txnData);
				
				txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(buyerModePes.getId());
				txnData.setValue("");
				txnDatas.add(txnData);
				
				txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(buyerModePod.getId());
				txnData.setValue("");
				txnDatas.add(txnData);
				
				txn.setTxnPlayExecutionData(txnDatas);
				
				 
				//feedback 
				List<TxnPlayExecutionFeedback> txnFeedback = new ArrayList<>();
				TxnPlayExecutionFeedback feedback = new TxnPlayExecutionFeedback();
				feedback.setPesFeedback(detailedFeedback);
				feedback.setPodLeadFeedback(detailedFeedback);
				feedback.setTxnPlayExecutionId(txn.getId());
				feedback.setStatus("Declined");
				txnFeedback.add(feedback);
				txn.setTxnPlayExecutionFeedback(txnFeedback);
				
				txns.add(txn);
	    	}
	    	txnRepo.saveAll(txns);
	        LOGGER.info("Discovery Execute Call data migration completed");
	        return true;
	    		
	    	}
		}
		catch (Exception e) {
			LOGGER.error("DataMigrationUtil.processDCExecCallRecords() : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean processOTCRecords() {
		try {
		LOGGER.info("DataMigrationUtil.processOTCRecords() : START");
		sheetsService = gsheetUtil.getSheetsService();
		String sheet = "OTC Whitespace Analysis GI/FA";
		String sheetId = propertiesUtil.getPropertyByName("DATA_MIGRATION_SHEET_ID").getPropertyValue();
		String dataRange = sheet + "!A2:W";
		
		ValueRange response = sheetsService.spreadsheets().values()
				.get(sheetId, dataRange).execute();
		
		List<TxnPlayExecutions> txns = new ArrayList<>();
		
		
		//response we get in list<list<object>> format
		List<List<Object>> values = response.getValues();
		
//		lookups
		List<Employee> allEmp = empRepo.findAll();
		List<Market> allMarkets = marketRepo.findAll();
		List<Team> allTeams = teamRepo.findAll();
		List<MapFieldOptions> allOptions = mapFieldOptionsRepo.findAll();
		
		Field generateInterestDate = fieldRepo.findByFieldName("generateInterestDate");
		Field functionalAlignmentDate = fieldRepo.findByFieldName("functionalAlignmentDate");
		Field valueAlignmentDate = fieldRepo.findByFieldName("valueAlignmentDate");
		Field aeTeam = fieldRepo.findByFieldName("aeTeam");
		Field stage = fieldRepo.findByFieldName("stage");
		Field otcWhitespaceStage = fieldRepo.findByFieldName("otcWhitespaceStage");
		Field opportunityName = fieldRepo.findByFieldName("opportunityName");
		
		Map<String, Employee> empNameMap = new HashMap<>();
		Map<String, Market> marketNameMap = new HashMap<>();
		Map<String, Team> teamNameMap = new HashMap<>();
		Map<String, MapFieldOptions> optionsNameMap = new HashMap<>();
		Play giPlay = playRepo.findByName("OTC Whitespace Analysis - GI Stage");
		Play faPlay = playRepo.findByName("OTC Whitespace Analysis - FA Stage");
		Play webPlay = playRepo.findByName("OTC Whitespace Web Research");
		
		
		for(Employee emp : allEmp) {
			empNameMap.put(emp.getFullName(), emp);
		}
		
		for(Market market : allMarkets) {
			marketNameMap.put(market.getName(), market);
		}
		
		for(Team team : allTeams) {
			teamNameMap.put(team.getName(), team);
		}
		
		for(MapFieldOptions option : allOptions) {
			String key = option.getFieldId() + "-" + option.getDisplayName();
			optionsNameMap.put(key, option);
		}
				
//	    Code we implement to use the response got
		if(values == null) {
			LOGGER.error("Data is not present in OTC Sheet");
		}
	    else {
	    	for(List<Object> row : values) {
	    		TxnPlayExecutions txn = new TxnPlayExecutions();
	    		String createdDate = row.get(0).toString();
	    		Date createdDt = new SimpleDateFormat("MM/dd/yyyy").parse(createdDate);
	    		String nameOfProspect = row.get(1).toString();
	    		String whitespaceStage = row.get(4).toString();
	    		String dateOfExecution = row.get(5).toString();
	    		Date dateOfExec = new SimpleDateFormat("MM/dd/yyyy").parse(dateOfExecution);
	    		String marketName = row.get(6).toString();
	    		String teamName = row.get(7).toString();
	    		String score = row.get(10).toString();
	    		String docLink = row.get(11).toString();
	    		String detailedFeedback = row.get(14).toString();
	    		String spName = row.get(16).toString();
	    		String onsiteSpName = row.get(17).toString();
	    		String spPodLead = row.get(20).toString();
	    		String onsitePodLead = row.get(21).toString();
	    		
	    		txn.setNameOfProspect(nameOfProspect);
	    		txn.setDateOfExecution(dateOfExec);
	    		txn.setCreatedDate(createdDt);
	    		txn.setCompletedOn(createdDt);
	    		
	    		if(marketNameMap.get(marketName) != null)
	    			txn.setMarket(marketNameMap.get(marketName));
	    		
	    		if(teamNameMap.get(teamName) != null)
	    			txn.setTeam(teamNameMap.get(teamName));
	    		txn.setPesStatus(PesConstants.COMPLETED);
	    		txn.setCreatedBy("SYSTEM");
	    		txn.setPesScore(score);
	    		txn.setPodLeadScore(score);
	    		txn.setDocLink(docLink);
	    		txn.setDetailed_feedback(detailedFeedback);
	    		txn.setHighLevelFeedback(detailedFeedback);
	    		
				if (!StringUtils.isEmpty(spName)) {
					Employee seller = empNameMap.get(spName);
					Employee podLead = empNameMap.get(spPodLead);
					if (seller == null)
						LOGGER.info(spName + " SP not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setSp(seller);
						if (podLead == null)
							LOGGER.info(spPodLead + " SP Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
				if (!StringUtils.isEmpty(onsiteSpName)) {
					Employee seller = empNameMap.get(onsiteSpName);
					Employee podLead = empNameMap.get(onsitePodLead);
					if (seller == null)
						LOGGER.info(onsiteSpName + " Onsite SP not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setOnsiteSp(seller);
						if (podLead == null)
							LOGGER.info(onsitePodLead + " Onsite SP Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
				
				if(whitespaceStage.equals("Web Research (GI)")) {
					txn.setPlay(webPlay);
				}
				else if(whitespaceStage.equals("Generate Interest (GI to FA)")) {
					txn.setPlay(giPlay);
				}
				else if(whitespaceStage.equals("Functional Alignment (FA to VA)")) {
					txn.setPlay(faPlay);
				}
					
				txnRepo.save(txn);
				
				//playfields
				List<TxnPlayExecutionData> txnDatas = new ArrayList<>();
				
				if(!whitespaceStage.equals("Web Research (GI)")) {
					
					//GI Date
					TxnPlayExecutionData txnData = new TxnPlayExecutionData();
					txnData.setTxnPlayExecutionId(txn.getId());
					txnData.setFieldId(generateInterestDate.getId());
					txnData.setValue("");
					txnDatas.add(txnData);
					
					//FA date
					txnData = new TxnPlayExecutionData();
					txnData.setTxnPlayExecutionId(txn.getId());
					txnData.setFieldId(functionalAlignmentDate.getId());
					txnData.setValue("");
					txnDatas.add(txnData);
					
					//VA date
					txnData = new TxnPlayExecutionData();
					txnData.setTxnPlayExecutionId(txn.getId());
					txnData.setFieldId(valueAlignmentDate.getId());
					txnData.setValue("");
					txnDatas.add(txnData);
					
					//AE team
					txnData = new TxnPlayExecutionData();
					txnData.setTxnPlayExecutionId(txn.getId());
					txnData.setFieldId(aeTeam.getId());
					txnData.setValue(teamName);
					txnDatas.add(txnData);
					
					//Stage
					txnData = new TxnPlayExecutionData();
					txnData.setTxnPlayExecutionId(txn.getId());
					txnData.setFieldId(stage.getId());
					txnData.setValue("");
					txnDatas.add(txnData);
					
					//Whitespace Stage
					txnData = new TxnPlayExecutionData();
					txnData.setTxnPlayExecutionId(txn.getId());
					txnData.setFieldId(otcWhitespaceStage.getId());
					txnData.setValue(optionsNameMap.get(otcWhitespaceStage.getId() + "-" + whitespaceStage).getId() + "");
					txnDatas.add(txnData);
				}
				
				//opportunity
				TxnPlayExecutionData txnData = new TxnPlayExecutionData();
				txnData.setTxnPlayExecutionId(txn.getId());
				txnData.setFieldId(opportunityName.getId());
				txnData.setValue("");
				txnDatas.add(txnData);
				
				txn.setTxnPlayExecutionData(txnDatas);
				
				 
				//feedback 
				List<TxnPlayExecutionFeedback> txnFeedback = new ArrayList<>();
				TxnPlayExecutionFeedback feedback = new TxnPlayExecutionFeedback();
				feedback.setPesFeedback(detailedFeedback);
				feedback.setPodLeadFeedback(detailedFeedback);
				feedback.setTxnPlayExecutionId(txn.getId());
				feedback.setStatus("Declined");
				txnFeedback.add(feedback);
				txn.setTxnPlayExecutionFeedback(txnFeedback);
				
				txns.add(txn);
	    	}
	    	txnRepo.saveAll(txns);
	        LOGGER.info("OTC data migration completed");
	        return true;
	    		
	    	}
		}
		catch (Exception e) {
			LOGGER.error("DataMigrationUtil.processOTCRecords() : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean processCPRRecords() {
		try {
		LOGGER.info("DataMigrationUtil.processCPRRecords() : START");
		sheetsService = gsheetUtil.getSheetsService();
		String sheet = "CPR";
		String sheetId = propertiesUtil.getPropertyByName("DATA_MIGRATION_SHEET_ID").getPropertyValue();
		String dataRange = sheet + "!A2:U";
		
		ValueRange response = sheetsService.spreadsheets().values()
				.get(sheetId, dataRange).execute();
		
		List<TxnPlayExecutions> txns = new ArrayList<>();
		
		
		//response we get in list<list<object>> format
		List<List<Object>> values = response.getValues();
		
//		lookups
		List<Employee> allEmp = empRepo.findAll();
		List<Market> allMarkets = marketRepo.findAll();
		List<Team> allTeams = teamRepo.findAll();
		
		Map<String, Employee> empNameMap = new HashMap<>();
		Map<String, Market> marketNameMap = new HashMap<>();
		Map<String, Team> teamNameMap = new HashMap<>();
		Play play = playRepo.findByName("Company and People Research (CPR)");
		
		
		for(Employee emp : allEmp) {
			empNameMap.put(emp.getFullName(), emp);
		}
		
		for(Market market : allMarkets) {
			marketNameMap.put(market.getName(), market);
		}
		
		for(Team team : allTeams) {
			teamNameMap.put(team.getName(), team);
		}
				
//	    Code we implement to use the response got
		if(values == null) {
			LOGGER.error("Data is not present in CPR Sheet");
		}
	    else {
	    	for(List<Object> row : values) {
	    		TxnPlayExecutions txn = new TxnPlayExecutions();
	    		String createdDate = row.get(0).toString();
	    		Date createdDt = new SimpleDateFormat("MM/dd/yyyy").parse(createdDate);
	    		String nameOfProspect = row.get(1).toString();
	    		String dateOfExecution = row.get(3).toString();
	    		Date dateOfExec = new SimpleDateFormat("MM/dd/yyyy").parse(dateOfExecution);
	    		String marketName = row.get(4).toString();
	    		String teamName = row.get(5).toString();
	    		String score = row.get(8).toString();
	    		String docLink = row.get(9).toString();
	    		String detailedFeedback = row.get(12).toString();
	    		String aeName = row.get(13).toString();
	    		String spName = row.get(14).toString();
	    		String aePodLead = row.get(17).toString();
	    		String spPodLead = row.get(18).toString();
	    		
	    		txn.setNameOfProspect(nameOfProspect);
	    		txn.setDateOfExecution(dateOfExec);
	    		txn.setCreatedDate(createdDt);
	    		txn.setCompletedOn(createdDt);
	    		
	    		if(marketNameMap.get(marketName) != null)
	    			txn.setMarket(marketNameMap.get(marketName));
	    		
	    		if(teamNameMap.get(teamName) != null)
	    			txn.setTeam(teamNameMap.get(teamName));
	    		txn.setPesStatus(PesConstants.COMPLETED);
	    		txn.setCreatedBy("SYSTEM");
	    		txn.setPesScore(score);
	    		txn.setPodLeadScore(score);
	    		txn.setPlay(play);
	    		txn.setDocLink(docLink);
	    		txn.setDetailed_feedback(detailedFeedback);
	    		txn.setHighLevelFeedback(detailedFeedback);
	    		
	    		if (!StringUtils.isEmpty(aeName)) {
					Employee seller = empNameMap.get(aeName);
					Employee podLead = empNameMap.get(aePodLead);
					if (seller == null)
						LOGGER.info(aeName + " AE not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setAe(seller);
						if (podLead == null)
							LOGGER.info(aePodLead + " AE Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
	    		
				if (!StringUtils.isEmpty(spName)) {
					Employee seller = empNameMap.get(spName);
					Employee podLead = empNameMap.get(spPodLead);
					if (seller == null)
						LOGGER.info(spName + " SP not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setSp(seller);
						if (podLead == null)
							LOGGER.info(spPodLead + " SP Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
				txnRepo.save(txn);				
				 
				//feedback 
				List<TxnPlayExecutionFeedback> txnFeedback = new ArrayList<>();
				TxnPlayExecutionFeedback feedback = new TxnPlayExecutionFeedback();
				feedback.setPesFeedback(detailedFeedback);
				feedback.setPodLeadFeedback(detailedFeedback);
				feedback.setTxnPlayExecutionId(txn.getId());
				feedback.setStatus("Declined");
				txnFeedback.add(feedback);
				txn.setTxnPlayExecutionFeedback(txnFeedback);
				
				txns.add(txn);
	    	}
	    	txnRepo.saveAll(txns);
	        LOGGER.info("CPR data migration completed");
	        return true;
	    		
	    	}
		}
		catch (Exception e) {
			LOGGER.error("DataMigrationUtil.processOTCRecords() : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	public boolean processSIHRecords() {
		try {
		LOGGER.info("DataMigrationUtil.processSIHRecords() : START");
		sheetsService = gsheetUtil.getSheetsService();
		String sheet = "SIH";
		String sheetId = propertiesUtil.getPropertyByName("DATA_MIGRATION_SHEET_ID").getPropertyValue();
		String dataRange = sheet + "!A2:U";
		
		ValueRange response = sheetsService.spreadsheets().values()
				.get(sheetId, dataRange).execute();
		
		List<TxnPlayExecutions> txns = new ArrayList<>();
		
		
		//response we get in list<list<object>> format
		List<List<Object>> values = response.getValues();
		
//		lookups
		List<Employee> allEmp = empRepo.findAll();
		List<Market> allMarkets = marketRepo.findAll();
		List<Team> allTeams = teamRepo.findAll();
		
		Map<String, Employee> empNameMap = new HashMap<>();
		Map<String, Market> marketNameMap = new HashMap<>();
		Map<String, Team> teamNameMap = new HashMap<>();
		Play play = playRepo.findByName("Sales Interaction History (SIH)");
		
		
		for(Employee emp : allEmp) {
			empNameMap.put(emp.getFullName(), emp);
		}
		
		for(Market market : allMarkets) {
			marketNameMap.put(market.getName(), market);
		}
		
		for(Team team : allTeams) {
			teamNameMap.put(team.getName(), team);
		}
				
//	    Code we implement to use the response got
		if(values == null) {
			LOGGER.error("Data is not present in CPR Sheet");
		}
	    else {
	    	for(List<Object> row : values) {
	    		TxnPlayExecutions txn = new TxnPlayExecutions();
	    		String createdDate = row.get(0).toString();
	    		Date createdDt = new SimpleDateFormat("MM/dd/yyyy").parse(createdDate);
	    		String nameOfProspect = row.get(1).toString();
	    		String dateOfExecution = row.get(3).toString();
	    		Date dateOfExec = new SimpleDateFormat("MM/dd/yyyy").parse(dateOfExecution);
	    		String marketName = row.get(4).toString();
	    		String teamName = row.get(5).toString();
	    		String score = row.get(8).toString();
	    		String docLink = row.get(9).toString();
	    		String detailedFeedback = row.get(12).toString();
	    		String aeName = row.get(13).toString();
	    		String aePodLead = row.get(17).toString();
	    		
	    		txn.setNameOfProspect(nameOfProspect);
	    		txn.setDateOfExecution(dateOfExec);
	    		txn.setCreatedDate(createdDt);
	    		txn.setCompletedOn(createdDt);
	    		
	    		if(marketNameMap.get(marketName) != null)
	    			txn.setMarket(marketNameMap.get(marketName));
	    		
	    		if(teamNameMap.get(teamName) != null)
	    			txn.setTeam(teamNameMap.get(teamName));
	    		txn.setPesStatus(PesConstants.COMPLETED);
	    		txn.setCreatedBy("SYSTEM");
	    		txn.setPesScore(score);
	    		txn.setPodLeadScore(score);
	    		txn.setPlay(play);
	    		txn.setDocLink(docLink);
	    		txn.setDetailed_feedback(detailedFeedback);
	    		txn.setHighLevelFeedback(detailedFeedback);
	    		
	    		if (!StringUtils.isEmpty(aeName)) {
					Employee seller = empNameMap.get(aeName);
					Employee podLead = empNameMap.get(aePodLead);
					if (seller == null)
						LOGGER.info(aeName + " AE not present for prospect " + nameOfProspect);
					else if (seller != null) {
						txn.setScoringFor(seller);
						txn.setAe(seller);
						if (podLead == null)
							LOGGER.info(aePodLead + " AE Pod Lead not present for prosepect " + nameOfProspect);
						else if (podLead != null)
							txn.setPodLead(podLead);
					}

				}
				txnRepo.save(txn);				
				 
				//feedback 
				List<TxnPlayExecutionFeedback> txnFeedback = new ArrayList<>();
				TxnPlayExecutionFeedback feedback = new TxnPlayExecutionFeedback();
				feedback.setPesFeedback(detailedFeedback);
				feedback.setPodLeadFeedback(detailedFeedback);
				feedback.setTxnPlayExecutionId(txn.getId());
				feedback.setStatus("Declined");
				txnFeedback.add(feedback);
				txn.setTxnPlayExecutionFeedback(txnFeedback);
				
				txns.add(txn);
	    	}
	    	txnRepo.saveAll(txns);
	        LOGGER.info("SIH data migration completed");
	        return true;
	    		
	    	}
		}
		catch (Exception e) {
			LOGGER.error("DataMigrationUtil.processOTCRecords() : ERROR : " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
}
