/**
 * 
 */
package com.highradius.pes.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vamshi.bonagiri
 *
 */
@Entity
@Table(name="pes_seller_scores")
public class PesSellerScores implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long year; 
	private String month; 
	private String email;
	
	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "end_date")
	private Date endDate;
	
	@Column(name = "seller_name")
	private String sellerName; 
	
	@Column(name = "role")
	private String role; 
	
	@Column(name = "play_name")
	private String playName;
	
	@Column(name = "play_status")
	private String playStatus;
	
	private Long weightage; 
	
	@Column(name = "plays_scored")
	private Long playsScored; 
	
	@Column(name = "total_score")
	private Long totalScore; 
	
	@Column(name = "avg_score")
	private Double avgScore; 
	
	@Column(name = "play_attainment_percentage")
	private Double playAttainmentPercentage; 
	
	@Column(name = "created_date")
	private Date createdDate; 
	
	@Column(name = "created_by")
	private String createdBy;

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPlayName() {
		return playName;
	}

	public void setPlayName(String playName) {
		this.playName = playName;
	}

	public String getPlayStatus() {
		return playStatus;
	}

	public void setPlayStatus(String playStatus) {
		this.playStatus = playStatus;
	}

	public Long getWeightage() {
		return weightage;
	}

	public void setWeightage(Long weightage) {
		this.weightage = weightage;
	}

	public Long getPlaysScored() {
		return playsScored;
	}

	public void setPlaysScored(Long playsScored) {
		this.playsScored = playsScored;
	}

	public Long getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(Long totalScore) {
		this.totalScore = totalScore;
	}

	public Double getAvgScore() {
		return avgScore;
	}

	public void setAvgScore(Double avgScore) {
		this.avgScore = avgScore;
	}

	public Double getPlayAttainmentPercentage() {
		return playAttainmentPercentage;
	}

	public void setPlayAttainmentPercentage(Double playAttainmentPercentage) {
		this.playAttainmentPercentage = playAttainmentPercentage;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "PesSellerScores [id=" + id + ", year=" + year + ", month=" + month + ", email=" + email + ", startDate="
				+ startDate + ", endDate=" + endDate + ", sellerName=" + sellerName + ", role=" + role + ", playName="
				+ playName + ", playStatus=" + playStatus + ", weightage=" + weightage + ", playsScored=" + playsScored
				+ ", totalScore=" + totalScore + ", avgScore=" + avgScore + ", playAttainmentPercentage="
				+ playAttainmentPercentage + ", createdDate=" + createdDate + ", createdBy=" + createdBy + "]";
	}

}
