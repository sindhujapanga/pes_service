package com.highradius.pes.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="lu_employee")
/**
 * Model class for Employee pojo.Handles transactions for employees table.
 * Has many to one relation with Designation,Market, Department, SecurityRole and FunctionalRole pojos
 *
 */
public class Employee implements Comparable<Object>,Serializable{
	
	public static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "employee_id")
	private Long empId;
	
	@Column(name = "sf_18_char_id")
	private String sf18CharId;
	
	@Column(name = "sf_user_id")
	private String sfUserId;
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "full_name")
	private String fullName;
	
	@Column(name = "alias")
	private String alias;
	
	@Column(name = "profile_name")
	private String profileName;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "pod_lead_id")
	private Long podLeadId;
	
	@Column(name = "dotted_manager_id")
	private Long dottedMangerId;
	
	@Column(name = "designation_id")
	private Long designationId;
	
	@Column(name = "market_id")
	private Long marketId;
	
	@Column(name = "department_id")
	private Long departmentId;
	
	@Column(name = "security_role_id")
	private Long securityRoleId;
	
	@Column(name = "gh_id")
	private Long ghId;
	
	@Column(name = "team_id")
	private Long teamId;
	
	@Column(name = "location")
	private String location;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date")
	private Date createdDate;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_date")
	private Date updatedDate;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER, targetEntity = FunctionalRole.class)
	@JoinColumn(name = "fn_role_id", referencedColumnName = "id")
	private FunctionalRole fnRole;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String full_name) {
		this.fullName = full_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getPodLeadId() {
		return podLeadId;
	}

	public void setPodLeadId(Long podLeadId) {
		this.podLeadId = podLeadId;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Long getDottedMangerId() {
		return dottedMangerId;
	}

	public void setDottedMangerId(Long dottedMangerId) {
		this.dottedMangerId = dottedMangerId;
	}

	public Long getGhId() {
		return ghId;
	}

	public void setGhId(Long ghId) {
		this.ghId = ghId;
	}

	public Long getTeamId() {
		return teamId;
	}

	public void setTeamId(Long teamId) {
		this.teamId = teamId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSf18CharId() {
		return sf18CharId;
	}

	public void setSf18CharId(String sf18CharId) {
		this.sf18CharId = sf18CharId;
	}

	public String getSfUserId() {
		return sfUserId;
	}

	public void setSfUserId(String sfUserId) {
		this.sfUserId = sfUserId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getProfileName() {
		return profileName;
	}

	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}

	

	public Long getDesignationId() {
		return designationId;
	}

	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}

	public Long getMarketId() {
		return marketId;
	}

	public void setMarketId(Long marketId) {
		this.marketId = marketId;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public Long getSecurityRoleId() {
		return securityRoleId;
	}

	public void setSecurityRoleId(Long securityRoleId) {
		this.securityRoleId = securityRoleId;
	}

	public FunctionalRole getFnRole() {
		return fnRole;
	}

	public void setFnRole(FunctionalRole fnRole) {
		this.fnRole = fnRole;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (fullName == null) {
			if (other.fullName != null)
				return false;
		} else if (!fullName.equals(other.fullName))
			return false;
		return true;
	}

	@Override
	public int compareTo(Object o) {
		Employee emp = (Employee) o;
		return (this.getFullName().compareTo(emp.getFullName()));

	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", empId=" + empId + ", sf18CharId=" + sf18CharId + ", sfUserId=" + sfUserId
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", fullName=" + fullName + ", alias=" + alias
				+ ", profileName=" + profileName + ", email=" + email + ", status=" + status + ", podLeadId="
				+ podLeadId + ", dottedMangerId=" + dottedMangerId + ", designationId=" + designationId + ", marketId="
				+ marketId + ", departmentId=" + departmentId + ", securityRoleId=" + securityRoleId + ", ghId=" + ghId
				+ ", teamId=" + teamId + ", location=" + location + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", fnRole=" + fnRole
				+ "]";
	}

	
}
