package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Playbook;
/**
 * Repository class for Playbook pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface PlaybookRepository extends JpaRepository<Playbook, Long>{
	
	//Query to get playbook with id
	@Query("Select p from Playbook p where p.id =?1")
	public Playbook getById(Long id);
	
	//Query to get playbook from name
	@Query("Select p from Playbook p where p.name =?1")
	public Playbook findByName(String name);
	
	@Query("Select p from Playbook p where p.name =?1 and p.department.id =?2")
	public List<Playbook> findByNameAndDepartment(String name, Long deptId);

}
