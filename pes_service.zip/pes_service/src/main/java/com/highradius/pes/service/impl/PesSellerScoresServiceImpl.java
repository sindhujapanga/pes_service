package com.highradius.pes.service.impl;

import static java.time.DayOfWeek.MONDAY;
import static java.time.temporal.TemporalAdjusters.nextOrSame;
import static java.time.temporal.TemporalAdjusters.previousOrSame;

import java.sql.Date;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import com.highradius.pes.dto.PesSellerPlaySearchDTO;
import com.highradius.pes.dto.PesSellerPlaySearchResultsDTO;
import com.highradius.pes.dto.PesSellerScoresDTO;
import com.highradius.pes.dto.PesSellerSearchDTO;
import com.highradius.pes.dto.PlayStatusDTO;
import com.highradius.pes.model.FunctionalRole;
import com.highradius.pes.model.PesSellerScores;
import com.highradius.pes.model.Play;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FunctionalRoleRepository;
import com.highradius.pes.repository.PesSellerScoresRepository;
import com.highradius.pes.repository.PlayRepository;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;
import com.highradius.pes.service.PesSellerScoresService;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.PesConstants;
import com.highradius.pes.util.PesPropertiesUtil;

@Service
@Transactional
public class PesSellerScoresServiceImpl implements PesSellerScoresService {

	@Autowired
	PesSellerScoresRepository sellerScoresRepo;

	@Autowired
	TxnPlayExecutionsRepository txnRepo;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	PlayRepository playRepo;
	
	@Autowired
	PesScoringServiceImpl scoringService;
	
	@Autowired
	FunctionalRoleRepository fnRoleRepo;
	
	@Autowired
	PesPropertiesUtil propertiesUtil;

	private static final Logger LOGGER = LogManager.getLogger(PesSellerScoresServiceImpl.class);
	
	@Override
	public GenericResult searchSellerAttainments(PesSellerSearchDTO sellerSearchDTO, Long roleId, Long pkId) {
		LOGGER.info("PesSellerScoresServiceImpl.searchSellerAttainments() : START");
		GenericResult result = new GenericResult();
		boolean isWeek = false;
		String weekLbl = "";
		boolean isPlayAvailable = false;
		FunctionalRole userRole = fnRoleRepo.getById(roleId);
		try {
			Long sellerId = pkId;
			String role = userRole != null? userRole.getName() : "";
			List<String> nonSellerUsers = Arrays.asList(propertiesUtil.getPropertyByName("NON_SELLER_USERS_FOR_SELLER_VIEW").getPropertyValue().split(","));
			if(nonSellerUsers.contains(role)) {
				sellerId = sellerSearchDTO.getSellerId();
				role = sellerSearchDTO.getRole();
			}
			LOGGER.info(sellerId + " - " + role);
			if (sellerId == null) {
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Seller Id is missing");
				return result;
			}

			if (StringUtils.isEmpty(role)) {
				result.setStatus(PesConstants.FAIL);
				result.setMessage("Seller Role is missing");
				return result;
			}

			String weekDate = sellerSearchDTO.getWeekDate();
			if (!StringUtils.isEmpty(weekDate)) {
				LocalDate date = LocalDate.parse(weekDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				LocalDate currentMonday = date.with(previousOrSame(MONDAY));
				LocalDate currentSunday = date.with(nextOrSame(DayOfWeek.SUNDAY));
				Date stDate = java.sql.Date.valueOf(currentMonday);
				Date endDate = java.sql.Date.valueOf(currentSunday);
				LOGGER.info("week Date:" + date + ": Start date: " + stDate + ": End Date: " + endDate);

				isWeek = true;
				DateFormat formatter = new SimpleDateFormat("MMMM dd, yyyy");
				String strtDtStr = formatter.format(stDate);
				String endDtStr = formatter.format(endDate);
				weekLbl = strtDtStr + " - " + endDtStr;

			}
			
			//creating a final Long to search with workaround for local Long issue
			final Long sellerSearchId = sellerId;

			List<PesSellerScores> sellerList = sellerScoresRepo.findAll(new Specification<PesSellerScores>() {
				private static final long serialVersionUID = 1L;

				@Override
				public Predicate toPredicate(Root<PesSellerScores> root, CriteriaQuery<?> query,
						CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();

					// get values from DTO
					Long year = sellerSearchDTO.getYear();
					String email = employeeRepository.getById(sellerSearchId).getEmail();
					String role = sellerSearchDTO.getRole();
					String weekDate = sellerSearchDTO.getWeekDate();
					Long month = sellerSearchDTO.getMonth();
					String playName = sellerSearchDTO.getPlay();
					LOGGER.info(email + " - " + role + " - " + year + " - " + month + " - " + weekDate);
					if (year == null) {
						Calendar calendar = new GregorianCalendar();
						calendar.setTime(new java.util.Date());
						year = (long) calendar.get(Calendar.YEAR);
					}

					predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("email"), email)));
					predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("role"), role)));
					predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("year"), year)));

					if (!StringUtils.isEmpty(weekDate)) {
						LocalDate date = LocalDate.parse(weekDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						LocalDate currentMonday = date.with(previousOrSame(MONDAY));
						LocalDate currentSunday = date.with(nextOrSame(DayOfWeek.SUNDAY));
						Date stDate = java.sql.Date.valueOf(currentMonday);
						Date endDate = java.sql.Date.valueOf(currentSunday);
						LOGGER.info("week Date:" + date + ": Start date: " + stDate + ": End Date: " + endDate);
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("startDate"), stDate)));
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("endDate"), endDate)));
					} else if (month != null) {
						String nameOfMonth = PesConstants.Months[month.intValue()];
						LOGGER.info(nameOfMonth);
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("month"), nameOfMonth)));
					} else {
						predicates.add(criteriaBuilder.and(criteriaBuilder.isNotNull(root.get("month"))));
					}
					if(!StringUtils.isEmpty(playName)) {
						Predicate playSelected = criteriaBuilder.equal(root.get("playName"), playName);
						Predicate nullPlay = criteriaBuilder.isNull(root.get("playName"));
						predicates.add(criteriaBuilder.or(playSelected, nullPlay));
					}

					LOGGER.info("PesSellerScoresServiceImpl.searchSellerAttainments(): Adding data filters has been successful");
					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}

			});

			LOGGER.info("PesSellerScoresServiceImpl.searchSellerAttainments() : END");
			LOGGER.info(sellerList);
			//validate if playname available and seller not performed the play in given period
			if(StringUtils.isNotBlank(sellerSearchDTO.getPlay())){
				for (PesSellerScores pesSellerScores : sellerList) {
					if(StringUtils.isNotBlank(pesSellerScores.getPlayName()) && 
							pesSellerScores.getPlayName().equals(sellerSearchDTO.getPlay())) {
						isPlayAvailable = true;
						break;
					}
				}
				if(!isPlayAvailable) {
					sellerList = new ArrayList<PesSellerScores>();
				}
			}
			
			List<PesSellerScoresDTO> data = prepareSellerSearchAttainments(sellerList, isWeek, weekLbl);

			// to return latest records first
			Collections.reverse(data);
			result.setData(data);
			return result;
		} catch (Exception e) {
			LOGGER.error("Exception while fetching Record: " ,e);
			// to send back in case of error
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Operation failed, Unable to fetch the seller report, Please contact administarator");
			return result;
		}

	}

	public List<PesSellerScoresDTO> prepareSellerSearchAttainments(List<PesSellerScores> sellerList, boolean isWeek,
            String weekLbl) {
        LOGGER.info("PesSellerScoresServiceImpl.prepareSellerSearchAttainments() : START");
        List<PesSellerScoresDTO> sellerResult = new ArrayList<>();
        try {
            HashSet<String> set = new HashSet<>();
            for (PesSellerScores score : sellerList) {
                PesSellerScoresDTO scoreDto = new PesSellerScoresDTO();
                String startDate = score.getStartDate().toString();
                String endDate = score.getEndDate().toString();
                String playName = score.getPlayName();    
                String key = startDate + "-" + endDate + "-" + playName;
                //checks whether the set contains the key or not
                if(!set.contains(key)) {
                    set.add(key);
                }
                else {
                    continue;
                }
                java.util.Date date = score.getStartDate();
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                List<String> playGroup = new ArrayList<>();

                if (score.getPlayName() == null) {
                    if (!isWeek) {
                        playGroup.add(PesConstants.Months[cal.get(Calendar.MONTH)]);
                    } else {
                        playGroup.add(weekLbl);
                    }
                } else {
                    if (!isWeek) {
                        playGroup.add(PesConstants.Months[cal.get(Calendar.MONTH)]);
                    } else {
                        playGroup.add(weekLbl);
                    }
                    playGroup.add(score.getPlayName());
                }
                /*
                 * to get the avgscore upto one decimal(8.75 to 8.8)
                 */
                if(score.getAvgScore()!=null) {
                    DecimalFormat df = new DecimalFormat("0.0");
                    String formattedValue = df.format(score.getAvgScore());
                    scoreDto.setAvgScore(Double.valueOf(formattedValue));
                }
                scoreDto.setId(score.getId());
                scoreDto.setPlaysScored(score.getPlaysScored());
                scoreDto.setWeightage(score.getWeightage());
                /*
                 * round up the attainment percentagevalue (86.2069 as 86)
                 */
                if(score.getPlayAttainmentPercentage()!=null) {
                    scoreDto.setPlayAttainmentPercentage((double) Math.round(score.getPlayAttainmentPercentage()));
                }                
                scoreDto.setPlayGroup(playGroup);
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                String strtDtStr = formatter.format(score.getStartDate());
                scoreDto.setStartDate(strtDtStr);
                scoreDto.setEndDate(formatter.format(score.getEndDate()));
                scoreDto.setEmail(score.getEmail());
                scoreDto.setRole(score.getRole());
                scoreDto.setYear(score.getYear().toString());
                sellerResult.add(scoreDto);

            }
            LOGGER.info("PesSellerScoresServiceImpl.prepareSellerSearchAttainments() : END");
        } catch (Exception e) {
            LOGGER.info("PesSellerScoresServiceImpl.prepareSellerSearchAttainments(): ERROR : " + e.getMessage());
            e.printStackTrace();
        }
        return sellerResult;
    }

	@Override
	public GenericResult scoredPlayDetails(PesSellerPlaySearchDTO sellerPlaySearchDTO, Long roleId, Long pkId) {
		LOGGER.info("PesSellerScoringServiceImpl.searchSellerPlayDetails() : START");
		GenericResult result = new GenericResult();
		try {
			FunctionalRole role = fnRoleRepo.getById(roleId); 
			String roleName = role != null? role.getName(): "";
			Long sellerId = pkId;
			List<String> nonSellerUsers = Arrays.asList(propertiesUtil.getPropertyByName("NON_SELLER_USERS_FOR_SELLER_VIEW").getPropertyValue().split(","));
			// Checking for mandatory fields check
			if ((StringUtils.isEmpty(roleName)
					|| StringUtils.isEmpty(sellerPlaySearchDTO.getPlayName())
					|| sellerId == null || sellerPlaySearchDTO.getYear() == null)
					|| (sellerPlaySearchDTO.getMonth() == null && sellerPlaySearchDTO.getWeekDate() == null)) {
				LOGGER.warn("Mandatory Inputs Missing");
				result.setData(new ArrayList<PesSellerPlaySearchResultsDTO>());
				return result;
			}
			
			if(nonSellerUsers.contains(roleName)) {
				roleName = sellerPlaySearchDTO.getRole();
				sellerId = sellerPlaySearchDTO.getSellerId();
			}
			
			//workaround for the local variable
			final String curRole = roleName;
			final Long curSellerId = sellerId;

			List<TxnPlayExecutions> txnPlayList = txnRepo.findAll(new Specification<TxnPlayExecutions>() {

				private static final long serialVersionUID = 1L;

				public Predicate toPredicate(Root<TxnPlayExecutions> root, CriteriaQuery<?> query,
						CriteriaBuilder criteriaBuilder) {

					// List of Predicates
					List<Predicate> predicates = new ArrayList<>();

					// getting values from sellerSearchDTO object
					String playName = sellerPlaySearchDTO.getPlayName();
					Long year = sellerPlaySearchDTO.getYear();
					Long month = sellerPlaySearchDTO.getMonth();
					String role = curRole;
					Long sellerId = curSellerId;
					String weekDate = sellerPlaySearchDTO.getWeekDate();
					LOGGER.info(playName + " - " + sellerId + " - " + role + " - " + year + " - " + month + " - "
							+ weekDate);

					// Checking null values and adding to predicates

					// Checking for Play Name
					if (!StringUtils.isEmpty(playName)) {
						// Get the value for Play ID directly from Repo
						Long id = playRepo.getIdByName(playName);
						// Get only Completed records
						String status = "Completed";
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("pesStatus"), status)));
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("play").get("id"), id)));
					}

					// Check for WeekDate
					if (!StringUtils.isEmpty(weekDate)) {
						LocalDate date = LocalDate.parse(weekDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						LocalDate currentMonday = date.with(previousOrSame(MONDAY));
						LocalDate currentSunday = date.with(nextOrSame(DayOfWeek.SUNDAY));
						Date startDate = Date.valueOf(currentMonday);
						Date endDate = Date.valueOf(currentSunday);
						LOGGER.info("WeekDate:" + date + "WeekStartDate:" + startDate + "weekEndDate:" + endDate);
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.between(root.get("createdDate"), startDate, endDate)));
					}

					else if (!ObjectUtils.isEmpty(month) && !ObjectUtils.isEmpty(year)) {

						// Convert Long to Int for Month of method
						int i = Math.toIntExact(month);
						int j = Math.toIntExact(year);

						// Get MonthName from Int value of Month,Add 1 since month start from 0
						Month monthName = Month.of(i + 1);

						// Use YearMonth library to get starting date of month
						YearMonth yearMonth = YearMonth.of(j, monthName);
						LocalDate firstOfMonth = yearMonth.atDay(1);
						LocalDate lastOfMonth = yearMonth.atEndOfMonth();
						Date startDate = Date.valueOf(firstOfMonth);
						Date endDate = Date.valueOf(lastOfMonth);
						LOGGER.info("MonthDate:" + yearMonth + "MonthStartDate:" + startDate + "MonthDate:" + endDate);

						predicates.add(criteriaBuilder
								.and(criteriaBuilder.between(root.get("createdDate"), startDate, endDate)));

						String finalYear = String.valueOf(year);
						String yearStart = finalYear + "-01-01";
						String yearEnd = finalYear + "-12-31";
						LocalDate FirstDate = LocalDate.parse(yearStart, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						LocalDate LastDate = LocalDate.parse(yearEnd, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						Date startDateY = Date.valueOf(FirstDate);
						Date endDateY = Date.valueOf(LastDate);
						LOGGER.info(
								"YearDate:" + finalYear + "YearStartDate:" + startDateY + "YearEndDate:" + endDateY);
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.between(root.get("createdDate"), startDate, endDate)));

					}

					// Check for Month

					if (!StringUtils.isEmpty(role) && sellerId != null) {
						// Get Employee ID from Email ID using Emp Repo
						// Long empId = employeeRepository.findByEmailId(email).getId();
						// Convert role to lowercase ,match with the column and for onsite Sp since to
						// lowercase will not match,convert it and then pass the employee ID
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root
								.get(role.equalsIgnoreCase("onsite Sp") ? "onsiteSp" : role.toLowerCase()).get("id"),
								sellerId)));
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("scoringFor"), sellerId)));
					}

					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			});

			List<PesSellerPlaySearchResultsDTO> data = prepareSellerPlaySearchResults(txnPlayList);
			Collections.reverse(data);
			result.setData(data);
			LOGGER.info("PesSellerScoringServiceImpl.searchSellerPlayDetails() : END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesSellerScoringServiceImpl.searchSellerPlayDetails(): Search failed due to " + e.getMessage()
					+ "::" + e);
			result.setMessage("Operation failed, Please connect with administrator");
			return result;
		}

	}

//converts TxnPlayExecutions objects to Front-End ready objects in reverse,
	// latest records at top
	public List<PesSellerPlaySearchResultsDTO> prepareSellerPlaySearchResults(List<TxnPlayExecutions> txnPlayList) {
		LOGGER.info("PesSellerScoringServiceImpl.prepareSellerPlaySearchResults(): START");
		List<PesSellerPlaySearchResultsDTO> result = new ArrayList<>();
		if (txnPlayList == null) {
			LOGGER.info("NO RESULTS");

			return null;
		}
		for (TxnPlayExecutions exec : txnPlayList) {
			PesSellerPlaySearchResultsDTO sellerPlaySearchResult = new PesSellerPlaySearchResultsDTO();
			// To show play in Id and DisplayName
			Map<String, String> play = new HashMap<>();

			// Get value from each of execution
			Date dateOfExecution = null;
			if (exec.getDateOfExecution() != null)
				dateOfExecution = new Date(exec.getDateOfExecution().getTime());
			Long id = exec.getId();
			String nameOfProspect = exec.getNameOfProspect();
			String pesStatus = exec.getPesStatus();
			String sfdcStatus = exec.getSfdcStatus();
			String pesFeedback = exec.getPesFeedback();
			String podLeadFeedback = exec.getPodLeadFeedback();
			String pesScore = exec.getPesScore();
			String podLeadScore = exec.getPodLeadScore();
			String docLink = exec.getDocLink();
			String overriden = exec.getOverriden();
			String scoringForName = exec.getScoringFor().getFullName();

			// Creating obj for play {Id:,DisplayName:}
			Play playObj = exec.getPlay();

			if (play != null) {
				play.put("id", playObj.getId() + "");
				play.put("displayName", playObj.getName());
			}

			// Preparing the results DTO

			sellerPlaySearchResult.setId(id);
			sellerPlaySearchResult.setDateOfExecution(dateOfExecution);
			sellerPlaySearchResult.setPlay(play);
			sellerPlaySearchResult.setNameOfProspect(nameOfProspect);
			sellerPlaySearchResult.setPesStatus(pesStatus);
			sellerPlaySearchResult.setSfdcStatus(sfdcStatus);
			sellerPlaySearchResult.setPesScore(pesScore);
			sellerPlaySearchResult.setPodLeadScore(podLeadScore);
			sellerPlaySearchResult.setDocLink(docLink);
			sellerPlaySearchResult.setPesFeedback(pesFeedback);
			sellerPlaySearchResult.setPodLeadFeedback(podLeadFeedback);
			sellerPlaySearchResult.setOverriden(overriden);
			sellerPlaySearchResult.setPlayFieldsFromTxnDataList(exec.getTxnPlayExecutionData());
			sellerPlaySearchResult.setPlayExecFeedback(exec.getTxnPlayExecutionFeedback());
			sellerPlaySearchResult.setScoringFor(scoringForName);


			result.add(sellerPlaySearchResult);
		}
		LOGGER.info("PesSellerScoringServiceImpl.prepareSellerPlaySearchResults(): END");
		return result;
	}

	@Override
	public GenericResult getPlayExecutions(Long id, Long roleId, Long pkId) {
		LOGGER.info("PesSellerScoringServiceImpl.getPlayExecutions(): START");
		GenericResult result = new GenericResult();
		try {
			List<String> nonSellerUsers = Arrays.asList(propertiesUtil.getPropertyByName("NON_SELLER_USERS_FOR_SELLER_VIEW").getPropertyValue().split(","));
			TxnPlayExecutions playExc = txnRepo.getById(id);
			List<TxnPlayExecutions> playExcList = new ArrayList<>();
			String status = playExc.getPesStatus();
			Long scoringFor = playExc.getScoringFor().getId();
			FunctionalRole role = fnRoleRepo.getById(roleId);
			String roleName = role != null? role.getName() : ""; 
			if (nonSellerUsers.contains(roleName) || (scoringFor.equals(pkId)
					&& (status.equals(PesConstants.PUSH_TO_POD_LEAD) || status.equals(PesConstants.COMPLETED)))) {
				playExcList.add(playExc);
			}
			List<PesSellerPlaySearchResultsDTO> res = prepareSellerPlaySearchResults(playExcList);

			if (playExcList.size() != 0) {
				//result.setData(res);
				result.setMessage("Operation Successful");
				result.setStatus(PesConstants.SUCCESS);
				result.setData(res);
				result.setSuccess(true);
			} else {
				LOGGER.error("PesSellerScoringServiceImpl.getPlayExecutions(): No Txn Records found for id " + id);
				result.setMessage("TxnPlay fetching playExc Operation failed");
				result.setStatus(PesConstants.FAIL);
				result.setSuccess(false);
			}
		} catch (Exception e) {
			LOGGER.error("PesSellerScoringServiceImpl.getPlayExecutions(): Txn Record retrieving failed for id " + id + " :: "
					+ e.getMessage());
			result.setData(null);
			result.setMessage("TxnPlay fetching playExc Operation failed");
			result.setStatus(PesConstants.FAIL);
			result.setSuccess(false);
		}

		LOGGER.info("PesSellerScoringServiceImpl.getPlayExecutions(): END");
		return result;
	}
	
	//Seller search impl
			@Override
			public GenericResult searchSellerPlayExecutions(PlayStatusDTO sellerSearchDto, Long roleId) {
				LOGGER.info("PesScoringServiceImpl.searchSellerPlayExecutions() : START");
				GenericResult result = new GenericResult();
				try {
					List<PesSellerPlaySearchResultsDTO> res = new ArrayList<>();
					
					//Need to initialize again outside the Predicate class
					String sellerIds[] = sellerSearchDto.getSellerIds();
					String roleName = fnRoleRepo.getById(roleId).getName();
					
					//condition to check whether the POD lead doesn't have any sellers mapped to him/her
					if(roleName.equalsIgnoreCase("POD Lead") && (sellerIds == null || sellerIds.length == 0)) {
						result.setSuccess(Boolean.TRUE);
						result.setStatus(PesConstants.SUCCESS);
						result.setMessage("No Data present as POD Lead does not have any subordinates");
						result.setData(res);
						return result;
					}
					
					List<TxnPlayExecutions> txnPlayList = txnRepo.findAll(new Specification<TxnPlayExecutions>() {

						private static final long serialVersionUID = 1L;

						@Override
						public Predicate toPredicate(Root<TxnPlayExecutions> root, CriteriaQuery<?> query,
								CriteriaBuilder criteriaBuilder) {
							List<Predicate> predicates = new ArrayList<>();

							// Variables from scoringSearchDTO object
							String playIds[] = sellerSearchDto.getPlays();
							String nameOfProspect = sellerSearchDto.getNameOfProspect();
							String startDateString = sellerSearchDto.getCreatedDateStart();
							String endDateString = sellerSearchDto.getCreatedDateEnd();
							String pesStatus = sellerSearchDto.getPesStatus();
							String podLeadScore = sellerSearchDto.getPodLeadRating();
							String pesScore = sellerSearchDto.getPesRating();
							String sellerIds[] = sellerSearchDto.getSellerIds();
							
							Date startDate = null;
							Date endDate = null;
							
							
							// Converting start date from string to sql type
							if (!StringUtils.isEmpty(startDateString)) {
								LocalDate date = LocalDate.parse(startDateString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
								startDate = Date.valueOf(date);
							}
							// same for end date
							if (!StringUtils.isEmpty(endDateString)) {
								LocalDate date = LocalDate.parse(endDateString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
								endDate = Date.valueOf(date);
							}

							if (playIds != null && playIds.length != 0) {
								In<Object> in = criteriaBuilder.in(root.get("play").get("id"));
								List<Long> playIdList = Arrays.stream(playIds).map(Long::parseLong)
										.collect(Collectors.toList());
								in.value(playIdList);
								predicates.add(in);
							}
							if (!StringUtils.isEmpty(nameOfProspect)) {
								predicates.add(
										criteriaBuilder.and(criteriaBuilder.equal(root.get("nameOfProspect"), nameOfProspect)));
							}
							if (!StringUtils.isEmpty(pesStatus)) {
								if (!pesStatus.equals(PesConstants.COMPLETED))
									predicates.add(criteriaBuilder
											.and(criteriaBuilder.notEqual(root.get("pesStatus"), PesConstants.COMPLETED)));
								predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("pesStatus"), pesStatus)));
							}
							if (!StringUtils.isEmpty(podLeadScore)) {
								predicates.add(
										criteriaBuilder.and(criteriaBuilder.equal(root.get("podLeadScore"), podLeadScore)));
							}
							if (!StringUtils.isEmpty(pesScore)) {
								predicates.add(
										criteriaBuilder.and(criteriaBuilder.equal(root.get("pesScore"), pesScore)));
							}
							if (!StringUtils.isEmpty(startDateString) && !StringUtils.isEmpty(endDateString)) {
								predicates.add(criteriaBuilder
										.and(criteriaBuilder.between(root.get("createdDate"), startDate, endDate)));
							} else if (!StringUtils.isEmpty(startDateString)) {
								predicates.add(criteriaBuilder
										.and(criteriaBuilder.greaterThanOrEqualTo(root.get("createdDate"), startDate)));
							} else if (!StringUtils.isEmpty(endDateString)) {
								predicates.add(criteriaBuilder
										.and(criteriaBuilder.lessThanOrEqualTo(root.get("createdDate"), endDate)));
							}
							if (sellerIds != null && sellerIds.length != 0) {
								In<Object> in = criteriaBuilder.in(root.get("scoringFor").get("id"));
								List<Long> sellerIdList = Arrays.stream(sellerIds).map(Long::parseLong)
										.collect(Collectors.toList());
								in.value(sellerIdList);
								predicates.add(in);
							}

							return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
						}
					});

						res = prepareSellerPlaySearchResults(txnPlayList);
//					Collections.reverse(result);

					result.setSuccess(Boolean.TRUE);
					result.setStatus(PesConstants.SUCCESS);
					result.setMessage("Operation Successful");
					result.setData(res);
					LOGGER.info("PesScoringServiceImpl.searchPlayExecutions() : END");
					return result;
				} catch (Exception e) {
					LOGGER.error("PesScoringServiceImpl.searchPlayExecutions() :Exception while fetching Record: "
							+ e.getMessage() + "::" + e);
					// to send back in case of error
					result.setSuccess(Boolean.FALSE);
					result.setStatus(PesConstants.FAIL);
					result.setMessage("Something went wrong! Txn Records search failed");
					result.setData(null);
					return result;
				}
			
			}

}