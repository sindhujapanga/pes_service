package com.highradius.pes.dto;

import java.util.List;

public class MovePlayDTO {
	
	List<Long> idList;
	String moveToDate;
	String user;
	
	public List<Long> getIdList() {
		return idList;
	}
	public void setIdList(List<Long> idList) {
		this.idList = idList;
	}
	public String getMoveToDate() {
		return moveToDate;
	}
	public void setMoveToDate(String moveToDate) {
		this.moveToDate = moveToDate;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}

}
