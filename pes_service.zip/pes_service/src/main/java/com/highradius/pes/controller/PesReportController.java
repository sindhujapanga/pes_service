/**
 * 
 */
package com.highradius.pes.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.highradius.pes.service.PesReportService;
import com.highradius.pes.service.impl.PesReportServiceImpl;
import com.highradius.pes.util.PdfUtil;
import com.highradius.pes.util.PesPropertiesUtil;

/**
 * @author vamshi.bonagiri
 *
 */

@RestController
@CrossOrigin(origins = {"http://localhost:3000","https://pestest.highradius.com","https://pestest-sb.highradius.com"
		, "https://pes.highradius.com","https://pes-sb.highradius.com"})
@RequestMapping(value = "/report")
public class PesReportController {
	
	@Autowired
	PesReportService pesReportService;
	
	@Autowired
	PesReportServiceImpl pesReportServiceImpl;
	
	@Autowired
	PdfUtil pdfUtil;
	
	@Autowired
	PesPropertiesUtil properties;
	
	private static final Logger LOGGER = LogManager.getLogger(PesReportController.class);
	
	/**
	 * processes weekly scores
	 * @throws Exception
	 */
	@GetMapping(value = "/process/weekly")
	public void processWeeklySellerReports() throws Exception{
		LOGGER.info("PesReportController.processWeeklySellerReports: Processing weekly reports...");
		pesReportService.processWeeklySellerReports();
	}
	
	/**
	 * processes monthly scores
	 * @throws Exception
	 */
	@GetMapping(value = "/process/monthly")
	public void processMonthlySellerReports() throws Exception{
		LOGGER.info("PesReportController.processMonthlySellerReports: Processing Monthly reports...");
		pesReportService.processMonthlySellerReports();
	}
	
	/**
	 * generates monthly seller reports
	 * @throws Exception
	 */
	@GetMapping(value = "/generate/monthly")
	public void generateMonthlySellerReports() throws Exception {
		LOGGER.info("PesReportController.generateMonthlySellerReports: Generating Monthly reports...");
		pesReportService.generateMonthlySellerReports();
	}
	
	/**
	 * Generates weekly seller reports
	 * @throws Exception
	 */
	@GetMapping(value = "/generate/weekly")
	public void generateWeeklySellerReports() throws Exception {
		LOGGER.info("PesReportController.generateWeeklySellerReports: Generating Weekly reports...");
		pesReportService.generateWeeklySellerReports();
	}
	
	/**
	 * Sends monthly seller reports
	 * @throws Exception
	 */
	@GetMapping(value = "/sendReports/monthly")
	public void sendReportsMonthly() throws Exception{
		LOGGER.info("PesReportController.sendReportsMonthly: Sending Monthly reports...");
		boolean enableGlobalMail = Boolean.parseBoolean(properties.getPropertyByName("ENABLE_GLOBAL_EMAIL").getPropertyValue());
		if (enableGlobalMail) {
		pesReportService.sendMonthlySellerReports();
		}
	}
	
	/**
	 * Sends weekly seller reports
	 * @throws Exception
	 */
	@GetMapping(value = "/sendReports/weekly")
	public void sendReportsWeekly() throws Exception{
		LOGGER.info("PesReportController.sendReportsWeekly: Sending Weekly reports...");
		boolean enableGlobalMail = Boolean.parseBoolean(properties.getPropertyByName("ENABLE_GLOBAL_EMAIL").getPropertyValue());
		if (enableGlobalMail) {
			pesReportService.sendWeeklySellerReports();
		}
	}
	
	/**
	 * used to process a particular week
	 * @param obj
	 * @throws Exception
	 */
	@GetMapping(value = "/process/week")
	public void processWeeklyMigrationSellerReports(@RequestBody JSONObject obj) throws Exception{
		String start = obj.get("start").toString();
		String end = obj.get("end").toString();
		LOGGER.info(start + "-" + end);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate preMonday = LocalDate.parse(start, formatter);
		LocalDate preSunday = LocalDate.parse(end, formatter);
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));
		LOGGER.info("PesReportController.processWeeklySellerReports: Processing weekly reports...");
		pesReportServiceImpl.processSellerReports("WEEK", startDate, endDate);
	}
	
	/**
	 * generate week reports
	 * @param obj
	 * @throws Exception
	 */
	@GetMapping(value = "/generate/week")
	public void generateWeeklyMigrationSellerReports(@RequestBody JSONObject obj) throws Exception {
		String start = obj.get("start").toString();
		String end = obj.get("end").toString();
		LOGGER.info(start + "-" + end);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate preMonday = LocalDate.parse(start, formatter);
		LocalDate preSunday = LocalDate.parse(end, formatter);
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));
		LOGGER.info("PesReportController.generateWeeklySellerReports: Generating Weekly reports...");
		pesReportService.generateWeeklySellerReports();
	}
	
	/**
	 * process month data
	 * @param obj
	 * @throws Exception
	 */
	@GetMapping(value = "/process/month")
	public void processMonthlyMigrationSellerReports(@RequestBody JSONObject obj) throws Exception{
		String start = obj.get("start").toString();
		String end = obj.get("end").toString();
		LOGGER.info(start + "-" + end);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate preMonday = LocalDate.parse(start, formatter);
		LocalDate preSunday = LocalDate.parse(end, formatter);
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));
		LOGGER.info("PesReportController.processMonthlySellerReports: Processing Monthly reports...");
		pesReportServiceImpl.processSellerReports("MONTH", startDate, endDate);
	}
	
	
}