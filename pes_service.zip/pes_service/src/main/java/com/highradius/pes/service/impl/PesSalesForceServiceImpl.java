package com.highradius.pes.service.impl;

import static java.time.DayOfWeek.MONDAY;
import static java.time.temporal.TemporalAdjusters.previousOrSame;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;  
import java.net.URL;  
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.highradius.pes.dto.ChampionsnZZTopDTO;
import com.highradius.pes.dto.Demo_Play_DTO;
import com.highradius.pes.dto.DiscoveryCallDTO;
import com.highradius.pes.dto.EmployeeSFDTO;
import com.highradius.pes.dto.OTCWebResearchDTO;
import com.highradius.pes.dto.STRAP_DTO;
import com.highradius.pes.dto.SalesPipelineOTCDTO;
import com.highradius.pes.service.PesSalesForceService;
import com.highradius.pes.util.PesConstants;
import com.highradius.pes.util.PesPropertiesUtil;

//properties Util class
	
@Service
public class PesSalesForceServiceImpl implements PesSalesForceService {
	
	@Autowired
	PesPropertiesUtil propertiesService;

	
	
	private static final Logger LOGGER = LogManager.getLogger(PesSalesForceServiceImpl.class);

	//Getting activation token for SalesForce integration everytime a report is accessed
	@Override
	public String getSFAPIAccessToken(String token, String clientID, String clientSecret) {
		// TODO Auto-generated method stub
		String authToken = null;
		int timeout = 500;
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
				.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse authResponse = null;

		HttpPost post = new HttpPost("https://login.salesforce.com/services/oauth2/token");
		post.setURI(URI.create(
				"https://login.salesforce.com/services/oauth2/token?client_id=3MVG9szVa2RxsqBZFY0iWONq0E3M2QuJONvVV.yItSfpBPpvSTaCul_hfrxjd45ubUk5SpvI7zHxedvAzgb53&client_secret=8E804112C6D2709F5AF6FB0258FF035667890EFBD3A5C194A9B9FA4E822B7BD0&redirect_uri=https://login.salesforce.com&username=sfdcintuser@highradius.com&password=SforceIntPwd1!sTlS0czNgJhI5Lum7hMz5W0fg&grant_type=password"));
		post.addHeader("Content-Type", "application/x-www-form-urlencoded");
		post.addHeader("cache-control", "no-cache");
		try {
			authResponse = httpClient.execute(post);
			String json = EntityUtils.toString(authResponse.getEntity());
			JSONObject parser = new JSONObject(json);
			authToken = parser.getString("access_token");
			LOGGER.info("Auth token - " + authToken);
		} catch (Exception e) {
			LOGGER.error("PesSalesForceImpl Error", e);
		} 
		return authToken;
	}
	
	/**
	 * Gets the start and end dates as a [startDate,endDate] for Discovery Calls
	 * @return
	 */
	public Date getDCFilterDate() {
		try {
		String dayNames[] = new DateFormatSymbols().getWeekdays(); 
		TimeZone tz = TimeZone.getTimeZone("Asia/Kolkata");
		Calendar cal = Calendar.getInstance(tz);  
		
		System.out.println("Today is "+ dayNames[cal.get(Calendar.DAY_OF_WEEK)]); 
		
		Date filetrDate = new Date();
		String day = dayNames[cal.get(Calendar.DAY_OF_WEEK)];
		int noOfDays = -2;
		if(day.equals("Sunday")){
			noOfDays = -4;
		} if(day.equals("Monday") || day.equals("Tuesday")) {
			noOfDays = -4;
		}
		cal.add(Calendar.DATE, noOfDays);
		String fltrDtStr = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH)+1) + "-" + cal.get(Calendar.DATE);
		filetrDate = new SimpleDateFormat("yyyy-MM-dd").parse(fltrDtStr);
		
		return filetrDate;
		}catch(Exception e) {
			LOGGER.info("Error in fetching filter date");
			return null;
		}
	}
	
	/**
	 * Gets the start and end dates as a [startDate,endDate] for OTC Calls
	 * @return
	 */
	public Date[] getOTCFilterDates() {
		ZoneId z = ZoneId.of("Asia/Kolkata");
		LocalDate today = LocalDate.now(z);
		LocalDate monday = today.with(previousOrSame(MONDAY));
		LocalDate preMonday = monday.minusDays(14);
		LocalDate preSunday = monday.minusDays(8);
		System.out.println("Retrieving the filtering dates " + preMonday + " : " + preSunday);
		// Calendar cal = Calendar.getInstance();
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));
		Date stDate = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
		Date edDate = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
        Date[] dateFilterData = {stDate,edDate};
        return dateFilterData;
	}
	
	/**
	 * Gets the start and end dates as a [startDate,endDate] for STRAP Calls
	 * @return
	 */
	public Date[] getSTRAPFilterDates() {
		ZoneId z = ZoneId.of("Asia/Kolkata");
		LocalDate today = LocalDate.now(z);
		LocalDate monday = today.with(previousOrSame(MONDAY));
		LocalDate preMonday = monday.minusDays(7);
		LocalDate preSunday = monday.minusDays(1);
		System.out.println("Retrieving the filtering dates " + preMonday + " : " + preSunday);
		// Calendar cal = Calendar.getInstance();
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));
		Date stDate = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
		Date edDate = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
        Date[] dateFilterData = {stDate,edDate};
        return dateFilterData;
	}

	//fetching Discovery Call Reports for Enterprise EMEA
	@Override
	public List<DiscoveryCallDTO> getEnterpriseEMEADCCReport(String start, String end){
		LOGGER.info("PesSalesForceServiceImpl.getEnterpriseEMEADCCReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		//String ReportID = "00O5d000007pKFxEAM";
		//Added property in DB and getting ID from DB
		String ReportID = propertiesService.getPropertyByName("ENTERPRISE_EMEA_DCCREPORT_ID").getPropertyValue();
		Date startDate = null;
		Date endDate = null;
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}
			catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		int timeout = 500;
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
				.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;

		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + ReportID);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		List<DiscoveryCallDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			JSONObject resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
			JSONArray rows = table.getJSONArray("rows");
			DiscoveryCallDTO reportRecord = null;
			
			Date filterDate = getDCFilterDate();

			for (int i = 0; i < rows.length(); i++) {
				JSONObject row1 = rows.getJSONObject(i);
				JSONArray dataCells = row1.getJSONArray("dataCells");
				reportRecord = new DiscoveryCallDTO();
				JSONObject eachCell = (JSONObject) dataCells.get(0);
				
				if (!eachCell.isNull("value")) {
					try {
						String dateOfExecution = eachCell.getString("value").substring(0,
								eachCell.getString("value").indexOf('T'));
						Date dateOfExec = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecution);
						if (startDate != null
								&& (startDate.compareTo(dateOfExec) <= 0 && endDate.compareTo(dateOfExec) >= 0)) {
							reportRecord.setDateOfExecution(eachCell.getString("value"));
						} else if (startDate == null && filterDate.compareTo(dateOfExec) == 0) {
							reportRecord.setDateOfExecution(eachCell.getString("value"));
						}
						else
							continue;
					} catch (Exception e) {
						LOGGER.info("Error in dateOfExecution");
						continue;
					}
				}

				
				eachCell = (JSONObject) dataCells.get(3);
				if (!eachCell.isNull("label")) {
					reportRecord.setActivityId(eachCell.getString("value"));
					reportRecord.setDcId(eachCell.getString("label"));
				}
				else {
					reportRecord.setActivityId("");
					reportRecord.setDcId("");
				}
				eachCell = (JSONObject) dataCells.get(5);
				if (!eachCell.isNull("label"))
					reportRecord.setNameOfProspect(eachCell.getString("label"));
				else
					reportRecord.setNameOfProspect("");
				eachCell = (JSONObject) dataCells.get(22);
				if (!eachCell.isNull("value"))
					reportRecord.setFtaSfId(eachCell.getString("value"));
				else
					reportRecord.setFtaSfId("");
				eachCell = (JSONObject) dataCells.get(23);
				if (!eachCell.isNull("value"))
					reportRecord.setAeSfId(eachCell.getString("value"));
				else
					reportRecord.setAeSfId("");
				eachCell = (JSONObject) dataCells.get(24);
				if (!eachCell.isNull("value"))
					reportRecord.setSpSfId(eachCell.getString("value"));
				else
					reportRecord.setSpSfId("");
				eachCell = (JSONObject) dataCells.get(17);
				if (!eachCell.isNull("label"))
					reportRecord.setSfdcStatus(eachCell.getString("label"));
				else
					reportRecord.setSfdcStatus("");
				eachCell = (JSONObject) dataCells.get(9);
				if (!eachCell.isNull("label"))
					reportRecord.setDocLink(eachCell.getString("label"));
				else
					reportRecord.setDocLink("");
				eachCell = (JSONObject) dataCells.get(36);
				if (!eachCell.isNull("label"))
					reportRecord.setMarket(eachCell.getString("label"));
				else
					reportRecord.setMarket("");
				repList.add(reportRecord);
			}
			LOGGER.info("No. of records queried - " + repList.size());
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}

	//fetching Discovery Call Reports for Enterprise NA
	@Override
	public List<DiscoveryCallDTO> getEnterpriseNADCCReport(String start, String end) {
		// TODO Auto-generated method stub
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		//Adding Report ID in DB
		String ReportID = propertiesService.getPropertyByName("ENTERPRISE_NA_DCCREPORT_ID").getPropertyValue();
		//String ReportID = "00O5d00000815wREAQ"; //00O1K000009ioiTUAQ old IDx`
		Date startDate = null;
		Date endDate = null;
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}
			catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		int timeout = 500;
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
				.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;

		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + ReportID);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		List<DiscoveryCallDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			JSONObject resp = new JSONObject(json);
			
			Date filterDate = getDCFilterDate();
			
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				DiscoveryCallDTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new DiscoveryCallDTO();
					JSONObject eachCell = (JSONObject) dataCells.get(0);
					if (!eachCell.isNull("label")) {
						reportRecord.setActivityId(eachCell.getString("value"));
						reportRecord.setDcId(eachCell.getString("label"));
					}
					else {
						reportRecord.setActivityId("");
						reportRecord.setDcId("");
					}
					eachCell = (JSONObject) dataCells.get(1);
					if (!eachCell.isNull("label"))
						reportRecord.setNameOfProspect(eachCell.getString("label"));
					else
						reportRecord.setNameOfProspect("");
					eachCell = (JSONObject) dataCells.get(8);
					if (!eachCell.isNull("value")) {
						try {
							String dateOfExecution = eachCell.getString("value").substring(0,
									eachCell.getString("value").indexOf('T'));
							Date dateOfExec = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecution);
							if (startDate != null
									&& (startDate.compareTo(dateOfExec) <= 0 && endDate.compareTo(dateOfExec) >= 0)) {
								reportRecord.setDateOfExecution(eachCell.getString("value"));
							} else if (startDate == null && filterDate.compareTo(dateOfExec) == 0) {
								reportRecord.setDateOfExecution(eachCell.getString("value"));
							}
							else
								continue;
						} catch (Exception e) {
							LOGGER.info("Error in dateOfExecution");
							continue;
						}
					}
					else
						reportRecord.setDateOfExecution("");
					eachCell = (JSONObject) dataCells.get(21);
					if (!eachCell.isNull("value"))
						reportRecord.setFtaSfId(eachCell.getString("value"));
					else
						reportRecord.setFtaSfId("");
					eachCell = (JSONObject) dataCells.get(22);
					if (!eachCell.isNull("value"))
						reportRecord.setAeSfId(eachCell.getString("value"));
					else
						reportRecord.setAeSfId("");
					eachCell = (JSONObject) dataCells.get(23);
					if (!eachCell.isNull("value"))
						reportRecord.setSpSfId(eachCell.getString("value"));
					else
						reportRecord.setSpSfId("");
					eachCell = (JSONObject) dataCells.get(12);
					if (!eachCell.isNull("label"))
						reportRecord.setDocLink(eachCell.getString("label"));
					else
						reportRecord.setDocLink("");
					eachCell = (JSONObject) dataCells.get(48);
					if (!eachCell.isNull("label"))
						reportRecord.setMarket(eachCell.getString("label"));
					else
						reportRecord.setMarket("");
					eachCell = (JSONObject) dataCells.get(25);
					if (!eachCell.isNull("label"))
						reportRecord.setSfdcStatus(eachCell.getString("label"));
					else
						reportRecord.setSfdcStatus("");
					repList.add(reportRecord);
				}
			}
			LOGGER.info("No. of records queried - " + repList.size());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return repList;

	}

	//fetching Discovery Call Reports for MidMarket	
	@Override
	public List<DiscoveryCallDTO> getMidMarketReport(String start, String end) {
		// TODO Auto-generated method stub
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		//String ReportID = "00O5d000007p00sEAA";
		//Added property in DB and getting ID from DB
		String ReportID = propertiesService.getPropertyByName("MIDMARKET_REPORT_ID").getPropertyValue();
		Date startDate = null;
		Date endDate = null;
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}
			catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		int timeout = 500;
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
				.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;

		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + ReportID);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		List<DiscoveryCallDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			JSONObject resp = new JSONObject(json);
			Date filterDate = getDCFilterDate();
			
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				DiscoveryCallDTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new DiscoveryCallDTO();
					JSONObject eachCell = (JSONObject) dataCells.get(0);
					if (!eachCell.isNull("label"))
						reportRecord.setNameOfProspect(eachCell.getString("label"));
					else
						reportRecord.setNameOfProspect("");
					eachCell = (JSONObject) dataCells.get(3);
					if (!eachCell.isNull("value")) {
						try {
							String dateOfExecution = eachCell.getString("value");
							Date dateOfExec = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecution);
							if (startDate != null
									&& (startDate.compareTo(dateOfExec) <= 0 && endDate.compareTo(dateOfExec) >= 0)) {
								reportRecord.setDateOfExecution(eachCell.getString("value")+"T");
							} else if (startDate == null && filterDate.compareTo(dateOfExec) == 0) {
								reportRecord.setDateOfExecution(eachCell.getString("value")+"T");
							}
							else
								continue;
						} catch (Exception e) {
							LOGGER.info("Error in dateOfExecution");
							continue;
						}
					}
					else
						reportRecord.setDateOfExecution("");
					eachCell = (JSONObject) dataCells.get(6);
					if (!eachCell.isNull("value"))
						reportRecord.setFtaSfId(eachCell.getString("value"));
					else
						reportRecord.setFtaSfId("");
					eachCell = (JSONObject) dataCells.get(7);
					if (!eachCell.isNull("value"))
						reportRecord.setSpSfId(eachCell.getString("value"));
					else
						reportRecord.setSpSfId("");
					eachCell = (JSONObject) dataCells.get(8);
					if (!eachCell.isNull("value"))
						reportRecord.setAeSfId(eachCell.getString("value"));
					else
						reportRecord.setAeSfId("");
					eachCell = (JSONObject) dataCells.get(9);
					if (!eachCell.isNull("label"))
						reportRecord.setSfdcStatus(eachCell.getString("label"));
					else
						reportRecord.setSfdcStatus("");
					eachCell = (JSONObject) dataCells.get(1);
					if (!eachCell.isNull("label")) {
						reportRecord.setActivityId(eachCell.getString("label"));
						reportRecord.setDcId(eachCell.getString("value"));
					}
					else {
						reportRecord.setActivityId("");
						reportRecord.setDcId("");
					}
					eachCell = (JSONObject) dataCells.get(20);
					if (!eachCell.isNull("label"))
						reportRecord.setMarket(eachCell.getString("label"));
					else
						reportRecord.setMarket("");
					repList.add(reportRecord);
				}
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;

	}
	
	//fetching Discovery Call Reports for Enterprise EMEA
	@Override
	public List<DiscoveryCallDTO> getTreasuryReport() {
		// TODO Auto-generated method stub
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		//String ReportID = "00O1K000009j1MhUAI";
		//Added property in DB and getting ID from DB
		String ReportID = propertiesService.getPropertyByName("TREASURY_REPORT_ID").getPropertyValue();
		int timeout = 500;
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
				.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;

		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + ReportID);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		List<DiscoveryCallDTO> repList = new ArrayList<>();

		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			JSONObject resp = new JSONObject(json);
			Date filterDate = getDCFilterDate();
			
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				DiscoveryCallDTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new DiscoveryCallDTO();
					JSONObject eachCell = (JSONObject) dataCells.get(2);
					if (!eachCell.isNull("label"))
						reportRecord.setActivityId(eachCell.getString("label"));
					else
						reportRecord.setActivityId("");
					eachCell = (JSONObject) dataCells.get(3);
					if (!eachCell.isNull("label"))
						reportRecord.setNameOfProspect(eachCell.getString("label"));
					else
						reportRecord.setNameOfProspect("");
					eachCell = (JSONObject) dataCells.get(5);
					if (!eachCell.isNull("value")) {
						try {
							String dateOfExecution = eachCell.getString("value").substring(0, eachCell.getString("value").indexOf('T'));
							Date dateOfExec = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecution);
							if(filterDate.compareTo(dateOfExec) != 0)
								continue;
							reportRecord.setDateOfExecution(eachCell.getString("value"));
							}catch(Exception e) {
								LOGGER.info("Error in dateOfExecution");
								continue;
							}
					}
					else
						reportRecord.setDateOfExecution("");
					eachCell = (JSONObject) dataCells.get(11);
					if (!eachCell.isNull("value"))
						reportRecord.setFtaSfId(eachCell.getString("value"));
					else
						reportRecord.setFtaSfId("");
					eachCell = (JSONObject) dataCells.get(18);
					if (!eachCell.isNull("value"))
						reportRecord.setAeSfId(eachCell.getString("value"));
					else
						reportRecord.setAeSfId("");
					eachCell = (JSONObject) dataCells.get(19);
					if (!eachCell.isNull("value"))
						reportRecord.setSpSfId(eachCell.getString("value"));
					else
						reportRecord.setSpSfId("");
					eachCell = (JSONObject) dataCells.get(24);
					if (!eachCell.isNull("label"))
						reportRecord.setDocLink(eachCell.getString("label"));
					else
						reportRecord.setDocLink("");
					eachCell = (JSONObject) dataCells.get(27);
					if (!eachCell.isNull("label"))
						reportRecord.setMarket(eachCell.getString("label"));
					else
						reportRecord.setMarket("");
					eachCell = (JSONObject) dataCells.get(29);
					if (!eachCell.isNull("label"))
						reportRecord.setSfdcStatus(eachCell.getString("label"));
					else
						reportRecord.setSfdcStatus("");
					repList.add(reportRecord);
				}
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return repList;
	}
	
	@Override
	public List<OTCWebResearchDTO> getOTCWebResearchReport(String start, String end){
		LOGGER.info("PesSalesForceServiceImpl.getOTCDiscoveryCallReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		//String reportId = "00O1K000009iph7UAA";
		//Added property in DB and getting ID from DB
		String reportId = propertiesService.getPropertyByName("OTC_WEBRESEARCH_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		Date dateList[] = getOTCFilterDates();
		Date startDate = dateList[0];
		Date endDate = dateList[1];
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		
		LOGGER.info("Filtering data with startDate, endDate : " + startDate + " , " + endDate);
		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<OTCWebResearchDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				//Create object for DTO
				OTCWebResearchDTO reportRecord = null; 
				for (int i = 0; i < rows.length(); i++) {
					//get the row 
					JSONObject row1 = rows.getJSONObject(i);
					//get the datacell array of objects
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new OTCWebResearchDTO();
					//Get 1st json object of data cell array and set Activity ID
					JSONObject eachCell = (JSONObject) dataCells.get(0);
					if (!eachCell.isNull("label")) {
						reportRecord.setActivityId(eachCell.getString("value"));
						reportRecord.setDcId(eachCell.getString("label"));
					}
					else {
						reportRecord.setActivityId("");
						reportRecord.setDcId("");
					}
					//Get 2nd json object and take value of that 
					eachCell = (JSONObject) dataCells.get(1);
					if (!eachCell.isNull("value"))
						try {
							//Get the date in string and parse to format 
							String dateOfExecution = eachCell.getString("value").substring(0, eachCell.getString("value").indexOf('T'));
							Date dateOfExec = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecution);
							//convert dates in numbers and check for range of start and end in between the start and end 
							if(startDate.compareTo(dateOfExec) > 0 || endDate.compareTo(dateOfExec) < 0)
								continue;
							reportRecord.setDateOfExecution(eachCell.getString("value"));
							}catch(Exception e) {
								LOGGER.info("Error in dateOfExecution");
								continue;
							}
					else
						reportRecord.setDateOfExecution("");
					//get the next value of object ie.SFDC status
					eachCell = (JSONObject) dataCells.get(4);
					if (!eachCell.isNull("value")) {
						String status = eachCell.getString("label");
						//check if the Value of SFDC status is Cancelled/no show 
						if(status.equalsIgnoreCase(PesConstants.CANCELLED) || status.equalsIgnoreCase(PesConstants.NO_SHOW) || status.equalsIgnoreCase("Scheduled")) {
							continue;
						}
						reportRecord.setSfdcStatus(eachCell.getString("value"));
					}
					else
						reportRecord.setSfdcStatus("");
					//get the next value for account name-has recordID
					eachCell = (JSONObject) dataCells.get(5);
					if (!eachCell.isNull("label")) {
						String status = eachCell.getString("label");
						if(status.equalsIgnoreCase("Cancelled")) {
							continue;
						}
						reportRecord.setAccountName(eachCell.getString("label"));
					}
					else
						reportRecord.setAccountName("");
					eachCell = (JSONObject) dataCells.get(6);
					if (!eachCell.isNull("value"))
						reportRecord.setAeSf(eachCell.getString("value"));
					else
						reportRecord.setAeSf("");
					eachCell = (JSONObject) dataCells.get(7);
					if (!eachCell.isNull("value"))
						reportRecord.setSpSf(eachCell.getString("value"));
					else
						reportRecord.setSpSf("");
					eachCell = (JSONObject) dataCells.get(8);
					if (!eachCell.isNull("label"))
						reportRecord.setOpportunityName(eachCell.getString("label"));
					else
						reportRecord.setOpportunityName("");
					eachCell = (JSONObject) dataCells.get(9);
					if (!eachCell.isNull("label"))
						reportRecord.setStage(eachCell.getString("label"));
					else
						reportRecord.setStage("");
					eachCell = (JSONObject) dataCells.get(11);
					if (!eachCell.isNull("label"))
						reportRecord.setMarket(eachCell.getString("label"));
					else
						reportRecord.setMarket("");
					eachCell = (JSONObject) dataCells.get(12);
					if (!eachCell.isNull("label"))
						reportRecord.setTeam(eachCell.getString("label"));
					else
						reportRecord.setTeam("");
					
					
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
	@Override
	public List<SalesPipelineOTCDTO> getOTCSalesPipelineReport(String start, String end){
		LOGGER.info("PesSalesForceServiceImpl.getOTCSalesPipelineReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		Date dateList[] = getOTCFilterDates();
		Date startDate = dateList[0];
		Date endDate = dateList[1];
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		//String reportId = "00O1K000009jUt4UAE";
		//Added property in DB and getting ID from DB
		String reportId = propertiesService.getPropertyByName("OTC_SALESPIPELINE_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		
		
		HttpGet request = new HttpGet("https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);				
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<SalesPipelineOTCDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				SalesPipelineOTCDTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new SalesPipelineOTCDTO();
					String dateToFilter = null;
					String vaDate = null;
					String faDate = null;
					JSONObject eachCell = (JSONObject) dataCells.get(2);
					if(!eachCell.isNull("label")) {
						reportRecord.setACCOUNT_NAME(eachCell.getString("label"));	
					}
					else
						reportRecord.setACCOUNT_NAME("");
					eachCell = (JSONObject) dataCells.get(12);
					if(!eachCell.isNull("value")) {
						reportRecord.setGenerate_Interest_Date__c(eachCell.getString("value"));
					}
					else
						reportRecord.setGenerate_Interest_Date__c("");
					eachCell = (JSONObject) dataCells.get(13);
					if(!eachCell.isNull("value")) {
						reportRecord.setFunctional_Allignment_Date__c(eachCell.getString("value"));
						faDate = eachCell.getString("value");
					}
					else
						reportRecord.setFunctional_Allignment_Date__c("");
					
					eachCell = (JSONObject) dataCells.get(14);
					if(!eachCell.isNull("value")) {
						reportRecord.setValue_Alignment_Date__c(eachCell.getString("value"));
						vaDate = eachCell.getString("value");
					}
					else
						reportRecord.setValue_Alignment_Date__c("");
					eachCell = (JSONObject) dataCells.get(15);
					if(!eachCell.isNull("value")) {
						reportRecord.setStakeholders_Buy_in_Date__c(eachCell.getString("value"));
					}
					else
						reportRecord.setStakeholders_Buy_in_Date__c("");
					eachCell = (JSONObject) dataCells.get(16);
					if(!eachCell.isNull("value")) {
						reportRecord.setBudget_Approval_Date__c(eachCell.getString("value"));
					}
					else
						reportRecord.setBudget_Approval_Date__c("");
					eachCell = (JSONObject) dataCells.get(17);
					if(!eachCell.isNull("value")) {
						reportRecord.setContracts_Date__c(eachCell.getString("value"));
					}
					else
						reportRecord.setContracts_Date__c("");
					
					boolean isFaNull = StringUtils.isEmpty(faDate);
					boolean isVaNull = StringUtils.isEmpty(vaDate);
					
					if(isVaNull) {
						vaDate = compareDates(reportRecord.getStakeholders_Buy_in_Date__c(), 
							reportRecord.getBudget_Approval_Date__c(), reportRecord.getContracts_Date__c());
						if(!StringUtils.isEmpty(vaDate)) {
						    reportRecord.setValue_Alignment_Date__c(vaDate);
							isVaNull = false;
						}
					}
					
					if(isVaNull && isFaNull) {
						continue;
					}
					else if(!isVaNull) {
						//storing the date which needs to be compared
						try {
						Date vaDt = new SimpleDateFormat("yyyy-MM-dd").parse(vaDate);
						Date faDt = null;
						if(!StringUtils.isEmpty(faDate))
							faDt = new SimpleDateFormat("yyyy-MM-dd").parse(faDate);
						if(faDt != null && vaDt.compareTo(faDt) < 0) {
							dateToFilter = faDate;
							reportRecord.setPlayName("OTC Whitespace Analysis - GI Stage");
						}
						else {
						dateToFilter = vaDate;
						reportRecord.setPlayName("OTC Whitespace Analysis - FA Stage");
						}
						}catch (Exception e) {
							LOGGER.error("PesSalesForceServiceImpl.getOTCSalesPipelineReport(): ERROR: error in getting fa va dates");
							dateToFilter = vaDate;
							reportRecord.setPlayName("OTC Whitespace Analysis - FA Stage");
						}
					}
					else if(isVaNull && !isFaNull) {
						dateToFilter = faDate;
						reportRecord.setPlayName("OTC Whitespace Analysis - GI Stage");
					}
					else 
						continue;
					
					//applying date filter
					try {
					Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateToFilter);
					if(startDate.compareTo(date) > 0 || endDate.compareTo(date) < 0)
						continue;
					}catch (Exception e) {
						LOGGER.info("getOTCWhitespaceAnalysisData: error in filtering by date");
					}
					
					eachCell = (JSONObject) dataCells.get(0);
					if(!eachCell.isNull("label")) {
						reportRecord.setAE_Team__c(eachCell.getString("label"));
					}
					else
						reportRecord.setAE_Team__c("");
					eachCell = (JSONObject) dataCells.get(3);
					if(!eachCell.isNull("label")) {
						reportRecord.setOPPORTUNITY_NAME(eachCell.getString("label"));
						reportRecord.setACTIVITY_ID(eachCell.getString("value"));
					}
					else
						reportRecord.setOPPORTUNITY_NAME("");
					eachCell = (JSONObject) dataCells.get(4);
					if(!eachCell.isNull("label")) {
						reportRecord.setSTAGE_NAME(eachCell.getString("label"));
					}
					else
						reportRecord.setSTAGE_NAME("");
					eachCell = (JSONObject) dataCells.get(27);
					if(!eachCell.isNull("value")) {
						reportRecord.setOnsite_SP__c(eachCell.getString("value"));
					}
					else
						reportRecord.setOnsite_SP__c("");
					eachCell = (JSONObject) dataCells.get(28);
					if(!eachCell.isNull("value")) {
						reportRecord.setSolution_Principal__c(eachCell.getString("value"));
					}
					else
						reportRecord.setSolution_Principal__c("");
					eachCell = (JSONObject) dataCells.get(29);
					if(!eachCell.isNull("value")) {
						reportRecord.setMarketName(eachCell.getString("value"));
					}
					else
						reportRecord.setMarketName("");
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
	/*
	 * fetching reports seperately for OTC Expansion, not being used currently
	 * Market : Net New
	 */
	@Override
	public List<SalesPipelineOTCDTO> getOTCSalesPipelineNAExpansionReport(String start, String end){
		LOGGER.info("PesSalesForceServiceImpl.getOTCSalesPipelineReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		Date dateList[] = getOTCFilterDates();
		Date startDate = dateList[0];
		Date endDate = dateList[1];
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		//String reportId = "00O5d000007oSO2EAM";
		//Added property in DB and getting ID from DB
		String reportId = propertiesService.getPropertyByName("OTC_SALESPIPELINENAEXPANSION_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		
		
		HttpGet request = new HttpGet("https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);				
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<SalesPipelineOTCDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				SalesPipelineOTCDTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new SalesPipelineOTCDTO();
					String dateToFilter = null;
					String vaDate = null;
					JSONObject eachCell = (JSONObject) dataCells.get(1);
					if(!eachCell.isNull("label")) {
						reportRecord.setACCOUNT_NAME(eachCell.getString("label"));	
					}
					else
						reportRecord.setACCOUNT_NAME("");
					reportRecord.setGenerate_Interest_Date__c("");
					
					reportRecord.setFunctional_Allignment_Date__c("");
					
					eachCell = (JSONObject) dataCells.get(10);
					if(!eachCell.isNull("value")) {
						reportRecord.setValue_Alignment_Date__c(eachCell.getString("value"));
						vaDate = eachCell.getString("value");
					}
					else
						reportRecord.setValue_Alignment_Date__c("");
					
					boolean isVaNull = StringUtils.isEmpty(vaDate);
					
					if(isVaNull) {
						continue;
					}
					else if(!isVaNull) {
						//storing the date which needs to be compared
						dateToFilter = vaDate;
						reportRecord.setPlayName("OTC Whitespace Analysis - FA Stage");
					}
					
					//applying date filter
					try {
					Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateToFilter);
					if(startDate.compareTo(date) > 0 || endDate.compareTo(date) < 0)
						continue;
					}catch (Exception e) {
						LOGGER.info("getOTCWhitespaceAnalysisData: error in filtering by date");
					}
					
					eachCell = (JSONObject) dataCells.get(0);
					if(!eachCell.isNull("label")) {
						reportRecord.setAE_Team__c(eachCell.getString("label"));
					}
					else
						reportRecord.setAE_Team__c("");
					eachCell = (JSONObject) dataCells.get(2);
					if(!eachCell.isNull("label")) {
						reportRecord.setOPPORTUNITY_NAME(eachCell.getString("label"));
						reportRecord.setACTIVITY_ID(eachCell.getString("value"));
					}
					else
						reportRecord.setOPPORTUNITY_NAME("");
					eachCell = (JSONObject) dataCells.get(4);
					if(!eachCell.isNull("label")) {
						reportRecord.setSTAGE_NAME(eachCell.getString("label"));
					}
					else
						reportRecord.setSTAGE_NAME("");
					eachCell = (JSONObject) dataCells.get(19);
					if(!eachCell.isNull("value")) {
						reportRecord.setOnsite_SP__c(eachCell.getString("value"));
					}
					else
						reportRecord.setOnsite_SP__c("");
					eachCell = (JSONObject) dataCells.get(20);
					if(!eachCell.isNull("value")) {
						reportRecord.setSolution_Principal__c(eachCell.getString("value"));
					}
					else
						reportRecord.setSolution_Principal__c("");
					eachCell = (JSONObject) dataCells.get(21);
					if(!eachCell.isNull("value")) {
						reportRecord.setMarketName(eachCell.getString("value"));
					}
					else
						reportRecord.setMarketName("");
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
	
	/*
	 * used to fetch Champion and ZZ Top plays from salesforce. Same report for both
	 */
	@Override
	public List<ChampionsnZZTopDTO> getChampionsnZZTopReport(){
		LOGGER.info("PesSalesForceServiceImpl.getChampionsAndZZTopReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		//String reportId = "00O5d000007ogfCEAQ";
		//Added property in DB and getting `ID from DB
		String reportId = propertiesService.getPropertyByName("CHAMPIONNZZTOP_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		
		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<ChampionsnZZTopDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				ChampionsnZZTopDTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new ChampionsnZZTopDTO();
					JSONObject eachCell = (JSONObject) dataCells.get(0);
					if (!eachCell.isNull("label"))
						reportRecord.setAccountName(eachCell.getString("label"));
					else
						reportRecord.setAccountName("");
					eachCell = (JSONObject) dataCells.get(1);
					if (!eachCell.isNull("value")) {
						reportRecord.setOpportunityName(eachCell.getString("label"));
						reportRecord.setActivityId(eachCell.getString("value"));
							}
					else
						reportRecord.setOpportunityName("");
					eachCell = (JSONObject) dataCells.get(2);
					if (!eachCell.isNull("value")) {
						reportRecord.setAE(eachCell.getString("value"));
					}
					else
						reportRecord.setAE("");
					eachCell = (JSONObject) dataCells.get(3);
					if (!eachCell.isNull("label")) {
						reportRecord.setMarket(eachCell.getString("label"));
					}
					else
						reportRecord.setMarket("");
					eachCell = (JSONObject) dataCells.get(4);
					if (!eachCell.isNull("value")) {
						reportRecord.setAETeam(eachCell.getString("value"));
					}
					else
						reportRecord.setAETeam("");
					eachCell = (JSONObject) dataCells.get(5);
					if (!eachCell.isNull("value"))
						reportRecord.setSP(eachCell.getString("value"));
					else
						reportRecord.setSP("");
					eachCell = (JSONObject) dataCells.get(6);
					if (!eachCell.isNull("label")) {
						reportRecord.setStageName(eachCell.getString("label"));
						String stage = eachCell.getString("label").substring(0,1);
						int stageNo = Integer.parseInt(stage);
						if(stageNo < 3 )
							continue;
					}
					else
						reportRecord.setStageName("");
					eachCell = (JSONObject) dataCells.get(8);
					if (!eachCell.isNull("label"))
						reportRecord.setOpportunityId(eachCell.getString("label"));
					else
						reportRecord.setOpportunityId("");
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
	
	//Used to fetch STRAP plays from salesforce.
	@Override
	public List<STRAP_DTO> getSTRAPReport(String start, String end){
		LOGGER.info("PesSalesForceServiceImpl.getChampionsAndZZTopReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		//String reportId = "00O5d000007oi3PEAQ";
		//Added property in DB and getting ID from DB
		String reportId = propertiesService.getPropertyByName("STRAP_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		
		Date dateList[] = getSTRAPFilterDates();
		Date startDate = dateList[0];
		Date endDate = dateList[1];
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		
		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<STRAP_DTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				STRAP_DTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new STRAP_DTO();
					JSONObject eachCell = (JSONObject) dataCells.get(0);
					if (!eachCell.isNull("label"))
						reportRecord.setAccountName(eachCell.getString("label"));
					else
						reportRecord.setAccountName("");
					eachCell = (JSONObject) dataCells.get(1);
					if (!eachCell.isNull("value")) {
						reportRecord.setAE(eachCell.getString("value"));
					}
					else
						reportRecord.setAE("");
					eachCell = (JSONObject) dataCells.get(2);
					if (!eachCell.isNull("value")) {
						reportRecord.setOpportunityName(eachCell.getString("label"));
						reportRecord.setActivityId(eachCell.getString("value"));
							}
					else
						reportRecord.setOpportunityName("");
					
					eachCell = (JSONObject) dataCells.get(3);
					if (!eachCell.isNull("label")) {
						reportRecord.setStageName(eachCell.getString("label"));
					}
					else
						reportRecord.setStageName("");
					eachCell = (JSONObject) dataCells.get(4);
					if (!eachCell.isNull("label")) {
						reportRecord.setMarket(eachCell.getString("label"));
					}
					else
						reportRecord.setMarket("");
					eachCell = (JSONObject) dataCells.get(5);
					if (!eachCell.isNull("value")) {
						reportRecord.setStrapOpiumLink(eachCell.getString("value"));
					}
					else
						reportRecord.setStrapOpiumLink("");
					eachCell = (JSONObject) dataCells.get(6);
					if (!eachCell.isNull("value")) {
						reportRecord.setSP(eachCell.getString("value"));
					}
					else
						reportRecord.setSP("");
					eachCell = (JSONObject) dataCells.get(7);
					if (!eachCell.isNull("value")) {
						reportRecord.setOnsiteSP(eachCell.getString("value"));
					}
					else
						reportRecord.setOnsiteSP("");
					eachCell = (JSONObject) dataCells.get(8);
					if (!eachCell.isNull("value")) {
						reportRecord.setAETeam(eachCell.getString("value"));
					}
					else
						reportRecord.setAETeam("");
					eachCell = (JSONObject) dataCells.get(11);
					if (!eachCell.isNull("value")) {
						reportRecord.setStrapId(eachCell.getString("label"));
					}
					else
						reportRecord.setStrapId("");
					eachCell = (JSONObject) dataCells.get(12);
					if (!eachCell.isNull("value")) {
						try {
							String dateOfExecution = eachCell.getString("value");
							Date dateOfExec = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecution);
							if(startDate.compareTo(dateOfExec) > 0 || endDate.compareTo(dateOfExec) < 0)
								continue;
							reportRecord.setDateOfExecution(eachCell.getString("value"));
						} catch (Exception e) {
							LOGGER.info("Error in dateOfExecution");
							continue;
						}
					}
					else
						reportRecord.setDateOfExecution("");
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
	
	//Added by Vishesh
	@Override
	public List<STRAP_DTO> getSTRAPReportForExpansion(String start, String end){
		LOGGER.info("PesSalesForceServiceImpl.getChampionsAndZZTopReport(): START");
		//Taking instance of this class to run this function here in this class and that to non void returning
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		//Changed Report ID
		//String reportId = "00O5d000007ozZDEAY";
		//Added property in DB and getting ID from DB
		String reportId = propertiesService.getPropertyByName("STRAP_EXPANSION_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		
		Date dateList[] = getSTRAPFilterDates();
		Date startDate = dateList[0];
		Date endDate = dateList[1];
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		
		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<STRAP_DTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				STRAP_DTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new STRAP_DTO();
					
					
					//Get Date of Execution or don't continue
					JSONObject eachCell = (JSONObject) dataCells.get(5);
					if (!eachCell.isNull("value")) {
						try {
							String dateOfExecution = eachCell.getString("value");
							Date dateOfExec = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecution);
							if(startDate.compareTo(dateOfExec) > 0 || endDate.compareTo(dateOfExec) < 0)
								continue;
							reportRecord.setDateOfExecution(eachCell.getString("value"));
						} catch (Exception e) {
							LOGGER.info("Error in dateOfExecution");
							continue;
						}
					}
					else
						reportRecord.setDateOfExecution("");
					
					//Get Account name
					eachCell = (JSONObject) dataCells.get(0);
					if (!eachCell.isNull("label"))
						reportRecord.setAccountName(eachCell.getString("label"));
					else
						reportRecord.setAccountName("");
					
					//Get AE details
					eachCell = (JSONObject) dataCells.get(1);
					if (!eachCell.isNull("value")) {
						reportRecord.setAE(eachCell.getString("value"));
					}
					else
						reportRecord.setAE("");
	
					//Get SP details
					eachCell = (JSONObject) dataCells.get(2);
					if (!eachCell.isNull("value")) {
						reportRecord.setSP(eachCell.getString("value"));
					}
					else
						reportRecord.setSP("");
					//Get Strap ID
					eachCell = (JSONObject) dataCells.get(3);
					if (!eachCell.isNull("value")) {
						reportRecord.setStrapId(eachCell.getString("label"));
					}
					else
						reportRecord.setStrapId("");
					
					//Get Strap Opium Link
					eachCell = (JSONObject) dataCells.get(4);
					if (!eachCell.isNull("value")) {
						reportRecord.setStrapOpiumLink(eachCell.getString("value"));
					}
					else
						reportRecord.setStrapOpiumLink("");
					
					//get market details
					eachCell = (JSONObject) dataCells.get(6);
					if (!eachCell.isNull("label")) {
						reportRecord.setMarket(eachCell.getString("label"));
					}
					else
						reportRecord.setMarket("");
			
					//Adding the values to the report record
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
	
	
	
	
	
	
	@Override
	public List<EmployeeSFDTO> getEmployeeSFReport(){
		LOGGER.info("PesSalesForceServiceImpl.getEmployeeSFReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		//String reportId = "00O1K000009jPtbUAE";
		//Added property in DB and getting ID from DB
		String reportId = propertiesService.getPropertyByName("EMPLOYEESF_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		
		
		HttpGet request = new HttpGet("https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);				
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<EmployeeSFDTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				EmployeeSFDTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new EmployeeSFDTO();
					JSONObject eachCell = (JSONObject) dataCells.get(0);
					if(!eachCell.isNull("label")) {
						reportRecord.setSf18CharacterID(eachCell.getString("label"));
					}
					else
						reportRecord.setSf18CharacterID("");
					eachCell = (JSONObject) dataCells.get(1);
					if(!eachCell.isNull("label")) {
						reportRecord.setUserId(eachCell.getString("label"));
					}
					else
						reportRecord.setUserId("");
					eachCell = (JSONObject) dataCells.get(2);
					if(!eachCell.isNull("label")) {
						reportRecord.setFirstName(eachCell.getString("label"));
					}
					else
						reportRecord.setFirstName("");
					eachCell = (JSONObject) dataCells.get(3);
					if(!eachCell.isNull("label")) {
						reportRecord.setLastName(eachCell.getString("label"));
					}
					else
						reportRecord.setLastName("");
					eachCell = (JSONObject) dataCells.get(4);
					if(!eachCell.isNull("label")) {
						reportRecord.setFullName(eachCell.getString("label"));
					}
					else
						reportRecord.setFullName("");
					eachCell = (JSONObject) dataCells.get(5);
					if(!eachCell.isNull("label")) {
						reportRecord.setAlias(eachCell.getString("label"));
					}
					else
						reportRecord.setAlias("");
					eachCell = (JSONObject) dataCells.get(6);
					if(!eachCell.isNull("label")) {
						reportRecord.setEmail(eachCell.getString("label"));
					}
					else
						reportRecord.setEmail("");
					eachCell = (JSONObject) dataCells.get(7);
					if(!eachCell.isNull("label")) {
						reportRecord.setPodLeadName(eachCell.getString("label"));
					}
					else
						reportRecord.setPodLeadName("");
					eachCell = (JSONObject) dataCells.get(8);
					if(!eachCell.isNull("label")) {
						reportRecord.setPodLead18CharId(eachCell.getString("label"));
					}
					else
						reportRecord.setPodLead18CharId("");
					
					eachCell = (JSONObject) dataCells.get(9);
					if(!eachCell.isNull("label")) {
						reportRecord.setRole(eachCell.getString("label"));
					}
					else
						reportRecord.setRole("");
					eachCell = (JSONObject) dataCells.get(10);
					if(!eachCell.isNull("label")) {
						reportRecord.setProfile(eachCell.getString("label"));
					}
					else
						reportRecord.setProfile("");
					eachCell = (JSONObject) dataCells.get(11);
					if(!eachCell.isNull("label")) {
						reportRecord.setTeam(eachCell.getString("label"));
					}
					else
						reportRecord.setTeam("");
					eachCell = (JSONObject) dataCells.get(12);
					if(!eachCell.isNull("label")) {
						reportRecord.setDepartment(eachCell.getString("label"));
					}
					else
						reportRecord.setDepartment("");
					eachCell = (JSONObject) dataCells.get(13);
					//label key for this not string
					if(!eachCell.isNull("label")) {
						reportRecord.setMarket(eachCell.getString("label"));
					}
					else
						reportRecord.setMarket("");
					eachCell = (JSONObject) dataCells.get(14);
					if(!eachCell.isNull("label")) {
						reportRecord.setActive(eachCell.getString("label"));
					}
					else
						reportRecord.setActive("");
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}
		}
            catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
	
	
	public String compareDates(String stakeholderBuyIn, String budgetApproval, String contracts) {
		try {
	    Date stakeholderBuyInDate = null;
	    Date budgetDate = null;
	    Date contractsDate = null;        
		if(!StringUtils.isEmpty(stakeholderBuyIn))
		   stakeholderBuyInDate = new SimpleDateFormat("yyyy-MM-dd").parse(stakeholderBuyIn);
		if(!StringUtils.isEmpty(budgetApproval))
			budgetDate = new SimpleDateFormat("yyyy-MM-dd").parse(budgetApproval);
		if(!StringUtils.isEmpty(contracts))
			contractsDate = new SimpleDateFormat("yyyy-MM-dd").parse(contracts);
		
		Date max = new Date(1900);
		String maxDate = "";
		if(stakeholderBuyInDate != null && max.compareTo(stakeholderBuyInDate) < 0) {
			max = stakeholderBuyInDate;
			maxDate = stakeholderBuyIn;
		}
		if(budgetDate != null && max.compareTo(budgetDate) < 0) {
			max = budgetDate;
			maxDate = budgetApproval;
		}
		if(contractsDate != null && max.compareTo(contractsDate) < 0) {
		    max = contractsDate;
		    maxDate = contracts;
		}
		return maxDate;		
	}
		catch(Exception e) {
			LOGGER.error("Error in getting dates beyond VA");
		}
		return null;
	}

	@Override
	public List<Demo_Play_DTO> getDEMOReport(String start, String end) {
		LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): START");
		PesSalesForceServiceImpl impl = new PesSalesForceServiceImpl();
		String authToken = impl.getSFAPIAccessToken(null, null, null);
		int timeout = 500;	
		//String reportId = "00O5d000007pIrfEAE";
		//Added property in DB and getting ID from DB
		String reportId = propertiesService.getPropertyByName("DEMO_REPORT_ID").getPropertyValue();
		RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
		.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
        CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
		CloseableHttpResponse response = null;
		
		Date dateList[] = getSTRAPFilterDates();
		Date startDate = dateList[0];
		Date endDate = dateList[1];
		if(start != null) {
			try {
			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(start);
			endDate = new SimpleDateFormat("yyyy-MM-dd").parse(end);
			LOGGER.info("Getting data for date range : " + startDate + " - " + endDate);
			}catch(Exception e) {
				LOGGER.error("Error in getting manual filter dates");
			}
		}
		
		HttpGet request = new HttpGet(
				"https://highradius.my.salesforce.com/services/data/v54.0/analytics/reports/" + reportId);
		request.addHeader("Authorization", "Bearer " + authToken);
		request.addHeader("Content-Type", "application/json");
		JSONObject resp = null;
		List<Demo_Play_DTO> repList = new ArrayList<>();
		try {
			httpClient.execute(request);
			response = httpClient.execute(request);
			String json = EntityUtils.toString(response.getEntity());
			resp = new JSONObject(json);
			if (resp.has("message"))
				LOGGER.info("No data queried - " + resp.getString("message"));
			else {
				JSONObject table = resp.getJSONObject("factMap").getJSONObject("T!T");
				JSONArray rows = table.getJSONArray("rows");
				Demo_Play_DTO reportRecord = null;
				for (int i = 0; i < rows.length(); i++) {
					
					JSONObject row1 = rows.getJSONObject(i);
					JSONArray dataCells = row1.getJSONArray("dataCells");
					reportRecord = new Demo_Play_DTO();
					Date dateOfExecution = null;
					String dateOfExecString = "";
					String stageName = "";
					JSONObject eachCell = (JSONObject) dataCells.get(7);
					if (!eachCell.isNull("label")) {
						stageName = eachCell.getString("label");
						reportRecord.setStageName(eachCell.getString("label"));
					}
					else
						reportRecord.setStageName("");
					eachCell = (JSONObject) dataCells.get(9);
					//skip the entire record if FA is null
					if (eachCell.isNull("value") && (stageName.equals("10 - Closed Lost") || stageName.equals("9 - Closed Won"))) {
						eachCell = (JSONObject) dataCells.get(8);
						if(eachCell.isNull("value"))
							continue;
					}
					else if(eachCell.isNull("value"))
						continue;
					//checking to which step the first jump was made
					eachCell = (JSONObject) dataCells.get(10);
					if (!eachCell.isNull("value") && StringUtils.isEmpty(dateOfExecString)) {
						try {
							dateOfExecString = eachCell.getString("value");
							dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecString);
						} catch (Exception e) {
							LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): Error in VA date fetch");
							continue;
						}
					}
					eachCell = (JSONObject) dataCells.get(11);
					if (!eachCell.isNull("value") && StringUtils.isEmpty(dateOfExecString)) {
						try {
							dateOfExecString = eachCell.getString("value");
							dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecString);
						} catch (Exception e) {
							LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): Error in SB date fetch");
							continue;
						}
					}
					eachCell = (JSONObject) dataCells.get(12);
					if (!eachCell.isNull("value") && StringUtils.isEmpty(dateOfExecString)) {
						try {
							dateOfExecString = eachCell.getString("value");
							dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecString);
						} catch (Exception e) {
							LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): Error in BA date fetch");
							continue;
						}
					}
					eachCell = (JSONObject) dataCells.get(13);
					if (!eachCell.isNull("value") && StringUtils.isEmpty(dateOfExecString)) {
						try {
							dateOfExecString = eachCell.getString("value");
							dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecString);
						} catch (Exception e) {
							LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): Error in Contract date fetch");
							continue;
						}
					}
					eachCell = (JSONObject) dataCells.get(14);
					if (!eachCell.isNull("value") && StringUtils.isEmpty(dateOfExecString)) {
						try {
							dateOfExecString = eachCell.getString("value");
							dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecString);
						} catch (Exception e) {
							LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): Error in Contract date fetch");
							continue;
						}
					}
					eachCell = (JSONObject) dataCells.get(15);
					if (!eachCell.isNull("value") && StringUtils.isEmpty(dateOfExecString) && (stageName.equals("10 - Closed Lost") || stageName.equals("9 - Closed Won"))) {
						try {
							dateOfExecString = eachCell.getString("value");
							dateOfExecution = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfExecString);
						} catch (Exception e) {
							LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): Error in Contract date fetch");
							continue;
						}
					}
					if(dateOfExecution != null) {
						try {
							if(startDate.compareTo(dateOfExecution) > 0 || endDate.compareTo(dateOfExecution) < 0)
								continue;
							reportRecord.setDateOfExecution(dateOfExecString);
						} catch (Exception e) {
							LOGGER.info("PesSalesForceServiceImpl.getDEMOReport(): Error in dateOfExecution");
							continue;
						}
					}
					else 
						continue;
					eachCell = (JSONObject) dataCells.get(3);
					if (!eachCell.isNull("label"))
						reportRecord.setAccountName(eachCell.getString("label"));
					else
						reportRecord.setAccountName("");
					eachCell = (JSONObject) dataCells.get(4);
					if (!eachCell.isNull("value")) {
						reportRecord.setOpportunityName(eachCell.getString("label"));
						reportRecord.setActivityId(eachCell.getString("value"));
							}
					else
						reportRecord.setOpportunityName("");
					eachCell = (JSONObject) dataCells.get(2);
					if (!eachCell.isNull("value")) {
						reportRecord.setAE(eachCell.getString("value"));
					}
					else
						reportRecord.setAE("");	
					eachCell = (JSONObject) dataCells.get(0);
					if (!eachCell.isNull("label")) {
						reportRecord.setMarket(eachCell.getString("label"));
					}
					else
						reportRecord.setMarket("");
					eachCell = (JSONObject) dataCells.get(1);
					if (!eachCell.isNull("value")) {
						reportRecord.setAETeam(eachCell.getString("value"));
					}
					else
						reportRecord.setAETeam("");
					eachCell = (JSONObject) dataCells.get(7);
					if (!eachCell.isNull("label")) {
						reportRecord.setStageName(eachCell.getString("label"));
					}
					else
						reportRecord.setStageName("");
					eachCell = (JSONObject) dataCells.get(5);
					if (!eachCell.isNull("value")) {
						reportRecord.setSP(eachCell.getString("value"));
					}
					else
						reportRecord.setSP("");
					eachCell = (JSONObject) dataCells.get(6);
					if (!eachCell.isNull("value")) {
						reportRecord.setOnsiteSP(eachCell.getString("value"));
					}
					else
						reportRecord.setOnsiteSP("");
					repList.add(reportRecord);
				}
				
				LOGGER.info("No. of records queried - " + repList.size());
			}

		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return repList;
	}
}
