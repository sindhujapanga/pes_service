package com.highradius.pes.service.impl;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.json.simple.JSONObject;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.highradius.pes.dto.CPR_SIHDTO;
import com.highradius.pes.dto.ChampionsnZZTopDTO;
import com.highradius.pes.dto.Demo_Play_DTO;
import com.highradius.pes.dto.DiscoveryCallDTO;
import com.highradius.pes.dto.MovePlayDTO;
import com.highradius.pes.dto.OTCWebResearchDTO;
import com.highradius.pes.dto.PesStatusDTO;
import com.highradius.pes.dto.STRAP_DTO;
import com.highradius.pes.dto.SalesPipelineOTCDTO;
import com.highradius.pes.dto.ScoringDTO;
import com.highradius.pes.dto.ScoringGridSearchDTO;
import com.highradius.pes.dto.ScoringSearchDTO;
import com.highradius.pes.dto.ScoringSearchResultsDTO;
import com.highradius.pes.dto.PlayStatusDTO;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.FunctionalRole;
import com.highradius.pes.model.MapFieldOptions;
import com.highradius.pes.model.MapPlayFields;
import com.highradius.pes.model.MapPlayRoles;
import com.highradius.pes.model.Market;
import com.highradius.pes.model.Play;
import com.highradius.pes.model.Team;
import com.highradius.pes.model.TxnPlayExecutionData;
import com.highradius.pes.model.TxnPlayExecutionFeedback;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FieldRepository;
import com.highradius.pes.repository.FunctionalRoleRepository;
import com.highradius.pes.repository.MapFieldOptionsRepository;
import com.highradius.pes.repository.MapPlayFieldsRepository;
import com.highradius.pes.repository.MapPlayRolesRepository;
import com.highradius.pes.repository.MarketRepository;
import com.highradius.pes.repository.PlayRepository;
import com.highradius.pes.repository.TeamRepository;
import com.highradius.pes.repository.TxnPlayExecutionDataRepository;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;
import com.highradius.pes.service.PesSalesForceService;
import com.highradius.pes.service.PesSalesSFDCService;
import com.highradius.pes.service.PesScoringService;
import com.highradius.pes.util.EmailUtil;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.PesConstants;
import com.highradius.pes.util.PesGsheetUtil;
import com.highradius.pes.util.PesPropertiesUtil;

@Service
@Transactional
/**
 * Service class for everything related to scoring in PES.Assign, update, add,
 * fetch and delete.
 *
 *
 */
public class PesScoringServiceImpl implements PesScoringService {

	@Autowired
	TxnPlayExecutionDataRepository txnPlayExecDataRepository;

	@Autowired
	TxnPlayExecutionsRepository txnPlayExecRepository;

	@Autowired
	FunctionalRoleRepository functionalRoleRepository;

	@Autowired
	PlayRepository playRepository;

	@Autowired
	MarketRepository marketRepository;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	FieldRepository fieldRepository;

	@Autowired
	TeamRepository teamRepository;

	@Autowired
	PesSalesForceService pesSalesForceService;
	
	@Autowired
	PesSalesSFDCService pesSalesSFDCService;

	@Autowired
	MapPlayFieldsRepository mapPlayFieldsRepository;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	MapPlayRolesRepository mapPlayRolesRepository;

	@Autowired
	MapFieldOptionsRepository fieldOptionsRepo;

	@Autowired
	PesGsheetUtil gsheetUtil;

	@Autowired
	MarketRepository marketRepo;

	@Autowired
	TeamRepository teamRepo;

	@Autowired
	PesPropertiesUtil propertiesUtil;

	private static final Logger LOGGER = LogManager.getLogger(PesScoringServiceImpl.class);

	@Override
	/**
	 * Assigns records into the system. Used in all types of transaction creation in
	 * the system. General for all type of plays
	 */
	public GenericResult assignPlayExecForScoring(ScoringDTO scoringDto) {
		LOGGER.info("PesScoringServiceImpl.assignPlayExecForScoring() : START");
		try {
			// fetching all the keys and values from the DTO
			String aeId = scoringDto.getAeId();
			String nameOfProspect = scoringDto.getNameOfProspect();
			String assignedToPesAgentId = scoringDto.getAssignedToPesAgentId();
			String assignedByPesLeadId = scoringDto.getAssignedByPesLeadId();
			Long playId = Long.parseLong(scoringDto.getPlayId());
			String sfdcStatus = scoringDto.getSfdcStatus();
			String spId = scoringDto.getSpId();
			String ftaId = scoringDto.getFtaId();
			String dtaId = scoringDto.getDtaId();
			String dsaId = scoringDto.getDsaId();
			String onsiteSpId = scoringDto.getOnSiteSpId();
			String teamId = scoringDto.getTeamId();
			String marketId = scoringDto.getMarketId();
			String createdBy = scoringDto.getCreatedBy();
			String podLeadId = scoringDto.getPodLeadId();
			String scoringFor = scoringDto.getScoringFor();
			String activityId = scoringDto.getActivityId();
			Calendar cal = Calendar.getInstance();
			java.util.Date createdDate = cal.getTime();
			String comments = scoringDto.getPesComments();
			String docLink = scoringDto.getDocLink();
			java.util.Date submittedDate = cal.getTime();

			List<Long> empIds = new ArrayList<Long>();
			if (!StringUtils.isEmpty(aeId)) {
				empIds.add(Long.parseLong(aeId));
			}
			if (!StringUtils.isEmpty(assignedToPesAgentId)) {
				empIds.add(Long.parseLong(assignedToPesAgentId));
			}
			if (!StringUtils.isEmpty(spId)) {
				empIds.add(Long.parseLong(spId));
			}
			if (!StringUtils.isEmpty(ftaId)) {
				empIds.add(Long.parseLong(ftaId));
			}
			if (!StringUtils.isEmpty(dtaId)) {
				empIds.add(Long.parseLong(dtaId));
			}
			if (!StringUtils.isEmpty(dsaId)) {
				empIds.add(Long.parseLong(dsaId));
			}
			if (!StringUtils.isEmpty(onsiteSpId)) {
				empIds.add(Long.parseLong(onsiteSpId));
			}
			if (!StringUtils.isEmpty(assignedByPesLeadId)) {
				empIds.add(Long.parseLong(assignedByPesLeadId));
			}
			if (!StringUtils.isEmpty(podLeadId)) {
				empIds.add(Long.parseLong(podLeadId));
			}
			if (!StringUtils.isEmpty(scoringFor)) {
				empIds.add(Long.parseLong(scoringFor));
			}

			List<Employee> sellerList = employeeRepository.findEmployeeByIds(empIds);
			Map<Long, Employee> idEmpMap = new HashMap<Long, Employee>();
			for (Employee sellerEmp : sellerList) {
				idEmpMap.put(sellerEmp.getId(), sellerEmp);
			}

			// Getting the play specific fields from the json
			Map<String, String> playFields = scoringDto.getPlayFields();
			List<TxnPlayExecutionData> txnPlayExecDataList = new ArrayList<>();
			TxnPlayExecutions txnPlayExecObj = new TxnPlayExecutions();
			// checking for all the non compulsory inputs
			if (!StringUtils.isEmpty(scoringDto.getDateOfExecution())) {
				LocalDate date = LocalDate.parse(scoringDto.getDateOfExecution(),
						DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				Date dateOfExecution = Date.valueOf(date);
				txnPlayExecObj.setDateOfExecution(dateOfExecution);
			}
			if (!StringUtils.isEmpty(aeId)) {
				Employee emp = idEmpMap.get(Long.parseLong(aeId)); // employeeRepository.getById(Long.parseLong(aeId));
				txnPlayExecObj.setAe(emp);
			}
			txnPlayExecObj.setNameOfProspect(nameOfProspect);
			if (!StringUtils.isEmpty(assignedToPesAgentId)) {
				Employee emp = idEmpMap.get(Long.parseLong(assignedToPesAgentId)); // employeeRepository.getById(Long.parseLong(assignedToPesAgentId));
				txnPlayExecObj.setAssignedToPesAgent(emp);
			}
			Play ply = playRepository.getById(playId);
			txnPlayExecObj.setPlay(ply);
			txnPlayExecObj.setSfdcStatus(sfdcStatus);
			if (!StringUtils.isEmpty(spId)) {
				Employee emp = idEmpMap.get(Long.parseLong(spId)); // employeeRepository.getById(Long.parseLong(spId));
				txnPlayExecObj.setSp(emp);
			}
			if (!StringUtils.isEmpty(ftaId)) {
				Employee emp = idEmpMap.get(Long.parseLong(ftaId)); // employeeRepository.getById(Long.parseLong(ftaId));
				txnPlayExecObj.setFta(emp);
			}
			if (!StringUtils.isEmpty(onsiteSpId)) {
				Employee emp = idEmpMap.get(Long.parseLong(onsiteSpId)); // employeeRepository.getById(Long.parseLong(onsiteSpId));
				txnPlayExecObj.setOnsiteSp(emp);
			}
			if (!StringUtils.isEmpty(dtaId)) {
				Employee emp = idEmpMap.get(Long.parseLong(dtaId)); // employeeRepository.getById(Long.parseLong(onsiteSpId));
				txnPlayExecObj.setDta(emp);
			}
			if (!StringUtils.isEmpty(dsaId)) {
				Employee emp = idEmpMap.get(Long.parseLong(dsaId)); // employeeRepository.getById(Long.parseLong(onsiteSpId));
				txnPlayExecObj.setDsa(emp);
			}
			if (!StringUtils.isEmpty(marketId)) {
				Market market = marketRepository.getById(Long.parseLong(marketId));
				txnPlayExecObj.setMarket(market);
			}
			if (!StringUtils.isEmpty(teamId)) {
				Team team = teamRepository.getById(Long.parseLong(teamId));
				txnPlayExecObj.setTeam(team);
			}
			if (!StringUtils.isEmpty(assignedByPesLeadId)) {
				Employee emp = idEmpMap.get(Long.parseLong(assignedByPesLeadId)); // employeeRepository.getById(Long.parseLong(assignedByPesLeadId));
				txnPlayExecObj.setAssignedByPesLead(emp);
				txnPlayExecObj.setReviewedBy(emp);
			}

			// can be changed when we get Mapping for should be scored for
			if (!StringUtils.isEmpty(podLeadId)) {
				Employee emp = idEmpMap.get(Long.parseLong(podLeadId)); // employeeRepository.getById(Long.parseLong(podLeadId));
				txnPlayExecObj.setPodLead(emp);
			}
			if (!StringUtils.isEmpty(scoringFor)) {
				Employee emp = idEmpMap.get(Long.parseLong(scoringFor)); // employeeRepository.getById(Long.parseLong(scoringFor));
				txnPlayExecObj.setScoringFor(emp);
			}
			LOGGER.info("PesScoringServiceImpl.assignPlayExecForScoring() :Checked for null values");

			txnPlayExecObj.setDocLink(docLink);
			txnPlayExecObj.setActivityId(activityId);

			// Creating the txnPlayExecutions object first.
			txnPlayExecRepository.save(txnPlayExecObj);

			for (String key : playFields.keySet()) {
				// Creating object for TxnPlayExecutionData child of TransactionPlaysExecution
				TxnPlayExecutionData txnPlayExecData = new TxnPlayExecutionData();
				txnPlayExecData.setFieldId(Long.parseLong(key));
				// Since the object of txnPlayExecutions is already created we can fetch its id.
				txnPlayExecData.setTxnPlayExecutionId(txnPlayExecObj.getId());
				txnPlayExecData.setValue(playFields.get(key));
				txnPlayExecDataList.add(txnPlayExecData);
			}
			// storing TxnPlayExecutionData list into the txnPlayExecObj
			txnPlayExecObj.setTxnPlayExecutionData(txnPlayExecDataList);
			// updating the txnPlayExecObj so that the txnPlayExecData objects can get saved
			txnPlayExecObj.setCreatedBy(createdBy);
			txnPlayExecObj.setCreatedDate(createdDate);
			txnPlayExecObj.setPesComments(comments);
			txnPlayExecObj.setSubmittedDate(submittedDate);
			if (StringUtils.isEmpty(scoringDto.getPesStatus()))
				txnPlayExecObj.setPesStatus(PesConstants.ASSIGNED);
			else if (scoringDto.getPesStatus().equals(PesConstants.NEW))
				txnPlayExecObj.setPesStatus(scoringDto.getPesStatus());
			txnPlayExecRepository.save(txnPlayExecObj);
			GenericResult result = new GenericResult(true, "The record was saved");
			result.setData(txnPlayExecObj);
			LOGGER.info("PesScoringServiceImpl.assignPlayExecForScoring() : END");
			return result;
		} catch (Exception e) {
			LOGGER.error("Exception while creating txnPlayExecutionRepository Record: " + e.getMessage() + "::" + e);
			e.printStackTrace();
			GenericResult result = new GenericResult(false, "The record could not be saved");
			result.setStatus(PesConstants.FAIL);
			return result;
		}
	}

	// Function to create Dummy Entries for STRAP plays
	@Override
	public GenericResult addDummyEntries(ScoringDTO scoringDto) {

		LOGGER.info("PesScoringServiceImpl.assignPlayExecForScoring() : START");
		// Get Values from DTO

		try {
			Long playId = Long.parseLong(scoringDto.getPlayId());
			String aeId = scoringDto.getAeId();
			String nameOfProspect = scoringDto.getNameOfProspect();
			String assignedToPesAgentId = scoringDto.getAssignedToPesAgentId();
			String spId = scoringDto.getSpId();
			String dtaId = scoringDto.getDtaId();
			String dsaId = scoringDto.getDsaId();
			String onsiteSpId = scoringDto.getOnSiteSpId();
			// String podLeadId = scoringDto.getPodLeadId();
			String teamId = scoringDto.getTeamId();
			String marketId = scoringDto.getMarketId();
			String noOfDummy = scoringDto.getNoOfDummy();
			String feedback = scoringDto.getPesComments();
			String scoringForId = scoringDto.getScoringFor();
			String createdBy = scoringDto.getCreatedBy();
			String createdDateString = scoringDto.getCreatedDate();
			Date createdDate = Date.valueOf(LocalDate.parse(createdDateString,
					DateTimeFormatter.ofPattern("yyyy-MM-dd")));
			java.util.Date submittedDate = Calendar.getInstance().getTime();


			int dummyLength = Integer.parseInt(noOfDummy);

			// Making Emp vs EmpID Map for ae/sp etc
			List<Long> empIds = new ArrayList<Long>();
			if (!StringUtils.isEmpty(aeId)) {
				empIds.add(Long.parseLong(aeId));
			}
			if (!StringUtils.isEmpty(assignedToPesAgentId)) {
				empIds.add(Long.parseLong(assignedToPesAgentId));
			}
			if (!StringUtils.isEmpty(spId)) {
				empIds.add(Long.parseLong(spId));
			}
			if (!StringUtils.isEmpty(dtaId)) {
				empIds.add(Long.parseLong(dtaId));
			}
			if (!StringUtils.isEmpty(dsaId)) {
				empIds.add(Long.parseLong(dsaId));
			}
			if (!StringUtils.isEmpty(onsiteSpId)) {
				empIds.add(Long.parseLong(onsiteSpId));
			}
//			if (!StringUtils.isEmpty(podLeadId)) {
//				empIds.add(Long.parseLong(podLeadId));
//			}

			List<Employee> sellerList = employeeRepository.findEmployeeByIds(empIds);
			Map<Long, Employee> idEmpMap = new HashMap<Long, Employee>();
			for (Employee sellerEmp : sellerList) {
				idEmpMap.put(sellerEmp.getId(), sellerEmp);
			}

			// Make List to add all the results
			List<TxnPlayExecutions> txnPlayExecDataList = new ArrayList<>();

			// Iterate to the number of dummy entries and add to list
			for (int i = 0; i < dummyLength; i++) {
				// New Object of TxnExecutions
				TxnPlayExecutions txnPlayExecObj = new TxnPlayExecutions();

				// Checking for empty/null values and adding values to newly created obj
				if (!StringUtils.isEmpty(scoringDto.getDateOfExecution())) {
					LocalDate date = LocalDate.parse(scoringDto.getDateOfExecution(),
							DateTimeFormatter.ofPattern("yyyy-MM-dd"));
					Date dateOfExecution = Date.valueOf(date);
					txnPlayExecObj.setDateOfExecution(dateOfExecution);
				}
				// Check for AEID and get AE name from map and set it
				if (!StringUtils.isEmpty(aeId)) {
					Employee emp = idEmpMap.get(Long.parseLong(aeId));
					txnPlayExecObj.setAe(emp);
				}

				txnPlayExecObj.setNameOfProspect(nameOfProspect);

				if (!StringUtils.isEmpty(assignedToPesAgentId)) {
					Employee emp = idEmpMap.get(Long.parseLong(assignedToPesAgentId));
					txnPlayExecObj.setAssignedToPesAgent(emp);
				}

				Play ply = playRepository.getById(playId);
				txnPlayExecObj.setPlay(ply);

				if (!StringUtils.isEmpty(onsiteSpId)) {
					Employee emp = idEmpMap.get(Long.parseLong(onsiteSpId));
					txnPlayExecObj.setOnsiteSp(emp);
				}
				if (!StringUtils.isEmpty(spId)) {
					Employee emp = idEmpMap.get(Long.parseLong(spId));
					txnPlayExecObj.setSp(emp);
				}
				if (!StringUtils.isEmpty(dtaId)) {
					Employee emp = idEmpMap.get(Long.parseLong(dtaId));
					txnPlayExecObj.setDta(emp);
				}
				if (!StringUtils.isEmpty(dsaId)) {
					Employee emp = idEmpMap.get(Long.parseLong(dsaId));
					txnPlayExecObj.setDsa(emp);
				}
				if (!StringUtils.isEmpty(scoringForId)) {
					Employee emp = idEmpMap.get(Long.parseLong(scoringForId));
					txnPlayExecObj.setScoringFor(emp);
					if (emp.getPodLeadId() != null) {
						Employee podLead = employeeRepository.getById(emp.getPodLeadId());
						txnPlayExecObj.setPodLead(podLead);
					}
				}
				if (!StringUtils.isEmpty(marketId)) {
					Market market = marketRepository.getById(Long.parseLong(marketId));
					txnPlayExecObj.setMarket(market);
				}
				if (!StringUtils.isEmpty(teamId)) {
					Team team = teamRepository.getById(Long.parseLong(teamId));
					txnPlayExecObj.setTeam(team);
				}

				txnPlayExecObj.setCreatedBy(createdBy);
				txnPlayExecObj.setCreatedDate(createdDate);
				// Set the feedback for Grid , this is not for the edit play feedback grid
				txnPlayExecObj.setPesFeedback(feedback);
				txnPlayExecObj.setSubmittedDate(submittedDate);
				// Setting PES Status to Push to Reviewed by PES
				if (StringUtils.isEmpty(scoringDto.getPesStatus()))
					txnPlayExecObj.setPesStatus(PesConstants.PUSH_TO_POD_LEAD);
				txnPlayExecObj.setPesScore(PesConstants.RED);
				txnPlayExecObj.setPodLeadScore(PesConstants.RED);
				txnPlayExecDataList.add(txnPlayExecObj);
			}
			// First save all the Txns to get the Txn ID so that we can then add comments
			txnPlayExecRepository.saveAll(txnPlayExecDataList);
			// Adding new feedback data

			// Template for all feedbacks
			TxnPlayExecutionFeedback txnPlayFeedback = new TxnPlayExecutionFeedback();
			txnPlayFeedback.setPesFeedback(feedback);

			txnPlayFeedback.setStatus(PesConstants.ACCEPTED);
			for (TxnPlayExecutions txn : txnPlayExecDataList) {
				List<TxnPlayExecutionFeedback> txnPlayFeedbackList = new ArrayList<>();
				Long txnPlayExecutionId = txn.getId();
				// for new feedbacks
				TxnPlayExecutionFeedback newFeedback = new TxnPlayExecutionFeedback();
				// creating copy of feedback obj so that data is copied to all the values not
				// just last
				newFeedback.copy(txnPlayFeedback);
				newFeedback.setTxnPlayExecutionId(txnPlayExecutionId);
				txnPlayFeedbackList.add(newFeedback);
				// Add the feedback list to txn
				txn.setTxnPlayExecutionFeedback(txnPlayFeedbackList);
			}
			// Finally save the Feedback for all the result txnx
			txnPlayExecRepository.saveAll(txnPlayExecDataList);

			GenericResult result = new GenericResult(true, "The record was saved");
			LOGGER.info("PesScoringServiceImpl.addDuplicatEntries() : END");
			return result;

		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.addDuplicatEntries(): Exception while creating dummy records: "
					+ e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult(false, "The record could not be saved");
			result.setStatus(PesConstants.FAIL);
			return result;
		}
	}

	/*
	 * Used for getting the searched data according to the data provided from
	 * frontend using scoringSearchDTO object
	 */
	@SuppressWarnings("unchecked")
	@Override
	public GenericResult searchPlayExecutions(ScoringSearchDTO scoringSearchDto, JSONObject pageOptions,
			ScoringGridSearchDTO scoringGridSearchDTO) {
		LOGGER.info("PesScoringServiceImpl.searchPlayExecutions() : START");
		List<String> gridObj = new ArrayList<String>();
		gridObj.add("play");
		gridObj.add("team");
		gridObj.add("market");

		List<String> empGridObj = new ArrayList<String>();
		empGridObj.add("sp");
		empGridObj.add("ae");
		empGridObj.add("fta");
		empGridObj.add("dsa");
		empGridObj.add("dta");
		empGridObj.add("onsiteSp");
		empGridObj.add("scoringFor");
		empGridObj.add("reviewedBy");
		empGridObj.add("assignedToPesAgent");
		empGridObj.add("podLead");

		GenericResult result = new GenericResult();
		try {
			Integer limit = (Integer) pageOptions.get("page");
			Integer offset = (Integer) pageOptions.get("pageSize");
			String sortingField = (String) pageOptions.get("field");
			String sortType = (String) pageOptions.get("sort");

			if (gridObj.contains(sortingField))
				sortingField += ".name";
			else if (empGridObj.contains(sortingField))
				sortingField += ".fullName";
			Sort sortModel = StringUtils.isNotEmpty(sortingField)
					? (sortType.equals("asc") ? Sort.by(sortingField).ascending() : Sort.by(sortingField).descending())
					: Sort.by("id").ascending();
			Pageable pageable = PageRequest.of(limit, offset, sortModel);
			Page<TxnPlayExecutions> txnPlayList = txnPlayExecRepository.findAll(new Specification<TxnPlayExecutions>() {

				private static final long serialVersionUID = 1L;

				@Override
				public Predicate toPredicate(Root<TxnPlayExecutions> root, CriteriaQuery<?> query,
						CriteriaBuilder criteriaBuilder) {
					List<Predicate> predicates = new ArrayList<>();

					// Variables from scoringSearchDTO object
					String playIds[] = scoringSearchDto.getPlayIds();
					String aeIds[] = scoringSearchDto.getAeIds();
					String nameOfProspect = scoringSearchDto.getNameOfProspect();
					String assignedToPesAgentId = scoringSearchDto.getAssignedToPesAgentId();
					String podLeadId = scoringSearchDto.getPodLeadId();
					String startDateString = scoringSearchDto.getExecutionStartDate();
					String endDateString = scoringSearchDto.getExecutionEndDate();
					String createdStartDateString = scoringSearchDto.getCreatedStartDate();
					String createdEndDateString = scoringSearchDto.getCreatedEndDate();
					String spIds[] = scoringSearchDto.getSpIds();
					String dtaIds[] = scoringSearchDto.getDtaIds();
					String dsaIds[] = scoringSearchDto.getDsaIds();
					String onsiteSpIds[] = scoringSearchDto.getOnsiteSpIds();
					String scoringForIds[] = scoringSearchDto.getScoringForIds();
					String teamIds[] = scoringSearchDto.getTeamIds();
					String marketIds[] = scoringSearchDto.getMarketIds();
					String sfdcStatus[] = scoringSearchDto.getSfdcStatus();
					String pesStatus = scoringSearchDto.getPesStatus();
					String podLeadScore = scoringSearchDto.getPodLeadRating();
					String pesScore = scoringSearchDto.getPesRating();
					String isOverridden = scoringSearchDto.getIsOverridden();
					String reviewedBy = scoringSearchDto.getReviewer();
					Date startDate = null;
					Date endDate = null;
					Date createdStartDate = null;
					Date createdEndDate = null;

					// Variable for ScoringGridSearchDTO
					Boolean gridIsStarred = scoringGridSearchDTO.getIsStarred();
					String gridPlayName = scoringGridSearchDTO.getPlay();
					String gridNameOfProspect = scoringGridSearchDTO.getNameOfProspect();
					String gridMarket = scoringGridSearchDTO.getMarket();
					String gridTeam = scoringGridSearchDTO.getTeam();
					String gridCreatedDate = scoringGridSearchDTO.getCreatedDate();
					String girdDateOfExecution = scoringGridSearchDTO.getDateOfExecution();
					String gridSfdcStatus = scoringGridSearchDTO.getSfdcStatus();
					String gridPesStatus = scoringGridSearchDTO.getPesStatus();
					String gridAssignedToPesAgent = scoringGridSearchDTO.getAssignedToPesAgent();
					String gridReviewedBy = scoringGridSearchDTO.getReviewedBy();
					String gridScoringFor = scoringGridSearchDTO.getScoringFor();
					String gridOverriden = scoringGridSearchDTO.getOverriden();
					String gridSp = scoringGridSearchDTO.getSp();
					String gridAe = scoringGridSearchDTO.getAe();
					String gridFta = scoringGridSearchDTO.getFta();
					String gridOnsiteSp = scoringGridSearchDTO.getOnsiteSp();
					String gridDta = scoringGridSearchDTO.getDta();
					String gridDsa = scoringGridSearchDTO.getDsa();
					String gridPodLead = scoringGridSearchDTO.getPodLead();
					String gridPesScore = scoringGridSearchDTO.getPesScore();
					String gridValidOverride = scoringGridSearchDTO.getValid_override();
					String gridRationale = scoringGridSearchDTO.getRationale();
					String gridManagerComments = scoringGridSearchDTO.getManager_comments();
					String gridRatingAccuracy = scoringGridSearchDTO.getRatingAccuracy();
					String gridFeedbackAccuracy = scoringGridSearchDTO.getFeedbackAccuracy();
					String gridOverallPesEffectiveness = scoringGridSearchDTO.getOverallPesEffectiveness();
					String gridPesComments = scoringGridSearchDTO.getPesComments();
					String gridPodLeadScore = scoringGridSearchDTO.getPodLeadScore();
					String gridDocLink = scoringGridSearchDTO.getDocLink();
					String gridPesFeedback = scoringGridSearchDTO.getPesFeedback();
					String gridPodLeadFeedback = scoringGridSearchDTO.getPodLeadFeedback();

					if (!StringUtils.isEmpty(gridPlayName)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("play").get("name"), "%" + gridPlayName + "%")));
					}

					if (gridIsStarred != false) {
						predicates
								.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("isStarred"), gridIsStarred)));
					}

					if (!StringUtils.isEmpty(gridNameOfProspect)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("nameOfProspect"), "%" + gridNameOfProspect + "%")));
					}

					if (!StringUtils.isEmpty(gridMarket)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("market").get("name"), "%" + gridMarket + "%")));
					}

					if (!StringUtils.isEmpty(gridTeam)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("team").get("name"), "%" + gridTeam + "%")));
					}

					if (!StringUtils.isEmpty(gridSfdcStatus)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("sfdcStatus"), "%" + gridSfdcStatus + "%")));
					}

					if (!StringUtils.isEmpty(gridPesStatus)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("pesStatus"), "%" + gridPesStatus + "%")));
					}

					if (!StringUtils.isEmpty(gridAssignedToPesAgent)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.like(
								root.get("assignedToPesAgent").get("fullName"), "%" + gridAssignedToPesAgent + "%")));
					}

					if (!StringUtils.isEmpty(gridReviewedBy)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.like(root.get("reviewedBy").get("fullName"),
								"%" + gridReviewedBy + "%")));
					}

					if (!StringUtils.isEmpty(gridScoringFor)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.like(root.get("scoringFor").get("fullName"),
								"%" + gridScoringFor + "%")));
					}

					if (!StringUtils.isEmpty(gridOverriden)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("overriden"), "%" + gridOverriden + "%")));
					}

					if (!StringUtils.isEmpty(gridSp)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("sp").get("fullName"), "%" + gridSp + "%")));
					}

					if (!StringUtils.isEmpty(gridAe)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("ae").get("fullName"), "%" + gridAe + "%")));
					}

					if (!StringUtils.isEmpty(gridFta)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("fta").get("fullName"), "%" + gridFta + "%")));
					}

					if (!StringUtils.isEmpty(gridOnsiteSp)) {
						predicates.add(criteriaBuilder.and(
								criteriaBuilder.like(root.get("onsiteSp").get("fullName"), "%" + gridOnsiteSp + "%")));
					}

					if (!StringUtils.isEmpty(gridDta)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("dta").get("fullName"), "%" + gridDta + "%")));
					}

					if (!StringUtils.isEmpty(gridDsa)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("dsa").get("fullName"), "%" + gridDsa + "%")));
					}

					if (!StringUtils.isEmpty(gridPodLead)) {
						predicates.add(criteriaBuilder.and(
								criteriaBuilder.like(root.get("podLead").get("fullName"), "%" + gridPodLead + "%")));
					}

					if (!StringUtils.isEmpty(gridPesScore)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("pesScore"), "%" + gridPesScore + "%")));
					}

					if (!StringUtils.isEmpty(gridValidOverride)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("valid_override"), "%" + gridValidOverride + "%")));
					}

					if (!StringUtils.isEmpty(gridRationale)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("rationale"), "%" + gridRationale + "%")));
					}

					if (!StringUtils.isEmpty(gridManagerComments)) {
						predicates.add(criteriaBuilder.and(
								criteriaBuilder.like(root.get("manager_comments"), "%" + gridManagerComments + "%")));
					}

					if (!StringUtils.isEmpty(gridRatingAccuracy)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("ratingAccuracy"), "%" + gridRatingAccuracy + "%")));
					}

					if (!StringUtils.isEmpty(gridFeedbackAccuracy)) {
						predicates.add(criteriaBuilder.and(
								criteriaBuilder.like(root.get("feedbackAccuracy"), "%" + gridFeedbackAccuracy + "%")));
					}

					if (!StringUtils.isEmpty(gridOverallPesEffectiveness)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.like(root.get("overallPesEffectiveness"),
								"%" + gridOverallPesEffectiveness + "%")));
					}

					if (!StringUtils.isEmpty(gridPodLeadScore)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("podLeadScore"), "%" + gridPodLeadScore + "%")));
					}

					if (!StringUtils.isEmpty(gridPesComments)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("pesComments"), "%" + gridPesComments + "%")));
					}

					if (!StringUtils.isEmpty(gridDocLink)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("docLink"), "%" + gridDocLink + "%")));
					}

					if (!StringUtils.isEmpty(gridPesFeedback)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.like(root.get("pesFeedback"), "%" + gridPesFeedback + "%")));
					}

					if (!StringUtils.isEmpty(gridPodLeadFeedback)) {
						predicates.add(criteriaBuilder.and(
								criteriaBuilder.like(root.get("podLeadFeedback"), "%" + gridPodLeadFeedback + "%")));
					}

					// Converting start date from string to sql type
					if (!StringUtils.isEmpty(startDateString)) {
						LocalDate date = LocalDate.parse(startDateString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						startDate = Date.valueOf(date);
					}
					// same for end date
					if (!StringUtils.isEmpty(endDateString)) {
						LocalDate date = LocalDate.parse(endDateString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						endDate = Date.valueOf(date);
					}

					if (!StringUtils.isEmpty(createdStartDateString)) {
						LocalDate date = LocalDate.parse(createdStartDateString,
								DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						createdStartDate = Date.valueOf(date);
					}

					if (!StringUtils.isEmpty(createdEndDateString)) {
						LocalDate date = LocalDate.parse(createdEndDateString,
								DateTimeFormatter.ofPattern("yyyy-MM-dd"));
						createdEndDate = Date.valueOf(date);
					}
					if (playIds != null && playIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("play").get("id"));
						List<Long> playIdList = Arrays.stream(playIds).map(Long::parseLong)
								.collect(Collectors.toList());
						in.value(playIdList);
						predicates.add(in);
					}
					if (aeIds != null && aeIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("ae").get("id"));
						List<Long> aeIdList = Arrays.stream(aeIds).map(Long::parseLong).collect(Collectors.toList());
						in.value(aeIdList);
						predicates.add(in);
					}
					if (onsiteSpIds != null && onsiteSpIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("onsiteSp").get("id"));
						List<Long> onsiteSpIdList = Arrays.stream(onsiteSpIds).map(Long::parseLong)
								.collect(Collectors.toList());
						in.value(onsiteSpIdList);
						predicates.add(in);
					}
					if (spIds != null && spIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("sp").get("id"));
						List<Long> spIdList = Arrays.stream(spIds).map(Long::parseLong).collect(Collectors.toList());
						in.value(spIdList);
						predicates.add(in);
					}
					if (dtaIds != null && dtaIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("dta").get("id"));
						List<Long> dtaIdList = Arrays.stream(dtaIds).map(Long::parseLong).collect(Collectors.toList());
						in.value(dtaIdList);
						predicates.add(in);
					}
					if (dsaIds != null && dsaIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("dsa").get("id"));
						List<Long> dsaIdList = Arrays.stream(dsaIds).map(Long::parseLong).collect(Collectors.toList());
						in.value(dsaIdList);
						predicates.add(in);
					}
					if (scoringForIds != null && scoringForIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("scoringFor").get("id"));
						List<Long> scoringForList = Arrays.stream(scoringForIds).map(Long::parseLong)
								.collect(Collectors.toList());
						in.value(scoringForList);
						predicates.add(in);
					}

					if (teamIds != null && teamIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("team").get("id"));
						List<Long> teamIdList = Arrays.stream(teamIds).map(Long::parseLong)
								.collect(Collectors.toList());
						in.value(teamIdList);
//						predicates.add(criteriaBuilder.or(in,criteriaBuilder.isNull(root.get("team").get("id"))));
						predicates.add(in);
					}
					if (marketIds != null && marketIds.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("market").get("id"));
						List<Long> marketIdList = Arrays.stream(marketIds).map(Long::parseLong)
								.collect(Collectors.toList());
						in.value(marketIdList);
//						predicates.add(criteriaBuilder.or(in,criteriaBuilder.isNull(root.get("market").get("id"))));
						predicates.add(in);
					}
					if (sfdcStatus != null && sfdcStatus.length != 0) {
						In<Object> in = criteriaBuilder.in(root.get("sfdcStatus"));
						List<String> sfdcStatusList = Arrays.asList(sfdcStatus);
						in.value(sfdcStatusList);
						predicates.add(in);
					}
					if (!StringUtils.isEmpty(podLeadId)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.equal(root.get("podLead").get("id"), Long.parseLong(podLeadId))));
					}
					if (!StringUtils.isEmpty(nameOfProspect)) {
						predicates.add(
								criteriaBuilder.and(criteriaBuilder.equal(root.get("nameOfProspect"), nameOfProspect)));
					}
					if (!StringUtils.isEmpty(assignedToPesAgentId)) {
						predicates
								.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("assignedToPesAgent").get("id"),
										Long.parseLong(assignedToPesAgentId))));
					}
					if (!StringUtils.isEmpty(pesStatus)) {
						if (!pesStatus.equals(PesConstants.COMPLETED))
							predicates.add(criteriaBuilder
									.and(criteriaBuilder.notEqual(root.get("pesStatus"), PesConstants.COMPLETED)));
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("pesStatus"), pesStatus)));
					}

					if (!StringUtils.isEmpty(podLeadId)) {
						predicates.add(
								criteriaBuilder.and(criteriaBuilder.equal(root.get("podLead").get("id"), podLeadId)));
					}
					if (!StringUtils.isEmpty(podLeadScore)) {
						predicates.add(
								criteriaBuilder.and(criteriaBuilder.equal(root.get("podLeadScore"), podLeadScore)));
					}
					if (!StringUtils.isEmpty(pesScore)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("pesScore"), pesScore)));
					}

					if (!StringUtils.isEmpty(isOverridden)) {
						predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("overriden"), isOverridden)));
					}

					if (!StringUtils.isEmpty(reviewedBy)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.equal(root.get("reviewedBy").get("id"), reviewedBy)));
					}
					if (!StringUtils.isEmpty(startDateString) && !StringUtils.isEmpty(endDateString)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.between(root.get("dateOfExecution"), startDate, endDate)));
					} else if (!StringUtils.isEmpty(startDateString)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.greaterThanOrEqualTo(root.get("dateOfExecution"), startDate)));
					} else if (!StringUtils.isEmpty(endDateString)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.lessThanOrEqualTo(root.get("dateOfExecution"), endDate)));
					}

					if (!StringUtils.isEmpty(createdStartDateString) && !StringUtils.isEmpty(createdEndDateString)) {
						predicates.add(criteriaBuilder.and(
								criteriaBuilder.between(root.get("createdDate"), createdStartDate, createdEndDate)));
					} else if (!StringUtils.isEmpty(createdStartDateString)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.greaterThanOrEqualTo(root.get("createdDate"), createdStartDate)));
					} else if (!StringUtils.isEmpty(createdEndDateString)) {
						predicates.add(criteriaBuilder
								.and(criteriaBuilder.lessThanOrEqualTo(root.get("createdDate"), createdEndDate)));
					}

					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}
			}, pageable);

			LOGGER.info("getNumber " + txnPlayList.getNumber() + " getSize " + txnPlayList.getSize() + " getTotalPages "
					+ txnPlayList.getTotalPages() + " hasNext " + txnPlayList.hasNext() + " hasPrevious "
					+ txnPlayList.hasPrevious() + " getTotalElements " + txnPlayList.getTotalElements()
					+ " getNumberOfElements" + txnPlayList.getNumberOfElements());

			JSONObject pageConfig = new JSONObject();

			pageConfig.put("currentPage", txnPlayList.getNumber());
			pageConfig.put("totalPages", txnPlayList.getTotalPages());
			pageConfig.put("hasNext", txnPlayList.hasNext());
			pageConfig.put("hasPrevious", txnPlayList.hasPrevious());
			pageConfig.put("totalRows", txnPlayList.getTotalElements());

			List<ScoringSearchResultsDTO> res = prepareSearchResults(txnPlayList.toList());
//			Collections.reverse(result);

			JSONObject dataObj = new JSONObject();
			dataObj.put("pageConfig", pageConfig);
			dataObj.put("rows", res);

			result.setSuccess(Boolean.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successful");
			result.setData(dataObj);
			LOGGER.info("PesScoringServiceImpl.searchPlayExecutions() : END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.searchPlayExecutions() :Exception while fetching Record: "
					+ e.getMessage() + "::" + e);
			// to send back in case of error
			result.setSuccess(Boolean.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Something went wrong! Txn Records search failed");
			result.setData(null);
			return result;
		}
	}

	@Override
	/**
	 * Updates records as per the update functionality in client
	 */
	public GenericResult updatePlayExecutions(ScoringDTO scoringDto) {
		LOGGER.info("updatePlayExecutions() : START");
		try {
			// fetching all the keys and values from the DTO
			Long txnPlayExecutionId = Long.parseLong(scoringDto.getTxnPlayExecutionId());
			Map<String, String> playFields = scoringDto.getPlayFields();
			List<Map<String, String>> playFeedback = scoringDto.getPlayExecFeedback();
			String nameOfProspect = scoringDto.getNameOfProspect();
			String aeId = scoringDto.getAeId();
			String spId = scoringDto.getSpId();
			String ftaId = scoringDto.getFtaId();
			String dtaId = scoringDto.getDtaId();
			String dsaId = scoringDto.getDsaId();
			String assignedToPesAgentId = scoringDto.getAssignedToPesAgentId();
			String reviewedById = scoringDto.getReviewedById();
			String onsiteSpId = scoringDto.getOnSiteSpId();
			String marketId = scoringDto.getMarketId();
			String teamId = scoringDto.getTeamId();
			String updatedBy = scoringDto.getUpdatedBy();
			String docLink = scoringDto.getDocLink();
			String podLeadScore = scoringDto.getPodLeadScore();
			String pesScore = scoringDto.getPesScore();
			String podLeadId = scoringDto.getPodLeadId();
			String pesStatus = scoringDto.getPesStatus();
			String ratingAccuracy = scoringDto.getRatingAccuracy();
			String feedbackAccuracy = scoringDto.getFeedbackAccuracy();
			String overallPesAccuracy = scoringDto.getOverallPesEffectiveness();
			String activityId = scoringDto.getActivityId();
			Calendar cal = Calendar.getInstance();
			java.util.Date updatedDate = cal.getTime();
			Date dateOfExecution = null;
			// Need to convert the String date to sql date
			if (!StringUtils.isEmpty(scoringDto.getDateOfExecution())) {
				LocalDate date = LocalDate.parse(scoringDto.getDateOfExecution(),
						DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				dateOfExecution = Date.valueOf(date);
			}
			String sfdcStatus = scoringDto.getSfdcStatus();
			String comments = scoringDto.getPesComments();
			String leadComments = scoringDto.getLeaderComments();
			// Need to convert the String date to sql date
			TxnPlayExecutions txnPlayExecutionsObj = txnPlayExecRepository.getById(txnPlayExecutionId);

			List<Long> empIds = new ArrayList<Long>();
			if (!StringUtils.isEmpty(aeId)) {
				empIds.add(Long.parseLong(aeId));
			}
			if (!StringUtils.isEmpty(assignedToPesAgentId)) {
				empIds.add(Long.parseLong(assignedToPesAgentId));
			}
			if (!StringUtils.isEmpty(spId)) {
				empIds.add(Long.parseLong(spId));
			}
			if (!StringUtils.isEmpty(ftaId)) {
				empIds.add(Long.parseLong(ftaId));
			}
			if (!StringUtils.isEmpty(onsiteSpId)) {
				empIds.add(Long.parseLong(onsiteSpId));
			}
			if (!StringUtils.isEmpty(dsaId)) {
				empIds.add(Long.parseLong(dsaId));
			}
			if (!StringUtils.isEmpty(dtaId)) {
				empIds.add(Long.parseLong(dtaId));
			}
			if (!StringUtils.isEmpty(podLeadId)) {
				empIds.add(Long.parseLong(podLeadId));
			}
			if (!StringUtils.isEmpty(reviewedById)) {
				empIds.add(Long.parseLong(reviewedById));
			}

			List<Employee> sellerList = employeeRepository.findEmployeeByIds(empIds);
			Map<Long, Employee> idEmpMap = new HashMap<Long, Employee>();
			for (Employee sellerEmp : sellerList) {
				idEmpMap.put(sellerEmp.getId(), sellerEmp);
			}

			// checking whether values have been added or not
			if (!StringUtils.isEmpty(aeId)) {
				Employee emp = idEmpMap.get(Long.parseLong(aeId)); // employeeRepository.getById(Long.parseLong(aeId));
				txnPlayExecutionsObj.setAe(emp);
			} else
				txnPlayExecutionsObj.setAe(null);
			if (!StringUtils.isEmpty(assignedToPesAgentId)) {
				Employee emp = idEmpMap.get(Long.parseLong(assignedToPesAgentId)); // employeeRepository.getById(Long.parseLong(assignedToPesAgentId));
				txnPlayExecutionsObj.setAssignedToPesAgent(emp);
			} else
				txnPlayExecutionsObj.setAssignedToPesAgent(null);
			if (!StringUtils.isEmpty(spId)) {
				Employee emp = idEmpMap.get(Long.parseLong(spId)); // employeeRepository.getById(Long.parseLong(spId));
				txnPlayExecutionsObj.setSp(emp);
			} else
				txnPlayExecutionsObj.setSp(null);
			if (!StringUtils.isEmpty(ftaId)) {
				Employee emp = idEmpMap.get(Long.parseLong(ftaId)); // employeeRepository.getById(Long.parseLong(ftaId));
				txnPlayExecutionsObj.setFta(emp);
			} else
				txnPlayExecutionsObj.setFta(null);
			if (!StringUtils.isEmpty(onsiteSpId)) {
				Employee emp = idEmpMap.get(Long.parseLong(onsiteSpId)); // employeeRepository.getById(Long.parseLong(onsiteSpId));
				txnPlayExecutionsObj.setOnsiteSp(emp);
			} else
				txnPlayExecutionsObj.setOnsiteSp(null);
			if (!StringUtils.isEmpty(dtaId)) {
				Employee emp = idEmpMap.get(Long.parseLong(dtaId)); // employeeRepository.getById(Long.parseLong(aeId));
				txnPlayExecutionsObj.setDta(emp);
			} else
				txnPlayExecutionsObj.setDta(null);
			if (!StringUtils.isEmpty(dsaId)) {
				Employee emp = idEmpMap.get(Long.parseLong(dsaId)); // employeeRepository.getById(Long.parseLong(aeId));
				txnPlayExecutionsObj.setDsa(emp);
			} else
				txnPlayExecutionsObj.setDsa(null);

			if (!StringUtils.isEmpty(marketId)) {
				Market market = marketRepository.getById(Long.parseLong(marketId));
				txnPlayExecutionsObj.setMarket(market);
			}
			if (!StringUtils.isEmpty(teamId)) {
				Team team = teamRepository.getById(Long.parseLong(teamId));
				txnPlayExecutionsObj.setTeam(team);
			}
			if (!StringUtils.isEmpty(reviewedById)) {
				Employee emp = idEmpMap.get(Long.parseLong(reviewedById)); // employeeRepository.getById(Long.parseLong(reviewedById));
				txnPlayExecutionsObj.setReviewedBy(emp);
			} else
				txnPlayExecutionsObj.setReviewedBy(null);
			if (!StringUtils.isEmpty(podLeadId)) {
				Employee emp = idEmpMap.get(Long.parseLong(podLeadId)); // employeeRepository.getById(Long.parseLong(podLeadId));
				txnPlayExecutionsObj.setPodLead(emp);
			} else
				txnPlayExecutionsObj.setPodLead(null);
			// setting date of execution
			txnPlayExecutionsObj.setNameOfProspect(nameOfProspect);
			txnPlayExecutionsObj.setPesScore(pesScore);
			txnPlayExecutionsObj.setDocLink(docLink);
			txnPlayExecutionsObj.setPodLeadScore(podLeadScore);
			txnPlayExecutionsObj.setDateOfExecution(dateOfExecution);
			txnPlayExecutionsObj.setSfdcStatus(sfdcStatus);
			txnPlayExecutionsObj.setUpdatedBy(updatedBy);
			txnPlayExecutionsObj.setUpdatedDate(updatedDate);
			txnPlayExecutionsObj.setPesComments(comments);
			txnPlayExecutionsObj.setRatingAccuracy(ratingAccuracy);
			txnPlayExecutionsObj.setFeedbackAccuracy(feedbackAccuracy);
			txnPlayExecutionsObj.setOverallPesEffectiveness(overallPesAccuracy);
			txnPlayExecutionsObj.setActivityId(activityId);

			// logic for scoring for while updating

			if (pesStatus != null && (pesStatus.equals(PesConstants.ASSIGNED) || pesStatus.equals(PesConstants.NEW))) {
				txnPlayExecutionsObj.setPesStatus(PesConstants.INITIATED);
			} else {
				txnPlayExecutionsObj.setPesStatus(pesStatus);
			}
			txnPlayExecutionsObj.setLeaderComments(leadComments);
			List<TxnPlayExecutionData> txnExecDataList = txnPlayExecutionsObj.getTxnPlayExecutionData();

			// Field Id : TxnPlayExecutionData Map
			Map<Long, TxnPlayExecutionData> dataIdMap = new HashMap<>();
			for (TxnPlayExecutionData txnData : txnExecDataList) {
				dataIdMap.put(txnData.getFieldId(), txnData);
			}

			// Checking whether overriden
			if (!StringUtils.isEmpty(podLeadScore) && !StringUtils.isEmpty(pesScore)) {
				String overriden = podLeadScore.equals(pesScore) ? "No" : "Yes";
				txnPlayExecutionsObj.setOverriden(overriden);
			}

			// looping through the playFields map and updating respective
			// TxnPlayExecutionData
			for (String key : playFields.keySet()) {
				// Creating object for TxnPlayExecutionData child of TransactionPlaysExecution
				TxnPlayExecutionData txnData = dataIdMap.get(Long.parseLong(key));
				// Check for existing field data
				if (txnData != null) {
					txnData.setValue(playFields.get(key));
				}
				// new field data
				else {
					TxnPlayExecutionData newTxnData = new TxnPlayExecutionData();
					newTxnData.setFieldId(Long.parseLong(key));
					// Since the object of txnPlayExecutions is already created we can fetch its id.
					newTxnData.setTxnPlayExecutionId(txnPlayExecutionId);
					newTxnData.setValue(playFields.get(key));
					txnExecDataList.add(newTxnData);
				}
			}
			// Adding new feedback data
			List<TxnPlayExecutionFeedback> txnPlayFeedbackList = txnPlayExecutionsObj.getTxnPlayExecutionFeedback();
			Map<Long, TxnPlayExecutionFeedback> feedbackIdMap = new HashMap<>();
			// Mapping id : txnPlayExecutionFeedback obj
			for (TxnPlayExecutionFeedback txnfeedback : txnPlayFeedbackList) {
				feedbackIdMap.put(txnfeedback.getId(), txnfeedback);
			}

			StringBuilder pesFeedback = new StringBuilder();
			StringBuilder podLeadFeedback = new StringBuilder();
			for (Map<String, String> feedback : playFeedback) {
				// Checking for existing feedbacks
				if (txnPlayExecutionsObj.getPlay().getName().equals("STRAP")) {
					if (Long.parseLong(feedback.get("id")) > 0 && !feedback.get("id").equals("-1")) {
						TxnPlayExecutionFeedback txnPlayFeedback = feedbackIdMap
								.get(Long.parseLong(feedback.get("id")));
						txnPlayFeedback.setCriteria(feedback.get("criteria"));
						txnPlayFeedback.setPesFeedback(feedback.get("pesFeedback"));
						txnPlayFeedback.setPesFeedbackRating(feedback.get("pesFeedbackRating"));
						txnPlayFeedback.setPodLeadFeedback(feedback.get("podLeadFeedback"));
						txnPlayFeedback.setPodLeadFeedbackRating(feedback.get("podLeadFeedbackRating"));
						txnPlayFeedback.setStatus(feedback.get("status"));
						if (!StringUtils.isEmpty(feedback.get("pesFeedback"))) {
							pesFeedback.append(StringUtils.isEmpty(feedback.get("criteria")) ? ""
									: (feedback.get("criteria") + " ( "));
							pesFeedback.append(StringUtils.isEmpty(feedback.get("pesFeedbackRating")) ? ""
									: (feedback.get("pesFeedbackRating") + " ): "));
							pesFeedback.append(feedback.get("pesFeedback")).append(" \n ");

						}
						if (!StringUtils.isEmpty(feedback.get("podLeadFeedback"))) {
							podLeadFeedback.append(StringUtils.isEmpty(feedback.get("criteria")) ? ""
									: (feedback.get("criteria") + " ( "));
							podLeadFeedback.append(StringUtils.isEmpty(feedback.get("pesFeedbackRating")) ? ""
									: (feedback.get("pesFeedbackRating") + " ): "));
							podLeadFeedback.append(feedback.get("podLeadFeedback")).append(" \n ");

						}
					}
					// for new feedbacks
					else {
						TxnPlayExecutionFeedback txnPlayFeedback = new TxnPlayExecutionFeedback();
						txnPlayFeedback.setCriteria(feedback.get("criteria"));
						txnPlayFeedback.setPesFeedback(feedback.get("pesFeedback"));
						txnPlayFeedback.setPesFeedbackRating(feedback.get("pesFeedbackRating"));
						txnPlayFeedback.setPodLeadFeedback(feedback.get("podLeadFeedback"));
						txnPlayFeedback.setPodLeadFeedbackRating(feedback.get("podLeadFeedbackRating"));
						txnPlayFeedback.setStatus(feedback.get("status"));
						txnPlayFeedback.setTxnPlayExecutionId(txnPlayExecutionId);
						txnPlayFeedbackList.add(txnPlayFeedback);
						if (!StringUtils.isEmpty(feedback.get("pesFeedback"))) {
							pesFeedback.append(StringUtils.isEmpty(feedback.get("criteria")) ? ""
									: (feedback.get("criteria") + " ( "));
							pesFeedback.append(StringUtils.isEmpty(feedback.get("pesFeedbackRating")) ? ""
									: (feedback.get("pesFeedbackRating") + " ): "));
							pesFeedback.append(feedback.get("pesFeedback")).append(" \n ");
						}
						if (!StringUtils.isEmpty(feedback.get("podLeadFeedback"))) {
							podLeadFeedback.append(StringUtils.isEmpty(feedback.get("criteria")) ? ""
									: (feedback.get("criteria") + " ( "));
							podLeadFeedback.append(StringUtils.isEmpty(feedback.get("podLeadFeedbackRating")) ? ""
									: (feedback.get("pesFeedbackRating") + " ): "));
							podLeadFeedback.append(feedback.get("podLeadFeedback")).append(" \n ");
						}
					}

				} else {

					if (Long.parseLong(feedback.get("id")) > 0 && !feedback.get("id").equals("-1")) {
						TxnPlayExecutionFeedback txnPlayFeedback = feedbackIdMap
								.get(Long.parseLong(feedback.get("id")));
						txnPlayFeedback.setPesFeedback(feedback.get("pesFeedback"));
						txnPlayFeedback.setPodLeadFeedback(feedback.get("podLeadFeedback"));
						txnPlayFeedback.setStatus(feedback.get("status"));
						if (!StringUtils.isEmpty(feedback.get("pesFeedback"))) {
							pesFeedback.append(feedback.get("pesFeedback")).append(" | ");
						}
						if (!StringUtils.isEmpty(feedback.get("podLeadFeedback"))) {
							podLeadFeedback.append(feedback.get("podLeadFeedback")).append(" | ");
						}
					}

					else {
						TxnPlayExecutionFeedback txnPlayFeedback = new TxnPlayExecutionFeedback();
						txnPlayFeedback.setPesFeedback(feedback.get("pesFeedback"));
						txnPlayFeedback.setPodLeadFeedback(feedback.get("podLeadFeedback"));
						txnPlayFeedback.setStatus(feedback.get("status"));
						txnPlayFeedback.setTxnPlayExecutionId(txnPlayExecutionId);
						txnPlayFeedbackList.add(txnPlayFeedback);
						if (!StringUtils.isEmpty(feedback.get("pesFeedback"))) {
							pesFeedback.append(feedback.get("pesFeedback")).append(" | ");
						}
						if (!StringUtils.isEmpty(feedback.get("podLeadFeedback"))) {
							podLeadFeedback.append(feedback.get("podLeadFeedback")).append(" | ");
						}
					}
				}
			}

			txnPlayExecutionsObj.setTxnPlayExecutionFeedback(txnPlayFeedbackList);
			txnPlayExecutionsObj.setPesFeedback(pesFeedback.toString());
			txnPlayExecutionsObj.setPodLeadFeedback(podLeadFeedback.toString());
			// updating the txnPlayExecutions object.
			txnPlayExecRepository.save(txnPlayExecutionsObj);
			GenericResult result = new GenericResult(true, "TxnPlayExecutions edit operation successful");
			LOGGER.info("editPlayExecutions() : END");
			return result;
		} catch (Exception e) {
			LOGGER.error("editPlayExecutions() : " + e.getMessage() + "::" + e);
			GenericResult result = new GenericResult(false, "TxnPlayExecutions edit operation unsuccessful");
			result.setStatus(PesConstants.FAIL);
			return result;
		}
	}

	/**
	 * Gets play execution w.r.t txn id from the db
	 * 
	 * @param Long id
	 */
	public GenericResult getPlayExecutions(Long id) {
		LOGGER.info("PesScoringServiceImpl.getPlayExecutions(): START");
		GenericResult result = new GenericResult();
		try {
			TxnPlayExecutions playExc = txnPlayExecRepository.getById(id);
			List<TxnPlayExecutions> playExcList = new ArrayList<>();
			playExcList.add(playExc);
			List<ScoringSearchResultsDTO> res = prepareSearchResults(playExcList);

			if (playExc != null) {
				result.setData(res);
				result.setMessage("Operation Successful");
				result.setStatus(PesConstants.SUCCESS);
				result.setSuccess(true);
			} else {
				LOGGER.error("PesScoringServiceImpl.getPlayExecutions(): No Txn Records found for id " + id);
				result.setData(null);
				result.setMessage("TxnPlay fetching playExc Operation failed");
				result.setStatus(PesConstants.FAIL);
				result.setSuccess(false);
			}
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.getPlayExecutions(): Txn Record retrieving failed for id " + id + " :: "
					+ e.getMessage());
			result.setData(null);
			result.setMessage("TxnPlay fetching playExc Operation failed");
			result.setStatus(PesConstants.FAIL);
			result.setSuccess(false);
		}

		LOGGER.info("PesScoringServiceImpl.getPlayExecutions(): END");
		return result;
	}

	// converts TxnPlayExecutions objects to Front-End ready objects in reverse,
	// latest records at top
	public List<ScoringSearchResultsDTO> prepareSearchResults(List<TxnPlayExecutions> txnPlayList) {
		LOGGER.info("PesScoringServiceImpl.prepareSearchResults(): START");
		List<ScoringSearchResultsDTO> result = new ArrayList<>();
		for (TxnPlayExecutions exec : txnPlayList) {
			ScoringSearchResultsDTO searchResult = new ScoringSearchResultsDTO();
			Map<String, String> play = new HashMap<>();
			Map<String, String> ae = new HashMap<>();
			Map<String, String> sp = new HashMap<>();
			Map<String, String> fta = new HashMap<>();
			Map<String, String> onsiteSp = new HashMap<>();
			Map<String, String> dta = new HashMap<>();
			Map<String, String> dsa = new HashMap<>();
			Map<String, String> assignedToPesAgent = new HashMap<>();
			Map<String, String> assignedByPesLead = new HashMap<>();
			Map<String, String> podLead = new HashMap<>();
			Map<String, String> scoringFor = new HashMap<>();
			Map<String, String> market = new HashMap<>();
			Map<String, String> team = new HashMap<>();
			Map<String, String> reviewedBy = new HashMap<>();
			searchResult.setPlayFieldsFromTxnDataList(exec.getTxnPlayExecutionData());
			searchResult.setPlayExecFeedback(exec.getTxnPlayExecutionFeedback());
			Date dateOfExecution = null;
			if (exec.getDateOfExecution() != null)
				dateOfExecution = new Date(exec.getDateOfExecution().getTime());
			String leaderComments = exec.getLeaderComments();
			String pesComments = exec.getPesComments();
			String nameOfProspect = exec.getNameOfProspect();
			String opportunityName = exec.getOpportunityName();
			String pesStatus = exec.getPesStatus();
			String sfdcStatus = exec.getSfdcStatus();
			String pesFeedback = exec.getPesFeedback();
			String podLeadFeedback = exec.getPodLeadFeedback();
			Long id = exec.getId();
			Boolean isStarred = exec.getIsStarred();
			String activityId = exec.getActivityId();
			Employee empAe = exec.getAe();
			Employee empSp = exec.getSp();
			Employee empFta = exec.getFta();
			Employee empOnsiteSp = exec.getOnsiteSp();
			Employee empDta = exec.getDta();
			Employee empDsa = exec.getDsa();
			Employee empPesAgent = exec.getAssignedToPesAgent();
			Employee empPesLead = exec.getAssignedByPesLead();
			Employee empPodLead = exec.getPodLead();
			Employee empReviewedBy = exec.getReviewedBy();
			Employee empScoringFor = exec.getScoringFor();
			String pesScore = exec.getPesScore();
			String podLeadScore = exec.getPodLeadScore();
			String finalScore = exec.getFinalScore();
			String docLink = exec.getDocLink();
			String createdDate = new SimpleDateFormat("yyyy-MM-dd").format(exec.getCreatedDate());
			String overriden = exec.getOverriden();
			String ratingAccuracy = exec.getRatingAccuracy();
			String feedbackAccuracy = exec.getFeedbackAccuracy();
			String overallPesEffectiveness = exec.getOverallPesEffectiveness();
			Integer isvalidOveride = exec.getValid_override();
			String rationale = exec.getRationale();
			String managerComments = exec.getManager_comments();

			ae = getEmployeeMaps(empAe);
			sp = getEmployeeMaps(empSp);
			fta = getEmployeeMaps(empFta);
			onsiteSp = getEmployeeMaps(empOnsiteSp);
			dta = getEmployeeMaps(empDta);
			dsa = getEmployeeMaps(empDsa);
			assignedToPesAgent = getEmployeeMaps(empPesAgent);
			assignedByPesLead = getEmployeeMaps(empPesLead);
			podLead = getEmployeeMaps(empPodLead);
			reviewedBy = getEmployeeMaps(empReviewedBy);
			scoringFor = getEmployeeMaps(empScoringFor);

			Market marketObj = exec.getMarket();
			Team teamObj = exec.getTeam();
			Play playObj = exec.getPlay();

			// checking for non null objects
			if (marketObj != null) {
				market.put("id", marketObj.getId() + "");
				market.put("displayName", marketObj.getName());
			}
			if (teamObj != null) {
				team.put("id", teamObj.getId() + "");
				team.put("displayName", teamObj.getName());
			}
			if (play != null) {
				play.put("id", playObj.getId() + "");
				play.put("displayName", playObj.getName());
			}

			// Putting all the elements into the Dto
			searchResult.setAe(ae);
			searchResult.setAssignedByPesLead(assignedByPesLead);
			searchResult.setAssignedToPesAgent(assignedToPesAgent);
			searchResult.setDateOfExecution(dateOfExecution);
			searchResult.setDta(dta);
			searchResult.setDsa(dsa);
			searchResult.setFta(fta);
			searchResult.setId(id);
			searchResult.setIsStarred(isStarred);
			searchResult.setActivityId(activityId);
			searchResult.setLeaderComments(leaderComments);
			searchResult.setMarket(market);
			searchResult.setNameOfProspect(nameOfProspect);
			searchResult.setOnsiteSp(onsiteSp);
			searchResult.setReviewedBy(reviewedBy);
			searchResult.setScoringFor(scoringFor);
			searchResult.setOpportunityName(opportunityName);
			searchResult.setPesComments(pesComments);
			searchResult.setPesStatus(pesStatus);
			searchResult.setPlay(play);
			searchResult.setPodLead(podLead);
			searchResult.setPesScore(pesScore);
			searchResult.setPodLeadScore(podLeadScore);
			searchResult.setFinalScore(finalScore);
			searchResult.setDocLink(docLink);
			searchResult.setSfdcStatus(sfdcStatus);
			searchResult.setSp(sp);
			searchResult.setTeam(team);
			searchResult.setCreatedDate(createdDate);
			searchResult.setPesFeedback(pesFeedback);
			searchResult.setValid_override(isvalidOveride);
			searchResult.setRationale(rationale);
			searchResult.setManager_comments(managerComments);
			searchResult.setPodLeadFeedback(podLeadFeedback);
			searchResult.setOverriden(overriden);
			searchResult.setRatingAccuracy(ratingAccuracy);
			searchResult.setFeedbackAccuracy(feedbackAccuracy);
			searchResult.setOverallPesEffectiveness(overallPesEffectiveness);
			result.add(searchResult);
		}
		LOGGER.info("PesScoringServiceImpl.prepareSearchResults(): END");
		return result;
	}

	// converts Employee objects to simple {id:"",name:""} maps
	public Map<String, String> getEmployeeMaps(Employee emp) {
		Map<String, String> map = new HashMap<>();
		if (emp == null)
			return map;
		map.put("id", emp.getId() + "");
		map.put("displayName", emp.getFullName());
		return map;
	}

	// changes assignForScoring status of txnPlayExecutions Records
	@Override
	public boolean assignForScoring(PesStatusDTO statusDto) {
		try {
			LOGGER.info("PesScoringServiceImpl.assignForScoring(): START");
			String ids[] = statusDto.getIds();
			String employeeId = statusDto.getEmployeeId();
			String reviewerId = statusDto.getLoginUserId();
			Employee emp = employeeRepository.getById(Long.parseLong(employeeId));
			Employee reviewer = employeeRepository.getById(Long.parseLong(reviewerId));
			Calendar cal = Calendar.getInstance();
			java.util.Date updatedDate = cal.getTime();
			for (String id : ids) {
				if (!StringUtils.isEmpty(id)) {
					TxnPlayExecutions txn = txnPlayExecRepository.getById(Long.parseLong(id));
					txn.setPesStatus(PesConstants.ASSIGNED);
					txn.setAssignedToPesAgent(emp);
					txn.setReviewedBy(reviewer);
					txn.setAssignedByPesLead(reviewer);
					txn.setUpdatedDate(updatedDate);
					txn.setUpdatedBy(reviewer.getFullName());
					txnPlayExecRepository.save(txn);
				}
			}
			LOGGER.info("PesScoringServiceImpl.assignForScoring(): END");
			return true;
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.assignForScoring(): ERROR : " + e);
			e.printStackTrace();
			return false;
		}
	}

	// changes assignForReview status of txnPlayExecutions Records
	@Override
	public boolean assignForReview(PesStatusDTO statusDto) {
		try {
			LOGGER.info("PesScoringServiceImpl.assignForReview(): START");
			String ids[] = statusDto.getIds();
			String employeeId = statusDto.getEmployeeId();
			String loginUserId = statusDto.getLoginUserId();
			Employee reviewer = employeeRepository.getById(Long.parseLong(employeeId));
			Employee loginUser = employeeRepository.getById(Long.parseLong(loginUserId));
			Calendar cal = Calendar.getInstance();
			java.util.Date updatedDate = cal.getTime();
			for (String id : ids) {
				if (!StringUtils.isEmpty(id)) {
					TxnPlayExecutions txn = txnPlayExecRepository.getById(Long.parseLong(id));
					txn.setPesStatus(PesConstants.PENDING_REVIEW);
					txn.setReviewedBy(reviewer);
					txn.setUpdatedBy(loginUser.getFullName());
					txn.setUpdatedDate(updatedDate);
					txnPlayExecRepository.save(txn);
				}
			}
			LOGGER.info("PesScoringServiceImpl.assignForReview(): END");
			return true;
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.assignForReview(): ERROR : " + e);
			e.printStackTrace();
			return false;
		}
	}

	@Override
	/**
	 * Pushes records to the status Push To PodLead Splits records into multiple
	 * records depending upon the number of sellers responsible for that play
	 * Changes the pod lead for the play according to the seller
	 * 
	 * @param PesStatusDTO statusDto
	 */
	public String pushToPodLead(PesStatusDTO statusDto) {
		// Flag for Checking Valid Push/Partial Success
		Boolean validPushFlag = true;
		// Flag to check for Wrong Push/All failed
		Boolean invalidPushFlag = true;
		try {
			LOGGER.info("PesScoringServiceImpl.pushToPodLead(): START");
			// Get Ids for the selected plays
			String ids[] = statusDto.getIds();
			// New List for the records to update in TXN table
			List<TxnPlayExecutions> updateList = new ArrayList<>();
			List<Long> idList = Arrays.stream(ids).map(Long::parseLong).collect(Collectors.toList());
			// Get the txns from the txnList
			List<TxnPlayExecutions> txnPlayExecutionsList = txnPlayExecRepository.getByIds(idList);
			// Map of Play:Roles
			Map<Long, List<MapPlayRoles>> playRolesMap = new HashMap<Long, List<MapPlayRoles>>();
			// Map of roleId:Role
			Map<Long, FunctionalRole> fnRoleMap = new HashMap<Long, FunctionalRole>();
			Calendar cal = Calendar.getInstance();
			java.util.Date updatedDate = cal.getTime();
			String loginUserId = statusDto.getLoginUserId();
			Employee loginUser = employeeRepository.getById(Long.parseLong(loginUserId));

			for (TxnPlayExecutions txn : txnPlayExecutionsList) {
				// If scoringFor present then perform the action
				if (txn.getScoringFor() != null) {
					txn.setPesStatus(PesConstants.PUSH_TO_POD_LEAD);
					txn.setUpdatedBy(loginUser.getFullName());
					txn.setUpdatedDate(updatedDate);
					txn.setPodLeadScore(txn.getPesScore());
					updateList.add(txn);
					continue;
				}

				// Get Play model object
				Play play = txn.getPlay();
				// Make map for PLay vs role IDs
				List<MapPlayRoles> roles = null;
				if (playRolesMap.containsKey(play.getId())) {
					roles = playRolesMap.get(play.getId());
				} else {
					roles = mapPlayRolesRepository.findByPlayId(play.getId());
					playRolesMap.put(play.getId(), roles);
				}

				// Checking if the list of roles associated with the play is
				if (roles.size() <= 1) {
					FunctionalRole role = null;
					if (fnRoleMap.containsKey(roles.get(0).getRoleId())) {
						role = fnRoleMap.get(roles.get(0).getRoleId());
					} else {
						role = functionalRoleRepository.getById(roles.get(0).getRoleId());
						fnRoleMap.put(roles.get(0).getRoleId(), role); // ROle vs roleID
					}

					Employee podLead = null;
					Employee scoringFor = null;
					// get the respective seller using getSeller method
					Employee seller = getSeller(txn, role.getName());
					// If seller is not present then log and skip
					if (seller == null || seller.getId() == -1) {
						LOGGER.info("For the record with prospect name : " + txn.getNameOfProspect() + " "
								+ role.getName() + " not present");
						validPushFlag = false;
						continue;
					}
					// get Pod Lead from Emp table
					if (seller.getPodLeadId() != null)
						podLead = employeeRepository.getById(seller.getPodLeadId());
					// set scoring for
					scoringFor = seller;
					if (podLead != null && txn.getPodLead() == null)
						txn.setPodLead(podLead);
					txn.setPesStatus(PesConstants.PUSH_TO_POD_LEAD);
					txn.setScoringFor(scoringFor);
					txn.setPodLeadScore(txn.getPesScore());
					txn.setUpdatedBy(loginUser.getFullName());
					txn.setUpdatedDate(updatedDate);
					updateList.add(txn);
				}

				if (roles.size() > 1) {
					// checking number of records added to db
					String playName = txn.getPlay().getName();
					// List<TxnPlayExecutions> txnList =
					// txnPlayExecRepository.getByActivityIdNPlayName(txn.getActivityId(),
					// playName);
					// checking whether already pushed to pod lead
					if (txn.getPesStatus().equals(PesConstants.PUSH_TO_POD_LEAD) || txn.getScoringFor() != null) {
						LOGGER.info(
								"Split for the record with prospect : " + txn.getNameOfProspect() + " already done.");
						continue;
					}
					// for 1st role record
					int count = 0;
					for (MapPlayRoles role : roles) {
						FunctionalRole roleObj = null;
						Long roleId = role.getRoleId();
						if (fnRoleMap.containsKey(roleId)) {
							roleObj = fnRoleMap.get(roleId);
						} else {
							roleObj = functionalRoleRepository.getById(roleId);
							fnRoleMap.put(roleId, roleObj);
						}
						// FunctionalRole roleObj = functionalRoleRepository.getById(role.getRoleId());
						Employee podLead = null;
						Employee scoringFor = null;
						// for the first seller of any record
						if (count == 0) {
							Employee seller = getSeller(txn, roleObj.getName());
							if (seller == null || seller.getId() == -1) {
								LOGGER.info("For the record with prospect name : " + txn.getNameOfProspect() + " "
										+ roleObj.getName() + " not present");
								continue;
							}
							if (seller.getPodLeadId() != null)
								podLead = employeeRepository.getById(seller.getPodLeadId());
							scoringFor = seller;
							if (podLead != null && txn.getPodLead() == null)
								txn.setPodLead(podLead);
							txn.setPesStatus(PesConstants.PUSH_TO_POD_LEAD);
							txn.setScoringFor(scoringFor);
							txn.setPodLeadScore(txn.getPesScore());
							updateList.add(txn);
							count++;
						} else {
							Employee seller = getSeller(txn, roleObj.getName());
							if (seller == null || seller.getId() == -1) {
								LOGGER.info("For the record with prospect name : " + txn.getNameOfProspect() + " "
										+ roleObj.getName() + " not present");
								continue;
							}
							if (seller.getPodLeadId() != null)
								podLead = employeeRepository.getById(seller.getPodLeadId());
							scoringFor = seller;
							TxnPlayExecutions newTxn = new TxnPlayExecutions();
							newTxn.copy(txn);
							if (podLead != null)
								newTxn.setPodLead(podLead);
							newTxn.setPesStatus(PesConstants.PUSH_TO_POD_LEAD);
							newTxn.setScoringFor(scoringFor);
							txnPlayExecRepository.save(newTxn);
							List<TxnPlayExecutionData> txnDataList = new ArrayList<>();
							for (TxnPlayExecutionData txnData : txn.getTxnPlayExecutionData()) {
								TxnPlayExecutionData newData = new TxnPlayExecutionData();
								newData.copy(txnData);
								newData.setTxnPlayExecutionId(newTxn.getId());
								txnDataList.add(newData);
							}
							newTxn.setTxnPlayExecutionData(txnDataList);
							List<TxnPlayExecutionFeedback> feedbackList = new ArrayList<>();
							for (TxnPlayExecutionFeedback txnData : txn.getTxnPlayExecutionFeedback()) {
								TxnPlayExecutionFeedback newData = new TxnPlayExecutionFeedback();
								newData.copy(txnData);
								newData.setTxnPlayExecutionId(newTxn.getId());
								feedbackList.add(newData);
							}
							newTxn.setTxnPlayExecutionFeedback(feedbackList);
							newTxn.setPodLeadScore(newTxn.getPesScore());
							LOGGER.info(playName + " record with Opportunity Name : " + txn.getOpportunityName()
									+ " split");
							updateList.add(newTxn);
						}
					}
					// If there are no sellers for more than 1 roles
					if (count == 0) {
						validPushFlag = false;
					}

				}
			}
			LOGGER.info("Length-", updateList);
			if (updateList.isEmpty()) {
				invalidPushFlag = false;
			}
			txnPlayExecRepository.saveAll(updateList);
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.pushToPodLead() : ERROR : " + e.getMessage());
			e.printStackTrace();
			return "false";
		}
		// Based on condition check for all possible outcome
		// If both flags are true
		if (validPushFlag && invalidPushFlag)
			return "true";
		// For few records with proper data
		else if (!validPushFlag && invalidPushFlag)
			return "insufficient data";
		// For all recrods with wrong data
		else
			return "all Invalid";
	}

	/*
	 * function to call reports for Discovery Call and process that data
	 */
	@Override
	@Async
	public void processDiscoveryCallRecords(String reportName, String userMail, String startDate, String endDate) {
		LOGGER.info("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName + " : START");
		try {
			List<DiscoveryCallDTO> recordList = null;
			List<DiscoveryCallDTO> failedList = new ArrayList<>();
			List<TxnPlayExecutions> updateList = new ArrayList<>();
			int count = 0;

			if (reportName.equals("Enterprise EMEA"))
				recordList = pesSalesForceService.getEnterpriseEMEADCCReport(startDate, endDate);
			else if (reportName.equals("Enterprise NA"))
				recordList = pesSalesForceService.getEnterpriseNADCCReport(startDate, endDate);
			else if (reportName.equals("MidMarket"))
				recordList = gsheetUtil.getMidMarketDCData(startDate, endDate);
			else if (reportName.equals("Treasury"))
				recordList = pesSalesForceService.getTreasuryReport();

			if (CollectionUtils.isNotEmpty(recordList)) {

				Play playDC = playRepository.findByName("Discovery Execute Call");
				Play playDS = playRepository.findByName("Discovery STRAP");

				List<Employee> allSellers = employeeRepository.findAll();
				List<Market> allMarkets = marketRepository.findAll();
				List<Team> allTeams = teamRepository.findAll();
				Map<String, Employee> nameEmpMap = new HashMap<>();

				// maps with 18charId : Object
				Map<String, Team> idTeamMap = new HashMap<>();
				Map<String, Employee> idEmpMap = new HashMap<>();
				Map<String, Market> idMarketMap = new HashMap<>();

				for (Employee emp : allSellers) {
					idEmpMap.put(emp.getSf18CharId(), emp);
					nameEmpMap.put(emp.getFullName(), emp);
				}

				for (Market market : allMarkets) {
					idMarketMap.put(market.getName().toUpperCase(), market);
				}
				for (Team team : allTeams) {
					idTeamMap.put(team.getName().toUpperCase(), team);
				}
				List<MapPlayFields> fieldListDC = mapPlayFieldsRepository.getByPlayId(playDC.getId());
				List<MapPlayFields> fieldListDS = mapPlayFieldsRepository.getByPlayId(playDS.getId());
				Long dcIdField = fieldRepository.findByDisplayName("DC ID").getId();
				String createdBy = "SYSTEM";

				// New ActivityId List
				List<String> addedActivityIdList = new ArrayList<>();

				// Get the list of all the activity Id's from the Discover Call Report
				List<String> activityIds = new ArrayList<>();
				for (DiscoveryCallDTO record : recordList) {
					activityIds.add(record.getActivityId());
				}

				// Get all records from db for the current records fetched from salesforce
				List<TxnPlayExecutions> txnsByActivityIdList = txnPlayExecRepository
						.getDiscoveryPlaysByActivityIds(activityIds);

				// Get the list of all activityIds from db
				List<String> existingActivityIds = new ArrayList<>();
				for (TxnPlayExecutions txn : txnsByActivityIdList) {
					existingActivityIds.add(txn.getActivityId());
				}

				for (DiscoveryCallDTO rec : recordList) {
					try {
						Map<String, String> playFieldDC = new HashMap<>();
						Map<String, String> playFieldDS = new HashMap<>();
						ScoringDTO scoringDto = new ScoringDTO();
						ScoringDTO scoringDtoDS = new ScoringDTO();
						String dateOfExecution = "";
						if (!StringUtils.isEmpty(rec.getDateOfExecution()))
							dateOfExecution = rec.getDateOfExecution().substring(0,
									rec.getDateOfExecution().indexOf('T'));
						String activityId = rec.getActivityId();
						String sfdcStatus = rec.getSfdcStatus();

						// Get the activityIds added through current iteration & check for duplication
						if (addedActivityIdList.indexOf(activityId) != -1) {
							continue;
						}

						/*
						 * Get the index of activity Id present for Discovery STRAP Check if play is
						 * marked completed for the same activityId If not completed don't add the
						 * fetched record Else Completed Check Sfdc Status for that activityId Add to
						 * the updateList
						 */
						int activityIndex = existingActivityIds.indexOf(activityId);
						if (activityIndex != -1) {
							if (!txnsByActivityIdList.get(activityIndex).getPesStatus()
									.equals(PesConstants.COMPLETED)) {
								LOGGER.info(
										"Discovery STRAP Record with activity Id : " + activityId + " already present");
								continue;
								// If txn not completed match the sfdc status and prepare update list
								// accordingly
							} else if (!txnsByActivityIdList.get(activityIndex).getSfdcStatus().equals(sfdcStatus)) {
								for (TxnPlayExecutions txn : txnsByActivityIdList) {
									// Get the all the records fecthed from SalesForce for a particular activityId
									if (txn.getActivityId().equals(activityId)) {
										txn.setSfdcStatus(sfdcStatus);
										updateList.add(txn);
										count++;
									}
								}
								LOGGER.info(
										"SFDC Status for Transaction with Activity Id : " + activityId + " updated ");
							}
							continue;
						}
						if (sfdcStatus.equals(PesConstants.CONVERTED)
								|| sfdcStatus.equals(PesConstants.NOT_CONVERTED_SELLER_NOT_INTERESTED)
								|| sfdcStatus.equals(PesConstants.NOT_CONVERTED_PROSPECT_NOT_INTERESTED)
								|| sfdcStatus.equals(PesConstants.NOT_CONVERTED_FOLLOWUP_WITHIN_4WEEKS)
								) {
							// for extracting url from <a></a> tags
							String docLink = "";
							if (!StringUtils.isEmpty(rec.getDocLink())) {
								Pattern pattern = Pattern.compile("<a[^>]*>(.*?)</a>");
								Matcher matcher = pattern.matcher(rec.getDocLink());
								docLink = "";
								while (matcher.find()) {
									docLink = docLink + matcher.group(1);
								}
							}
							String nameOfProspect = rec.getNameOfProspect();
							for (MapPlayFields field : fieldListDC) {
								if (field.getFieldId() == dcIdField) {
									playFieldDC.put(field.getFieldId() + "", rec.getDcId());
								} else
									playFieldDC.put(field.getFieldId() + "", "");
							}
							for (MapPlayFields field : fieldListDS) {
								if (field.getFieldId() == dcIdField) {
									playFieldDS.put(field.getFieldId() + "", rec.getDcId());
								}
								else
									playFieldDS.put(field.getFieldId() + "", "");
							}
							Market market = idMarketMap
									.get(!StringUtils.isEmpty(rec.getMarket()) ? rec.getMarket().toUpperCase() : null);
							String marketId = null;
							Team team = idTeamMap
									.get(!StringUtils.isEmpty(rec.getTeam()) ? rec.getTeam().toUpperCase() : null);
							String teamId = null;
							String aeSfId = rec.getAeSfId();
							String ftaSfId = rec.getFtaSfId();
							String spSf = rec.getSpSfId();
							Employee ae = null;
							Employee sp = null;
							Employee fta = null;

							// employee and pod lead checks
							if (!StringUtils.isEmpty(aeSfId)) {
								ae = idEmpMap.get(aeSfId);
								if (ae == null)
									ae = nameEmpMap.get(aeSfId);
							}
							if (!StringUtils.isEmpty(spSf)) {
								// checking with full name for now as getting full name from sales force
								sp = idEmpMap.get(spSf);
								if (sp == null)
									sp = nameEmpMap.get(spSf);
							}
							if (!StringUtils.isEmpty(ftaSfId)) {
								fta = idEmpMap.get(ftaSfId);
								if (fta == null)
									fta = nameEmpMap.get(ftaSfId);
							}

							if (ae == null) {
								LOGGER.info("AE with SF Id : " + aeSfId + " not present for prospect : "
										+ rec.getNameOfProspect());
							}
							if (sp == null) {
								LOGGER.info("SP with SF Id: " + spSf + " not present for prospect : "
										+ rec.getNameOfProspect());
							}
							if (fta == null) {
								LOGGER.info("FTA with SF Id: " + ftaSfId + " not present for prospect : "
										+ rec.getNameOfProspect());
							}

							if (market == null) {
								if (ae != null) {
									marketId = ae.getMarketId() + "";
								} else if (sp != null) {
									marketId = sp.getMarketId() + "";
								} else {
									if (idMarketMap.get(reportName.toUpperCase()) != null) {
										marketId = idMarketMap.get(reportName.toUpperCase()).getId() + "";
									}
								}
							} else if (market != null) {
								marketId = market.getId() + "";
							}

							if (team == null) {
								if (ae != null) {
									teamId = ae.getTeamId() + "";
								} else if (sp != null) {
									teamId = sp.getTeamId() + "";
								}
							} else if (team != null) {
								teamId = team.getId() + "";
							}

							scoringDto.setDateOfExecution(dateOfExecution);
							scoringDto.setActivityId(activityId);
							scoringDto.setDocLink(docLink);
							scoringDto.setMarketId(marketId);
							scoringDto.setTeamId(teamId);
							scoringDto.setNameOfProspect(nameOfProspect);
							scoringDto.setSfdcStatus(sfdcStatus);

							if (ae != null) {
								if (ae.getPodLeadId() != null) {
									scoringDto.setPodLeadId(ae.getPodLeadId() + "");
									scoringDtoDS.setPodLeadId(ae.getPodLeadId() + "");
								}
								scoringDto.setAeId(ae.getId() + "");
								scoringDtoDS.setAeId(ae.getId() + "");
							}
							if (sp != null) {
								scoringDto.setSpId(sp.getId() + "");
								scoringDtoDS.setSpId(sp.getId() + "");
							}
							if (fta != null) {
								scoringDto.setFtaId(fta.getId() + "");
								scoringDtoDS.setFtaId(fta.getId() + "");
							}

							scoringDtoDS.setDateOfExecution(dateOfExecution);
							scoringDtoDS.setActivityId(activityId);
							scoringDtoDS.setDocLink(docLink);
							scoringDtoDS.setMarketId(marketId);
							scoringDtoDS.setTeamId(teamId);
							scoringDtoDS.setNameOfProspect(nameOfProspect);
							scoringDtoDS.setSfdcStatus(sfdcStatus);
							scoringDto.setCreatedBy(createdBy);
							scoringDto.setPesStatus(PesConstants.NEW);
							scoringDtoDS.setCreatedBy(createdBy);
							scoringDtoDS.setPesStatus(PesConstants.NEW);

							// PLay specific changes
							scoringDto.setPlayId(playDC.getId() + "");
							scoringDtoDS.setPlayId(playDS.getId() + "");
							scoringDto.setPlayFields(playFieldDC);
							scoringDtoDS.setPlayFields(playFieldDS);
							assignPlayExecForScoring(scoringDto);
							assignPlayExecForScoring(scoringDtoDS);
							addedActivityIdList.add(activityId);
							count++;

							LOGGER.info("Record with Activity Id : " + activityId + " saved");
						}
					} catch (Exception e) {
						e.printStackTrace();
						LOGGER.error("PesScoringServiceImpl.processDiscoveryCallRecords() - Recordwise: Report Name : "
								+ reportName + " : ERROR : " + e.getMessage());
						failedList.add(rec);
					}
				}
			}
			String emails = userMail;
			String subject = "[SUCCESS]SalesForce Discovery Call " + reportName + " report Completion Mail";
			StringBuilder body = new StringBuilder().append("The SalesForce Discovery Call " + reportName
					+ " report has been successfully fetched " + "and the records have been updated. <br>"
					+ "No. of records added/updated : " + count + "<br>");

			if (failedList.size() > 0) {
				subject = "[SUCCESS with FAILURES]SalesForce Discovery Call " + reportName + " report Completion Mail";
				body.append("The following records failed to get added : <br>");
				int failCount = 1;
				for (DiscoveryCallDTO rec : failedList) {
					body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
				}
			}
			emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
			txnPlayExecRepository.saveAll(updateList);
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName
					+ " : ERROR : " + e.getMessage());
			e.printStackTrace();
			String emails = userMail;
			String subject = "[FAILURE]SalesForce Discovery Call " + reportName + " report Completion Failure Mail";
			String body = "The SalesForce Discovery Call " + reportName + " report fetch failed. "
					+ "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName
						+ " : ERROR : " + er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName + " : END");
	}

	// process OTC WebResearch Report data
	@Override
	@Async
	public void processWebResearchOTCRecords(String usermail, String startDate, String endDate) {
		LOGGER.info("PesScoringServiceImpl.processWebResearchOTCRecords(): START");
		try {
			List<OTCWebResearchDTO> recordList = pesSalesForceService.getOTCWebResearchReport(startDate, endDate);

			if (CollectionUtils.isNotEmpty(recordList)) {
				List<OTCWebResearchDTO> failedList = new ArrayList<>();

				Play play = playRepository.findByName("OTC Whitespace Web Research");
				String createdBy = "SYSTEM";
				List<MapPlayFields> fieldList = mapPlayFieldsRepository.getByPlayId(play.getId());
				int count = 0;

				List<Employee> allSellers = employeeRepository.findAll();
				List<Market> allMarkets = marketRepository.findAll();
				// Addition for team Field
				List<Team> allTeams = teamRepository.findAll();

				// maps with 18charId : Object
				Map<String, Employee> idEmpMap = new HashMap<>();
				Map<String, Market> nameMarketMap = new HashMap<>();
				Map<String,Market> idMarketMap = new HashMap<>();
				// Map for ID vs Team
				Map<String, Team> nameTeamMap = new HashMap<>();
				Map<String, Team> idTeamMap = new HashMap<>();
				Map<String, Employee> nameEmpMap = new HashMap<>();

				for (Employee emp : allSellers) {
					idEmpMap.put(emp.getSf18CharId(), emp);
					nameEmpMap.put(emp.getFullName(), emp);
				}

				for (Market market : allMarkets) {
					nameMarketMap.put(market.getName().toUpperCase(), market);
					idMarketMap.put(market.getId().toString(),market);
				}

				// Created All Team ID Map
				for (Team team : allTeams) {
					nameTeamMap.put(team.getName().toUpperCase(), team);
					idTeamMap.put(team.getId().toString(),team);
				}

				List<MapFieldOptions> fieldOptions = fieldOptionsRepo.findAll();
				Map<String, Long> optionNameIdMap = new HashMap<>();
				for (MapFieldOptions option : fieldOptions) {
					String key = option.getFieldId() + " | " + option.getDisplayName();
					optionNameIdMap.put(key, option.getId());
				}

				// Get the list of all the activity Id's from the OTC Report
				List<String> activityIds = new ArrayList<>();
				for (OTCWebResearchDTO record : recordList) {
					activityIds.add(record.getActivityId());
				}

				// Get all not completed records from db for the current records fetched from
				// salesforce
				List<String> notCompletedActivityIds = txnPlayExecRepository
						.getByActivityIdsAndNotCompleted(activityIds);

				for (OTCWebResearchDTO rec : recordList) {
					try {
						// Get notCompleted Record for the activityId if present don't add the fetched
						// record
						String activityId = rec.getActivityId();
						if (notCompletedActivityIds.indexOf(activityId) != -1) {
							LOGGER.info("OTC DC Record with activity Id : " + activityId + " already present");
							continue;
						}

						Map<String, String> playFields = new HashMap<>();
						ScoringDTO scoringDto = new ScoringDTO();
						String dateOfExecution = "";
						String marketId = null;
						Market market = nameMarketMap
								.get(!StringUtils.isEmpty(rec.getMarket()) ? rec.getMarket().toUpperCase() : null);
						// Getting ID from Record
						String teamId = null;
						Team team = nameTeamMap
								.get(!StringUtils.isEmpty(rec.getMarket()) ? rec.getTeam().toUpperCase() : null);

						if (!StringUtils.isEmpty(rec.getDateOfExecution()))
							dateOfExecution = rec.getDateOfExecution().substring(0,
									rec.getDateOfExecution().indexOf('T'));

						String accountName = rec.getAccountName();

						String spSf = rec.getSpSf();
						String aeSf = rec.getAeSf();
						// dynamic fields
						String opportunityName = rec.getOpportunityName();
						String stageName = rec.getStage();
						String dcId = rec.getDcId();

						// dynamic field end
						scoringDto.setPlayId(play.getId() + "");

						// dynamic field map end
						for (MapPlayFields field : fieldList) {
							Field fld = fieldRepository.getById(field.getFieldId());
							if (fld.getFieldName().equals("stage")) {
								String key = fld.getId() + " | " + stageName;
								Long stageId = optionNameIdMap.get(key);
								if (stageId != null)
									playFields.put(fld.getId() + "", stageId + "");
								else
									playFields.put(fld.getId() + "", "");
							} else if (fld.getFieldName().equals("opportunityName")) {

								playFields.put(fld.getId() + "", opportunityName);
							} else if (fld.getDisplayName().equals("DC ID")) {

								playFields.put(fld.getId() + "", dcId);
							}
						}
						Employee sp = null;
						Employee ae = null;
						Employee dsa = null;

						if (!StringUtils.isEmpty(spSf)) {
							sp = nameEmpMap.get(spSf);
							if (sp == null && spSf.length() == 18) {
								sp = idEmpMap.get(spSf);
							}
							dsa = sp;
						}

						if (!StringUtils.isEmpty(aeSf)) {
							ae = idEmpMap.get(aeSf);
							if (ae == null) {
								ae = nameEmpMap.get(aeSf);
							}
						}

						if (sp == null)
							LOGGER.info(
									"SP with SF Id : " + spSf + " not present for prospect : " + rec.getAccountName());

						if (sp != null) {
							if (sp.getPodLeadId() != null)
								scoringDto.setPodLeadId(sp.getPodLeadId() + "");
							scoringDto.setSpId(sp.getId() + "");
						}
						if (ae != null) {
							scoringDto.setAeId(ae.getId() + "");
						}

						// market logic for getting markets
						if (market == null) {
							if (sp != null) {
								marketId = sp.getMarketId() + "";
								market = idMarketMap.get(marketId);
							}
						} else if (market != null) {
							marketId = market.getId() + "";
						}

						if (team == null) {
							if (sp != null) {
								teamId = sp.getTeamId() + "";
								team = idTeamMap.get(teamId);
							}
						} else if (team != null) {
							teamId = team.getId() + "";
						}

						// check whether market or team is expansion or not
						if ((market != null && market.getName().toLowerCase().indexOf("expansion") != -1)
								|| (team != null && team.getName().toLowerCase().indexOf("expansion") != -1)) {
							scoringDto.setAeId("-1");
							scoringDto.setSpId("-1");
							if (dsa != null)
								scoringDto.setDsaId(dsa.getId() + "");
						} else {
							scoringDto.setDsaId("-1");
						}

						scoringDto.setDateOfExecution(dateOfExecution);
						scoringDto.setNameOfProspect(accountName);
						scoringDto.setCreatedBy(createdBy);
						scoringDto.setMarketId(marketId);
						scoringDto.setTeamId(teamId);
						scoringDto.setPesStatus(PesConstants.NEW);
						scoringDto.setActivityId(activityId);

						// PLay specific changes
						scoringDto.setPlayFields(playFields);

						assignPlayExecForScoring(scoringDto);

						notCompletedActivityIds.add(activityId);

						count++;
						LOGGER.info("Record with Account Name : " + accountName + " saved");
					} catch (Exception e) {
						e.printStackTrace();
						LOGGER.error("PesScoringServiceImpl.processWebResearchOTCRecords() - Recordwise : ERROR : "
								+ e.getMessage());
						failedList.add(rec);
					}
				}
				String emails = usermail;
				String subject = "[SUCCESS]SalesForce OTC Web Research report Completion Mail";
				StringBuilder body = new StringBuilder()
						.append("The SalesForce OTC Web Research report has been successfully fetched "
								+ "and the records have been updated.<br>" + "No. of records added : " + count
								+ "<br>");

				if (failedList.size() > 0) {
					subject = "[SUCCESS with FAILURES]SalesForce OTC Web Research report Completion Mail";
					body.append("The following records failed to get added : <br>");
					int failCount = 1;
					for (OTCWebResearchDTO rec : failedList) {
						body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
					}
				}
				emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			String emails = usermail;
			String subject = "[FAILURE]SalesForce OTC Web Research report Completion Failure Mail";
			String body = "The SalesForce OTC Web Research report fetch failed. " + "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processWebResearchOTCRecords() : ERROR : " + er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processWebResearchOTCRecords(): END");
	}

	// processes OTC Whitespace Sales Pipeline report
	// need to work more on this
	@Override
	@Async
	public void processSalesPipelineOTCWhiteSpaceRecords(String usermail, String startDate, String endDate) {
		LOGGER.info("PesScoringServiceImpl.processSalesPipelineOTCWhiteSpaceRecords(): START");

		List<SalesPipelineOTCDTO> failedList = new ArrayList<>();

		try {
			List<SalesPipelineOTCDTO> recordList = new ArrayList<>();
			List<SalesPipelineOTCDTO> recordListAllMarket = null;
			List<SalesPipelineOTCDTO> recordListNaExpansion = null;
			recordListAllMarket = pesSalesForceService.getOTCSalesPipelineReport(startDate, endDate);
			recordListNaExpansion = pesSalesForceService.getOTCSalesPipelineNAExpansionReport(startDate, endDate);
			if (recordListAllMarket != null)
				recordList.addAll(recordListAllMarket);
			if (recordListNaExpansion != null)
				recordList.addAll(recordListNaExpansion);

			if (CollectionUtils.isNotEmpty(recordList)) {
				Play giPlay = playRepository.findByName("OTC Whitespace Analysis - GI Stage");
				Play faPlay = playRepository.findByName("OTC Whitespace Analysis - FA Stage");
				Play webPlay = playRepository.findByName("OTC Whitespace Web Research");
				String createdBy = "SYSTEM";
				List<MapPlayFields> fieldList = mapPlayFieldsRepository.getByPlayId(giPlay.getId());
				int count = 0;

				List<Employee> allSellers = employeeRepository.findAll();
				List<Market> allMarkets = marketRepository.findAll();
				List<Team> allTeams = teamRepository.findAll();
				List<MapFieldOptions> options = fieldOptionsRepo.findAll();

				// maps with 18charId : Object
				Map<String, Team> idTeamMap = new HashMap<>();
				Map<String, Employee> idEmpMap = new HashMap<>();
				Map<String, Market> idMarketMap = new HashMap<>();
				Map<String, MapFieldOptions> nameOptionsMap = new HashMap<>();
				Map<String, Employee> nameEmpMap = new HashMap<>();

				for (Employee emp : allSellers) {
					idEmpMap.put(emp.getSf18CharId(), emp);
					nameEmpMap.put(emp.getFullName(), emp);
				}

				for (Market market : allMarkets) {
					idMarketMap.put(market.getName().toUpperCase(), market);
				}

				for (Team team : allTeams) {
					idTeamMap.put(team.getName().toUpperCase(), team);
				}

				for (MapFieldOptions option : options) {
					String key = option.getFieldId() + "|" + option.getDisplayName();
					nameOptionsMap.put(key, option);
				}

				List<Field> fields = fieldRepository.findAll();
				Map<Long, Field> fieldsMap = new HashMap<Long, Field>();
				for (Field f : fields) {
					fieldsMap.put(f.getId(), f);
				}

				// Get the list of all the activity Id's from the Sales Pipeline OTC Report
				List<String> activityIds = new ArrayList<>();
				for (SalesPipelineOTCDTO record : recordList) {
					activityIds.add(record.getACTIVITY_ID());
				}

				// Get all not completed records from db for the current records fetched from
				// salesforce
				List<TxnPlayExecutions> txnsByActivityId = txnPlayExecRepository.getByActivityIdsPlays(activityIds);

				List<String> uniquePlayActivityIdList = new ArrayList<>();
				for (TxnPlayExecutions txn : txnsByActivityId) {
					uniquePlayActivityIdList.add(txn.getActivityId() + txn.getPlay().getName());
				}

				for (SalesPipelineOTCDTO rec : recordList) {
					try {
						Map<String, String> playFields = new HashMap<>();
						Map<String, String> webPlayFields = new HashMap<>();
						ScoringDTO scoringDto = new ScoringDTO();
						ScoringDTO webResearch = new ScoringDTO();
						ScoringDTO scoringDto2 = new ScoringDTO();

						String accountName = rec.getACCOUNT_NAME();
						String activityId = rec.getACTIVITY_ID();
						String opportunityName = rec.getOPPORTUNITY_NAME();
						String spSf = rec.getSolution_Principal__c();
						String onsiteSpSf = rec.getOnsite_SP__c();
						// dynamic fields
						String aeTeam = rec.getAE_Team__c();
						String valueAlignmentDate = rec.getValue_Alignment_Date__c();
						String functionalAlignmentDate = rec.getFunctional_Allignment_Date__c();
						String generateInterestDate = rec.getGenerate_Interest_Date__c();
						String stageName = rec.getSTAGE_NAME();
						String playName = rec.getPlayName();
						String marketName = "";
						Play play = null;
						if (playName.equals(giPlay.getName())) {
							play = giPlay;
							scoringDto.setDateOfExecution(functionalAlignmentDate);
						} else if (playName.equals(faPlay.getName())) {
							play = faPlay;
							scoringDto.setDateOfExecution(valueAlignmentDate);
						}

						if (play == null)
							continue;

						List<TxnPlayExecutions> updatedTxn = new ArrayList<>();

						String uniqueKey = activityId + playName;
						int activityIndex = uniquePlayActivityIdList.indexOf(uniqueKey);
						if (activityIndex != -1) {
							if (txnsByActivityId.get(activityIndex).getPesStatus().equals(PesConstants.COMPLETED)) {
								LOGGER.info(
										"Discovery STRAP Record with activity Id : " + activityId + " already present");
								continue;
							}
							for (TxnPlayExecutions txn : txnsByActivityId) {
								// Get the all the records fecthed from SalesForce for a particular activityId
								String uniqueIdentifier = txn.getActivityId() + txn.getPlay().getName();
								if (uniqueIdentifier.equals(uniqueKey)) {
									// updating each data record
									List<TxnPlayExecutionData> dataList = txn.getTxnPlayExecutionData();
									for (TxnPlayExecutionData txnData : dataList) {
										Field fld = fieldsMap.get(txnData.getFieldId()); // fieldRepository.getById(txnData.getFieldId());
										if (fld.getFieldName().equals("generateInterestDate")) {
											txnData.setValue(generateInterestDate);
										} else if (fld.getFieldName().equals("functionalAlignmentDate")) {
											txnData.setValue(functionalAlignmentDate);
										} else if (fld.getFieldName().equals("valueAlignmentDate")) {
											txnData.setValue(valueAlignmentDate);
										} else if (fld.getFieldName().equals("stage")) {
											String key = fld.getId() + "|" + stageName;
											if (nameOptionsMap.get(key) != null)
												txnData.setValue(nameOptionsMap.get(key).getId() + "");
										}
									}

									txn.setTxnPlayExecutionData(dataList);
									updatedTxn.add(txn);
									count++;
								}
								txnPlayExecRepository.saveAll(updatedTxn);
								continue;
							}
						}

						// dynamic field end
						scoringDto.setPlayId(play.getId() + "");
						for (MapPlayFields playField : fieldList) {
							Field fld = fieldsMap.get(playField.getFieldId()); // fieldRepository.getById(field.getFieldId());
							if (fld.getFieldName().equals("generateInterestDate"))
								playFields.put(playField.getFieldId() + "", generateInterestDate);
							else if (fld.getFieldName().equals("functionalAlignmentDate"))
								playFields.put(playField.getFieldId() + "", functionalAlignmentDate);
							else if (fld.getFieldName().equals("valueAlignmentDate"))
								playFields.put(playField.getFieldId() + "", valueAlignmentDate);
							else if (fld.getFieldName().equals("aeTeam"))
								playFields.put(playField.getFieldId() + "", aeTeam);
							else if (fld.getFieldName().equals("opportunityName")) {
								playFields.put(playField.getFieldId() + "", opportunityName);
								webPlayFields.put(playField.getFieldId() + "", opportunityName);
							} else if (fld.getFieldName().equals("stage")) {
								String key = fld.getId() + "|" + stageName;
								if (nameOptionsMap.get(key) != null)
									playFields.put(playField.getFieldId() + "", nameOptionsMap.get(key).getId() + "");
							}
						}

						Employee sp = null;
						Employee onsiteSp = null;
						Employee dsa = null;
						if (!StringUtils.isEmpty(spSf)) {
							sp = idEmpMap.get(spSf);
							if (sp == null) {
								sp = nameEmpMap.get(spSf);
							}

							dsa = sp;
						}
						if (!StringUtils.isEmpty(onsiteSpSf)) {
							// checking with full name for now as getting full name from sales force
							onsiteSp = idEmpMap.get(onsiteSpSf);
							if (onsiteSp == null) {
								onsiteSp = nameEmpMap.get(onsiteSpSf);
							}
						}

						if (sp == null)
							LOGGER.info(
									"SP with SF Id : " + spSf + " not present for prospect : " + rec.getACCOUNT_NAME());
						if (onsiteSp == null)
							LOGGER.info("onSite SP with SF Id: " + onsiteSpSf + " not present for prospect : "
									+ rec.getACCOUNT_NAME());

						Market market = idMarketMap.get(
								!StringUtils.isEmpty(rec.getMarketName()) ? rec.getMarketName().toUpperCase() : null);
						String marketId = null;
						Team team = idTeamMap.get(
								!StringUtils.isEmpty(rec.getAE_Team__c()) ? rec.getAE_Team__c().toUpperCase() : null);
						String teamId = null;

						if (market == null) {
							if (sp != null) {
								marketId = sp.getMarketId() + "";
								if (sp.getFnRole().getName().equals("DSA"))
									marketName = "Expansion";
							} else if (onsiteSp != null) {
								marketId = onsiteSp.getMarketId() + "";
							}
						} else if (market != null) {
							marketId = market.getId() + "";
						}

						if (team == null) {
							if (sp != null) {
								teamId = sp.getTeamId() + "";
							} else if (onsiteSp != null) {
								teamId = onsiteSp.getTeamId() + "";
							}
						} else if (team != null) {
							teamId = team.getId() + "";
						}

						// setting the check for expansion markets/ if emp in sp variable is actually
						// DSA
						if ((market != null && market.getName().toLowerCase().indexOf("expansion") != -1)
								|| (team != null && team.getName().toLowerCase().indexOf("expansion") != -1)) {
							scoringDto.setSpId("-1");
							sp = null;
							if (dsa != null)
								scoringDto.setDsaId(dsa.getId() + "");
						} else {
							dsa = null;
							scoringDto.setDsaId("-1");
						}

						if (sp != null) {
							if (sp.getPodLeadId() != null)
								scoringDto.setPodLeadId(sp.getPodLeadId() + "");
							scoringDto.setSpId(sp.getId() + "");
						}
						if (dsa != null) {
							if (dsa.getPodLeadId() != null)
								scoringDto.setPodLeadId(dsa.getPodLeadId() + "");
							scoringDto.setDsaId(dsa.getId() + "");
						}
						if (onsiteSp != null)
							scoringDto.setOnSiteSpId(onsiteSp.getId() + "");

						scoringDto.setNameOfProspect(accountName);
						scoringDto.setCreatedBy(createdBy);
						scoringDto.setPesStatus(PesConstants.NEW);
						scoringDto.setActivityId(activityId);
						scoringDto.setMarketId(marketId);
						scoringDto.setTeamId(teamId);

						// PLay specific changes
						scoringDto.setPlayFields(playFields);
						assignPlayExecForScoring(scoringDto);
						boolean isGenerateInterestDatePresent = !StringUtils.isEmpty(generateInterestDate);
						boolean isFunctionalAlignmentDatePresent = !StringUtils.isEmpty(functionalAlignmentDate);
						boolean isValueAlignmentDatePresent = !StringUtils.isEmpty(valueAlignmentDate);
						if ((isGenerateInterestDatePresent && isFunctionalAlignmentDatePresent
								&& isValueAlignmentDatePresent) && generateInterestDate.equals(functionalAlignmentDate)
								&& functionalAlignmentDate.equals(valueAlignmentDate)) {
							LOGGER.info("Generating 3 OTC records for " + scoringDto.getNameOfProspect() + " FA Date : "
									+ functionalAlignmentDate + " VA Date : " + valueAlignmentDate + " GI Date : "
									+ generateInterestDate);
							webResearch.copy(scoringDto);
							webResearch.setPlayId(webPlay.getId() + "");
							webResearch.setPlayFields(webPlayFields);
							assignPlayExecForScoring(webResearch);
							scoringDto2.copy(scoringDto);
							scoringDto2.setPlayId(giPlay.getId() + "");
							scoringDto2.setPlayFields(playFields);
							assignPlayExecForScoring(scoringDto2);
						}
						// checking through play name as for case where gidate + fadate > vadate
						else if ((isGenerateInterestDatePresent && isFunctionalAlignmentDatePresent)
								&& generateInterestDate.equals(functionalAlignmentDate)
								&& scoringDto.getPlayId().equals(giPlay.getId() + "")) {

							LOGGER.info("Generating OTC fa and gi records for " + scoringDto.getNameOfProspect()
									+ " FA Date : " + functionalAlignmentDate + " GI Date : " + generateInterestDate);
							webResearch.copy(scoringDto);
							webResearch.setPlayId(webPlay.getId() + "");
							webResearch.setPlayFields(webPlayFields);
							assignPlayExecForScoring(webResearch);
						} else if ((isFunctionalAlignmentDatePresent && isValueAlignmentDatePresent)
								&& functionalAlignmentDate.equals(valueAlignmentDate)
								&& scoringDto.getPlayId().equals(faPlay.getId() + "")) {

							LOGGER.info("Generating OTC gi and web records for " + scoringDto.getNameOfProspect()
									+ " FA Date : " + functionalAlignmentDate + " VA Date : " + valueAlignmentDate);
							scoringDto2.copy(scoringDto);
							scoringDto2.setPlayId(giPlay.getId() + "");
							scoringDto2.setPlayFields(playFields);
							assignPlayExecForScoring(scoringDto2);
						}
						count++;
						LOGGER.info("Record with Account Name : " + accountName + " saved");

					} catch (Exception e) {
						e.printStackTrace();
						LOGGER.error(
								"PesScoringServiceImpl.processSalesPipelineOTCWhiteSpaceRecords() - Recordwise : ERROR : "
										+ e.getMessage());
						failedList.add(rec);
					}
				}
				String emails = usermail;
				String subject = "[SUCCESS]SalesForce OTC SalesPipeline report Completion Mail";
				StringBuilder body = new StringBuilder()
						.append("The SalesForce OTC SalesPipeline report has been successfully fetched "
								+ "and the records have been updated.<br>" + "No. of records added/updated : " + count
								+ "<br>");

				if (failedList.size() > 0) {
					subject = "[SUCCESS with FAILURES]SalesForce OTC SalesPipeline report Completion Mail";
					body.append("\"The following records failed to get added : <br>");
					int failCount = 1;
					for (SalesPipelineOTCDTO rec : failedList) {
						body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
					}
				}
				emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			String emails = usermail;
			String subject = "[FAILURE]SalesForce OTC SalesPipeline report Completion Failure Mail";
			String body = "The SalesForce OTC SalesPipeline report fetch failed. "
					+ "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processSalesPipelineOTCWhiteSpaceRecords() : ERROR : "
						+ er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processSalesPipelineOTCWhiteSpaceRecords(): END");
	}

	// CPR SIH records fetch from google sheet once every monday
	@Override
	@Async
	public void processCPRSIHRecords(String usermail, String startDate, String endDate) {
		LOGGER.info("PesScoringServiceImpl.processSTRAPRecords(): START");
		try {
			java.util.Date stDate = null;
			java.util.Date edDate = null;
			if (!StringUtils.isEmpty(startDate))
				stDate = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
			if (!StringUtils.isEmpty(endDate))
				edDate = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
			// we get CPRSIH data from google sheet, sheet id present in db.
			List<CPR_SIHDTO> recordList = gsheetUtil.getCPRSIHData(stDate, edDate);
			List<CPR_SIHDTO> failedList = new ArrayList<>();
			Play cprPlay = playRepository.findByName("Company and People Research (CPR)");
			Play sihPlay = playRepository.findByName("Sales Interaction History (SIH)");
			String createdBy = "SYSTEM";
			int count = 0;

			List<Employee> allEmp = employeeRepository.findAll();
			List<Market> allMarkets = marketRepo.findAll();
			List<Team> allTeams = teamRepo.findAll();
			List<Long> playIds = new ArrayList<>();
			playIds.add(cprPlay.getId());
			playIds.add(sihPlay.getId());
			Map<String, Employee> sellerMap = new HashMap<>();
			Map<String, Employee> podLeadMap = new HashMap<>();
			Map<String, Market> marketMap = new HashMap<>();
			Map<String, Team> teamMap = new HashMap<>();

			for (Employee emp : allEmp) {
				if (emp.getFnRole().getName().equals("POD Lead"))
					podLeadMap.put(emp.getFullName(), emp);
				else
					sellerMap.put(emp.getFullName(), emp);
			}

			for (Market market : allMarkets) {
				marketMap.put(market.getName(), market);
			}
			for (Team team : allTeams) {
				teamMap.put(team.getName(), team);
			}

			// iterating through the record list
			for (CPR_SIHDTO rec : recordList) {
				try {
					ScoringDTO cprPlayAE = new ScoringDTO();
					ScoringDTO cprPlaySP = new ScoringDTO();
					ScoringDTO sihPlayDto = new ScoringDTO();
					Map<String, String> playFields = new HashMap<>();
					String dateOfExecution = "";
					String marketName = rec.getMarket();
					Market market = marketMap.get(marketName);
					String accountName = rec.getNameOfProspect();
					String aeName = rec.getAE();
					String spName = rec.getSP();
					String aePodLead = rec.getAePodLead();
					String spPodLead = rec.getSpPodLead();
					String aeTeam = rec.getAeTeam();
					String spTeam = rec.getSpTeam();
					String docUrl = rec.getDocUrl();
					if (!StringUtils.isEmpty(rec.getDateOfExecution()))
						dateOfExecution = rec.getDateOfExecution();

					String marketId = "";
					String aeTeamId = "";
					String spTeamId = "";

					// setting values for the cprPlayAE and SP records
					cprPlayAE.setPlayId(cprPlay.getId() + "");
					cprPlaySP.setPlayId(cprPlay.getId() + "");
					sihPlayDto.setPlayId(sihPlay.getId() + "");
					cprPlayAE.setPlayFields(playFields);
					cprPlaySP.setPlayFields(playFields);
					sihPlayDto.setPlayFields(playFields);
					cprPlayAE.setDateOfExecution(dateOfExecution);
					cprPlaySP.setDateOfExecution(dateOfExecution);
					sihPlayDto.setDateOfExecution(dateOfExecution);
					cprPlayAE.setNameOfProspect(accountName);
					cprPlaySP.setNameOfProspect(accountName);
					sihPlayDto.setNameOfProspect(accountName);
					if (market != null) {
						cprPlayAE.setMarketId(market.getId() + "");
						cprPlaySP.setMarketId(market.getId() + "");
						sihPlayDto.setMarketId(market.getId() + "");
					}
					cprPlayAE.setDocLink(docUrl);
					cprPlaySP.setDocLink(docUrl);
					sihPlayDto.setDocLink(docUrl);
					cprPlayAE.setCreatedBy(createdBy);
					cprPlaySP.setCreatedBy(createdBy);
					sihPlayDto.setCreatedBy(createdBy);

					Employee sp = null;
					Employee ae = null;
					String aeLeadId = null;
					String spLeadId = null;

					if (!StringUtils.isEmpty(spName))
						sp = sellerMap.get(spName);
					if (!StringUtils.isEmpty(aeName))
						ae = sellerMap.get(aeName);
					if (!StringUtils.isEmpty(aePodLead)) {
						if (podLeadMap.get(aePodLead) != null)
							aeLeadId = podLeadMap.get(aePodLead).getId() + "";
					}
					if (!StringUtils.isEmpty(spPodLead)) {
						if (podLeadMap.get(spPodLead) != null)
							spLeadId = podLeadMap.get(spPodLead).getId() + "";
					}

					if (ae == null)
						LOGGER.info("SP with SF Name : " + aeName + " not present for prospect : "
								+ rec.getNameOfProspect());

					if (sp == null)
						LOGGER.info("SP with SF Name : " + spName + " not present for prospect : "
								+ rec.getNameOfProspect());

					// market logic for getting markets
					if (market == null) {
						if (ae != null) {
							marketId = ae.getMarketId() + "";
						}
					} else if (market != null) {
						marketId = market.getId() + "";
					}
					cprPlayAE.setMarketId(marketId);
					cprPlaySP.setMarketId(marketId);
					sihPlayDto.setMarketId(marketId);
					// adding None for making plays seller specific.
					cprPlayAE.setSpId(-1 + "");
					cprPlaySP.setAeId(-1 + "");

					if (ae != null) {
						cprPlayAE.setAeId(ae.getId() + "");
						sihPlayDto.setAeId(ae.getId() + "");
						if (aeLeadId == null && ae.getPodLeadId() != null)
							aeLeadId = ae.getPodLeadId() + "";
						if (!StringUtils.isEmpty(aeTeam)) {
							if (teamMap.get(aeTeam) != null)
								aeTeamId = teamMap.get(aeTeam).getId() + "";
						}
					}

					if (sp != null) {
						cprPlaySP.setSpId(sp.getId() + "");
						if (spLeadId == null && sp.getPodLeadId() != null)
							spLeadId = sp.getPodLeadId() + "";
						if (!StringUtils.isEmpty(spTeam)) {
							if (teamMap.get(spTeam) != null)
								spTeamId = teamMap.get(spTeam).getId() + "";
						}
					}

					cprPlayAE.setPodLeadId(aeLeadId);
					sihPlayDto.setPodLeadId(aeLeadId);
					cprPlayAE.setTeamId(aeTeamId);
					sihPlayDto.setTeamId(aeTeamId);
					cprPlaySP.setPodLeadId(spLeadId);
					cprPlaySP.setTeamId(spTeamId);

					cprPlayAE.setPesStatus(PesConstants.NEW);
					cprPlaySP.setPesStatus(PesConstants.NEW);
					sihPlayDto.setPesStatus(PesConstants.NEW);

					if (!aeName.equals("No Scoring Due to PTO")) {
						assignPlayExecForScoring(cprPlayAE);
						assignPlayExecForScoring(sihPlayDto);
					}
					if (!spName.equals("No Scoring Due to PTO"))
						assignPlayExecForScoring(cprPlaySP);
					count++;
					LOGGER.info("Record with Account Name : " + accountName + " saved");
				} catch (Exception e) {
					e.printStackTrace();
					LOGGER.error(
							"PesScoringServiceImpl.processCPRSIHRecords() - recordwise : ERROR : " + e.getMessage());
					failedList.add(rec);
				}
			}
			String emails = usermail;
			String subject = "[SUCCESS]CPR and SIH report Completion Mail";
			StringBuilder body = new StringBuilder().append("The CPR and SIH report has been successfully fetched "
					+ "and the records have been updated.<br>" + "No. of records added : " + count + "<br>");

			if (failedList.size() > 0) {
				subject = "[SUCCESS with FAILURES]CPR and SIH report Completion Mail";
				body.append("\"The following records failed to get added : <br>");
				int failCount = 1;
				for (CPR_SIHDTO rec : failedList) {
					body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
				}
			}

			emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
		} catch (Exception e) {
			e.printStackTrace();
			String emails = usermail;
			String subject = "[FAILURE]The CPR and SIH report Completion Failure Mail";
			String body = "The CPR and SIH report fetch failed. " + "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processCPRSIHRecords() : ERROR : " + er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processCPRSIHRecords(): END");
	}

	/*
	 * function to fetch STRAP records from Salesforce, different from DC STRAP
	 */
	@Override
	@Async
	public void processSTRAPRecords(String usermail, String startDate, String endDate) {
		LOGGER.info("PesScoringServiceImpl.processSTRAPRecords(): START");
		try {
			// get the strap report list
			List<STRAP_DTO> recordListRest = pesSalesForceService.getSTRAPReport(startDate, endDate);
			// Get the Strap Expansion list
			List<STRAP_DTO> recordListExpansion = pesSalesForceService.getSTRAPReportForExpansion(startDate, endDate);
			// Make third Array list to add the records from both the lists
			List<STRAP_DTO> recordList = new ArrayList<>();
			List<STRAP_DTO> failedList = new ArrayList<>();

			if (recordListRest != null)
				recordList.addAll(recordListRest);
			if (recordListExpansion != null)
				recordList.addAll(recordListExpansion);
			// get strapPlay
			Play strapPlay = playRepository.findByName("STRAP");
			List<MapPlayFields> fieldList = mapPlayFieldsRepository.getByPlayId(strapPlay.getId());
			List<MapFieldOptions> options = fieldOptionsRepo.findAll();
			String createdBy = "SYSTEM";
			int count = 0;
			// Get all the employees/markets/teams from repo
			List<Employee> allEmp = employeeRepository.findAll();
			List<Market> allMarkets = marketRepo.findAll();
			List<Team> allTeams = teamRepo.findAll();
			Map<String, Employee> sellerMap = new HashMap<>();
			Map<String, Employee> podLeadMap = new HashMap<>();
			Map<String, Market> nameMarketMap = new HashMap<>();
			Map<String, Market> idMarketMap = new HashMap<>();
			Map<String, Team> nameTeamMap = new HashMap<>();
			Map<String, Team> idTeamMap = new HashMap<>();
			Map<String, MapFieldOptions> nameOptionsMap = new HashMap<>();
			Map<String, Employee> sellerNameMap = new HashMap<>();

			List<Field> fields = fieldRepository.findAll();
			Map<Long, Field> fieldsMap = new HashMap<Long, Field>();

			for (Employee emp : allEmp) {
				if (emp.getFnRole().getName().equals("POD Lead"))
					podLeadMap.put(emp.getSf18CharId(), emp);
				else
					sellerMap.put(emp.getSf18CharId(), emp);
				sellerNameMap.put(emp.getFullName(), emp);

			}

			for (Market market : allMarkets) {
				nameMarketMap.put(market.getName().toUpperCase(), market);
				idMarketMap.put(market.getId().toString(),market);
			}
			for (Team team : allTeams) {
				nameTeamMap.put(team.getName().toUpperCase(), team);
				idTeamMap.put(team.getId().toString(), team);
			}

			for (MapFieldOptions option : options) {
				String key = option.getFieldId() + "|" + option.getDisplayName();
				nameOptionsMap.put(key, option);
			}

			for (Field f : fields) {
				fieldsMap.put(f.getId(), f);
			}

			// iterating through records of STRAP fetched from Salesforce
			for (STRAP_DTO rec : recordList) {
				try {
					// Make new object Scoring DTO,set
					ScoringDTO strap = new ScoringDTO();
					Map<String, String> playFields = new HashMap<>();
					// Get the fields from the report
					String dateOfExecution = "";
					String marketName = rec.getMarket();
					String teamName = rec.getAETeam();
					Market market = nameMarketMap.get(!StringUtils.isEmpty(marketName) ? marketName.toUpperCase() : null);
					Team team = nameTeamMap.get(!StringUtils.isEmpty(teamName) ? teamName.toUpperCase() : null);
					String accountName = rec.getAccountName();
					String aeName = rec.getAE();
					String spName = rec.getSP();
					String onsiteSpName = rec.getOnsiteSP();
					String aeTeam = rec.getAETeam();
					String opportunityName = rec.getOpportunityName();
					String stageName = rec.getStageName();
					String docLink = rec.getStrapOpiumLink();
					String activityId = rec.getActivityId();
					String strapId = rec.getStrapId();
					if (!StringUtils.isEmpty(rec.getDateOfExecution()))
						dateOfExecution = rec.getDateOfExecution();

					String marketId = "";
					String teamId = "";

					Employee sp = null;
					Employee ae = null;
					Employee onsiteSP = null;

					String spId = "";
					String aeId = "";
					String onsiteSpId = "";
					String dtaId = "";
					String dsaId = "";

					// play specific fields for STRAP

					if (!StringUtils.isEmpty(spName)) {
						sp = sellerMap.get(spName);
						if (sp == null) 
							sp = sellerNameMap.get(spName);							
						if (sp != null)
							spId = sp.getId().toString();
						dsaId = spId;
					}
					if (!StringUtils.isEmpty(aeName)) {
						ae = sellerMap.get(aeName);
						if (ae == null)
							ae = sellerNameMap.get(aeName);
						if (ae != null) {
							aeId = ae.getId().toString();
							dtaId = aeId;
						}
					}
					if (!StringUtils.isEmpty(onsiteSpName)) {
						onsiteSP = sellerMap.get(onsiteSpName);
						if (onsiteSP == null)
							onsiteSP = sellerNameMap.get(onsiteSpName);
						if (onsiteSP != null)
							onsiteSpId = onsiteSP.getId().toString();
					}

					if (ae == null)
						LOGGER.info(
								"SP with SF Name : " + aeName + " not present for prospect : " + rec.getAccountName());

					if (sp == null)
						LOGGER.info(
								"SP with SF Name : " + spName + " not present for prospect : " + rec.getAccountName());

					if (onsiteSP == null)
						LOGGER.info("SP with SF Name : " + onsiteSpName + " not present for prospect : "
								+ rec.getAccountName());

					for (MapPlayFields playField : fieldList) {
						Field fld = fieldsMap.get(playField.getFieldId()); // fieldRepository.getById(field.getFieldId());
						if (fld.getFieldName().equals("strapId")) {
							playFields.put(playField.getFieldId() + "", strapId);
						} else if (fld.getFieldName().equals("aeTeam") && aeTeam != null)
							playFields.put(playField.getFieldId() + "", aeTeam);
						else if (fld.getFieldName().equals("opportunityName") && opportunityName != null) {
							playFields.put(playField.getFieldId() + "", opportunityName);
						} else if (fld.getFieldName().equals("opportunityOwner") && ae != null) {
							playFields.put(playField.getFieldId() + "", ae.getFullName());
						} else if (fld.getFieldName().equals("stage")) {
							String key = fld.getId() + "|" + stageName;
							if (nameOptionsMap.get(key) != null)
								playFields.put(playField.getFieldId() + "", nameOptionsMap.get(key).getId() + "");
						}
					}

					// market logic for getting markets
					if (market == null) {
						if (ae != null) {
							marketId = ae.getMarketId() + "";
							market = idMarketMap.get(marketId);
						}
					} else if (market != null) {
						marketId = market.getId() + "";
					}

					if (team == null) {
						if (ae != null) {
							teamId = ae.getTeamId().toString();
							team = idTeamMap.get(teamId);
						}
					} else if (team != null)
						teamId = team.getId().toString();
		
					if ((market != null && market.getName().toLowerCase().indexOf("expansion") != -1)
							|| (team != null && team.getName().toLowerCase().indexOf("expansion") != -1)) {
						aeId = "-1";
						spId = "-1";
					} else {
						dtaId = "-1";
						dsaId = "-1";
					}

					// Set values to ScoringDTO
					strap.setActivityId(activityId);
					strap.setPlayId(strapPlay.getId().toString());
					strap.setNameOfProspect(accountName);
					strap.setDateOfExecution(dateOfExecution);
					strap.setDocLink(docLink);
					strap.setMarketId(marketId);
					strap.setTeamId(teamId);
					strap.setAeId(aeId);
					strap.setSpId(spId);
					strap.setDtaId(dtaId);
					strap.setDsaId(dsaId);
					strap.setOnSiteSpId(onsiteSpId);
					strap.setPesStatus(PesConstants.NEW);
					strap.setPlayFields(playFields);
					strap.setCreatedBy(createdBy);

					// Call assign function with Scoring DTO
					assignPlayExecForScoring(strap);
					count++;
					LOGGER.info("Record with Account Name : " + accountName + " saved");
				} catch (Exception e) {
					e.printStackTrace();
					LOGGER.error(
							"PesScoringServiceImpl.processSTRAPRecords() - recordwise : ERROR : " + e.getMessage());
					failedList.add(rec);
				}
			}
			// Prepare Mail data
			String emails = usermail;
			String subject = "[SUCCESS]STRAP report Completion Mail";
			StringBuilder body = new StringBuilder().append("The STRAP report has been successfully fetched "
					+ "and the records have been updated.<br>" + "No. of records added : " + count + "<br>");

			if (failedList.size() > 0) {
				subject = "[SUCCESS with FAILURES]STRAP report Completion Mail";
				body.append("\"The following records failed to get added : <br>");
				int failCount = 1;
				for (STRAP_DTO rec : failedList) {
					body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
				}
			}
			emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
		} catch (Exception e) {
			e.printStackTrace();
			String emails = usermail;
			String subject = "[FAILURE]The STRAP report Completion Failure Mail";
			String body = "The STRAP report fetch failed. " + "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processSTRAPRecords() : ERROR : " + er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processSTRAPRecords(): END");
	}

	/*
	 * function to fetch Champions and ZZTop plays from salesforce and gsheet
	 */
	@Override
	@Async
	public void processChampionsnZZTop(String usermail) {
		LOGGER.info("PesScoringServiceImpl.processChampionsnZZTop(): START");
		try {
			// salesforce fetch, opportunity based
			List<ChampionsnZZTopDTO> sfdcRecordList = pesSalesForceService.getChampionsnZZTopReport();
			List<ChampionsnZZTopDTO> gsheetRecordList = gsheetUtil.getChampionsnZZTopExpansionData(null, null);
			List<ChampionsnZZTopDTO> recordList = new ArrayList<>();

			// compiling all the fetched records
			if (sfdcRecordList != null)
				recordList.addAll(sfdcRecordList);
			if (gsheetRecordList != null)
				recordList.addAll(gsheetRecordList);
			List<ChampionsnZZTopDTO> failedList = new ArrayList<>();
			Play championsPlay = playRepository.findByName("Champions");
			Play zzTopPlay = playRepository.findByName("ZZTop");
			List<MapPlayFields> fieldList = mapPlayFieldsRepository.getByPlayId(championsPlay.getId());
			List<MapFieldOptions> options = fieldOptionsRepo.findAll();
			String createdBy = "SYSTEM";

			int count = 0;

			List<Employee> allEmp = employeeRepository.findAll();
			List<Market> allMarkets = marketRepo.findAll();
			List<Team> allTeams = teamRepo.findAll();
			List<Long> playIds = new ArrayList<>();
			playIds.add(championsPlay.getId());
			playIds.add(zzTopPlay.getId());
			Map<String, MapFieldOptions> nameOptionsMap = new HashMap<>();
			// for salesforce
			Map<String, Employee> sellerMap = new HashMap<>();
			// for gsheet which contains emp names
			Map<String, Employee> sellerNameMap = new HashMap<>();
			Map<String, Employee> podLeadMap = new HashMap<>();
			Map<String, Market> marketMap = new HashMap<>();
			Map<String, Team> teamMap = new HashMap<>();
			List<Field> fields = fieldRepository.findAll();
			Map<Long, Field> fieldsMap = new HashMap<Long, Field>();

			for (Employee emp : allEmp) {
				if (emp.getFnRole().getName().equals("POD Lead"))
					podLeadMap.put(emp.getFullName(), emp);
				else {
					sellerMap.put(emp.getSf18CharId(), emp);
					sellerNameMap.put(emp.getFullName(), emp);
				}
			}

			for (Market market : allMarkets) {
				marketMap.put(market.getName().toUpperCase(), market);
			}
			for (Team team : allTeams) {
				teamMap.put(team.getName().toUpperCase(), team);
			}

			for (MapFieldOptions option : options) {
				String key = option.getFieldId() + "|" + option.getDisplayName();
				nameOptionsMap.put(key, option);
			}

			for (Field f : fields) {
				fieldsMap.put(f.getId(), f);
			}

			// iterating through all fetched records
			int countChampion = 0;
			int countZZ = 0;
			for (ChampionsnZZTopDTO rec : recordList) {
				try {
					ScoringDTO champions = new ScoringDTO();
					ScoringDTO zzTop = new ScoringDTO();
					Map<String, String> playFields = new HashMap<>();
					Map<String, String> playFieldsForZZ = new HashMap<>();
					String marketName = rec.getMarket();
					String teamName = rec.getAETeam();
					Market market = marketMap.get(!StringUtils.isEmpty(marketName) ? marketName.toUpperCase() : null);
					Team team = teamMap.get(!StringUtils.isEmpty(teamName) ? teamName.toUpperCase() : null);
					String accountName = rec.getAccountName();
					String aeName = rec.getAE();
					String spName = rec.getSP();
					String aeTeam = rec.getAETeam();
					String marketId = "";
					String teamId = "";
					String aeId = "";
					String spId = "";
					String dtaId = "";
					String podLeadId = "";
					String stageName = rec.getStageName();
					String dateOfExec = "";
					int stageNum = 0;
					if (!StringUtils.isEmpty(stageName)) {
						String stageNumString = stageName.substring(0, 1);
						stageNum = Integer.parseInt(stageNumString);
					}
					String opportunityName = rec.getOpportunityName();
					String opportunityId = rec.getOpportunityId();
					String playName = rec.getPlayName();
					String docLink = "";
					if (rec.getPodLeadSFId() != null && podLeadMap.get(rec.getPodLeadSFId()) != null) {
						podLeadId = podLeadMap.get(rec.getPodLeadSFId()).getId().toString();
					}

					if (!StringUtils.isEmpty(opportunityId))
						docLink = "https://highradius.lightning.force.com/lightning/r/Opportunity/" + opportunityId
								+ "/view";
					if (rec.getDateOfExecution() != null)
						dateOfExec = rec.getDateOfExecution();
					if (team != null)
						teamId = team.getId() + "";

					Employee sp = null;
					Employee ae = null;

					if (!StringUtils.isEmpty(spName)) {
						sp = sellerMap.get(spName);
						if (sp == null)
							sp = sellerNameMap.get(spName);
						if (sp != null)
							spId = sp.getId().toString();
					}
					if (!StringUtils.isEmpty(aeName)) {
						ae = sellerMap.get(aeName);
						if (ae == null)
							ae = sellerNameMap.get(aeName);
						if (ae != null) {
							aeId = ae.getId().toString();
							dtaId = aeId;
						}
					}

					if (ae == null)
						LOGGER.info(
								"AE with SF Name : " + aeName + " not present for prospect : " + rec.getAccountName());

					if (sp == null)
						LOGGER.info(
								"SP with SF Name : " + spName + " not present for prospect : " + rec.getAccountName());

					if (market != null) {
						marketId = market.getId() + "";
					}

					if ((market != null && market.getName().toLowerCase().indexOf("expansion") != -1)
							|| (team != null && team.getName().toLowerCase().indexOf("expansion") != -1)) {

						aeId = "-1";
					} else {
						dtaId = "-1";
					}

					for (MapPlayFields playField : fieldList) {
						Field fld = fieldsMap.get(playField.getFieldId()); // fieldRepository.getById(field.getFieldId());
						if (fld.getFieldName().equals("aeTeam") && !StringUtils.isEmpty(aeTeam)) {
							playFields.put(playField.getFieldId() + "", aeTeam);
							playFieldsForZZ.put(playField.getFieldId() + "", aeTeam);
						} else if (fld.getFieldName().equals("opportunityName")
								&& !StringUtils.isEmpty(opportunityName)) {
							playFields.put(playField.getFieldId() + "", opportunityName);
							playFieldsForZZ.put(playField.getFieldId() + "", opportunityName);
						} else if (fld.getFieldName().equals("opportunityOwner") && ae != null) {
							playFields.put(playField.getFieldId() + "", ae.getFullName());
							playFieldsForZZ.put(playField.getFieldId() + "", ae.getFullName());
						} else if (fld.getFieldName().equals("stage") && !StringUtils.isEmpty(stageName)) {
							String key = fld.getId() + "|" + stageName;
							if (nameOptionsMap.get(key) != null) {
								playFields.put(playField.getFieldId() + "", nameOptionsMap.get(key).getId() + "");
								playFieldsForZZ.put(playField.getFieldId() + "", nameOptionsMap.get(key).getId() + "");
							}
						}
					}

					/*
					 * Criteria for champion play stage >= 3 For account based records from gsheet
					 * we set the playName during fetch depending upon sheet of fetch
					 */
					if ((!StringUtils.isEmpty(playName) && playName.equals("Champions"))
							|| (stageNum != 0 && stageNum >= 3)) {
						champions.setPlayId(championsPlay.getId().toString());
						champions.setNameOfProspect(accountName);
						champions.setDocLink(docLink);
						champions.setMarketId(marketId);
						champions.setTeamId(teamId);
						champions.setAeId(aeId);
						champions.setSpId(spId);
						champions.setDtaId(dtaId);
						champions.setPesStatus(PesConstants.NEW);
						champions.setPlayFields(playFields);
						champions.setPodLeadId(podLeadId);
						champions.setCreatedBy(createdBy);
						champions.setDateOfExecution(dateOfExec);
						assignPlayExecForScoring(champions);
						count++;
						++countChampion;
					}
					/*
					 * Criteria for zztop play stage >= 4 For account based records from gsheet we
					 * set the playName during fetch depending upon sheet of fetch
					 */
					if ((!StringUtils.isEmpty(playName) && playName.equals("ZZTop"))
							|| (stageNum != 0 && stageNum >= 4)) {
						zzTop.setPlayId(zzTopPlay.getId().toString());
						zzTop.setNameOfProspect(accountName);
						zzTop.setDocLink(docLink);
						zzTop.setMarketId(marketId);
						zzTop.setTeamId(teamId);
						zzTop.setAeId(aeId);
						zzTop.setSpId(spId);
						zzTop.setDtaId(dtaId);
						zzTop.setPesStatus(PesConstants.NEW);
						zzTop.setPlayFields(playFieldsForZZ);
						zzTop.setCreatedBy(createdBy);
						zzTop.setPodLeadId(podLeadId);
						zzTop.setDateOfExecution(dateOfExec);
						assignPlayExecForScoring(zzTop);
						count++;
						++countZZ;
					}
					LOGGER.info("Record with Account Name : " + accountName + " saved");
				} catch (Exception e) {
					e.printStackTrace();
					LOGGER.error("PesScoringServiceImpl.processChampionnZZTopRecords() - recordwise : ERROR : "
							+ e.getMessage());
					failedList.add(rec);
				}
			}
			System.out.println("Champions count : " + countChampion);
			System.out.println("ZZTop count : " + countZZ);
			String emails = usermail;
			String subject = "[SUCCESS]Champions and ZZTop report Completion Mail";
			StringBuilder body = new StringBuilder()
					.append("The Champions and ZZTop report has been successfully fetched "
							+ "and the records have been updated.<br>" + "No. of records added : " + count + "<br>");

			if (failedList.size() > 0) {
				subject = "[SUCCESS with FAILURES]Champions and ZZTop report Completion Mail";
				body.append("\"The following records failed to get added : <br>");
				int failCount = 1;
				for (ChampionsnZZTopDTO rec : failedList) {
					body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
				}
			}

			emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
		} catch (Exception e) {
			e.printStackTrace();
			String emails = usermail;
			String subject = "Champions and ZZTop report Completion Failure Mail";
			String body = "Champions and ZZTop report fetch failed. " + "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processChampionnZZTopRecords() : ERROR : " + er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processChampionnZZTopRecords(): END");
	}

	/*
	 * Steps for Demo -Get the sf data -create scoring objects -send the scoring
	 * objects for assign
	 */
	@Override
	@Async
	public void processDemoPlay(String usermail, String startDate, String endDate) {
		LOGGER.info("PesScoringServiceImpl.processDemoPlay(): START");
		try {
			List<Demo_Play_DTO> recordList = pesSalesForceService.getDEMOReport(null, null);
			List<Demo_Play_DTO> failedList = new ArrayList<>();
			
			if (CollectionUtils.isNotEmpty(recordList)) {
				Play demoPlay = playRepository.findByName("DEMO");
				List<MapPlayFields> fieldList = mapPlayFieldsRepository.getByPlayId(demoPlay.getId());
				List<MapFieldOptions> options = fieldOptionsRepo.findAll();

				String createdBy = "SYSTEM";

				int count = 0;

				List<Employee> allEmp = employeeRepository.findAll();
				List<Market> allMarkets = marketRepo.findAll();
				List<Team> allTeams = teamRepo.findAll();
				Map<String, MapFieldOptions> nameOptionsMap = new HashMap<>();
				// for salesforce
				Map<String, Employee> sellerMap = new HashMap<>();
				// for gsheet which contains emp names
				Map<String, Employee> sellerNameMap = new HashMap<>();
				Map<String, Employee> podLeadMap = new HashMap<>();
				Map<String, Market> marketMap = new HashMap<>();
				Map<String, Team> teamMap = new HashMap<>();
				List<Field> fields = fieldRepository.findAll();
				Map<Long, Field> fieldsMap = new HashMap<Long, Field>();

				for (Employee emp : allEmp) {
					if (emp.getFnRole().getName().equals("POD Lead"))
						podLeadMap.put(emp.getFullName(), emp);
					else {
						sellerMap.put(emp.getSf18CharId(), emp);
						sellerNameMap.put(emp.getFullName(), emp);
					}
				}

				for (Market market : allMarkets) {
					marketMap.put(market.getName().toUpperCase(), market);
				}
				for (Team team : allTeams) {
					teamMap.put(team.getName().toUpperCase(), team);
				}

				for (MapFieldOptions option : options) {
					String key = option.getFieldId() + "|" + option.getDisplayName();
					nameOptionsMap.put(key, option);
				}

				for (Field f : fields) {
					fieldsMap.put(f.getId(), f);
				}

				// Get the list of all the activity Id's from the OTC Report
				List<String> activityIds = new ArrayList<>();
				for (Demo_Play_DTO record : recordList) {
					activityIds.add(record.getActivityId());
				}

				// Get all not completed records from db for the current records fetched from
				// salesforce
				List<String> notCompletedActivityIds = txnPlayExecRepository.getNotCompletedByDemoPlay(activityIds);

				for (Demo_Play_DTO rec : recordList) {
					try {
						ScoringDTO demo = new ScoringDTO();
						Map<String, String> playFields = new HashMap<>();
						String marketName = rec.getMarket();
						String teamName = rec.getAETeam();
						Market market = marketMap
								.get(!StringUtils.isEmpty(marketName) ? marketName.toUpperCase() : null);
						Team team = teamMap.get(!StringUtils.isEmpty(teamName) ? teamName.toUpperCase() : null);
						String accountName = rec.getAccountName();
						String aeName = rec.getAE();
						String spName = rec.getSP();
						String onsiteSPName = rec.getOnsiteSP();
						String aeTeam = rec.getAETeam();
						String marketId = "";
						String teamId = "";
						String aeId = "";
						String spId = "";
						String onsiteSpId = "";
						String dsaId = "";
						String podLeadId = "";
						String stageName = rec.getStageName();
						String dateOfExec = "";
						String activityId = rec.getActivityId();

						// Check for non completed records present in db for the records received from
						// saleforce
						if (notCompletedActivityIds.indexOf(activityId) != -1) {
							LOGGER.info("Record already existis with the activity ID : " + activityId);
							continue;
						}

						String opportunityName = rec.getOpportunityName();
						String docLink = "";

						if (rec.getDateOfExecution() != null)
							dateOfExec = rec.getDateOfExecution();
						if (team != null)
							teamId = team.getId() + "";

						Employee sp = null;
						Employee ae = null;
						Employee onsiteSp = null;

						if (!StringUtils.isEmpty(spName)) {
							sp = sellerMap.get(spName);
							if (sp == null)
								sp = sellerNameMap.get(spName);
							if (sp != null) {
								spId = sp.getId().toString();
								dsaId = spId;
								if (StringUtils.isEmpty(podLeadId) && sp.getPodLeadId() != null)
									podLeadId = sp.getPodLeadId().toString();
							}
						}
						if (!StringUtils.isEmpty(aeName)) {
							ae = sellerMap.get(aeName);
							if (ae == null)
								ae = sellerNameMap.get(aeName);
							if (ae != null) {
								aeId = ae.getId().toString();
							}
						}

						if (!StringUtils.isEmpty(onsiteSPName)) {
							onsiteSp = sellerMap.get(onsiteSPName);
							if (onsiteSp == null)
								onsiteSp = sellerNameMap.get(onsiteSPName);
							if (onsiteSp != null) {
								onsiteSpId = onsiteSp.getId().toString();
							}
						}

						if (ae == null)
							LOGGER.info("AE with SF Name : " + aeName + " not present for prospect : "
									+ rec.getAccountName());

						if (sp == null)
							LOGGER.info("SP with SF Name : " + spName + " not present for prospect : "
									+ rec.getAccountName());

						if (market != null) {
							marketId = market.getId() + "";
						}

						if ((market != null && (market.getName().indexOf("Expansion") != -1
								|| market.getName().indexOf("expansion") != -1))
								|| (team != null && (team.getName().indexOf("Expansion") != -1
										|| team.getName().indexOf("expansion") != -1))) {
							spId = "-1";
						} else {
							dsaId = "-1";
						}

						for (MapPlayFields playField : fieldList) {
							Field fld = fieldsMap.get(playField.getFieldId()); // fieldRepository.getById(field.getFieldId());
							if (fld.getFieldName().equals("aeTeam") && !StringUtils.isEmpty(aeTeam)) {
								playFields.put(playField.getFieldId() + "", aeTeam);
							} else if (fld.getFieldName().equals("opportunityName")
									&& !StringUtils.isEmpty(opportunityName)) {
								playFields.put(playField.getFieldId() + "", opportunityName);
							} else if (fld.getFieldName().equals("opportunityOwner") && ae != null) {
								playFields.put(playField.getFieldId() + "", ae.getFullName());
							} else if (fld.getFieldName().equals("stage") && !StringUtils.isEmpty(stageName)) {
								String key = fld.getId() + "|" + stageName;
								if (nameOptionsMap.get(key) != null) {
									playFields.put(playField.getFieldId() + "", nameOptionsMap.get(key).getId() + "");
								}
							}
						}
						demo.setActivityId(activityId);
						demo.setNameOfProspect(accountName);
						demo.setPlayId(demoPlay.getId().toString());
						demo.setDocLink(docLink);
						demo.setMarketId(marketId);
						demo.setTeamId(teamId);
						demo.setAeId(aeId);
						demo.setSpId(spId);
						demo.setDsaId(dsaId);
						demo.setOnSiteSpId(onsiteSpId);
						demo.setPesStatus(PesConstants.NEW);
						demo.setPlayFields(playFields);
						demo.setPodLeadId(podLeadId);
						demo.setCreatedBy(createdBy);
						demo.setDateOfExecution(dateOfExec);

						assignPlayExecForScoring(demo);

						notCompletedActivityIds.add(activityId);
						count++;

					} catch (Exception e) {
						LOGGER.error("PesScoringServiceImpl.processDemoPlay(): ERROR : " + e.getMessage());
						e.printStackTrace();
						failedList.add(rec);
					}
				}
				String emails = usermail;
				String subject = "[SUCCESS]Demo report Completion Mail";
				StringBuilder body = new StringBuilder().append("The Demo report has been successfully fetched "
						+ "and the records have been added.<br>" + "No. of records added : " + count + "<br>");

				if (failedList.size() > 0) {
					subject = "[SUCCESS with FAILURES]Demo report Completion Mail";
					body.append("\"The following records failed to get added : <br>");
					int failCount = 1;
					for (Demo_Play_DTO rec : failedList) {
						body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
					}
				}

				emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
			}
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.processDemoPlay(): ERROR : " + e.getMessage());
			e.printStackTrace();
			String emails = usermail;
			String subject = "Demo report Completion Failure Mail";
			String body = "Demo report fetch failed. " + "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processDemoPlay() : ERROR : " + er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processDemoPlay(): END");
	}

	// This method will run every friday BOD, by scheduler
	@Override
	public void updateStatusToCompleted() {
		checkOverriden();
		Calendar cal = Calendar.getInstance();
		int week = cal.get(Calendar.WEEK_OF_MONTH);
		List<Long> monthSpecificPlaysList = new ArrayList<>();
		String[] monthSpecificPlayNames = { "Champions", "ZZTop" };
		monthSpecificPlaysList = playRepository.getIdsByNames(monthSpecificPlayNames);
		if (week == 4)
			txnPlayExecRepository.updateStatusToCompleted();
		else
			txnPlayExecRepository.updateStatusToCompletedForWeeklyPlays(monthSpecificPlaysList);
	}

	// Checks for overriden and sets the overriden column
	public void checkOverriden() {
		Calendar cal = Calendar.getInstance();
		List<TxnPlayExecutions> txnList = txnPlayExecRepository.getByPesStatus(PesConstants.PUSH_TO_POD_LEAD,
				cal.get(Calendar.YEAR) + "");
		List<TxnPlayExecutions> updateList = new ArrayList<>();
		for (TxnPlayExecutions txn : txnList) {
			String pesScore = txn.getPesScore();
			String podLeadScore = txn.getPodLeadScore();
			if (!StringUtils.isEmpty(pesScore) && !StringUtils.isEmpty(podLeadScore)
					&& !pesScore.equals(podLeadScore)) {
				txn.setOverriden("YES");
			} else
				txn.setOverriden("NO");
			updateList.add(txn);
		}
		txnPlayExecRepository.saveAll(updateList);
	}

	// This method will return the sellers
	public Employee getSeller(TxnPlayExecutions txn, String role) {
		if (role.equals("AE"))
			return txn.getAe();
		else if (role.equals("SP"))
			return txn.getSp();
		else if (role.equals("Onsite SP"))
			return txn.getOnsiteSp();
		else if (role.equals("DTA"))
			return txn.getDta();
		else if (role.equals("DSA"))
			return txn.getDsa();
		return null;
	}

	// return true after changing the created date
	@Override
	public boolean movePlays(MovePlayDTO movePlayDto) {
		try {
			LOGGER.info("PesScoringServiceImpl.movePlay() : START");
			List<TxnPlayExecutions> updateList = new ArrayList<>();
			java.util.Date newDate = new SimpleDateFormat("yyyy-MM-dd").parse(movePlayDto.getMoveToDate());
			java.util.Date currentDate = Calendar.getInstance().getTime();
			List<Long> txnIdList = movePlayDto.getIdList();
			List<TxnPlayExecutions> txnList = txnPlayExecRepository.findAllById(txnIdList);
			for (TxnPlayExecutions txn : txnList) {
				txn.setCreatedDate(newDate);
				txn.setUpdatedDate(currentDate);
				txn.setUpdatedBy(movePlayDto.getUser());
				updateList.add(txn);
			}
			txnPlayExecRepository.saveAll(updateList);
			LOGGER.info("PesCommonServiceImpl.movePlay(): END");
			return true;
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.movePlay(): ERROR " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public GenericResult toggleFavouriteForPlay(Boolean isStarred, Long rowId) {
		LOGGER.info("PesScoringServiceImpl.updatePlayAsFavourite(): START");
		GenericResult result = new GenericResult();
		try {

			txnPlayExecRepository.toggleFavouriteForPlay(isStarred, rowId);
			result.setMessage("Operation Successful");
			result.setStatus(PesConstants.SUCCESS);
			result.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.updatePlayAsFavourite(): ERROR ", e);
			result.setData(null);
			result.setMessage("Failed");
			result.setStatus(PesConstants.FAIL);
			result.setSuccess(false);
		}
		return result;
	}

	@Override
	@Async
	public void saveReportData(String reportName, String userMail, String startDate, String endDate) {
		LOGGER.info("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName + " : START");
		try {
			List<DiscoveryCallDTO> recordList = null;
			List<DiscoveryCallDTO> failedList = new ArrayList<>();
			List<TxnPlayExecutions> updateList = new ArrayList<>();
			int count = 0;
			if(reportName.equals("MidMarket")) 
				recordList = pesSalesSFDCService.getReport1Data(startDate, endDate);
			else if(reportName.equals("Enterprise NA")) 
				recordList = pesSalesSFDCService.getReport2Data(startDate, endDate);
			if (CollectionUtils.isNotEmpty(recordList)) {

				Play playDC = playRepository.findByName("Discovery Execute Call");
				Play playDS = playRepository.findByName("Discovery STRAP");

				List<Employee> allSellers = employeeRepository.findAll();
				List<Market> allMarkets = marketRepository.findAll();
				List<Team> allTeams = teamRepository.findAll();
				Map<String, Employee> nameEmpMap = new HashMap<>();

				// maps with 18charId : Object
				Map<String, Team> idTeamMap = new HashMap<>();
				Map<String, Employee> idEmpMap = new HashMap<>();
				Map<String, Market> idMarketMap = new HashMap<>();

				for (Employee emp : allSellers) {
					idEmpMap.put(emp.getSf18CharId(), emp);
					nameEmpMap.put(emp.getFullName(), emp);
				}

				for (Market market : allMarkets) {
					idMarketMap.put(market.getName().toUpperCase(), market);
				}
				for (Team team : allTeams) {
					idTeamMap.put(team.getName().toUpperCase(), team);
				}
				List<MapPlayFields> fieldListDC = mapPlayFieldsRepository.getByPlayId(playDC.getId());
				List<MapPlayFields> fieldListDS = mapPlayFieldsRepository.getByPlayId(playDS.getId());
				Long dcIdField = fieldRepository.findByDisplayName("DC ID").getId();
				String createdBy = "SYSTEM";

				// New ActivityId List
				List<String> addedActivityIdList = new ArrayList<>();

				// Get the list of all the activity Id's from the Discover Call Report
				List<String> activityIds = new ArrayList<>();
				for (DiscoveryCallDTO record : recordList) {
					activityIds.add(record.getActivityId());
				}

				// Get all records from db for the current records fetched from salesforce
				List<TxnPlayExecutions> txnsByActivityIdList = txnPlayExecRepository
						.getDiscoveryPlaysByActivityIds(activityIds);

				// Get the list of all activityIds from db
				List<String> existingActivityIds = new ArrayList<>();
				for (TxnPlayExecutions txn : txnsByActivityIdList) {
					existingActivityIds.add(txn.getActivityId());
				}

				for (DiscoveryCallDTO rec : recordList) {
					try {
						Map<String, String> playFieldDC = new HashMap<>();
						Map<String, String> playFieldDS = new HashMap<>();
						ScoringDTO scoringDto = new ScoringDTO();
						ScoringDTO scoringDtoDS = new ScoringDTO();
						String dateOfExecution = "";
						if (!StringUtils.isEmpty(rec.getDateOfExecution()))
							dateOfExecution = rec.getDateOfExecution().substring(0,
									rec.getDateOfExecution().indexOf('T'));
						String activityId = rec.getActivityId();
						String sfdcStatus = rec.getSfdcStatus();

						// Get the activityIds added through current iteration & check for duplication
						if (addedActivityIdList.indexOf(activityId) != -1) {
							continue;
						}

						/*
						 * Get the index of activity Id present for Discovery STRAP Check if play is
						 * marked completed for the same activityId If not completed don't add the
						 * fetched record Else Completed Check Sfdc Status for that activityId Add to
						 * the updateList
						 */
						int activityIndex = existingActivityIds.indexOf(activityId);
						if (activityIndex != -1) {
							if (!txnsByActivityIdList.get(activityIndex).getPesStatus()
									.equals(PesConstants.COMPLETED)) {
								LOGGER.info(
										"Discovery STRAP Record with activity Id : " + activityId + " already present");
								continue;
								// If txn not completed match the sfdc status and prepare update list
								// accordingly
							} else if (!txnsByActivityIdList.get(activityIndex).getSfdcStatus().equals(sfdcStatus)) {
								for (TxnPlayExecutions txn : txnsByActivityIdList) {
									// Get the all the records fecthed from SalesForce for a particular activityId
									if (txn.getActivityId().equals(activityId)) {
										txn.setSfdcStatus(sfdcStatus);
										updateList.add(txn);
										count++;
									}
								}
								LOGGER.info(
										"SFDC Status for Transaction with Activity Id : " + activityId + " updated ");
							}
							continue;
						}
						if (sfdcStatus.equals(PesConstants.DISQUALIFIED)
								|| sfdcStatus.equals(PesConstants.CANCELLED)
								|| sfdcStatus.equals(PesConstants.NO_SHOW)
								|| sfdcStatus.equals(PesConstants.OPPTY_CREATED)
								|| sfdcStatus.equals(PesConstants.SCHEDULED)
								|| sfdcStatus.equals(PesConstants.CONVERTED)
								|| sfdcStatus.equals(PesConstants.NOT_CONVERTED_SELLER_NOT_INTERESTED)
								|| sfdcStatus.equals(PesConstants.NOT_CONVERTED_PROSPECT_NOT_INTERESTED)
								|| sfdcStatus.equals(PesConstants.NOT_CONVERTED_FOLLOWUP_WITHIN_4WEEKS)
								) {
							// for extracting url from <a></a> tags
							String docLink = "";
							if (!StringUtils.isEmpty(rec.getDocLink())) {
								Pattern pattern = Pattern.compile("<a[^>]*>(.*?)</a>");
								Matcher matcher = pattern.matcher(rec.getDocLink());
								docLink = "";
								while (matcher.find()) {
									docLink = docLink + matcher.group(1);
								}
							}
							String nameOfProspect = rec.getNameOfProspect();
							for (MapPlayFields field : fieldListDC) {
								if (field.getFieldId() == dcIdField) {
									playFieldDC.put(field.getFieldId() + "", rec.getDcId());
								} else
									playFieldDC.put(field.getFieldId() + "", "");
							}
							for (MapPlayFields field : fieldListDS) {
								if (field.getFieldId() == dcIdField) {
									playFieldDS.put(field.getFieldId() + "", rec.getDcId());
								}
								else
									playFieldDS.put(field.getFieldId() + "", "");
							}
							Market market = idMarketMap
									.get(!StringUtils.isEmpty(rec.getMarket()) ? rec.getMarket().toUpperCase() : null);
							String marketId = null;
							Team team = idTeamMap
									.get(!StringUtils.isEmpty(rec.getTeam()) ? rec.getTeam().toUpperCase() : null);
							String teamId = null;
							String aeSfId = rec.getAeSfId();
							String ftaSfId = rec.getFtaSfId();
							String spSf = rec.getSpSfId();
							Employee ae = null;
							Employee sp = null;
							Employee fta = null;

							// employee and pod lead checks
							if (!StringUtils.isEmpty(aeSfId)) {
								ae = idEmpMap.get(aeSfId);
								if (ae == null)
									ae = nameEmpMap.get(aeSfId);
							}
							if (!StringUtils.isEmpty(spSf)) {
								// checking with full name for now as getting full name from sales force
								sp = idEmpMap.get(spSf);
								if (sp == null)
									sp = nameEmpMap.get(spSf);
							}
							if (!StringUtils.isEmpty(ftaSfId)) {
								fta = idEmpMap.get(ftaSfId);
								if (fta == null)
									fta = nameEmpMap.get(ftaSfId);
							}

							if (ae == null) {
								LOGGER.info("AE with SF Id : " + aeSfId + " not present for prospect : "
										+ rec.getNameOfProspect());
							}
							if (sp == null) {
								LOGGER.info("SP with SF Id: " + spSf + " not present for prospect : "
										+ rec.getNameOfProspect());
							}
							if (fta == null) {
								LOGGER.info("FTA with SF Id: " + ftaSfId + " not present for prospect : "
										+ rec.getNameOfProspect());
							}

							if (market == null) {
								if (ae != null) {
									marketId = ae.getMarketId() + "";
								} else if (sp != null) {
									marketId = sp.getMarketId() + "";
								} else {
									if (idMarketMap.get(reportName.toUpperCase()) != null) {
										marketId = idMarketMap.get(reportName.toUpperCase()).getId() + "";
									}
								}
							} else if (market != null) {
								marketId = market.getId() + "";
							}

							if (team == null) {
								if (ae != null) {
									teamId = ae.getTeamId() + "";
								} else if (sp != null) {
									teamId = sp.getTeamId() + "";
								}
							} else if (team != null) {
								teamId = team.getId() + "";
							}

							scoringDto.setDateOfExecution(dateOfExecution);
							scoringDto.setActivityId(activityId);
							scoringDto.setDocLink(docLink);
							scoringDto.setMarketId(marketId);
							scoringDto.setTeamId(teamId);
							scoringDto.setNameOfProspect(nameOfProspect);
							scoringDto.setSfdcStatus(sfdcStatus);

							if (ae != null) {
								if (ae.getPodLeadId() != null) {
									scoringDto.setPodLeadId(ae.getPodLeadId() + "");
									scoringDtoDS.setPodLeadId(ae.getPodLeadId() + "");
								}
								scoringDto.setAeId(ae.getId() + "");
								scoringDtoDS.setAeId(ae.getId() + "");
							}
							if (sp != null) {
								scoringDto.setSpId(sp.getId() + "");
								scoringDtoDS.setSpId(sp.getId() + "");
							}
							if (fta != null) {
								scoringDto.setFtaId(fta.getId() + "");
								scoringDtoDS.setFtaId(fta.getId() + "");
							}

							scoringDtoDS.setDateOfExecution(dateOfExecution);
							scoringDtoDS.setActivityId(activityId);
							scoringDtoDS.setDocLink(docLink);
							scoringDtoDS.setMarketId(marketId);
							scoringDtoDS.setTeamId(teamId);
							scoringDtoDS.setNameOfProspect(nameOfProspect);
							scoringDtoDS.setSfdcStatus(sfdcStatus);
							scoringDto.setCreatedBy(createdBy);
							scoringDto.setPesStatus(PesConstants.NEW);
							scoringDtoDS.setCreatedBy(createdBy);
							scoringDtoDS.setPesStatus(PesConstants.NEW);

							// PLay specific changes
							scoringDto.setPlayId(playDC.getId() + "");
							scoringDtoDS.setPlayId(playDS.getId() + "");
							scoringDto.setPlayFields(playFieldDC);
							scoringDtoDS.setPlayFields(playFieldDS);
							assignPlayExecForScoring(scoringDto);
							assignPlayExecForScoring(scoringDtoDS);
							addedActivityIdList.add(activityId);
							count++;

							LOGGER.info("Record with Activity Id : " + activityId + " saved");
						}
					} catch (Exception e) {
						e.printStackTrace();
						LOGGER.error("PesScoringServiceImpl.processDiscoveryCallRecords() - Recordwise: Report Name : "
								+ reportName + " : ERROR : " + e.getMessage());
						failedList.add(rec);
					}
				}
			}
			String emails = userMail;
			String subject = "[SUCCESS]SalesForce Discovery Call " + reportName + " report Completion Mail";
			StringBuilder body = new StringBuilder().append("The SalesForce Discovery Call " + reportName
					+ " report has been successfully fetched " + "and the records have been updated. <br>"
					+ "No. of records added/updated : " + count + "<br>");

			if (failedList.size() > 0) {
				subject = "[SUCCESS with FAILURES]SalesForce Discovery Call " + reportName + " report Completion Mail";
				body.append("The following records failed to get added : <br>");
				int failCount = 1;
				for (DiscoveryCallDTO rec : failedList) {
					body.append(failCount++ + " > " + rec.toStringForMail() + "<br>");
				}
			}
			emailUtil.sendEmailWithAttachment(subject, body.toString(), emails, null);
			txnPlayExecRepository.saveAll(updateList);
		} catch (Exception e) {
			LOGGER.error("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName
					+ " : ERROR : " + e.getMessage());
			e.printStackTrace();
			String emails = userMail;
			String subject = "[FAILURE]SalesForce Discovery Call " + reportName + " report Completion Failure Mail";
			String body = "The SalesForce Discovery Call " + reportName + " report fetch failed. "
					+ "Please contact the Administrator.";
			try {
				emailUtil.sendEmailWithAttachment(subject, body, emails, null);
			} catch (Exception er) {
				LOGGER.error("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName
						+ " : ERROR : " + er.getMessage());
				er.printStackTrace();
			}
		}
		LOGGER.info("PesScoringServiceImpl.processDiscoveryCallRecords(): Report Name : " + reportName + " : END");
	}

}