package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Designation;

/**
 * Repository class for Designation pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface DesignationRepository extends JpaRepository<Designation, Long> {
	
	@Query("Select d from Designation d where d.id=?1")
	public Designation getById(Long id);
	
	@Query("Select d from Designation d where d.name=?1")
	public Designation getByName(String name);
	
	//Query to delete designation by Id
	@Query("Delete from Designation d where d.id=?1")
	public void deleteById(Long Id);
}
