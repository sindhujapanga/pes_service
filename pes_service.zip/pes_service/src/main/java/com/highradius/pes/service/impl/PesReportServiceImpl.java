/**
 * 
 */
package com.highradius.pes.service.impl;

import static java.time.DayOfWeek.MONDAY;
import static java.time.temporal.TemporalAdjusters.previousOrSame;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.FunctionalRole;
import com.highradius.pes.model.MapFieldOptions;
import com.highradius.pes.model.MapPlayMarketWeightage;
import com.highradius.pes.model.MapPlayRoles;
import com.highradius.pes.model.PesSchedulerExecHistory;
import com.highradius.pes.model.PesSellerScores;
import com.highradius.pes.model.PesSellersReports;
import com.highradius.pes.model.Play;
import com.highradius.pes.model.TxnPlayExecutionFeedback;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FieldRepository;
import com.highradius.pes.repository.FunctionalRoleRepository;
import com.highradius.pes.repository.MapPlayMarketWeightageRepository;
import com.highradius.pes.repository.MapPlayRolesRepository;
import com.highradius.pes.repository.PesSchedulerExecHistoryRepository;
import com.highradius.pes.repository.PesSellerReportsRepository;
import com.highradius.pes.repository.PesSellerScoresRepository;
import com.highradius.pes.repository.PlayRepository;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;
import com.highradius.pes.service.PesReportService;
import com.highradius.pes.util.EmailUtil;
import com.highradius.pes.util.PdfUtil;
import com.highradius.pes.util.PesConstants;
import com.highradius.pes.util.PesPropertiesUtil;

/**
 * @author vamshi.bonagiri
 *
 */
@Service
@Transactional
public class PesReportServiceImpl implements PesReportService {

	private static final Logger LOGGER = LogManager.getLogger(PesReportServiceImpl.class);

	@Autowired
	TxnPlayExecutionsRepository txnRepo;

	@Autowired
	MapPlayMarketWeightageRepository mapPlayMarketWeightageRepo;

	@Autowired
	PlayRepository playRepo;

	@Autowired
	FunctionalRoleRepository functionalRoleRepo;

	@Autowired
	PesSellerScoresRepository pesSellerScoresRepo;

	@Autowired
	MapPlayRolesRepository mapPlayRolesRepo;

	@Autowired
	EmployeeRepository empRepo;

	@Autowired
	PesSchedulerExecHistoryRepository schedulerExecHistoryRepo;

	@Autowired
	PdfUtil pdfUtil;

	@Autowired
	PesSellerReportsRepository pesSellersReportRepo;

	@Autowired
	FieldRepository fieldRepo;

	@Autowired
	EmailUtil emailUtil;

	@Autowired
	PesPropertiesUtil propertiesUtil;
	
	@Autowired
	PesSellerReportsRepository reportsRepo;

	/**
	 * Processes Seller scores for all sellers depending upon their assigned plays 
	 * Processes both monthly and weekly scores depending upon the 'type' flag
	 * startDate and endDate depends upon the type
	 * @param type
	 * @param startDate
	 * @param endDate
	 * @throws ParseException
	 */
	public void processSellerReports(String type, LocalDateTime startDate, LocalDateTime endDate)
			throws ParseException {
		System.out.println("Retrieving the scoring data between " + startDate + " : " + endDate);
		List<TxnPlayExecutions> txnPlayExecutionsList = txnRepo.getScoresBetweenDates(startDate, endDate);
		System.out.println("Number of play execution scored : " + txnPlayExecutionsList.size());

		/*updates the feedback summary of different plays
		 * consolidates final feedback and pes feedback as highlevel feedback and detailed feedback respectively as per
		 * db
		 */
		updateFeedbackSummary(txnPlayExecutionsList);

		// Rating score map, to get score based on rating while calculating the formula
		Map<String, Long> scoreVal = new HashMap<String, Long>();
		scoreVal.put("Green", 10L);
		scoreVal.put("Yellow", 5L);
		scoreVal.put("Red", 0L);

		// get the list of Plays and prepare lookup map for id and name
		List<Play> plays = playRepo.findAll();
		Map<Long, String> playIdNameMap = new HashMap<Long, String>();
		Map<String, Long> playNamIDMap = new HashMap<String, Long>();
		for (Play play : plays) {
			playIdNameMap.put(play.getId(), play.getName());
			playNamIDMap.put(play.getName(), play.getId());
		}

		// get the list of Roles and prepare lookup map for id and name
		List<FunctionalRole> fRoles = functionalRoleRepo.findAll();
		Map<Long, String> roleIdNameMap = new HashMap<Long, String>();
		for (FunctionalRole fRole : fRoles) {
			roleIdNameMap.put(fRole.getId(), fRole.getName());
		}

		// get the wtgs for play+role
		List<MapPlayMarketWeightage> playRoleWtgsList = mapPlayMarketWeightageRepo.findAll();
		Map<String, Long> playRoleWtg = new HashMap<String, Long>();
		for (MapPlayMarketWeightage prWtg : playRoleWtgsList) {
			playRoleWtg.put(prWtg.getPlayId() + "|" + prWtg.getFuncRoleId(), prWtg.getWeightage());
		}
		// get list of plays performed by role
		List<MapPlayRoles> mapPlayRolesList = mapPlayRolesRepo.findAll();

		Map<String, List<String>> rolePlaysMap = new HashMap<String, List<String>>();
		for (MapPlayRoles playRole : mapPlayRolesList) {
			String playName = playIdNameMap.get(playRole.getPlayId());
			String roleName = roleIdNameMap.get(playRole.getRoleId());
			List<String> rolePlays = null;
			if (rolePlaysMap.containsKey(roleName)) {
				rolePlays = rolePlaysMap.get(roleName);
			} else {
				rolePlays = new ArrayList<String>();
			}
			rolePlays.add(playName);
			rolePlaysMap.put(roleName, rolePlays);
		}

		Map<String, Map<String, Map<String, String>>> allSellerPlays = new HashMap<>();
		Map<String, String> sellerRoleMap = new HashMap<String, String>();
		Map<String, String> sellerEmailMap = new HashMap<String, String>();
		Set<Long> sellersExecutedPlays = new HashSet<Long>();
		
		Long aeFnId = functionalRoleRepo.getByName("AE").getId();
		Long spFnId = functionalRoleRepo.getByName("SP").getId();
		Long onsiteSPFnId = functionalRoleRepo.getByName("Onsite SP").getId();
		Long dtaFnId = functionalRoleRepo.getByName("DTA").getId();
		Long dsaFnId = functionalRoleRepo.getByName("DSA").getId();
		
		for (TxnPlayExecutions playExec : txnPlayExecutionsList) {
			
			//condition where scoredFor has left the org, or is not found in the system.
			if(playExec.getScoringFor() == null)
				continue;
			String playName = playExec.getPlay().getName();
			if(type.equals("WEEK") && (playName.equals("Champions") || playName.equals("ZZTop")))
				continue;
			String sellerName = playExec.getScoringFor().getFullName();
            Long sellerId = playExec.getScoringFor().getId();
			sellersExecutedPlays.add(playExec.getScoringFor().getId());
			Long playId = playExec.getPlay().getId();
			Long score = scoreVal.get(playExec.getPodLeadScore());
			Long roleId = playExec.getScoringFor().getFnRole().getId();
			String email = playExec.getScoringFor().getEmail();
			
			//new add
			  Employee ae = playExec.getAe();
	            Long aeId = null;
	            Long scoredRoleId = null;
	            if(ae != null) {
	                aeId = ae.getId();
	                if(aeId == sellerId) {
	                	LOGGER.info(sellerName);
	                    scoredRoleId = aeFnId;
	                }
	            }
	            Employee sp = playExec.getSp();
	            Long spId = null;
	            if(sp != null) {
	                spId = sp.getId();
	                if(spId == sellerId) {
	                	LOGGER.info(sellerName);
	                    scoredRoleId = spFnId;
	                }
	            }
	            
	            Employee onsiteSp = playExec.getOnsiteSp();
	            Long onsiteSpId = null;
	            if(onsiteSp != null) {
	                onsiteSpId = onsiteSp.getId();
	                if(onsiteSpId == sellerId) {
	                	LOGGER.info(sellerName);
	                    scoredRoleId = onsiteSPFnId;
	                }
	            }
	            
	            Employee dta = playExec.getDta();
	            Long dtaId = null;
	            if(dta != null) {
	                dtaId = dta.getId();
	                if(dtaId == sellerId) {
	                	LOGGER.info(sellerName);
	                    scoredRoleId = dtaFnId;
	                }
	            }
	            
	            Employee dsa = playExec.getDsa();
	            Long dsaId = null;
	            if(dsa != null) {
	                dsaId = dsa.getId();
	                if(dsaId == sellerId) {
	                	LOGGER.info(sellerName);
	                    scoredRoleId = dsaFnId;
	                }
	            }

			sellerRoleMap.put(sellerName, roleIdNameMap.get(roleId));
			sellerEmailMap.put(sellerName, email);
			//key to uniquely add sellers w.r.t scored roles
			String key = sellerName + "-" + scoredRoleId;
			Long wtgForSellerRole = playRoleWtg.get(playId + "|" + scoredRoleId);
			if(wtgForSellerRole == null) {
				LOGGER.warn("** Scoring for Role is "+roleId+" is different from Role execute the play");
				continue;
			}
			
			if (allSellerPlays.containsKey(key)) {
				Map<String, Map<String, String>> sellerPlays = allSellerPlays.get(key);
				if (sellerPlays.containsKey(playName)) {
					Map<String, String> sellerPlay = sellerPlays.get(playName);
					Long noOfPlays = Long.parseLong(sellerPlay.get("PLAYS_SCORED")) + 1;
					Long totalScore = Long.parseLong(sellerPlay.get("TOTAL_SCORE")) + score;
					Double avgScore = (double)totalScore / (double)noOfPlays;

					sellerPlay.put("PLAYS_SCORED", noOfPlays.toString());
					sellerPlay.put("TOTAL_SCORE", totalScore.toString());
					sellerPlay.put("ROLE", scoredRoleId.toString());
					sellerPlay.put("AVG_SCORE", avgScore.toString());
					sellerPlays.put(playName, sellerPlay);
				} else {
					Map<String, String> sellerPlay = new HashMap<>();
					sellerPlay.put("PLAYS_SCORED", "1");
					sellerPlay.put("TOTAL_SCORE", score.toString());
					sellerPlay.put("ROLE", scoredRoleId.toString());
					sellerPlay.put("AVG_SCORE", score.toString());
					sellerPlay.put("WTG", wtgForSellerRole.toString());
					sellerPlays.put(playName, sellerPlay);
				}
				allSellerPlays.put(key, sellerPlays);
			} else {
				Map<String, Map<String, String>> sellerPlays = new HashMap<>();
				Map<String, String> sellerPlay = new HashMap<>();
				sellerPlay.put("PLAYS_SCORED", "1");
				sellerPlay.put("TOTAL_SCORE", score.toString());
				sellerPlay.put("ROLE", scoredRoleId.toString());
				sellerPlay.put("AVG_SCORE", score.toString());
				sellerPlay.put("WTG", wtgForSellerRole.toString());
				sellerPlays.put(playName, sellerPlay);
				allSellerPlays.put(key, sellerPlays);
			}
			//added to add current role map also to the map.
			if(scoredRoleId != roleId){
				key = sellerName + "-" + roleId;
                 if(!allSellerPlays.containsKey(key)){
                	 Map<String, Map<String, String>> sellerPlays = new HashMap<>();
                	 allSellerPlays.put(key, sellerPlays);
                	 }
                 }
		}


		// insert records to pes_seller_reports
		// TODO: saveAll, insert plays which are not executed and mapped to the seller's
		// role
		Set<String> sellers = allSellerPlays.keySet();
		for (String seller : sellers) {
			String sellerName = seller.substring(0,seller.lastIndexOf('-'));
			String sellerRoleId = seller.substring(seller.lastIndexOf('-')+1);
			Map<String, Map<String, String>> playsData = allSellerPlays.get(seller);
			Set<String> playNames = playsData.keySet();
			String roleName = null;
			Long exeSellerRoleId = null;

			Double totalOccurrencesWtgAvgScore = 0.0;
			Double totalOccurrencesWtg = 0.0;

			for (String play : playNames) {
				Map<String, String> playSummary = playsData.get(play);
				PesSellerScores pesSellerScores = new PesSellerScores();
				pesSellerScores.setSellerName(sellerName);
				pesSellerScores.setPlayName(play);
				pesSellerScores.setPlayStatus("Live");
				pesSellerScores.setPlaysScored(Long.parseLong(playSummary.get("PLAYS_SCORED")));
				pesSellerScores.setTotalScore(Long.parseLong(playSummary.get("TOTAL_SCORE")));
				pesSellerScores.setAvgScore(Double.parseDouble(playSummary.get("AVG_SCORE")));
				exeSellerRoleId = Long.parseLong(playSummary.get("ROLE"));
				roleName = roleIdNameMap.get(exeSellerRoleId);
				pesSellerScores.setRole(roleName);
				pesSellerScores.setWeightage(Long.parseLong(playSummary.get("WTG")));
				Date startDt = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
				pesSellerScores.setStartDate(startDt);
				Date endDt = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
				pesSellerScores.setEndDate(endDt);
				pesSellerScores.setCreatedDate(new Date());
				pesSellerScores.setCreatedBy("System");
				pesSellerScores.setEmail(sellerEmailMap.get(sellerName));

				pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
				if (type.equals("MONTH")) {
					// for same month names
					pesSellerScores.setMonth(PesConstants.Months[startDate.getMonth().getValue() - 1]);
				}
					//pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
					totalOccurrencesWtgAvgScore += Long.parseLong(playSummary.get("PLAYS_SCORED")) * Long.parseLong(playSummary.get("WTG"))
							* Double.parseDouble(playSummary.get("AVG_SCORE"));
					totalOccurrencesWtg += Long.parseLong(playSummary.get("PLAYS_SCORED")) * Long.parseLong(playSummary.get("WTG"));
//				}
				pesSellerScoresRepo.save(pesSellerScores);
			}
			// insert plays for seller, which are mapped to his role but not performed
			// during this period
			List<String> sellerPlays = rolePlaysMap.get(roleIdNameMap.get(Long.parseLong(sellerRoleId)));
			if(sellerPlays == null) {
				continue;
			}

			// get the list of plays not executed by the seller
			List<String> notExecutedPlays = new ArrayList<String>(sellerPlays);
//					+ "dst list size (notExecutedPlays): " + notExecutedPlays.size());
			List<String> executedPlays = new ArrayList<String>(playNames);
			notExecutedPlays.removeAll(executedPlays);

			for (String play : notExecutedPlays) {
				Long wtg = playRoleWtg.get(playNamIDMap.get(play) + "|" + sellerRoleId);
				if(wtg == null) continue;
				
				if(type.equals("WEEK") && (play.equals("Champions") || play.equals("ZZTop")))
					continue;
				PesSellerScores pesSellerScores = new PesSellerScores();
				roleName = roleIdNameMap.get(Long.parseLong(sellerRoleId));
				pesSellerScores.setSellerName(sellerName);
				pesSellerScores.setPlayName(play);
				pesSellerScores.setPlayStatus("Live");
				pesSellerScores.setPlaysScored(0L);
				pesSellerScores.setTotalScore(0L);
				pesSellerScores.setAvgScore(0.0);
				pesSellerScores.setRole(roleName);
				pesSellerScores.setWeightage(wtg);
				Date startDt = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
				pesSellerScores.setStartDate(startDt);
				Date endDt = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
				pesSellerScores.setEndDate(endDt);
				pesSellerScores.setCreatedDate(new Date());
				pesSellerScores.setCreatedBy("System");
				pesSellerScores.setEmail(sellerEmailMap.get(sellerName));

				pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
				if (type.equals("MONTH")) {
					pesSellerScores.setMonth(PesConstants.Months[startDate.getMonth().getValue() - 1]);
					//pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
				}
				pesSellerScoresRepo.save(pesSellerScores);
			}
			// Saving Monthly attainment score record
//			if (type.equals("MONTH")) {
			Double finalScore = 0.0;
			if(totalOccurrencesWtg != 0.0)
			    finalScore = (totalOccurrencesWtgAvgScore / totalOccurrencesWtg);				
				Double attainmentPercent = (finalScore*100/scoreVal.get("Green"));
			if(executedPlays.size() == 0) {
				attainmentPercent = 100.00;
				LOGGER.info("Non executed for seller " + sellerName);
			}
				LOGGER.debug(
						"Saving Monthly attainment score record for sellers: attainmentPercent = " + attainmentPercent);
				PesSellerScores pesSellerScores = new PesSellerScores();
				if (type.equals("MONTH")) {
				pesSellerScores.setMonth(PesConstants.Months[startDate.getMonth().getValue() - 1]);
				}
				pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
				Date startDt = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
				pesSellerScores.setStartDate(startDt);
				Date endDt = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
				pesSellerScores.setEndDate(endDt);
				pesSellerScores.setSellerName(sellerName);
				pesSellerScores.setRole(roleName);
				pesSellerScores.setPlayAttainmentPercentage(attainmentPercent);
				pesSellerScores.setCreatedDate(new Date());
				pesSellerScores.setCreatedBy("System");
				pesSellerScores.setEmail(sellerEmailMap.get(sellerName));

				pesSellerScoresRepo.save(pesSellerScores);
//			}
		}

		// insert sellers , who are not executed any play
		// get all the sellers (AE/SP/Onsite SP) from employee
		List<Employee> sellersList = empRepo.getSellersList();

		// get all the Sellers who performed at least one play
		System.out.println("sellersExecutedPlays = " + sellersExecutedPlays);
		List<Long> execSellers = new ArrayList<Long>(sellersExecutedPlays);

		// iterate through the sellers
		for (Employee empSeller : sellersList) {
			//skipping calculating scores for inactive sellers
			if(empSeller.getStatus().equals(PesConstants.Inactive))
				continue;
			// exclude sellers who played at least one play from all the sellers list
			if (execSellers.indexOf(empSeller.getId()) == -1) {// seller didn't perform any play
				// get the plays mapped to the role
				String rName = roleIdNameMap.get(empSeller.getFnRole().getId());
				List<String> rolePlays = rolePlaysMap.get(rName);
				if (rolePlays == null)
					continue;
				// insert record into pes_sellers_score with role
				for (String play : rolePlays) {
					if(type.equals("WEEK") && (play.equals("Champions") || play.equals("ZZTop")))
						continue;
					Long wtg = playRoleWtg.get(playNamIDMap.get(play) + "|" + empSeller.getFnRole().getId());
					if(wtg == null) continue;
					
					PesSellerScores pesSellerScores = new PesSellerScores();
					pesSellerScores.setSellerName(empSeller.getFullName());
					pesSellerScores.setPlayName(play);
					pesSellerScores.setPlayStatus("Live");
					pesSellerScores.setPlaysScored(0L);
					pesSellerScores.setTotalScore(0L);
					pesSellerScores.setAvgScore(0.0);
					pesSellerScores.setRole(rName);
					pesSellerScores.setWeightage(wtg);
					Date startDt = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
					pesSellerScores.setStartDate(startDt);
					Date endDt = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
					pesSellerScores.setEndDate(endDt);
					pesSellerScores.setCreatedDate(new Date());
					pesSellerScores.setCreatedBy("System");
					pesSellerScores.setEmail(empSeller.getEmail());

					pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
					if (type.equals("MONTH")) {
						pesSellerScores.setMonth(PesConstants.Months[startDate.getMonth().getValue() - 1]);
						//pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
					}
					pesSellerScoresRepo.save(pesSellerScores);
				}

				// Saving Monthly attainment score record
				LOGGER.debug("Saving Monthly attainment score record for noPlays sellers");
					PesSellerScores pesSellerScores = new PesSellerScores();
					if (type.equals("MONTH")) {
					pesSellerScores.setMonth(PesConstants.Months[startDate.getMonth().getValue() - 1]);
					}
					pesSellerScores.setYear(Long.valueOf(startDate.getYear()));
					Date startDt = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
					pesSellerScores.setStartDate(startDt);
					Date endDt = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
					pesSellerScores.setEndDate(endDt);
					pesSellerScores.setSellerName(empSeller.getFullName());
					pesSellerScores.setRole(rName);
					pesSellerScores.setPlayAttainmentPercentage(100.0);
					pesSellerScores.setCreatedDate(new Date());
					pesSellerScores.setCreatedBy("System");
					pesSellerScores.setEmail(empSeller.getEmail());
					pesSellerScoresRepo.save(pesSellerScores);
			}
		}

	}

	/**
	 * Consolidates the feedback object into a 2 different feedbacks
	 * @param txnPlayExecutionsList
	 */
	public void updateFeedbackSummary(List<TxnPlayExecutions> txnPlayExecutionsList) {
		for (TxnPlayExecutions playExec : txnPlayExecutionsList) {
			List<TxnPlayExecutionFeedback> txnPlayExecutionFeedbacks = playExec.getTxnPlayExecutionFeedback();
			//Summary Feedback - PES 
			//Detail Feedback - Pod Lead
			StringBuilder sbSummaryFeedback = new StringBuilder();
			StringBuilder sbDetailFeedback = new StringBuilder();
			for (TxnPlayExecutionFeedback feedback : txnPlayExecutionFeedbacks) {
				String status = feedback.getStatus();
				if(playExec.getPlay().getName().equals("STRAP") ) {
					if(status.equalsIgnoreCase(PesConstants.ACCEPTED)) {
						sbSummaryFeedback.append(StringUtils.isEmpty(feedback.getCriteria())?"":(feedback.getCriteria()+ "( "));
						sbSummaryFeedback.append(StringUtils.isEmpty(feedback.getPesFeedbackRating())?"":(feedback.getPesFeedbackRating() + " ):: "));
						sbSummaryFeedback.append(feedback.getPesFeedback()).append(" \n");
						if(!StringUtils.isEmpty(feedback.getPodLeadFeedback())) {
//							sbSummaryFeedback.append(StringUtils.isEmpty(feedback.getCriteria())?"":feedback.getCriteria()).append("  ( ");
//							sbSummaryFeedback.append(StringUtils.isEmpty(feedback.getPodLeadFeedbackRating())?"":feedback.getPodLeadFeedbackRating()).append(" ): ");
							sbSummaryFeedback.append("\n"+feedback.getPodLeadFeedback()).append("\n\n");
						}
					}
					else if(status.equalsIgnoreCase(PesConstants.DECLINED)){
						    if(!StringUtils.isEmpty(feedback.getPodLeadFeedback())) {
						    sbSummaryFeedback.append(StringUtils.isEmpty(feedback.getCriteria())?"":(feedback.getCriteria()+ "( "));
							sbSummaryFeedback.append(StringUtils.isEmpty(feedback.getPodLeadFeedbackRating())?"":(feedback.getPodLeadFeedbackRating() + " ):: "));
							sbSummaryFeedback.append(feedback.getPodLeadFeedback()).append("\n\n");
							}
					}
					sbDetailFeedback.append(StringUtils.isEmpty(feedback.getCriteria())?"":(feedback.getCriteria()+ "( "));
					sbDetailFeedback.append(StringUtils.isEmpty(feedback.getPesFeedbackRating())?"":(feedback.getPesFeedbackRating() + " ):: "));
					sbDetailFeedback.append(feedback.getPesFeedback()).append(" \n");	
				}else {
					if(status.equalsIgnoreCase(PesConstants.ACCEPTED)) {
						sbSummaryFeedback.append(feedback.getPesFeedback()).append(" | ");
						if(!StringUtils.isEmpty(feedback.getPodLeadFeedback()))
							sbSummaryFeedback.append(feedback.getPodLeadFeedback()).append(" | ");
					}
					else if(status.equalsIgnoreCase(PesConstants.DECLINED)){
						    if(!StringUtils.isEmpty(feedback.getPodLeadFeedback()))
						    	sbSummaryFeedback.append(feedback.getPodLeadFeedback()).append(" | ");
						}
					sbDetailFeedback.append(feedback.getPesFeedback()).append(" | ");		
				}
				
			}
			playExec.setHighLevelFeedback(sbSummaryFeedback.toString());
			playExec.setDetailed_feedback(sbDetailFeedback.toString());
			txnRepo.save(playExec);
		}
	}

	// This method will run every friday EOD, by scheduler
	@Override
	public void processWeeklySellerReports() throws ParseException {
		// get the startedate (Monday of prev week) and endDate (Sunday of prev week)
		LocalDate today = LocalDate.now();
		LocalDate monday = today.with(previousOrSame(MONDAY));
		LocalDate preMonday = monday.minusDays(7);
		LocalDate preSunday = monday.minusDays(1);
		System.out.println("Retrieving the scoring data between " + preMonday + " : " + preSunday);
		Calendar cal = Calendar.getInstance();
		Date d = new SimpleDateFormat("yyyy-MM-dd").parse(preMonday.toString());
		cal.setTime(d);
		int week = cal.get(Calendar.WEEK_OF_YEAR);
		System.out.println("Week no: " + week);

		// get the records from txn_play_executions where date of execution between
		// startdate and enddate inclusive
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));

		processSellerReports("WEEK", startDate, endDate);
	}

	@Override
	/**
	 * Sends seller reports for weekly
	 */
	public void sendWeeklySellerReports() {
		ZoneId z = ZoneId.of("Asia/Kolkata");
		LocalDate today = LocalDate.now(z);
		LocalDate monday = today.with(previousOrSame(MONDAY));
		LocalDate preMonday = monday.minusDays(7);
		LocalDate preSunday = monday.minusDays(1);
		List<Employee> allEmp = empRepo.findAll();
		Map<String,Employee> empEmailMap = new HashMap<>();
		Map<Long,Employee> empIdMap = new HashMap<>();
		Map<String, String> props = new HashMap<>();
		Map<String, PesSellersReports> reportMap = new HashMap<>();
		
		for(Employee emp : allEmp) {
			empEmailMap.put(emp.getEmail(), emp);
			empIdMap.put(emp.getId(), emp);
		}
		
		// Calendar cal = Calendar.getInstance();
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));
		List<PesSellersReports> reportList = pesSellersReportRepo.getReportsBetweenDates(startDate, endDate);
		if(reportList.size() == 0)
			return;
		String weekName = PesConstants.Months[startDate.getMonthValue() - 1] + " " + startDate.getDayOfMonth() + "-"
				+ PesConstants.Months[endDate.getMonthValue() - 1] + " " + endDate.getDayOfMonth() + " ,"
				+ (startDate.getYear());
		boolean isEnableSellerEmail = Boolean.parseBoolean(propertiesUtil.getPropertyByName("ENABLE_SELLER_EMAIL").getPropertyValue());
		// count the number of mails being sent to add proper buffer.
		int count = 0;

		// Getting mail properties
		String emailId = propertiesUtil.getPropertyByName("MAIL_ID").getPropertyValue();
		props.put("MAIL_ID", emailId);

		String emailPassword = propertiesUtil.getPropertyByName("MAIL_PASSWORD").getPropertyValue();
		props.put("MAIL_PASSWORD", emailPassword);

		String mailHost = propertiesUtil.getPropertyByName("MAIL_HOST").getPropertyValue();
		props.put("MAIL_HOST", mailHost);

		String mailCC = propertiesUtil.getPropertyByName("MAIL_CC").getPropertyValue();
		props.put("MAIL_CC", mailCC);

		String mailPort = propertiesUtil.getPropertyByName("MAIL_PORT").getPropertyValue();
		props.put("MAIL_PORT", mailPort);

		// getting the latest unique records
		for (PesSellersReports report : reportList) {
			reportMap.put(report.getEmail(), report);
		}
		
		for (String email : reportMap.keySet()) {
			try {
			PesSellersReports report = reportMap.get(email);
			String emails = "";
			if(isEnableSellerEmail) {
				emails = emails + email;
				Long podLeadId = empEmailMap.get(email).getPodLeadId();
			    if(podLeadId != null && empIdMap.get(podLeadId) != null) {
			    	emails = emails + "," + empIdMap.get(podLeadId).getEmail();
			    }

			String subject = PesConstants.REPORT_SUBJECT +" for "+report.getSellerName()+", Week - " + weekName;
			StringBuilder sbBody = new StringBuilder();
			String body = sbBody.append("<p>Hello ").append(report.getSellerName()).append(",\n")
					.append("			<br/>\n").append("			<br/>\n")
					.append("Hope you are doing well. We wanted to share with you, how the last week looked like for you.\n")
					.append("			<br/>\n").append("			<br/>\n")
					.append("Please find the weekly report pdf below which will help you gain more insight into each of the scores for the plays executed along with specific feedback.\n")
					.append("			<br/>\n").append("			<br/>\n")
					.append("Details on scoring criteria and rationales can be found in the <a href='")
					.append(PesConstants.PES_OPERA_LINK).append( "'>PES OPERA.</a>\n").append( "			</p><br/>\n")
					.append("<p style =\"text-decoration:underline\"> Note: This report is in the form of a standardized template used across all markets."
							+" The Plays for which the sellers do not get scored for will be mentioned as \"No plays scored\""
							+"and thus, their scores will not be affected.</p>")
					.append( "			<br/>\n").append("<p>All the best for the next week. Happy Selling!\n")
					.append("			<br/>\n" ).append( "			<br/>\n")
					.append("With Best Regards,\n").append("			<br/>\n" ).append( "Sales - Strategy & Ops\n")
					.append( "		</p>").toString();
			String[] attachment = { report.getReportUrl() };
			LOGGER.info("Sending mail for seller : "+ report.getSellerName() + " emails : " + emails);
			emailUtil.sendEmailWithAttachment(subject, body, emails, attachment, props);
			report.setMailSent(1L);
			reportsRepo.save(report);
			count++;
			}
			if(count == 50) {
				//2 minutes
				Thread.sleep(1*60*1000);
				count = 0;
			}
			}catch(Exception e) {
				LOGGER.info("Error in sending mail");
			}
		}

	}

	@Override
	/**
	 * generates weekly seller reports
	 */
	public void generateWeeklySellerReports() throws ParseException {
		ZoneId z = ZoneId.of("Asia/Kolkata");
		LocalDate today = LocalDate.now(z);
		LocalDate monday = today.with(previousOrSame(MONDAY));
		LocalDate preMonday = monday.minusDays(7);
		LocalDate preSunday = monday.minusDays(1);
		System.out.println("Retrieving the scoring data between " + preMonday + " : " + preSunday);
		// Calendar cal = Calendar.getInstance();
		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));

		generateSellerReports(PesConstants.WEEKLY, startDate, endDate, null, null);
	}

	// TODO: calculation of attainment% for each month using formula and insert
	// year,month, seller and attainment % to pessellerscores
	@Override
	/**
	 * Generates scores for month
	 */
	public void processMonthlySellerReports() throws ParseException {
		Calendar aCalendar = Calendar.getInstance();
		// add -1 month to current month
		aCalendar.add(Calendar.MONTH, -1);
		// set DATE to 1, so first date of previous month
		aCalendar.set(Calendar.DATE, 1);
		Date firstDateOfPreviousMonth = aCalendar.getTime();

		// set actual maximum date of previous month
		aCalendar.set(Calendar.DATE, aCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date lastDateOfPreviousMonth = aCalendar.getTime();

		// get the records from txn_play_executions where date of execution between
		// startdate and enddate inclusive
		LocalDate startDt = new java.sql.Date(firstDateOfPreviousMonth.getTime()).toLocalDate();
		LocalDate endDt = new java.sql.Date(lastDateOfPreviousMonth.getTime()).toLocalDate();

		LocalDateTime startDate = LocalDateTime.of(LocalDate.from(startDt), LocalTime.of(0, 0, 0));
		LocalDateTime endDate = LocalDateTime.of(LocalDate.from(endDt), LocalTime.of(23, 59, 59));
		processSellerReports("MONTH", startDate, endDate);
	}

	@Override
	/**
	 * Sends monthly seller report
	 */
	public void sendMonthlySellerReports() {
		LOGGER.info("PesReportServiceImpl.sendMonthlySellerReports() : START");
		Calendar cal = Calendar.getInstance();
		String monthName = PesConstants.Months[cal.get(Calendar.MONTH) - 1 == -1? 11:cal.get(Calendar.MONTH) - 1];
		String year = cal.get(Calendar.MONTH) - 1 == -1?(cal.get(Calendar.YEAR) -1) + "":cal.get(Calendar.YEAR) + "";
		List<Employee> allEmp = empRepo.findAll();
		Map<String,Employee> empEmailMap = new HashMap<>();
		Map<Long,Employee> empIdMap = new HashMap<>();
		Map<String, String> props = new HashMap<>();
		Map<String, PesSellersReports> reportMap = new HashMap<>();
		
		for(Employee emp : allEmp) {
			empEmailMap.put(emp.getEmail(), emp);
			empIdMap.put(emp.getId(), emp);
		}
		
		List<PesSellersReports> reportList = pesSellersReportRepo.findByTypeNMonth(PesConstants.MONTHLY, monthName,
				year);
		if(reportList.size() == 0)
			return;
		
		boolean isEnableSellerEmail = Boolean.parseBoolean(propertiesUtil.getPropertyByName("ENABLE_SELLER_EMAIL").getPropertyValue());
		//count the number of mails being sent to add proper buffer.
		int count = 0;
		
		//Getting mail properties
		String emailId = propertiesUtil.getPropertyByName("MAIL_ID").getPropertyValue();
		props.put("MAIL_ID", emailId);
		
		String emailPassword = propertiesUtil.getPropertyByName("MAIL_PASSWORD").getPropertyValue();
		props.put("MAIL_PASSWORD", emailPassword);
		
		String mailHost = propertiesUtil.getPropertyByName("MAIL_HOST").getPropertyValue();
		props.put("MAIL_HOST", mailHost);

		String mailCC = propertiesUtil.getPropertyByName("MAIL_CC").getPropertyValue();
		props.put("MAIL_CC", mailCC);

		String mailPort = propertiesUtil.getPropertyByName("MAIL_PORT").getPropertyValue();
		props.put("MAIL_PORT", mailPort);
		
		// getting the latest unique records
		for (PesSellersReports report : reportList) {
			reportMap.put(report.getEmail(), report);
		}
		
		//sending mails
		for (String email : reportMap.keySet()) {
			try {
			PesSellersReports report = reportMap.get(email);
			String emails = "";
			if(isEnableSellerEmail) {
			emails = emails + email;
			Long podLeadId = empEmailMap.get(email).getPodLeadId();
		    if(podLeadId != null && empIdMap.get(podLeadId) != null) {
		    	emails = emails + "," + empIdMap.get(podLeadId).getEmail();
		    }
			String subject = PesConstants.REPORT_SUBJECT + " for "+report.getSellerName() + ", Month - " + monthName + ", " + year;
			StringBuilder sbBody = new StringBuilder();
			String body = sbBody.append("<p>Hello ").append(report.getSellerName()).append(",\n")
					.append("			<br/>\n").append("			<br/>\n")
					.append("Hope you are doing well. We wanted to share with you, how the last week looked like for you.\n")
					.append("			<br/>\n").append("			<br/>\n")
					.append("Please find the weekly report pdf below which will help you gain more insight into each of the scores for the plays executed along with specific feedback.\n")
					.append("			<br/>\n").append("			<br/>\n")
					.append("Details on scoring criteria and rationales can be found in the <a href='")
					.append(PesConstants.PES_OPERA_LINK).append( "'>PES OPERA.</a>\n").append( "			<br/>\n")
					.append("<p style =\"text-decoration:underline\"> Note: This report is in the form of a standardized template used across all markets."
							+" The Plays for which the sellers do not get scored for will be mentioned as \"No plays scored\""
							+"and thus, their scores will not be affected.</p>")
					.append( "			<br/>\n").append("<p>All the best for the next week. Happy Selling!\n")
					.append("			<br/>\n" ).append( "			<br/>\n")
					.append("With Best Regards,\n").append("			<br/>\n" ).append( "Sales - Strategy & Ops\n")
					.append( "		</p>").toString();
			String[] attachment = { report.getReportUrl() };
			LOGGER.info("Sending mail for seller : "+ report.getSellerName() + " emails : " + emails);
			emailUtil.sendEmailWithAttachment(subject, body, emails, attachment, props);
			report.setMailSent(1L);
			reportsRepo.save(report);
			count++;
		}
			if(count == 50) {
				//2 minutes
				Thread.sleep(1*60*1000);
				count = 0;
			}
		}catch(Exception e) {
			LOGGER.info("Error in sending mail");
		}
		}
	}

	@Override
	/**
	 * generates monthly seller reports
	 */
	public void generateMonthlySellerReports() throws ParseException {
		ZoneId z = ZoneId.of("Asia/Kolkata");
		LocalDate today = LocalDate.now(z);
		LocalDate monday = today.with(previousOrSame(MONDAY));
		LocalDate preMonday = monday.minusDays(7);
		LocalDate preSunday = monday.minusDays(1);
		LocalDateTime weekStartDate = LocalDateTime.of(LocalDate.from(preMonday), LocalTime.of(0, 0, 0));
		LocalDateTime weekEndDate = LocalDateTime.of(LocalDate.from(preSunday), LocalTime.of(23, 59, 59));
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		// add -1 month to current month
		cal.add(Calendar.MONTH, -1);
		// set DATE to 1, so first date of previous month
		cal.set(Calendar.DATE, 1);
		Date firstDateOfPreviousMonth = cal.getTime();

		// set actual maximum date of previous month
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		Date lastDateOfPreviousMonth = cal.getTime();

		// get the records from txn_play_executions where date of execution between
		// startdate and enddate inclusive
		LocalDate startDt = new java.sql.Date(firstDateOfPreviousMonth.getTime()).toLocalDate();
		LocalDate endDt = new java.sql.Date(lastDateOfPreviousMonth.getTime()).toLocalDate();

		LocalDateTime monthStartDate = LocalDateTime.of(LocalDate.from(startDt), LocalTime.of(0, 0, 0));
		LocalDateTime monthEndDate = LocalDateTime.of(LocalDate.from(endDt), LocalTime.of(23, 59, 59));
		generateSellerReports(PesConstants.MONTHLY, weekStartDate, weekEndDate, monthStartDate, monthEndDate);
	}

	@Override
	/**
	 * Saves scheduler exec history as audit
	 */
	public PesSchedulerExecHistory saveSchedulerExecutionHistory(String name, String status) {
		PesSchedulerExecHistory execHistory = new PesSchedulerExecHistory();
		execHistory.setSchedulerName(name);
		execHistory.setStatus(status);
		execHistory.setStartTime(new Timestamp(new Date().getTime()));
		execHistory = schedulerExecHistoryRepo.save(execHistory);
		return execHistory;
	}

	@Override
	/**
	 * Updates scheduler exec history
	 */
	public void updateSchedulerExecutionHistory(PesSchedulerExecHistory execHistory) {
		schedulerExecHistoryRepo.save(execHistory);
	}

	/**
	 * Generates Seller reports for both Month and Week depending upon the type
	 * startDate and endDate always for week start and end
	 * monthStartDate and monthEndDate depends upon month start and end
	 * @param type
	 * @param startDate
	 * @param endDate
	 * @param monthStartDate
	 * @param monthEndDate
	 */
	public void generateSellerReports(String type, LocalDateTime startDate, LocalDateTime endDate,
			LocalDateTime monthStartDate, LocalDateTime monthEndDate) {
		LOGGER.info("PesReportServiceImpl.generateSellerReports() : START");
		List<PesSellersReports> reportList = new ArrayList<>();
		try {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, -1);
			Long longYear = Long.parseLong(cal.get(Calendar.YEAR) + "");
			String prevMonth = PesConstants.Months[cal.get(Calendar.MONTH)];
			List<String> sellerEmails = pesSellerScoresRepo.findDistinctSellers(longYear);// TODO: pass year
			List<Employee> employees = empRepo.getActiveAndInactiveEmployees();
			List<PesSellerScores> plays = pesSellerScoresRepo.getUniqueScoresBetweenDates(startDate, endDate);
			//to add plays to be shown for only monthly report
			if(type.equals(PesConstants.MONTHLY)) {
				List<PesSellerScores> monthlyPlays = pesSellerScoresRepo.getMonthlyOnlyPlays("Champions", "ZZTop",monthStartDate,monthEndDate);
				plays.addAll(monthlyPlays);
			}
			List<Field> fields = fieldRepo.findAll();
			Map<String, Employee> empEmailMap = new HashMap<>();
			Map<Long, Employee> empIdMap = new HashMap<>();
			Map<String, Set<String>> empEmailRoleMap = new HashMap<>();
			Map<String, List<PesSellerScores>> rolePlayMap = new HashMap<>();
			// getting all the scores in a year
			List<PesSellerScores> scores = pesSellerScoresRepo.findByYear(longYear);
			Map<String, Map<String, PesSellerScores>> monthlyScoreMap = new HashMap<>();
			Map<String, Map<String, PesSellerScores>> weeklyScoreMap = new HashMap<>();
			Map<String, List<TxnPlayExecutions>> weeklyTxnsMap = new HashMap<>();
			Map<String, List<TxnPlayExecutions>> monthlyTxnsMap = new HashMap<>();
			Map<Long, Field> fieldIdMap = new HashMap<>();
			Map<String, String> fieldIdOptionsMap = new HashMap<>();
			List<TxnPlayExecutions> weeklyTxns = new ArrayList<>();
			List<TxnPlayExecutions> monthlyTxns = new ArrayList<>();
			// getting only related week scores
			List<PesSellerScores> weeklyScores = null;
			
			for (Employee emp : employees) {
				if (emp.getEmail() != null)
					empEmailMap.put(emp.getEmail(), emp);
				empIdMap.put(emp.getId(), emp);
			}

			// TODO:cleanup
			String unique = "";
			for (PesSellerScores play : plays) {
				String role = play.getRole();
				String playName = play.getPlayName();
				String searchKey = "";
				List<PesSellerScores> playList = rolePlayMap.get(role);
				List<PesSellerScores> playListWithoutMonthExclusive = rolePlayMap.get(role + "- w/o monthly exclusive");
				if (playList == null) 
					playList = new ArrayList<>();
				if(playListWithoutMonthExclusive == null)
					playListWithoutMonthExclusive = new ArrayList<>();
				//since  plays like STRAP and Discovery Strap have same set of characters
					searchKey = "," + playName + "-" + role;
				if (playName != null && unique.indexOf(searchKey) == -1) {
					playList.add(play);
					if(!playName.equals("Champions") && !playName.equals("ZZTop"))
						playListWithoutMonthExclusive.add(play);
					unique = unique + searchKey;
				}
				rolePlayMap.put(role, playList);
				rolePlayMap.put(role + "- w/o monthly exclusive", playListWithoutMonthExclusive);
			}
			
			

			for (Field field : fields) {
				fieldIdMap.put(field.getId(), field);
				List<MapFieldOptions> options = field.getFieldOptions();
				for(MapFieldOptions option:options) {
					String optionsVal = fieldIdOptionsMap.get(field.getId()+"-"+option.getId());
					if(optionsVal == null) {
						optionsVal = option.getDisplayName();
					}
					fieldIdOptionsMap.put(field.getId()+"-"+option.getId(), optionsVal);
				}
			}

			if (type.equals(PesConstants.MONTHLY)) {
				for (PesSellerScores score : scores) {
					if (score.getMonth() == null)
						continue;
					Map<String, PesSellerScores> currScores = monthlyScoreMap
							.get(score.getMonth() + "-" + score.getEmail() + "-" + score.getRole());
					if (currScores == null)
						currScores = new HashMap<>();

					if (score.getPlayName() != null) {
						currScores.put(score.getPlayName(), score);
					} else
						currScores.put("Attainment", score);
					monthlyScoreMap.put(score.getMonth() + "-" + score.getEmail() + "-" + score.getRole(), currScores);
					
					//getting only scores for last month to check role.
					if (score.getMonth().equals(prevMonth)) {
						Set<String> roles = empEmailRoleMap.get(score.getEmail());
						if (roles == null) {
							roles = new HashSet<>();
						}
						roles.add(score.getRole());
						empEmailRoleMap.put(score.getEmail(), roles);
					}
				}
				weeklyScores = pesSellerScoresRepo.getScoresBetweenDates(startDate, endDate);
				weeklyTxns = txnRepo.getScoresBetweenDates(startDate, endDate);
				monthlyTxns = txnRepo.getByPesStatus(PesConstants.COMPLETED,longYear+"");
				for (TxnPlayExecutions txn : monthlyTxns) {
					
					if(txn.getScoringFor() == null)
						continue;
					
					//to get the actual scored role.
					Employee ae = txn.getAe();
					Employee scoringFor = txn.getScoringFor();
					Long sellerId = scoringFor.getId();
		            Long aeId = null;
		            String scoredRole = null;
		            
		            if(ae != null) {
		                aeId = ae.getId();
		                if(aeId == sellerId) {
		                    scoredRole = "AE";
		                }
		            }
		            Employee sp = txn.getSp();
		            Long spId = null;
		            if(sp != null) {
		                spId = sp.getId();
		                if(spId == sellerId) {
		                    scoredRole = "SP";
		                }
		            }
		            
		            Employee onsiteSp = txn.getOnsiteSp();
		            Long onsiteSpId = null;
		            if(onsiteSp != null) {
		                onsiteSpId = onsiteSp.getId();
		                if(onsiteSpId == sellerId) {
		                    scoredRole = "Onsite SP";
		                }
		            }
		            
		            Employee dta = txn.getDta();
		            Long dtaId = null;
		            if(dta != null) {
		                dtaId = dta.getId();
		                if(dtaId == sellerId) {
		                    scoredRole = "DTA";
		                }
		            }
		            
		            Employee dsa = txn.getDsa();
		            Long dsaId = null;
		            if(dsa != null) {
		                dsaId = dsa.getId();
		                if(dsaId == sellerId) {
		                    scoredRole = "DSA";
		                }
		            }
		            
					String month = PesConstants.Months[txn.getCreatedDate().getMonth()];
			        if(empIdMap.get(txn.getScoringFor().getId()) == null)
			        	continue;
			        //key for the map = Email-PlayName-Month-ScoredRole
					List<TxnPlayExecutions> txnList = monthlyTxnsMap
							.get(empIdMap.get(txn.getScoringFor().getId()).getEmail() + "-" + txn.getPlay().getName() + "-" + month+
									"-"+scoredRole);
					if (txnList == null) {
						txnList = new ArrayList<>();
					}
					txn.getTxnPlayExecutionData();
					txnList.add(txn);
					monthlyTxnsMap.put(
							empIdMap.get(txn.getScoringFor().getId()).getEmail() + "-" + txn.getPlay().getName() + "-" + month+"-"+scoredRole,
							txnList);
				}
			} else if (type.equals(PesConstants.WEEKLY)) {
				weeklyScores = pesSellerScoresRepo.getScoresBetweenDates(startDate, endDate);
				weeklyTxns = txnRepo.getScoresBetweenDates(startDate, endDate);
			}

			for (PesSellerScores score : weeklyScores) {
				Map<String, PesSellerScores> currScores = weeklyScoreMap.get(score.getEmail() + "-" + score.getRole());
				if (currScores == null)
					currScores = new HashMap<>();
				if (score.getPlayName() != null && score.getMonth() == null)
					currScores.put(score.getPlayName(), score);
				else if(score.getMonth() == null)
					currScores.put("Attainment", score);
					weeklyScoreMap.put(score.getEmail() + "-" + score.getRole(), currScores);
				
				Set<String> roles = empEmailRoleMap.get(score.getEmail());
				if(roles == null) {
					roles = new HashSet<>();
				}
				roles.add(score.getRole());
				empEmailRoleMap.put(score.getEmail(), roles);	
				}
			// getting weekly data, key = empEmail-playName
			for (TxnPlayExecutions txn : weeklyTxns) {
				if(txn.getScoringFor() == null)
					continue;
				
				Employee ae = txn.getAe();
				Employee scoringFor = txn.getScoringFor();
				Long sellerId = scoringFor.getId();
	            Long aeId = null;
	            String scoredRole = null;
	            
	            if(ae != null) {
	                aeId = ae.getId();
	                if(aeId == sellerId) {
	                    scoredRole = "AE";
	                }
	            }
	            Employee sp = txn.getSp();
	            Long spId = null;
	            if(sp != null) {
	                spId = sp.getId();
	                if(spId == sellerId) {
	                    scoredRole = "SP";
	                }
	            }
	            
	            Employee onsiteSp = txn.getOnsiteSp();
	            Long onsiteSpId = null;
	            if(onsiteSp != null) {
	                onsiteSpId = onsiteSp.getId();
	                if(onsiteSpId == sellerId) {
	                    scoredRole = "Onsite SP";
	                }
	            }
	            
	            Employee dta = txn.getDta();
	            Long dtaId = null;
	            if(dta != null) {
	                dtaId = dta.getId();
	                if(dtaId == sellerId) {
	                    scoredRole = "DTA";
	                }
	            }
	            
	            Employee dsa = txn.getDsa();
	            Long dsaId = null;
	            if(dsa != null) {
	                dsaId = dsa.getId();
	                if(dsaId == sellerId) {
	                    scoredRole = "DSA";
	                }
	            }
				// getting map as id:txn
	            System.out.println(txn.getScoringFor().getId() + " " + txn.getScoringFor().getFullName());
				List<TxnPlayExecutions> txnList = weeklyTxnsMap
						.get(empIdMap.get(txn.getScoringFor().getId()).getEmail() + "-" + txn.getPlay().getName()+"-"+
				scoredRole);
				if (txnList == null) {
					txnList = new ArrayList<>();
				}
				txn.getTxnPlayExecutionData();
				txnList.add(txn);
				weeklyTxnsMap.put(empIdMap.get(txn.getScoringFor().getId()).getEmail() + "-" + txn.getPlay().getName()
						+"-"+scoredRole,
						txnList);
			}
			// converting dates for save
			Date wStartDate = java.util.Date.from(startDate.atZone(ZoneId.systemDefault()).toInstant());
			Date wEndDate = java.util.Date.from(endDate.atZone(ZoneId.systemDefault()).toInstant());
			cal = Calendar.getInstance();
			
			Map<String,String> properties = new HashMap<String, String>();
			String imageLocation = propertiesUtil.getPropertyByName("HRC_LOGO_LOC").getPropertyValue();
			properties.put("HRC_LOGO_LOC", imageLocation);
			String pdfFolder = propertiesUtil.getPropertyByName("PDF_LOC").getPropertyValue();
			properties.put("PDF_LOC", pdfFolder);
			
			if (type.equals(PesConstants.MONTHLY)) {
				Date mStartDate = java.util.Date.from(monthStartDate.atZone(ZoneId.systemDefault()).toInstant());
				Date mEndDate = java.util.Date.from(monthEndDate.atZone(ZoneId.systemDefault()).toInstant());
				for (String seller : sellerEmails) {
					try {
						//new
						Employee emp = empEmailMap.get(seller);
						if (emp == null || emp.getStatus().equals(PesConstants.Inactive))
							continue;
						Set<String> roles = empEmailRoleMap.get(emp.getEmail());
						if(roles == null)
							continue;
						for(String role: roles) {
							if(role.equals("POD Lead"))
									continue;
						//new ends
						PesSellersReports report = pdfUtil.createMonthlyReport(emp,
								rolePlayMap.get(role),rolePlayMap.get(role + "- w/o monthly exclusive"), monthlyScoreMap, weeklyScoreMap,
								monthlyTxnsMap, weeklyTxnsMap, fieldIdMap, wStartDate, wEndDate, fieldIdOptionsMap,properties,role);
						report.setCreatedDate(cal.getTime());
						report.setEndDate(mEndDate);
						report.setMonth(PesConstants.Months[cal.get(Calendar.MONTH) - 1 == -1? 11:cal.get(Calendar.MONTH) - 1]);
						report.setStartDate(mStartDate);
						report.setYear(longYear);
						report.setMailSent(0L);
						reportList.add(report);
						}
					} catch (Exception e) {
						LOGGER.info("Could not create monthly record for seller " + seller);
						LOGGER.info("PesReportServiceImpl.generateSellerReports(): ERROR: " + e.getMessage());
						e.printStackTrace();
					}
				}
			} else if (type.equals(PesConstants.WEEKLY)) {
				for (String seller : sellerEmails) {
					try {
						Employee emp = empEmailMap.get(seller);
						if (emp == null || emp.getStatus().equals(PesConstants.Inactive))
							continue;
						Set<String> roles = empEmailRoleMap.get(emp.getEmail());
						if(roles == null)
							continue;
						for(String role: roles) {
						PesSellersReports report = pdfUtil.createWeeklyReport(emp,
								rolePlayMap.get(role), weeklyScoreMap, weeklyTxnsMap, fieldIdMap,
								wStartDate, wEndDate, fieldIdOptionsMap,properties,role);
						report.setCreatedDate(cal.getTime());
						report.setEndDate(wEndDate);
						report.setMonth(PesConstants.Months[cal.get(Calendar.MONTH)-1 == -1?11:cal.get(Calendar.MONTH)-1]);
						report.setStartDate(wStartDate);
						report.setYear(longYear);
						report.setMailSent(0L);
						reportList.add(report);
						}
					} catch (Exception e) {
						LOGGER.info("Could not create weekly record for seller " + seller);
						LOGGER.info("PesReportServiceImpl.generateWeeklyReport(): ERROR: " + e.getMessage());
						e.printStackTrace();
					}
				}
			}
			pesSellersReportRepo.saveAll(reportList);
		} catch (Exception e) {
			LOGGER.info("PesReportServiceImpl.generateWeeklyReport(): ERROR: " + e.getMessage());
			e.printStackTrace();
			return;
		}
		LOGGER.info("PesReportServiceImpl.generateWeeklyReport(): END");
	}

}
