package com.highradius.pes.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

import com.highradius.pes.dto.EmployeeDTO;
import com.highradius.pes.dto.EmployeeSearchDTO;
import com.highradius.pes.dto.EmployeeSearchResultDTO;
import com.highradius.pes.dto.HistoryDTO;
import com.highradius.pes.dto.HistorySearchDTO;
import com.highradius.pes.dto.HistorySearchResultDTO;
import com.highradius.pes.dto.MarketPlayWeightageDTO;
import com.highradius.pes.dto.MarketPlayWeightageSearchDTO;
import com.highradius.pes.dto.PlaysSearchDTO;
import com.highradius.pes.model.Field;
import com.highradius.pes.dto.MapPlayMarketWeightageSearchResultDTO;
import com.highradius.pes.util.GenericResult;

public interface PesAdminService {

	GenericResult addEmployee(EmployeeDTO empDto);
	
	GenericResult updateEmployee(EmployeeDTO empDto);
	
	List<Map<String,String>> getEmployeeNames();
	
	List<Map<String,String>> getFunctionalRoles();
	
	List<Map<String,String>> getSfUserIds();
	
	List<Map<String,String>> getProfileNames();
	
	List<Map<String,String>> getEmails();
	
	List<Map<String,String>> getSecurityRoles();
	
	List<EmployeeSearchResultDTO> searchEmployees(EmployeeSearchDTO empSearchDto);
	
	GenericResult addMarket(JSONObject market);
	
	GenericResult addTeam(JSONObject team);
	
	GenericResult addWeightage(MarketPlayWeightageDTO weightageDto);
	
	GenericResult updateWeightage(MarketPlayWeightageDTO weightageDto);
	
	List<MapPlayMarketWeightageSearchResultDTO> searchMarketWeightages(MarketPlayWeightageSearchDTO weightageSearchDto);
	
	List<Map<String,String>> getFieldTypes();
	
	List<Map<String, String>> getPlaybookList();
	
	List<Map<String, String>> getDepartmentList();
	
	List<Field> getSearchedFieldsList(JSONObject playbookSearchFields);
	
	GenericResult addField(JSONObject fieldDetails);
	
	GenericResult addPlay(JSONObject playDetails);
	
	GenericResult playDetails(PlaysSearchDTO searchParams);
	
	GenericResult updateMapPlayFields(JSONObject mapDetails);
	
	GenericResult addPlaybook(JSONObject playbookDetails);
	
	boolean deleteEmployeesById(String[] id);

	GenericResult saveHistory(HistoryDTO historyDto);

	List<HistorySearchResultDTO> searchHistory(HistorySearchDTO historySearchDto);
	
	Map<String, List<Map<String, String>>> getReportsConfigData();

}
