package com.highradius.pes.dto;

public class CPR_SIHDTO {
	
	private String nameOfProspect;
	
	private String AE;
	
	private String SP;
	
	private String docUrl;
	
	private String dateOfExecution;
	
	private String aePodLead;
	
	private String spPodLead;
	
	private String market;
	
	private String aeTeam;
	
	private String spTeam;

	public String getNameOfProspect() {
		return nameOfProspect;
	}

	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}

	public String getAE() {
		return AE;
	}

	public void setAE(String aE) {
		AE = aE;
	}

	public String getSP() {
		return SP;
	}

	public void setSP(String sP) {
		SP = sP;
	}

	public String getDocUrl() {
		return docUrl;
	}

	public void setDocUrl(String docUrl) {
		this.docUrl = docUrl;
	}

	public String getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(String dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}

	public String getAePodLead() {
		return aePodLead;
	}

	public void setAePodLead(String aePodLead) {
		this.aePodLead = aePodLead;
	}

	public String getSpPodLead() {
		return spPodLead;
	}

	public void setSpPodLead(String spPodLead) {
		this.spPodLead = spPodLead;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getAeTeam() {
		return aeTeam;
	}

	public void setAeTeam(String aeTeam) {
		this.aeTeam = aeTeam;
	}

	public String getSpTeam() {
		return spTeam;
	}

	public void setSpTeam(String spTeam) {
		this.spTeam = spTeam;
	}

	@Override
	public String toString() {
		return "CPR_SIHDTO [nameOfProspect=" + nameOfProspect + ", AE=" + AE + ", SP=" + SP + ", docUrl=" + docUrl
				+ ", dateOfExecution=" + dateOfExecution + ", aePodLead=" + aePodLead + ", spPodLead=" + spPodLead
				+ ", market=" + market + ", aeTeam=" + aeTeam + ", spTeam=" + spTeam + "]";
	}
	
	
	public String toStringForMail() {
		return "Account Name = " + nameOfProspect + ", AE = " + AE + ", SP = " + SP + ", Date = " 
	           + dateOfExecution + ", Market = " + market + ", AE Team=" + aeTeam + ", SP Team=" + spTeam;
	}

}
