package com.highradius.pes.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.PesSellersReports;

@Repository
/**
 * Repository class for PesSellerReports pojo. Used for queries and crud operations.
 * @author subhayan.mukherjee
 *
 */
public interface PesSellerReportsRepository extends JpaRepository<PesSellersReports, Long> {

	@Query(value = "SELECT * FROM pes_seller_reports WHERE type = :type AND month =:month AND year =:year AND mail_sent = 0",nativeQuery = true)
	public List<PesSellersReports> findByTypeNMonth(@Param("type") String type, @Param("month") String month,
			@Param("year") String year);

	// Query to get txnPlayExecutions scored in given dates
	@Query(value = "SELECT * FROM pes_seller_reports WHERE start_date >= :startDate AND end_date <= :endDate AND mail_sent = 0", nativeQuery = true)
	public List<PesSellersReports> getReportsBetweenDates(@Param("startDate") LocalDateTime startDate,
			@Param("endDate") LocalDateTime endDate);

}
