package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.MapApiRoles;

@Repository
public interface MapApiRolesRepository extends JpaRepository<MapApiRoles, Long>{

	@Query(value = "SELECT * FROM map_api_roles WHERE api_id = (SELECT id FROM lu_api WHERE api_name=?1 AND status='Active') AND (role_id=?2 OR role_id IS NULL)", nativeQuery = true)
    public MapApiRoles getByNameAndRole(String apiName, Long roleId);
	
}
