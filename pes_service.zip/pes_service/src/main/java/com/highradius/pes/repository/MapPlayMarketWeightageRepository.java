package com.highradius.pes.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.highradius.pes.model.MapPlayMarketWeightage;

/**
 * Repository class for MapPlayMarketWeightage pojo. Used for queries and crud operations.
 * @author subhayan.mukherjee
 *
 */
public interface MapPlayMarketWeightageRepository extends JpaRepository<MapPlayMarketWeightage, Long>, JpaSpecificationExecutor<MapPlayMarketWeightage>{
	
	@Query("Select m from MapPlayMarketWeightage m where m.id=?1")
	public MapPlayMarketWeightage getById(Long id);
	
	@Query("Select m from MapPlayMarketWeightage m where m.playId=?1")
	public List<MapPlayMarketWeightage> getByPlayId(Long id);
	
	@Query("Select m from MapPlayMarketWeightage m where m.marketId=?1")
	public List<MapPlayMarketWeightage> getByMarketId(Long id);
	
	@Query("Select m from MapPlayMarketWeightage m where m.funcRoleId=?1")
	public List<MapPlayMarketWeightage> getByFunctionalRoleId(Long id);
	
	@Query("Select m from MapPlayMarketWeightage m where m.playId=?1 and m.funcRoleId=?2")
	public MapPlayMarketWeightage getByPlayIdNRoleId(Long playId, Long roleId);
	

}
