package com.highradius.pes.dto;

import java.util.List;
import java.util.Map;

import com.highradius.pes.model.TxnPlayExecutions;

/**
 * DTO related to scoring assign and addition.Modeled according to the Json sent from frontend.
 * 
 *
 */
public class ScoringDTO implements Cloneable{

	private String txnPlayExecutionId;

	private String nameOfProspect;
	
	private String activityId;

	private String assignedToPesAgentId;
	
	private String assignedByPesLeadId;
	
	private String reviewedById;

	private String playId;

	private String dateOfExecution;

	private String sfdcStatus;

	private String spId;

	private String aeId;

	private String ftaId;
	
	private String dtaId;
	
	private String dsaId;

	private String podLeadId;
	
	private String pesComments;
	
	private String leaderComments;
	
	private String onSiteSpId;
	
	private String marketId;
	
	private String teamId;
	
	private String pesScore;
	
	private String podLeadScore;
	
	private String pesStatus;
	
	private String docLink;
	
	private String scoringFor;
	
	private String createdBy;
	
	private String createdDate;
	
	private String updatedBy;
	
	private String updatedDate;
	
	private String ratingAccuracy;
	
	private String feedbackAccuracy;
	
	private String overallPesEffectiveness;

	private String noOfDummy;
	
	private Map<String, String> playFields;

	private List<Map<String, String>> playExecFeedback;
	//Added for Dummy Entries
	public String getNoOfDummy() {
		return noOfDummy;
	}

	public void setNoOfDummy(String noOfDummy) {
		this.noOfDummy = noOfDummy;
	}
	
	
	public String getTxnPlayExecutionId() {
		return txnPlayExecutionId;
	}

	public void setTxnPlayExecutionId(String txnPlayExecutionId) {
		this.txnPlayExecutionId = txnPlayExecutionId;
	}

	public String getNameOfProspect() {
		return nameOfProspect;
	}
	
	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public void setNameOfProspect(String nameOfProspect) {
		this.nameOfProspect = nameOfProspect;
	}

	public String getAssignedToPesAgentId() {
		return assignedToPesAgentId;
	}

	public void setAssignedToPesAgentId(String assignedToPesAgentId) {
		this.assignedToPesAgentId = assignedToPesAgentId;
	}

	
	public String getAssignedByPesLeadId() {
		return assignedByPesLeadId;
	}

	public void setAssignedByPesLeadId(String assignedByPesLeadId) {
		this.assignedByPesLeadId = assignedByPesLeadId;
	}
	
	public String getReviewedById() {
		return reviewedById;
	}

	public void setReviewedById(String reviewedById) {
		this.reviewedById = reviewedById;
	}

	public String getPlayId() {
		return playId;
	}

	public String getPesScore() {
		return pesScore;
	}

	public String getScoringFor() {
		return scoringFor;
	}

	public void setScoringFor(String scoringFor) {
		this.scoringFor = scoringFor;
	}

	public void setPesScore(String pesScore) {
		this.pesScore = pesScore;
	}

	public String getPodLeadScore() {
		return podLeadScore;
	}

	public void setPodLeadScore(String podLeadScore) {
		this.podLeadScore = podLeadScore;
	}

	public String getOnSiteSpId() {
		return onSiteSpId;
	}

	public void setOnSiteSpId(String onSiteSpId) {
		this.onSiteSpId = onSiteSpId;
	}

	public String getMarketId() {
		return marketId;
	}

	public void setMarketId(String marketId) {
		this.marketId = marketId;
	}

	public String getTeamId() {
		return teamId;
	}

	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}

	public void setPlayId(String playId) {
		this.playId = playId;
	}

	public String getPodLeadId() {
		return podLeadId;
	}

	public void setPodLeadId(String podLeadId) {
		this.podLeadId = podLeadId;
	}

	public String getDateOfExecution() {
		return dateOfExecution;
	}

	public void setDateOfExecution(String dateOfExecution) {
		this.dateOfExecution = dateOfExecution;
	}

	public String getSfdcStatus() {
		return sfdcStatus;
	}

	public void setSfdcStatus(String sfdcStatus) {
		this.sfdcStatus = sfdcStatus;
	}
	

	public String getSpId() {
		return spId;
	}

	public void setSpId(String spId) {
		this.spId = spId;
	}

	public String getAeId() {
		return aeId;
	}

	public void setAeId(String aeId) {
		this.aeId = aeId;
	}

	public String getFtaId() {
		return ftaId;
	}

	public void setFtaId(String ftaId) {
		this.ftaId = ftaId;
	}

	public Map<String, String> getPlayFields() {
		return playFields;
	}

	public void setPlayFields(Map<String, String> playFields) {
		this.playFields = playFields;
	}

	public String getDocLink() {
		return docLink;
	}

	public void setDocLink(String docLink) {
		this.docLink = docLink;
	}

	public List<Map<String, String>> getPlayExecFeedback() {
		return playExecFeedback;
	}

	public void setPlayExecFeedback(List<Map<String, String>> playExecFeedback) {
		this.playExecFeedback = playExecFeedback;
	}

	
	public String getPesComments() {
		return pesComments;
	}

	public void setPesComments(String pesComments) {
		this.pesComments = pesComments;
	}

	public String getLeaderComments() {
		return leaderComments;
	}

	public void setLeaderComments(String leaderComments) {
		this.leaderComments = leaderComments;
	}
	

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getPesStatus() {
		return pesStatus;
	}

	public void setPesStatus(String pesStatus) {
		this.pesStatus = pesStatus;
	}
	
	public Object clone()throws CloneNotSupportedException{  
		return super.clone();  
		}
	
	public String getDtaId() {
		return dtaId;
	}

	public void setDtaId(String dtaId) {
		this.dtaId = dtaId;
	}

	public String getDsaId() {
		return dsaId;
	}

	public void setDsaId(String dsaId) {
		this.dsaId = dsaId;
	}
	
	public String getRatingAccuracy() {
		return ratingAccuracy;
	}

	public void setRatingAccuracy(String ratingAccuracy) {
		this.ratingAccuracy = ratingAccuracy;
	}

	public String getFeedbackAccuracy() {
		return feedbackAccuracy;
	}

	public void setFeedbackAccuracy(String feedbackAccuracy) {
		this.feedbackAccuracy = feedbackAccuracy;
	}

	public String getOverallPesEffectiveness() {
		return overallPesEffectiveness;
	}

	public void setOverallPesEffectiveness(String overallPesEffectiveness) {
		this.overallPesEffectiveness = overallPesEffectiveness;
	}

	public void copy(ScoringDTO scoringDto) {
		this.setActivityId(scoringDto.getActivityId());
		this.setAeId(scoringDto.getAeId());
		this.setAssignedByPesLeadId(scoringDto.getAssignedByPesLeadId());
		this.setAssignedToPesAgentId(scoringDto.getAssignedToPesAgentId());
		this.setCreatedBy(scoringDto.getCreatedBy());
		this.setCreatedDate(scoringDto.getCreatedDate());
		this.setDateOfExecution(scoringDto.getDateOfExecution());
		this.setDocLink(scoringDto.getDocLink());
		this.setFtaId(scoringDto.getFtaId());
		this.setLeaderComments(scoringDto.getLeaderComments());
		this.setMarketId(scoringDto.getMarketId());
		this.setNameOfProspect(scoringDto.getNameOfProspect());
		this.setOnSiteSpId(scoringDto.getOnSiteSpId());
		this.setPesComments(scoringDto.getPesComments());
		this.setPesScore(scoringDto.getPesScore());
		this.setPesStatus(scoringDto.getPesStatus());
		this.setPlayFields(scoringDto.getPlayFields());
		this.setPlayId(scoringDto.getPlayId());
		this.setPodLeadId(scoringDto.getPodLeadId());
		this.setPodLeadScore(scoringDto.getPodLeadScore());
		this.setReviewedById(scoringDto.getReviewedById());
		this.setScoringFor(scoringDto.getScoringFor());
		this.setSfdcStatus(scoringDto.getSfdcStatus());
		this.setSpId(scoringDto.getSpId());
		this.setTeamId(scoringDto.getTeamId());
		this.setUpdatedBy(scoringDto.getUpdatedBy());
		this.setUpdatedDate(scoringDto.getUpdatedDate());
		this.setRatingAccuracy(scoringDto.getRatingAccuracy());
		this.setFeedbackAccuracy(scoringDto.getFeedbackAccuracy());
		this.setOverallPesEffectiveness(scoringDto.getOverallPesEffectiveness());

	}

	@Override
	public String toString() {
		return "ScoringDTO [txnPlayExecutionId=" + txnPlayExecutionId + ", nameOfProspect=" + nameOfProspect
				+ ", activityId=" + activityId + ", assignedToPesAgentId=" + assignedToPesAgentId
				+ ", assignedByPesLeadId=" + assignedByPesLeadId + ", reviewedById=" + reviewedById + ", playId="
				+ playId + ", dateOfExecution=" + dateOfExecution + ", sfdcStatus=" + sfdcStatus + ", spId=" + spId
				+ ", aeId=" + aeId + ", ftaId=" + ftaId + ", dtaId=" + dtaId + ", dsaId=" + dsaId + ", podLeadId="
				+ podLeadId + ", pesComments=" + pesComments + ", leaderComments=" + leaderComments + ", onSiteSpId="
				+ onSiteSpId + ", marketId=" + marketId + ", teamId=" + teamId + ", pesScore=" + pesScore
				+ ", podLeadScore=" + podLeadScore + ", pesStatus=" + pesStatus + ", docLink=" + docLink
				+ ", scoringFor=" + scoringFor + ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", ratingAccuracy=" + ratingAccuracy
				+ ", feedbackAccuracy=" + feedbackAccuracy + ", overallPesEffectiveness=" + overallPesEffectiveness
				+ ", noOfDummy=" + noOfDummy + ", playFields=" + playFields + ", playExecFeedback=" + playExecFeedback
				+ "]";
	}  

}
