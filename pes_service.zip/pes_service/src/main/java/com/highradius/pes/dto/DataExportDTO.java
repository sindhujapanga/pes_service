package com.highradius.pes.dto;

//New DTO created to capture the export Play data details
import java.util.Arrays;
import java.util.List;

import org.json.simple.JSONObject;

public class DataExportDTO {
	private String startDate;
	private String endDate;
	private List <JSONObject> play;
	private List <JSONObject> pesStatus;
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public List<JSONObject> getPlay() {
		return play;
	}
	public void setPlay(List<JSONObject> play) {
		this.play = play;
	}
	public List<JSONObject> getPesStatus() {
		return pesStatus;
	}
	public void setPesStatus(List<JSONObject> pesStatus) {
		this.pesStatus = pesStatus;
	}
	@Override
	public String toString() {
		return "DataExportDTO [startDate=" + startDate + ", endDate=" + endDate + ", play=" + play + ", pesStatus="
				+ pesStatus + "]";
	}
	
}