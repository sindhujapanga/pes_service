package com.highradius.pes.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.highradius.pes.dto.EmployeeDTO;
import com.highradius.pes.dto.EmployeeSFDTO;
import com.highradius.pes.dto.EmployeeSearchResultDTO;
import com.highradius.pes.dto.OverriddenCommentsDTO;
import com.highradius.pes.dto.Reports_DTO;
import com.highradius.pes.model.Department;
import com.highradius.pes.model.Employee;
import com.highradius.pes.model.Field;
import com.highradius.pes.model.FunctionalRole;
import com.highradius.pes.model.MapFieldOptions;
import com.highradius.pes.model.MapPlayFields;
import com.highradius.pes.model.MapPlayRoles;
import com.highradius.pes.model.Market;
import com.highradius.pes.model.Play;
import com.highradius.pes.model.Reports;
import com.highradius.pes.model.Team;
import com.highradius.pes.model.TxnPlayExecutions;
import com.highradius.pes.repository.DepartmentRepository;
import com.highradius.pes.repository.EmployeeRepository;
import com.highradius.pes.repository.FieldRepository;
import com.highradius.pes.repository.FunctionalRoleRepository;
import com.highradius.pes.repository.MapFieldOptionsRepository;
import com.highradius.pes.repository.MapPlayFieldsRepository;
import com.highradius.pes.repository.MapPlayRolesRepository;
import com.highradius.pes.repository.MarketRepository;
import com.highradius.pes.repository.PlayRepository;
import com.highradius.pes.repository.ReportRepository;
import com.highradius.pes.repository.TeamRepository;
import com.highradius.pes.repository.TxnPlayExecutionsRepository;
import com.highradius.pes.service.PesAdminService;
import com.highradius.pes.service.PesCommonService;
import com.highradius.pes.service.PesSalesForceService;
import com.highradius.pes.util.PesGsheetUtil;
import com.highradius.pes.util.GenericResult;
import com.highradius.pes.util.PesConstants;
import com.highradius.pes.util.PesPropertiesUtil;

@Service
@Transactional
public class PesCommonServiceImpl implements PesCommonService {

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	FunctionalRoleRepository functionalRoleRepository;

	@Autowired
	MarketRepository marketRepository;

	@Autowired
	PlayRepository playRepository;

	@Autowired
	TxnPlayExecutionsRepository txnPlayExecutionsRepository;

	@Autowired
	MapPlayFieldsRepository mapPlayFieldsRepository;

	@Autowired
	FieldRepository fieldRepository;

	@Autowired
	ReportRepository reportRepository;

	@Autowired
	TeamRepository teamRepository;

	@Autowired
	MapFieldOptionsRepository mapFieldOptionsRepository;

	@Autowired
	PesSalesForceService pesSalesForceService;

	@Autowired
	DepartmentRepository departmentRepository;

	@Autowired
	MapPlayRolesRepository mapPlayRolesRepository;

	@Autowired
	PesAdminService adminService;

	@Autowired
	PesGsheetUtil gsheetUtil;

	@Autowired
	PesPropertiesUtil propUtil;

	private static final Logger LOGGER = LogManager.getLogger(PesCommonServiceImpl.class);

	/*
	 * Function that gets the employee list by particular role
	 */
	@Override
	public Map<String, List<Map<String, String>>> getEmployeesLookupData(Long roleId, Long pkId) {
		LOGGER.debug("PesCommonServiceImpl.getEmployeesLookupData() : START");
		Map<String, List<Map<String, String>>> empByRolsMap = new HashMap<>();
		try {
			List<Employee> employees = employeeRepository.findAll();
			List<FunctionalRole> fnRoleList = functionalRoleRepository.findAll();

			List<Map<String, String>> sfIds = new ArrayList<Map<String, String>>();
			Set<String> profileName = new HashSet<String>();
			List<Map<String, String>> emailsIdList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> nameList = new ArrayList<Map<String, String>>();
			Map<Long,String> roleIdMap = new HashMap<>();

			for(FunctionalRole fnRole: fnRoleList) {
				roleIdMap.put(fnRole.getId(), fnRole.getName());
			}
			for (Employee emp : employees) {
				if (!emp.getStatus().equals("Active"))
					continue;

				if (emp.getFnRole() != null) {
					String roleName = emp.getFnRole().getName();
					List<Map<String, String>> newEmpList = null;
					if (empByRolsMap.containsKey(roleName)) {
						newEmpList = empByRolsMap.get(roleName);
						Map<String, String> map = new HashMap<>();
						map.put("id", emp.getId() + "");
						map.put("displayName", emp.getFullName());
						newEmpList.add(map);
					} else {
						newEmpList = new ArrayList<>();
						// None entry with -1
						if (!(roleName.equals("PES Agent") || roleName.equals("PES Supervisor")
								|| roleName.equals("POD Lead"))) {
							Map<String, String> noneMap = new HashMap<>();
							noneMap.put("id", "-1");
							noneMap.put("displayName", " NONE ");// added space to show none as first element in the
																	// list
							newEmpList.add(noneMap);
						}

						Map<String, String> map = new HashMap<>();
						map.put("id", emp.getId() + "");
						map.put("displayName", emp.getFullName());
						newEmpList.add(map);
					}
					empByRolsMap.put(roleName, newEmpList);
				}

				// SFid
				if (emp.getSfUserId() != null) {
					Map<String, String> sfIdMap = new HashMap<>();
					sfIdMap.put("id", emp.getSfUserId());
					sfIdMap.put("displayName", emp.getSfUserId());
					sfIds.add(sfIdMap);
				}

				// profileName
				if (emp.getProfileName() != null) {
					profileName.add(emp.getProfileName());
				}

				// Emails
				if (emp.getEmail() != null) {
					Map<String, String> emailMap = new HashMap<>();
					emailMap.put("id", emp.getEmail());
					emailMap.put("displayName", emp.getEmail());
					emailsIdList.add(emailMap);
				}

				// names
				Map<String, String> nameMap = new HashMap<>();
				nameMap.put("id", emp.getId() + "");
				String alias = (!StringUtils.isEmpty(emp.getAlias())) ? "(" + emp.getAlias() + ")" : "";
				nameMap.put("displayName", emp.getFullName() + " - " + alias);
				nameList.add(nameMap);
			}

			empByRolsMap.put("SF_USERIDS", sfIds);

			// get unique profile names
			List<String> pfNameList = new ArrayList<>(profileName);
			List<Map<String, String>> pfNames = new ArrayList<Map<String, String>>();
			for (String pfName : pfNameList) {
				Map<String, String> pfNameMap = new HashMap<>();
				pfNameMap.put("id", pfName);
				pfNameMap.put("displayName", pfName);
				pfNames.add(pfNameMap);
			}

			empByRolsMap.put("PROFILE_NAMES", pfNames);
			empByRolsMap.put("EMP_EMAILS", emailsIdList);
			empByRolsMap.put("EMP_NAMES", nameList);
			
			//Only for podleads
			if(roleIdMap.get(roleId).equals("POD Lead")) {
				List<Employee> reporteeList = employeeRepository.getReporteeList(pkId);
				List<Map<String,String>> reporteeObjList = new ArrayList<>();
				for(Employee reportee: reporteeList) {
					Map<String,String> mapObj = new HashMap<>();
					mapObj.put("id", reportee.getId().toString());
					mapObj.put("displayName", reportee.getFullName());
					reporteeObjList.add(mapObj);
				}
				empByRolsMap.put("Reportee List", reporteeObjList);
			}

			// sort all the lists by display name
			Set<String> keys = empByRolsMap.keySet();
			for (String key : keys) {
				List<Map<String, String>> newEmpList = empByRolsMap.get(key);
				Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
					public int compare(Map<String, String> m1, Map<String, String> m2) {
						return m1.get("displayName").compareTo(m2.get("displayName"));
					}
				};
				Collections.sort(newEmpList, mapComparator);
				empByRolsMap.put(key, newEmpList);
			}

			LOGGER.debug("getEmployeesLookupData() : END");
			return empByRolsMap;

		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getEmployeesLookupData() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return null;
		}

	}

	/*
	 * Function that gets the employee list by particular role
	 */
	@Override
	public Map<String, List<Map<String, String>>> getCommonLookupData() {
		Map<String, List<Map<String, String>>> lookupMap = new HashMap<>();
		lookupMap.put("MARKETS", getMarketList());
		lookupMap.put("TEAMS", getTeamList());
		lookupMap.put("PLAYS", getPlayList());
		lookupMap.put("PROSPECTS", getProspectList());
		lookupMap.put("FUNCTIONAL_ROLES", adminService.getFunctionalRoles());
		lookupMap.put("SECURITY_ROLES", adminService.getSecurityRoles());
		lookupMap.put("FIELD_TYPES", adminService.getFieldTypes());
		lookupMap.put("PLAY_BOOKS", adminService.getPlaybookList());
		lookupMap.put("DEPARTMENTS", adminService.getDepartmentList());

		return lookupMap;
	}

	/*
	 * Function that gets the employee list by particular role
	 */
	@Override
	public List<Map<String, String>> getEmployeeByRole(String role) {
		LOGGER.debug("PesCommonServiceImpl.getEmployeeByRole() : START: role = " + role);
		List<Map<String, String>> newEmpList = new ArrayList<>();
		try {
			Long roleId = functionalRoleRepository.getByName(role).getId();
			List<Employee> empList = employeeRepository.getByFunctionalRole(roleId);

			for (Employee emp : empList) {
				Map<String, String> map = new HashMap<>();
				map.put("id", emp.getId() + "");
				map.put("displayName", emp.getFullName());
				newEmpList.add(map);
			}
			Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
				public int compare(Map<String, String> m1, Map<String, String> m2) {
					return m1.get("displayName").compareTo(m2.get("displayName"));
				}
			};
			Collections.sort(newEmpList, mapComparator);
			LOGGER.debug("Number of employees with role " + role + " are " + newEmpList.size());
			LOGGER.debug("getEmployeeByRole() : END");
			return newEmpList;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getEmployeeByRole() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/*
	 * Function that gets all the Markets present in db
	 */
	@Override
	public List<Map<String, String>> getMarketList() {
		LOGGER.debug("PesCommonServiceImpl.getMarketList(): START");
		List<Map<String, String>> marketResultList = new ArrayList<>();
		try {
			List<Market> markets = marketRepository.findAll();
			for (Market market : markets) {
				if (market.getName().equals("") || market.getName().equals("-"))
					continue;
				Map<String, String> map = new HashMap<>();
				map.put("id", market.getId() + "");
				map.put("displayName", market.getName());
				marketResultList.add(map);
			}
			Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
				public int compare(Map<String, String> m1, Map<String, String> m2) {
					return m1.get("displayName").compareTo(m2.get("displayName"));
				}
			};
			Collections.sort(marketResultList, mapComparator);
			LOGGER.debug("Total number of markets available : " + marketResultList.size());
			LOGGER.debug("PesCommonServiceImpl.getMarketList(): END");
			return marketResultList;
		} catch (Exception e) {
			LOGGER.error("PesComonServiceImpl.geMarketList() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return null;
		}

	}
	
	@Override
	public List<Map<String, String>> getEmployeeRoleMap() {
		LOGGER.debug("PesCommonServiceImpl.getEmployeeRoleMap(): START");
		List<Map<String, String>> employeeResultList = new ArrayList<>();
		try {
			List<Employee> employees = employeeRepository.findAll();
			for (Employee employee : employees) {
				Map<String, String> map = new HashMap<>();
				map.put("id", employee.getId() + "");
				map.put("roleId", employee.getFnRole().getId().toString());
				employeeResultList.add(map);
			}
			LOGGER.debug("Total number of markets available : " + employeeResultList.size());
			LOGGER.debug("PesCommonServiceImpl.getEmployeeRoleMap(): END");
			return employeeResultList;
		} catch (Exception e) {
			LOGGER.error("PesComonServiceImpl.getEmployeeRoleMap() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return null;
		}

	}

	/*
	 * Function gets all the plays present in db
	 */
	@Override
	public List<Map<String, String>> getPlayList() {
		LOGGER.debug("PesCommonServiceImpl.getPlayList(): START");
		List<Map<String, String>> playResultList = new ArrayList<>();
		try {
			List<Play> plays = playRepository.findAll();
			for (Play play : plays) {
				Map<String, String> map = new HashMap<>();
				map.put("id", play.getId() + "");
				map.put("displayName", play.getName());
				playResultList.add(map);
			}
			Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
				public int compare(Map<String, String> m1, Map<String, String> m2) {
					return m1.get("displayName").compareTo(m2.get("displayName"));
				}
			};
			Collections.sort(playResultList, mapComparator);
			LOGGER.debug("Total number of plays available : " + playResultList.size());
			LOGGER.debug("PesCommonServiceImpl.getPlayList(): END");
			return playResultList;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getPlayList() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/*
	 * Function gets the list of distinct prospects from txn table
	 */
	@Override
	public List<Map<String, String>> getProspectList() {
		LOGGER.debug("PesCommonServiceImpl.getProspectList() : START");
		List<Map<String, String>> prospectList = new ArrayList<>();
		try {
			List<String> prospects = txnPlayExecutionsRepository.getDistinctNameOfProspects();
			for (String prospect : prospects) {
				Map<String, String> map = new HashMap<>();
				map.put("id", prospect);
				map.put("displayName", prospect);
				prospectList.add(map);
			}
			Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
				public int compare(Map<String, String> m1, Map<String, String> m2) {
					return m1.get("displayName").compareTo(m2.get("displayName"));
				}
			};
			Collections.sort(prospectList, mapComparator);
			LOGGER.debug("Total number of prospects found : " + prospectList.size());
			LOGGER.debug("PesCommonServiceImpl.getProspectList() : END");
			return prospectList;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getProspectList() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/*
	 * Function to get the team list from db
	 */
	@Override
	public List<Map<String, String>> getTeamList() {
		LOGGER.debug("PesCommonServiceImpl.getTeamList() : START");
		List<Map<String, String>> teamList = new ArrayList<>();
		try {
			List<Team> teams = teamRepository.findAll();
			for (Team team : teams) {
				if (team.getName().equals("") || team.getName().equals("-"))
					continue;
				Map<String, String> map = new HashMap<>();
				map.put("id", team.getId() + "");
				map.put("displayName", team.getName());
				teamList.add(map);
			}
			Comparator<Map<String, String>> mapComparator = new Comparator<Map<String, String>>() {
				public int compare(Map<String, String> m1, Map<String, String> m2) {
					return m1.get("displayName").compareTo(m2.get("displayName"));
				}
			};
			Collections.sort(teamList, mapComparator);
			LOGGER.debug("Total number of teams found : " + teamList.size());
			LOGGER.debug("PesCommonServiceImpl.getTeamList() : END");
			return teamList;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getTeamList() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	/*
	 * Function to get user login data
	 */
	@Override
	public Employee getLoginUserData(String email) {
		LOGGER.debug("PesCommonServiceImpl.getUserLoginData(): START");
		try {
			Employee user = employeeRepository.findByEmailId(email);
			LOGGER.debug(user.toString());
			LOGGER.debug("PesCommonServiceImpl.getUserLoginData(): END");
			return user;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getUserLoginData(): ERROR : " + e.getMessage());
			return null;
		}
	}

	/*
	 * Function to get play fields map data
	 */
	@Override
	public Map<Long, List<Long>> getPlayFieldsMapData() {
		LOGGER.debug("PesCommonServiceImpl.getPlayFieldsMapData(): START");
		try {
			Map<Long, List<Long>> playFieldsMap = new HashMap<>();
			List<MapPlayFields> mapPlayFieldsList = mapPlayFieldsRepository.findAll();
			for (MapPlayFields mapField : mapPlayFieldsList) {
				Long playId = mapField.getPlayId();
				Long fldId = mapField.getFieldId();
				List<Long> fldIds = null;

				if (playFieldsMap.containsKey(playId)) {
					fldIds = playFieldsMap.get(playId);
				} else {
					fldIds = new ArrayList<Long>();
				}
				fldIds.add(fldId);
				playFieldsMap.put(playId, fldIds);
			}
			LOGGER.debug("PesCommonServiceImpl.getPlayFieldsMapData(): END");
			return playFieldsMap;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getPlayFieldsMapData(): ERROR : " + e.getMessage());
			return null;
		}
	}

	// function to get the fields list for search and view
	@Override
	public Map<Long, Field> getFieldsList() {
		LOGGER.debug("PesCommonServiceImpl.getFieldsList(): START");
		try {
			Map<Long, Field> map = new HashMap<>();
			List<Field> fields = fieldRepository.findAll();
			for (Field f : fields) {
				if (!StringUtils.isEmpty(f.getViewableBy()))
					f.setViewableByArr(f.getViewableBy().split(","));
				if (!StringUtils.isEmpty(f.getEditableBy()))
					f.setEditableByArr(f.getEditableBy().split(","));
				List<MapFieldOptions> options = mapFieldOptionsRepository.getByFieldId(f.getId());
				f.setOptions(options);
				map.put(f.getId(), f);

			}
			LOGGER.debug("PesCommonServiceImpl.getFieldsList(): END");
			return map;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.getFieldsList(): ERROR : " + e.getMessage());
			return null;
		}
	}

	/*
	 * Function to get the Reports lookup data
	 */
	@Override
	public List<Reports_DTO> getReportsList() {
		LOGGER.debug("PesCommonServiceImpl.getReportsList(): START");
		List<Reports_DTO> reportResult = new ArrayList<>();
		try {
			List<Reports> reports = reportRepository.findAll();
			for (Reports report : reports) {
				Reports_DTO reportDTO = new Reports_DTO();
				List<String> category = new ArrayList<>();
				category.add(report.getCategory());
				category.add(report.getName());
				reportDTO.setId(report.getId());
				reportDTO.setName(report.getName());
				reportDTO.setCategory(category);
				reportDTO.setDescription(report.getDescription());
				reportDTO.setUrl(report.getURL());
				reportResult.add(reportDTO);
			}

			LOGGER.debug("PesCommonServiceImpl.getReportsList(): END");
			return reportResult;
		} catch (Exception e) {
			LOGGER.error("PesComonServiceImpl.getReportList() : " + e + " : " + e.getMessage());
			e.printStackTrace();
			return Collections.emptyList();
		}

	}

	/*
	 * Function to add reports
	 */
	@Override
	public GenericResult addReport(Reports_DTO reportDto) {
		LOGGER.info("PesCommonServiceImpl.addReport(): START:");
		try {
			Reports report = new Reports();
			report.setName(reportDto.getName());
			report.setDescription(reportDto.getDescription());
			report.setURL(reportDto.getUrl());
			report.setCategory(reportDto.getCategory().get(0));
			GenericResult result = new GenericResult();
			reportRepository.save(report);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesCommonServiceImpl.addReport(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.addReport: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add report");
			return result;
		}
	}

	/**
	 * Adds overriden comments to records
	 */
	@Override
	public boolean addOverriddenComments(OverriddenCommentsDTO overrideCommentDto) {
		try {
			LOGGER.info("PesCommonServiceImpl.addOverridenComments(): START:");
			Integer validOverride = overrideCommentDto.getValid_override();
			String rationale = overrideCommentDto.getRationale();
			String manager_comments = overrideCommentDto.getManager_comments();
			String ids[] = overrideCommentDto.getIds();
			String reviewerId = overrideCommentDto.getLoginUserId();
			Employee reviewer = employeeRepository.getById(Long.parseLong(reviewerId));
			Calendar cal = Calendar.getInstance();
			List<TxnPlayExecutions> updateList = new ArrayList<>();
			java.util.Date updatedDate = cal.getTime();
			for (String id : ids) {
				if (!StringUtils.isEmpty(id)) {
					TxnPlayExecutions txn = txnPlayExecutionsRepository.getById(Long.parseLong(id));
					txn.setValid_override(validOverride);
					txn.setRationale(rationale);
					txn.setManager_comments(manager_comments);
					txn.setUpdatedDate(updatedDate);
					txn.setUpdatedBy(reviewer.getFullName());
					updateList.add(txn);
				}
			}
			txnPlayExecutionsRepository.saveAll(updateList);
			LOGGER.info("PesCommonServiceImpl.addOverriddenComments(): END");
			return true;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.addOverriddenComments: " + e.getMessage());
			e.printStackTrace();
			return false;

		}
	}

	/*
	 * Function to get the mapPlayRoles
	 * 
	 */
	public Map<Long, List<Long>> getMapPlayRoles() {
		List<MapPlayRoles> mapPlayRoles = mapPlayRolesRepository.findAll();
		Map<Long, List<Long>> map = new HashMap<>();
		for (MapPlayRoles mapPlayRole : mapPlayRoles) {
			Long playId = mapPlayRole.getPlayId();
			Long roleId = mapPlayRole.getRoleId();
			if (map.containsKey(playId)) {
				List<Long> rolesArr = map.get(playId);
				rolesArr.add(roleId);
			} else {
				List<Long> rolesArr = new ArrayList<>();
				rolesArr.add(roleId);
				map.put(playId, rolesArr);
			}
		}
		return map;
	}

	@Override
	public String getServerProperties(String propName) {
		String value = propUtil.getPropertyByName(propName).getPropertyValue();
		return value;

	}

	@Override
	public boolean clearServerProperties(String propName) {
		propUtil.clearPropertyByName(propName);
		return true;
	}

	/**
	 * Gets employee data from Salesforce(Currently Descoped)
	 */
	//Commenting employee gsheet data fetch code as per PES team use case as they are now adding data manually through system
//	public void getEmployeeSfData(String usermail) throws Exception {
//		LOGGER.error("PesCommonServiceImpl.getEmployeeSfData(): START");
//		List<EmployeeSFDTO> records = gsheetUtil.getEmployeeData();
//
//		List<Employee> empToSave = new ArrayList<>();
//		List<Employee> podLeadToSave = new ArrayList<>();
//		List<FunctionalRole> fnRoles = functionalRoleRepository.findAll();
//		List<Market> markets = marketRepository.findAll();
//		List<Team> teams = teamRepository.findAll();
//		List<Department> departments = departmentRepository.findAll();
//		Map<String, FunctionalRole> fnRoleMap = new HashMap<>();
//		Map<String, Market> marketsMap = new HashMap<>();
//		Map<String, Team> teamsMap = new HashMap<>();
//		Map<String, Department> departmentsMap = new HashMap<>();
//		Map<String, Employee> podLeadMap = new HashMap<>();
//		for (Department department : departments) {
//			departmentsMap.put(department.getName(), department);
//		}
//		for (Team team : teams) {
//			teamsMap.put(team.getName(), team);
//		}
//		for (Market market : markets) {
//			marketsMap.put(market.getName(), market);
//		}
//		for (FunctionalRole fnRole : fnRoles) {
//			fnRoleMap.put(fnRole.getName(), fnRole);
//		}
//		List<Employee> podLeads = employeeRepository.getByFunctionalRole(fnRoleMap.get("POD Lead").getId());
//		for (Employee podLead : podLeads) {
//			podLeadMap.put(podLead.getSf18CharId(), podLead);
//		}
//		List<Employee> allEmp = employeeRepository.getActiveAndInactiveEmployees();
//		Map<String, Employee> empMap = new HashMap<>();
//		for (Employee emp : allEmp) {
//			empMap.put(emp.getSf18CharId(), emp);
//		}
//		// for pod lead save
//		for (EmployeeSFDTO empRec : records) {
//			try {
//				String sf18CharId = empRec.getSf18CharacterID();
//				String status = empRec.getActive().equalsIgnoreCase("true") ? PesConstants.Active
//						: PesConstants.Inactive;
//				Employee existEmp = podLeadMap.get(sf18CharId);
//				Employee emp = new Employee();
//				if (existEmp != null) {
//					if (!existEmp.getStatus().equals(PesConstants.Active)) {
//						existEmp.setStatus(status);
//						empToSave.add(existEmp);
//					}
//					continue;
//				}
//				if (!status.equals(PesConstants.Active))
//					continue;
//				String alias = empRec.getAlias();
//				String email = empRec.getEmail();
//				String firstName = empRec.getFirstName();
//				String lastName = empRec.getLastName();
//				String fullName = empRec.getFullName();
//				String market = empRec.getMarket();
//				String team = empRec.getTeam();
//				String department = empRec.getDepartment();
//				String userId = empRec.getUserId();
//				String sfRole = empRec.getRole();
//				String profileName = empRec.getProfile();
//				Long marketId = null;
//				Long departmentId = null;
//				Long teamId = null;
//				FunctionalRole role = null;
//				// checking for pod lead
//				if (sfRole.indexOf("Lead") != -1) {
//					role = fnRoleMap.get("POD Lead");
//					podLeadMap.put(sf18CharId, emp);
//				}
//				if (sfRole.indexOf("Lead") == -1)
//					continue;
//				// adding market, team, department
//				if (marketsMap.get(market) != null)
//					marketId = marketsMap.get(market).getId();
//				else {
//					Market newMarket = new Market();
//					newMarket.setName(market);
//					marketRepository.save(newMarket);
//					marketsMap.put(market, newMarket);
//					marketId = newMarket.getId();
//				}
//				if (teamsMap.get(team) != null)
//					teamId = teamsMap.get(team).getId();
//				else {
//					Team newTeam = new Team();
//					newTeam.setName(team);
//					teamRepository.save(newTeam);
//					teamsMap.put(team, newTeam);
//					teamId = newTeam.getId();
//				}
//				if (departmentsMap.get(department) != null)
//					departmentId = departmentsMap.get(department).getId();
//				else {
//					Department dept = new Department();
//					dept.setName(department);
//					departmentRepository.save(dept);
//					departmentsMap.put(department, dept);
//					departmentId = dept.getId();
//				}
//				emp.setAlias(alias);
//				emp.setEmail(email);
//				emp.setFirstName(firstName);
//				emp.setLastName(lastName);
//				emp.setFullName(fullName);
//				emp.setSfUserId(userId);
//				emp.setSf18CharId(sf18CharId);
//				emp.setProfileName(profileName);
//				emp.setMarketId(marketId);
//				emp.setTeamId(teamId);
//				emp.setDepartmentId(departmentId);
//				if (role != null)
//					emp.setFnRole(role);
//				emp.setStatus("Active");
//				podLeadToSave.add(emp);
//				LOGGER.info(
//						"PodLead with employee name " + fullName + " and SF18CharacterId " + sf18CharId + " created.");
//			} catch (Exception e) {
//				LOGGER.info("PesCommonServiceImpl.getEmployeeSfData(): ERROR : " + e.getMessage());
//				e.printStackTrace();
//			}
//		}
//		employeeRepository.saveAll(podLeadToSave);
//		for (EmployeeSFDTO empRec : records) {
//			try {
//				String sf18CharId = empRec.getSf18CharacterID();
//				String active = empRec.getActive().equalsIgnoreCase("true") ? PesConstants.Active
//						: PesConstants.Inactive;
//				Employee existEmp = empMap.get(sf18CharId);
//				Employee emp = new Employee();
//				if (existEmp != null) {
//					if (!existEmp.getStatus().equals(PesConstants.Active)) {
//						existEmp.setStatus(active);
//						empToSave.add(existEmp);
//					}
//					continue;
//				}
//				if (!active.equals(PesConstants.Active))
//					continue;
//				String alias = empRec.getAlias();
//				String email = empRec.getEmail();
//				String firstName = empRec.getFirstName();
//				String lastName = empRec.getLastName();
//				String fullName = empRec.getFullName();
//				String market = empRec.getMarket();
//				String team = empRec.getTeam();
//				String department = empRec.getDepartment();
//				String userId = empRec.getUserId();
//				String sfRole = empRec.getRole();
//				String profileName = empRec.getProfile();
//				String podLead18CharId = empRec.getPodLead18CharId();
//				Long marketId = null;
//				Long departmentId = null;
//				Long teamId = null;
//				Employee podLead = null;
//				FunctionalRole role = null;
//				// checking for pod lead
//				if (sfRole.indexOf("Lead") != -1) {
//					continue;
//				} else {
//					if (empRec.getRole().indexOf("On Site Sp") != -1 || empRec.getRole().indexOf("On Site SP") != -1)
//						role = fnRoleMap.get("Onsite SP");
//					else {
//						if (sfRole.indexOf(' ') == -1)
//							continue;
//						String roleName = sfRole.substring(0, sfRole.indexOf(' '));
//						switch (roleName) {
//						case "AE":
//							role = fnRoleMap.get(roleName);
//							break;
//
//						case "SP":
//							role = fnRoleMap.get(roleName);
//							break;
//
//						default:
//							continue;
//						}
//					}
//					// adding market, team, department
//					if (marketsMap.get(market) != null)
//						marketId = marketsMap.get(market).getId();
//					else if (!market.equals("-")) {
//						Market newMarket = new Market();
//						newMarket.setName(market);
//						marketRepository.save(newMarket);
//						marketsMap.put(market, newMarket);
//						marketId = newMarket.getId();
//					}
//					if (teamsMap.get(team) != null)
//						teamId = teamsMap.get(team).getId();
//					else if (!team.equals("-")) {
//						Team newTeam = new Team();
//						newTeam.setName(team);
//						teamRepository.save(newTeam);
//						teamsMap.put(team, newTeam);
//						teamId = newTeam.getId();
//					}
//					if (departmentsMap.get(department) != null)
//						departmentId = departmentsMap.get(department).getId();
//					else if (!department.equals("-")) {
//						Department dept = new Department();
//						dept.setName(department);
//						departmentRepository.save(dept);
//						departmentsMap.put(department, dept);
//						departmentId = dept.getId();
//					}
//
//					podLead = podLeadMap.get(podLead18CharId);
//				}
//				if (podLead != null)
//					emp.setPodLeadId(podLead.getId());
//				emp.setAlias(alias);
//				emp.setEmail(email);
//				emp.setFirstName(firstName);
//				emp.setLastName(lastName);
//				emp.setFullName(fullName);
//				emp.setSfUserId(userId);
//				emp.setSf18CharId(sf18CharId);
//				emp.setProfileName(profileName);
//				emp.setMarketId(marketId);
//				emp.setTeamId(teamId);
//				emp.setDepartmentId(departmentId);
//				if (role != null)
//					emp.setFnRole(role);
//				emp.setStatus("Active");
//				empToSave.add(emp);
//				LOGGER.info(
//						"Record with employee name " + fullName + " and SF18CharacterId " + sf18CharId + " created.");
//			} catch (Exception e) {
//				LOGGER.info("PesCommonServiceImpl.getEmployeeSfData(): ERROR : " + e.getMessage());
//				e.printStackTrace();
//			}
//		}
//		employeeRepository.saveAll(empToSave);
//		LOGGER.info("PesCommonServiceImpl..getEmployeeSfData(): END");
//	}

	/*
	 * Function to add reports
	 */
	@Override
	public GenericResult editReport(Reports_DTO reportDto) {
		LOGGER.info("PesCommonServiceImpl.editReport(): START:");
		try {
			Reports report = reportRepository.findByCategoryAndName(reportDto.getCategory().get(0),
					reportDto.getName());
			report.setDescription(reportDto.getDescription());
			report.setURL(reportDto.getUrl());
			GenericResult result = new GenericResult();
			reportRepository.save(report);
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesCommonServiceImpl.editReport(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.addReport: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add report");
			return result;
		}
	}

	@Override
	public GenericResult deleteReport(Reports_DTO reportDto) {
		LOGGER.info("PesCommonServiceImpl.deleteReport(): START:");
		try {
			Reports report = reportRepository.findByCategoryAndName(reportDto.getCategory().get(0),
					reportDto.getName());
			reportRepository.deleteById(report.getId());
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.TRUE);
			result.setStatus(PesConstants.SUCCESS);
			result.setMessage("Operation Successfull");
			LOGGER.info("PesCommonServiceImpl.editReport(): END");
			return result;
		} catch (Exception e) {
			LOGGER.error("PesCommonServiceImpl.addReport: " + e.getMessage());
			e.printStackTrace();
			GenericResult result = new GenericResult();
			result.setSuccess(PesConstants.FALSE);
			result.setStatus(PesConstants.FAIL);
			result.setMessage("Unable to add report");
			return result;
		}
	}

}
