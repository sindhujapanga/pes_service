package com.highradius.pes.dto;

public class EmployeeDTO {
	private String id;
	private String sf18CharId;
	private String sfUserId ;
	private String empId ;
	private String alias ;
	private String firstName ;
	private String lastName ;
	private String fnRoleId ;
	private String securityRoleId ;
	private String podLeadId ;
	private String teamId ;
	private String marketId ;
	private String profileName ;
	private String email ;
	private String createdBy;
	private String updatedBy;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSf18CharId() {
		return sf18CharId;
	}
	public void setSf18CharId(String sf18CharId) {
		this.sf18CharId = sf18CharId;
	}
	public String getSfUserId() {
		return sfUserId;
	}
	public void setSfUserId(String sfUserId) {
		this.sfUserId = sfUserId;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFnRoleId() {
		return fnRoleId;
	}
	public void setFnRoleId(String fnRoleId) {
		this.fnRoleId = fnRoleId;
	}
	public String getSecurityRoleId() {
		return securityRoleId;
	}
	public void setSecurityRoleId(String securityRoleId) {
		this.securityRoleId = securityRoleId;
	}
	public String getPodLeadId() {
		return podLeadId;
	}
	public void setPodLeadId(String podLeadId) {
		this.podLeadId = podLeadId;
	}
	public String getTeamId() {
		return teamId;
	}
	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}
	public String getMarketId() {
		return marketId;
	}
	public void setMarketId(String marketId) {
		this.marketId = marketId;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Override
	public String toString() {
		return "EmployeeDTO [id=" + id + ", sf18CharId=" + sf18CharId + ", sfUserId=" + sfUserId + ", empId=" + empId
				+ ", alias=" + alias + ", firstName=" + firstName + ", lastName=" + lastName + ", fnRoleId=" + fnRoleId
				+ ", securityRoleId=" + securityRoleId + ", podLeadId=" + podLeadId + ", teamId=" + teamId
				+ ", marketId=" + marketId + ", profileName=" + profileName + ", email=" + email + "]";
	}
	
}
