package com.highradius.pes.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.Play;

/**
 * Repository class for Play pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface PlayRepository extends JpaRepository<Play, Long>, JpaSpecificationExecutor<Play> {
	
	//Query to get play by id
	@Query("Select p from Play p where p.id=?1")
	public Play getById(Long id);
	
	//Query to get play by name
	@Query("Select p from Play p where p.name=?1")
	public Play findByName(String name);
	
	@Query("Select p from Play p where p.name=?1 and p.department.id=?2 and p.playbook.id=?3")
	public Play findByNameDepartmentPlaybook(String name, Long deptId, Long playbookId);
	
	@Query("Select p.id from Play p where p.name in ?1")
	public List<Long> getIdsByNames(String[] playNames);
	
	@Query("Select p.id from Play p where p.name=?1")
	public  Long getIdByName(String name);
	
}
