package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.MapMarketTeam;

/**
 * Repository class for MarketPodMap pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface MapMarketTeamRepository extends JpaRepository<MapMarketTeam, Long> {

    //Query to get Market Pod mapping with id
	@Query("Select m from MapMarketTeam m where m.id=?1")
	public MapMarketTeam getById(Long id);
	
	//Query to get Market Pod mapping with market id
	@Query("Select m from MapMarketTeam m where m.marketId=?1")
	public MapMarketTeam findByMarketId(Long id);
	
	//Query to get Market Pod mapping with podLeadId
	@Query("Select m from MapMarketTeam m where m.podLeadId=?1")
	public MapMarketTeam findByPodLeadId(Long id);
}
