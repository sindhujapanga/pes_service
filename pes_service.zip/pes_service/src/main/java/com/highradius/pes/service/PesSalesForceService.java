package com.highradius.pes.service;

import java.util.List;

import com.highradius.pes.dto.ChampionsnZZTopDTO;
import com.highradius.pes.dto.Demo_Play_DTO;
import com.highradius.pes.dto.DiscoveryCallDTO;
import com.highradius.pes.dto.EmployeeSFDTO;
import com.highradius.pes.dto.OTCWebResearchDTO;
import com.highradius.pes.dto.STRAP_DTO;
import com.highradius.pes.dto.SalesPipelineOTCDTO;

public interface PesSalesForceService {
	
	public String getSFAPIAccessToken(String token, String clientID, String clientSecret);
	
	public List<DiscoveryCallDTO> getEnterpriseEMEADCCReport(String startDate, String endDate);
	
	public List<DiscoveryCallDTO> getEnterpriseNADCCReport(String startDate, String endDate);
	
	public List<DiscoveryCallDTO> getMidMarketReport(String startDate, String endDate);
	
	public List<DiscoveryCallDTO> getTreasuryReport();
	
	public List<OTCWebResearchDTO> getOTCWebResearchReport(String startDate, String endDate);
	
	public List<SalesPipelineOTCDTO> getOTCSalesPipelineReport(String startDate, String endDate);
	
	public List<EmployeeSFDTO> getEmployeeSFReport();
	
	public List<SalesPipelineOTCDTO> getOTCSalesPipelineNAExpansionReport(String start, String end);
	
	public List<ChampionsnZZTopDTO> getChampionsnZZTopReport();
	
	public List<STRAP_DTO> getSTRAPReport(String start, String end);
	
	//Changed by VC
	public List<STRAP_DTO> getSTRAPReportForExpansion(String start, String end);

	public List<Demo_Play_DTO> getDEMOReport(String start, String end);
}
