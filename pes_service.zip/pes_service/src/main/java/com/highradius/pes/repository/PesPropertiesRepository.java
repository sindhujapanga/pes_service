package com.highradius.pes.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.highradius.pes.model.PesProperties;

/**
 * Repository class for PesProperties pojo. Used for queries and crud operations.
 * 
 *
 */
@Repository
public interface PesPropertiesRepository extends JpaRepository<PesProperties, Long> {
      
	//Query to get properties by name
	@Query("select p from PesProperties p where p.propertyName=?1")
	PesProperties getPropertyByName(String propertyName);
}
