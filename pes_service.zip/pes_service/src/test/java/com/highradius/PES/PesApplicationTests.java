package com.highradius.PES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PesApplicationTests {

	@Test
	void contextLoads() {
	}

}
